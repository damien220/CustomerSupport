from .factory import (
    get_database,
    list_available_databases,
    is_database_available,
    list_installed_databases,
)
from .base import AbstractDatabase
from .exceptions import (
    DatabaseError,
    ConnectionError,
    OperationError,
    TransactionError,
    QueryError,
    ConfigurationError
)

__version__ = "0.1.0"

__all__ = [
    # Factory functions
    "get_database",
    "list_available_databases",
    "is_database_available",
    "list_installed_databases",
    # Base class
    "AbstractDatabase",
    # Exceptions
    "DatabaseError",
    "ConnectionError",
    "OperationError",
    "TransactionError",
    "QueryError",
    "ConfigurationError",
]
