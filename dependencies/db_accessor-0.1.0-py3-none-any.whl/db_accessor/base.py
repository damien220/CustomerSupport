from abc import ABC, abstractmethod

class AbstractDatabase(ABC):
    """
    An abstract class to define the interface for a database connection.
    It is designed to be used as a context manager to ensure that
    connections are properly managed.
    """
    @abstractmethod
    def connect(self, connection_details: dict):
        """Establishes a connection to the database."""
        pass

    @abstractmethod
    def disconnect(self):
        """Closes the database connection."""
        pass

    def __enter__(self):
        """Context manager entry point."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point, ensures disconnection."""
        self.disconnect()

    # --- CRUD Operations ---

    @abstractmethod
    def create(self, collection: str, data: dict):
        """Inserts a new record into the specified collection/table."""
        pass

    @abstractmethod
    def read(self, collection: str, query: dict):
        """Reads one or more records from the specified collection/table."""
        pass

    @abstractmethod
    def update(self, collection: str, query: dict, data: dict):
        """Updates records in the specified collection/table based on a query."""
        pass

    @abstractmethod
    def delete(self, collection: str, query: dict):
        """Deletes records from the specified collection/table based on a query."""
        pass

    # --- Transaction Management ---

    @abstractmethod
    def begin_transaction(self):
        """
        Starts a new transaction.

        Transaction support varies by database:
        - **SQLite, PostgreSQL, MySQL**: Full ACID transaction support
        - **MongoDB**: Requires replica set or sharded cluster (mongos)
        - **Redis**: Not supported; raises TransactionError

        Raises:
            TransactionError: If transaction cannot be started or is not supported

        Note:
            Always use transactions within try-except blocks and ensure
            you call either commit() or rollback() after begin_transaction().
        """
        pass

    @abstractmethod
    def commit(self):
        """
        Commits the current transaction.

        Persists all changes made during the transaction to the database.

        Raises:
            TransactionError: If commit fails or no active transaction exists

        Note:
            Should only be called after begin_transaction() and when
            all operations in the transaction have succeeded.
        """
        pass

    @abstractmethod
    def rollback(self):
        """
        Rolls back the current transaction.

        Discards all changes made during the transaction.

        Raises:
            TransactionError: If rollback fails or no active transaction exists

        Note:
            Should be called in exception handlers to undo changes when
            a transaction fails partway through.
        """
        pass

    # --- Optional Advanced Features ---
    # These methods have default implementations but can be overridden

    def execute_custom_query(self, query_details):
        """
        Executes a custom database-specific query.

        This method allows for advanced database-specific operations that don't
        fit into the standard CRUD pattern. The format of query_details varies
        by database implementation.

        Args:
            query_details: Database-specific query details. Format varies:
                - For relational databases (SQLite, PostgreSQL, MySQL):
                  - query: str - SQL query string
                  - params: tuple - Optional query parameters
                - For MongoDB:
                  - collection: str - Collection name
                  - query: dict - Query or aggregation pipeline
                  - type: str - "find" or "aggregate"
                - For Redis:
                  - command: str - Redis command name
                  - args: list - Command arguments
                  OR
                  - pipeline: list - List of commands for atomic execution

        Returns:
            Query results. Format varies by database and query type.

        Raises:
            NotImplementedError: If the implementation doesn't support custom queries
            QueryError: If the query execution fails

        Note:
            Default implementation raises NotImplementedError. Databases that support
            custom queries should override this method.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement execute_custom_query(). "
            "This database implementation does not support custom query execution."
        )

    def get_connection_status(self):
        """
        Returns the current connection status.

        Returns:
            str: Connection status, typically one of:
                - "connected": Active connection established
                - "disconnected": No active connection
                - "error": Connection error occurred
                - "unknown": Status cannot be determined

        Note:
            Default implementation returns "unknown". Implementations should
            override this to provide accurate status information.
        """
        return "unknown"

    def clear_cache(self, identifier=None):
        """
        Clears any internal caches maintained by the database implementation.

        Some implementations maintain in-memory caches for query results or
        connection state. This method provides a way to invalidate those caches.

        Args:
            identifier: Optional identifier for selective cache clearing.
                For relational databases: table name
                For non-relational databases: collection name
                If None, clears all caches.

        Returns:
            None

        Note:
            Default implementation is a no-op. Implementations with caching
            should override this method.
        """
        pass  # Default: no-op for implementations without caching
