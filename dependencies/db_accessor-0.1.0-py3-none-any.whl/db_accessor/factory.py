from typing import Type, Dict, List, Tuple, Optional
import importlib
from .base import AbstractDatabase
from .exceptions import ConfigurationError

# Registry maps database type name to (module_path, class_name)
_DATABASE_REGISTRY: Dict[str, Tuple[str, str]] = {
    "sqlite": ("db_accessor.relational.sqlite.implementation", "SqliteDatabase"),
    "postgres": ("db_accessor.relational.postgres.implementation", "PostgresDatabase"),
    "mysql": ("db_accessor.relational.mysql.implementation", "MySQLDatabase"),
    "mongodb": ("db_accessor.non_relational.mongodb.implementation", "MongoDBDatabase"),
    "redis": ("db_accessor.non_relational.redis.implementation", "RedisDatabase"),
}

# Cache for loaded classes
_loaded_classes: Dict[str, Type[AbstractDatabase]] = {}


def _load_database_class(db_type: str) -> Type[AbstractDatabase]:
    """
    Lazily load and cache a database implementation class.

    Args:
        db_type: The type of database to load.

    Returns:
        The database implementation class.

    Raises:
        ConfigurationError: If the required driver is not installed.
    """
    if db_type in _loaded_classes:
        return _loaded_classes[db_type]

    if db_type not in _DATABASE_REGISTRY:
        raise ValueError(f"Database type '{db_type}' is not supported. "
                        f"Available types: {list(_DATABASE_REGISTRY.keys())}")

    module_path, class_name = _DATABASE_REGISTRY[db_type]

    try:
        module = importlib.import_module(module_path)
        db_class = getattr(module, class_name)
        _loaded_classes[db_type] = db_class
        return db_class
    except ImportError as e:
        # Provide helpful error message about missing driver
        driver_info = {
            "sqlite": "sqlite3 (built-in)",
            "postgres": "psycopg2-binary (pip install db-accessor[postgres])",
            "mysql": "mysql-connector-python (pip install db-accessor[mysql])",
            "mongodb": "pymongo (pip install db-accessor[mongodb])",
            "redis": "redis (pip install db-accessor[redis])",
        }
        driver = driver_info.get(db_type, "unknown")
        raise ConfigurationError(
            f"Cannot load '{db_type}' database. Required driver not installed: {driver}. "
            f"Original error: {e}"
        ) from e


def get_database(db_type: str) -> AbstractDatabase:
    """
    Factory function to get a database instance.

    Args:
        db_type: The type of database to get (e.g., "sqlite", "postgres", "mysql",
                "mongodb", "redis").

    Returns:
        An instance of the requested database class.

    Raises:
        ValueError: If the requested database type is not supported.
        ConfigurationError: If the required database driver is not installed.

    Examples:
        >>> db = get_database("sqlite")
        >>> with db.connect({"file": ":memory:"}):
        ...     db.create("users", {"name": "Alice"})

        >>> # For databases requiring external drivers
        >>> db = get_database("postgres")  # Requires: pip install db-accessor[postgres]
    """
    db_class = _load_database_class(db_type)
    return db_class()


def list_available_databases() -> List[str]:
    """
    Returns a list of all registered database types.

    Note: This returns all database types known to the package, but some may
    require additional drivers to be installed. Use is_database_available() to
    check if a specific database can actually be used.

    Returns:
        List of database type identifiers.

    Examples:
        >>> list_available_databases()
        ['sqlite', 'postgres', 'mysql', 'mongodb', 'redis']
    """
    return list(_DATABASE_REGISTRY.keys())


def is_database_available(db_type: str) -> bool:
    """
    Check if a database type can be used (driver is installed).

    Args:
        db_type: The type of database to check.

    Returns:
        True if the database can be used, False otherwise.

    Examples:
        >>> is_database_available("sqlite")  # Always True (built-in)
        True
        >>> is_database_available("postgres")  # Depends on psycopg2 installation
        True  # or False
    """
    try:
        _load_database_class(db_type)
        return True
    except (ValueError, ConfigurationError):
        return False


def list_installed_databases() -> List[str]:
    """
    Returns a list of database types that have their drivers installed and ready to use.

    Returns:
        List of database type identifiers that can be used immediately.

    Examples:
        >>> list_installed_databases()
        ['sqlite']  # SQLite is always available
    """
    return [db_type for db_type in _DATABASE_REGISTRY if is_database_available(db_type)]
