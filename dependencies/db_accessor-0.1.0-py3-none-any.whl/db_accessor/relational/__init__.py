# Relational database implementations
# Use lazy imports to avoid requiring all drivers to be installed

__all__ = ["SqliteDatabase", "PostgresDatabase", "MySQLDatabase"]


def __getattr__(name):
    """Lazy import of database implementations."""
    if name == "SqliteDatabase":
        from .sqlite.implementation import SqliteDatabase
        return SqliteDatabase
    elif name == "PostgresDatabase":
        from .postgres.implementation import PostgresDatabase
        return PostgresDatabase
    elif name == "MySQLDatabase":
        from .mysql.implementation import MySQLDatabase
        return MySQLDatabase
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
