import mysql.connector
import logging
from db_accessor.base import AbstractDatabase
from db_accessor.exceptions import ConnectionError, OperationError, TransactionError, ConfigurationError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MySQLDatabase(AbstractDatabase):
    """
    A concrete implementation of AbstractDatabase for MySQL.
    """
    def __init__(self):
        self.connection = None
        self.cursor = None
        self._cache = {}

    def connect(self, connection_details: dict):
        """
        Establishes a connection to the MySQL database.
        Expected keys in connection_details:
        - database
        - user
        - password
        - host
        - port
        """
        try:
            self.connection = mysql.connector.connect(**connection_details)
            self.cursor = self.connection.cursor(dictionary=True)
            self._create_log_table()
            logger.info("MySQL connection established.")
            return self
        except mysql.connector.Error as e:
            logger.error(f"Error connecting to MySQL: {e}")
            raise ConnectionError(f"Failed to connect to MySQL: {e}") from e

    def disconnect(self):
        """Closes the database connection."""
        if self.connection and self.connection.is_connected():
            self.cursor.close()
            self.connection.close()
            logger.info("MySQL connection closed.")

    def get_connection_status(self):
        """Checks the status of the database connection."""
        if self.connection and self.connection.is_connected():
            return "connected"
        return "disconnected"

    def _create_log_table(self):
        """Creates the operations_log table if it doesn't exist."""
        try:
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS operations_log (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    operation VARCHAR(10) NOT NULL,
                    table_name VARCHAR(255) NOT NULL,
                    data TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            self.connection.commit()
        except mysql.connector.Error as e:
            logger.error(f"Error creating log table: {e}")
            self.connection.rollback()

    def _log_operation(self, operation: str, table: str, data: dict = None):
        """Logs a database operation to the operations_log table."""
        try:
            self.cursor.execute(
                "INSERT INTO operations_log (operation, table_name, data) VALUES (%s, %s, %s)",
                (operation, table, str(data))
            )
            self.connection.commit()
        except mysql.connector.Error as e:
            logger.error(f"Error logging operation: {e}")
            self.connection.rollback()

    def create(self, table: str, data: dict):
        """
        Inserts a new record into the specified table.

        Raises:
            OperationError: If the insert operation fails
        """
        self.clear_cache(table)
        columns = ", ".join(data.keys())
        values = ", ".join(["%s"] * len(data))
        query = f"INSERT INTO {table} ({columns}) VALUES ({values})"
        try:
            self.cursor.execute(query, list(data.values()))
            self.connection.commit()
            self._log_operation("create", table, data)
            return self.cursor.lastrowid
        except mysql.connector.Error as e:
            logger.error(f"Error creating record: {e}")
            self.connection.rollback()
            raise OperationError(f"Failed to create record in {table}: {e}") from e

    def read(self, table: str, filters: dict):
        """
        Reads one or more records from the specified table.

        Raises:
            OperationError: If the read operation fails
        """
        cache_key = (table, frozenset(filters.items()))
        if cache_key in self._cache:
            return self._cache[cache_key]

        where_clause = " AND ".join([f"{key} = %s" for key in filters.keys()])
        query = f"SELECT * FROM {table} WHERE {where_clause}"
        try:
            self.cursor.execute(query, list(filters.values()))
            result = self.cursor.fetchall()
            self._cache[cache_key] = result
            return result
        except mysql.connector.Error as e:
            logger.error(f"Error reading records: {e}")
            raise OperationError(f"Failed to read from {table}: {e}") from e

    def update(self, table: str, filters: dict, data: dict):
        """
        Updates records in the specified table based on a query.

        Raises:
            OperationError: If the update operation fails
        """
        self.clear_cache(table)
        set_clause = ", ".join([f"{key} = %s" for key in data.keys()])
        where_clause = " AND ".join([f"{key} = %s" for key in filters.keys()])
        query = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"
        try:
            self.cursor.execute(query, list(data.values()) + list(filters.values()))
            self.connection.commit()
            self._log_operation("update", table, {"filters": filters, "data": data})
            return self.cursor.rowcount
        except mysql.connector.Error as e:
            logger.error(f"Error updating records: {e}")
            self.connection.rollback()
            raise OperationError(f"Failed to update records in {table}: {e}") from e

    def delete(self, table: str, filters: dict):
        """
        Deletes records from the specified table based on a query.

        Raises:
            OperationError: If the delete operation fails
        """
        self.clear_cache(table)
        where_clause = " AND ".join([f"{key} = %s" for key in filters.keys()])
        query = f"DELETE FROM {table} WHERE {where_clause}"
        try:
            self.cursor.execute(query, list(filters.values()))
            self.connection.commit()
            self._log_operation("delete", table, filters)
            return self.cursor.rowcount
        except mysql.connector.Error as e:
            logger.error(f"Error deleting records: {e}")
            self.connection.rollback()
            raise OperationError(f"Failed to delete from {table}: {e}") from e

    def begin_transaction(self):
        """
        Starts a new transaction.

        Raises:
            TransactionError: If beginning the transaction fails
        """
        try:
            self.connection.start_transaction()
        except mysql.connector.Error as e:
            logger.error(f"Failed to begin transaction: {e}")
            raise TransactionError(f"Failed to begin transaction: {e}") from e

    def commit(self):
        """
        Commits the current transaction.

        Raises:
            TransactionError: If committing the transaction fails
        """
        try:
            self.connection.commit()
        except mysql.connector.Error as e:
            logger.error(f"Failed to commit transaction: {e}")
            raise TransactionError(f"Failed to commit transaction: {e}") from e

    def rollback(self):
        """
        Rolls back the current transaction.

        Raises:
            TransactionError: If rolling back the transaction fails
        """
        try:
            self.connection.rollback()
        except mysql.connector.Error as e:
            logger.error(f"Failed to rollback transaction: {e}")
            raise TransactionError(f"Failed to rollback transaction: {e}") from e

    def execute_custom_query(self, query: str, params: tuple = None):
        """
        Allows for execution of custom queries.
        This method is for advanced use cases.
        """
        try:
            self.cursor.execute(query, params)
            if self.cursor.with_rows:
                return self.cursor.fetchall()
            return self.cursor.rowcount
        except mysql.connector.Error as e:
            logger.error(f"Error executing custom query: {e}")
            return None

    def clear_cache(self, table: str = None):
        """Clears the in-memory cache for a specific table or the entire cache."""
        if table:
            keys_to_delete = [key for key in self._cache if key[0] == table]
            for key in keys_to_delete:
                del self._cache[key]
        else:
            self._cache.clear()
        logger.info(f"Cache cleared for table: {table if table else 'all'}")

    def __enter__(self):
        """Context manager entry point."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point, ensures disconnection."""
        self.disconnect()