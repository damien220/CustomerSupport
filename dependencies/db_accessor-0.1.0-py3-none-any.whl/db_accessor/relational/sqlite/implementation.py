import sqlite3
import logging
from db_accessor.base import AbstractDatabase
from db_accessor.exceptions import ConnectionError, OperationError, TransactionError, ConfigurationError

logger = logging.getLogger(__name__)

class SqliteDatabase(AbstractDatabase):
    """
    Concrete implementation of the AbstractDatabase for SQLite.
    This class is optimized for development and small-scale applications.
    """
    def __init__(self):
        self.connection = None
        self.cursor = None

    def connect(self, connection_details: dict):
        """
        Establishes a connection to the SQLite database.
        Expects a dictionary with a "file" key.
        To use an in-memory database, provide ":memory:" as the file value.

        Raises:
            ConfigurationError: If required connection parameters are missing
            ConnectionError: If connection to the database fails
        """
        db_file = connection_details.get("file")
        if not db_file:
            raise ConfigurationError("Connection details must include a 'file' key for SQLite.")

        try:
            self.connection = sqlite3.connect(db_file)
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
            logger.info(f"Connected to SQLite database: {db_file}")
            return self
        except sqlite3.Error as e:
            logger.error(f"Failed to connect to SQLite database: {e}")
            raise ConnectionError(f"Failed to connect to SQLite database: {e}") from e

    def disconnect(self):
        """Closes the database connection."""
        if self.connection:
            self.connection.close()
            self.connection = None
            self.cursor = None
            logger.info("Disconnected from SQLite database.")

    def __enter__(self):
        """Context manager entry point."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point, ensures disconnection."""
        self.disconnect()

    def execute_script(self, sql_script: str):
        """
        Executes a multi-statement SQL script, typically for schema creation.
        """
        logger.debug(f"Executing script: {sql_script}")
        self.cursor.executescript(sql_script)

    def create(self, collection: str, data: dict):
        """
        Inserts a new record into the specified table.

        Raises:
            OperationError: If the insert operation fails
        """
        try:
            columns = ', '.join(data.keys())
            placeholders = ', '.join('?' for _ in data)
            query = f"INSERT INTO {collection} ({columns}) VALUES ({placeholders})"
            values = tuple(data.values())

            logger.debug(f"Executing query: {query} with values: {values}")
            self.cursor.execute(query, values)
            return self.cursor.lastrowid
        except sqlite3.Error as e:
            logger.error(f"Failed to create record in {collection}: {e}")
            raise OperationError(f"Failed to create record in {collection}: {e}") from e

    def read(self, collection: str, query: dict):
        """
        Reads one or more records from the specified table based on a query.
        Returns a list of dictionaries.

        Raises:
            OperationError: If the read operation fails
        """
        try:
            where_clause, values = self._where_clause(query)
            query_sql = f"SELECT * FROM {collection} WHERE {where_clause}"

            logger.debug(f"Executing query: {query_sql} with values: {values}")
            self.cursor.execute(query_sql, values)
            return [dict(row) for row in self.cursor.fetchall()]
        except sqlite3.Error as e:
            logger.error(f"Failed to read from {collection}: {e}")
            raise OperationError(f"Failed to read from {collection}: {e}") from e

    def update(self, collection: str, query: dict, data: dict):
        """
        Updates records in the specified table based on a query.

        Raises:
            OperationError: If the update operation fails
        """
        try:
            set_clause = ', '.join(f"{key} = ?" for key in data.keys())
            where_clause, where_values = self._where_clause(query)

            values = tuple(data.values()) + where_values
            query_sql = f"UPDATE {collection} SET {set_clause} WHERE {where_clause}"

            logger.debug(f"Executing query: {query_sql} with values: {values}")
            self.cursor.execute(query_sql, values)
            return self.cursor.rowcount
        except sqlite3.Error as e:
            logger.error(f"Failed to update records in {collection}: {e}")
            raise OperationError(f"Failed to update records in {collection}: {e}") from e

    def delete(self, collection: str, query: dict):
        """
        Deletes records from the specified table based on a query.

        Raises:
            OperationError: If the delete operation fails
        """
        try:
            where_clause, values = self._where_clause(query)
            query_sql = f"DELETE FROM {collection} WHERE {where_clause}"

            logger.debug(f"Executing query: {query_sql} with values: {values}")
            self.cursor.execute(query_sql, values)
            return self.cursor.rowcount
        except sqlite3.Error as e:
            logger.error(f"Failed to delete from {collection}: {e}")
            raise OperationError(f"Failed to delete from {collection}: {e}") from e

    def _where_clause(self, query: dict) -> (str, tuple):
        """Helper to build a WHERE clause from a query dictionary."""
        if not query:
            return "1", () # Return all if query is empty
        clauses = []
        values = []
        for key, value in query.items():
            clauses.append(f"{key} = ?")
            values.append(value)
        return " AND ".join(clauses), tuple(values)

    def begin_transaction(self):
        """
        Starts a new transaction.

        Raises:
            TransactionError: If beginning the transaction fails
        """
        try:
            self.connection.execute("BEGIN")
            logger.debug("Transaction started.")
        except sqlite3.Error as e:
            logger.error(f"Failed to begin transaction: {e}")
            raise TransactionError(f"Failed to begin transaction: {e}") from e

    def commit(self):
        """
        Commits the current transaction.

        Raises:
            TransactionError: If committing the transaction fails
        """
        try:
            self.connection.commit()
            logger.debug("Transaction committed.")
        except sqlite3.Error as e:
            logger.error(f"Failed to commit transaction: {e}")
            raise TransactionError(f"Failed to commit transaction: {e}") from e

    def rollback(self):
        """
        Rolls back the current transaction.

        Raises:
            TransactionError: If rolling back the transaction fails
        """
        try:
            self.connection.rollback()
            logger.debug("Transaction rolled back.")
        except sqlite3.Error as e:
            logger.error(f"Failed to rollback transaction: {e}")
            raise TransactionError(f"Failed to rollback transaction: {e}") from e

