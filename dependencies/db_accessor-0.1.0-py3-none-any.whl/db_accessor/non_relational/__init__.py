# Non-relational database implementations
# Use lazy imports to avoid requiring all drivers to be installed

__all__ = ["MongoDBDatabase", "RedisDatabase"]


def __getattr__(name):
    """Lazy import of database implementations."""
    if name == "MongoDBDatabase":
        from .mongodb.implementation import MongoDBDatabase
        return MongoDBDatabase
    elif name == "RedisDatabase":
        from .redis.implementation import RedisDatabase
        return RedisDatabase
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
