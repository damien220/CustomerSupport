from db_accessor.base import AbstractDatabase
from db_accessor.exceptions import ConnectionError, OperationError, TransactionError, ConfigurationError
import redis
import json
import logging

class RedisDatabase(AbstractDatabase):
    def __init__(self):
        self.client = None
        self.connection_status = "disconnected"

    def connect(self, connection_details: dict):
        """
        Establishes a connection to the Redis server.

        Raises:
            ConnectionError: If connection to the Redis server fails
        """
        try:
            self.client = redis.Redis(
                host=connection_details.get("host", "localhost"),
                port=connection_details.get("port", 6379),
                db=connection_details.get("db", 0),
                decode_responses=True
            )
            self.client.ping()
            self.connection_status = "connected"
            logging.info("Successfully connected to Redis.")
            return self
        except redis.exceptions.ConnectionError as e:
            self.connection_status = "error"
            logging.error(f"Failed to connect to Redis: {e}")
            raise ConnectionError(f"Failed to connect to Redis: {e}") from e

    def disconnect(self):
        """Closes the Redis connection."""
        if self.client:
            self.client.close()
            self.connection_status = "disconnected"
            logging.info("Disconnected from Redis.")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def create(self, collection: str, data: dict):
        """
        Creates a new key-value pair. In Redis, the 'collection' is used as a prefix for the key.

        Raises:
            ConfigurationError: If data doesn't contain required 'id' field
            OperationError: If the create operation fails
        """
        if "id" not in data:
            raise ConfigurationError("Data must contain an 'id' field to use as the Redis key.")
        try:
            key = f"{collection}:{data['id']}"
            value = json.dumps(data)
            result = self.client.set(key, value)
            return result
        except (redis.exceptions.RedisError, json.JSONDecodeError) as e:
            logging.error(f"Failed to create in {collection}: {e}")
            raise OperationError(f"Failed to create in {collection}: {e}") from e

    def read(self, collection: str, query: dict):
        """
        Reads a value by key. The 'id' in the query is used to construct the key.

        Raises:
            ConfigurationError: If query doesn't contain required 'id' field
            OperationError: If the read operation fails
        """
        if "id" not in query:
            raise ConfigurationError("Query must contain an 'id' field to use as the Redis key.")
        try:
            key = f"{collection}:{query['id']}"
            value = self.client.get(key)
            return json.loads(value) if value else None
        except (redis.exceptions.RedisError, json.JSONDecodeError) as e:
            logging.error(f"Failed to read from {collection}: {e}")
            raise OperationError(f"Failed to read from {collection}: {e}") from e

    def update(self, collection: str, query: dict, data: dict):
        """
        Updates a key-value pair.

        Raises:
            ConfigurationError: If query doesn't contain required 'id' field
            OperationError: If the update operation fails
        """
        if "id" not in query:
            raise ConfigurationError("Query must contain an 'id' field to use as the Redis key.")
        try:
            key = f"{collection}:{query['id']}"
            if self.client.exists(key):
                value = json.dumps(data)
                return self.client.set(key, value)
            return False
        except (redis.exceptions.RedisError, json.JSONDecodeError) as e:
            logging.error(f"Failed to update in {collection}: {e}")
            raise OperationError(f"Failed to update in {collection}: {e}") from e

    def delete(self, collection: str, query: dict):
        """
        Deletes a key-value pair.

        Raises:
            ConfigurationError: If query doesn't contain required 'id' field
            OperationError: If the delete operation fails
        """
        if "id" not in query:
            raise ConfigurationError("Query must contain an 'id' field to use as the Redis key.")
        try:
            key = f"{collection}:{query['id']}"
            return self.client.delete(key)
        except redis.exceptions.RedisError as e:
            logging.error(f"Failed to delete from {collection}: {e}")
            raise OperationError(f"Failed to delete from {collection}: {e}") from e

    def begin_transaction(self):
        """
        Redis does not support traditional transactions.

        Raises:
            TransactionError: Always, as Redis doesn't support traditional transactions
        """
        logging.warning("Redis transactions are handled differently. Use 'execute_custom_query' with a pipeline.")
        raise TransactionError(
            "Redis does not support traditional transactions in the same way as relational databases. "
            "Use execute_custom_query() with pipelines for atomic operations."
        )

    def commit(self):
        """
        Redis does not support traditional transactions.

        Raises:
            TransactionError: Always, as Redis doesn't support traditional transactions
        """
        raise TransactionError(
            "Redis does not support traditional transactions. "
            "Use execute_custom_query() with pipelines for atomic operations."
        )

    def rollback(self):
        """
        Redis does not support traditional transactions.

        Raises:
            TransactionError: Always, as Redis doesn't support traditional transactions
        """
        raise TransactionError(
            "Redis does not support traditional transactions. "
            "Use execute_custom_query() with pipelines for atomic operations."
        )
    
    def execute_custom_query(self, query_details: dict):
        """
        Executes a custom command or a pipeline of commands.
        'query_details' should contain 'command' and 'args' or a 'pipeline'.
        """
        if "pipeline" in query_details:
            pipe = self.client.pipeline()
            for command in query_details["pipeline"]:
                func = getattr(pipe, command["command"])
                func(*command["args"])
            return pipe.execute()
        
        if "command" in query_details:
            func = getattr(self.client, query_details["command"])
            return func(*query_details.get("args", []))
            
        raise ValueError("Custom query for Redis requires 'command' or 'pipeline'.")

    def get_connection_status(self):
        """Returns the current connection status."""
        return self.connection_status