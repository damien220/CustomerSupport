from db_accessor.base import AbstractDatabase
from db_accessor.exceptions import ConnectionError, OperationError, TransactionError, ConfigurationError
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
import logging

class MongoDBDatabase(AbstractDatabase):
    def __init__(self):
        self.client = None
        self.db = None
        self.connection_status = "disconnected"
        self.operation_log = []
        self.cache = {}

    def connect(self, connection_details: dict):
        """
        Establishes a connection to the MongoDB database.

        Raises:
            ConfigurationError: If required connection parameters are missing
            ConnectionError: If connection to the database fails
        """
        if not connection_details.get("database"):
            raise ConfigurationError("Connection details must include a 'database' key for MongoDB.")

        try:
            self.client = MongoClient(
                host=connection_details.get("host", "localhost"),
                port=connection_details.get("port", 27017)
            )
            # The ismaster command is cheap and does not require auth.
            self.client.admin.command('ismaster')
            self.db = self.client[connection_details.get("database")]
            self.connection_status = "connected"
            logging.info("Successfully connected to MongoDB.")
            return self
        except ConnectionFailure as e:
            self.connection_status = "error"
            logging.error(f"Failed to connect to MongoDB: {e}")
            raise ConnectionError(f"Failed to connect to MongoDB: {e}") from e

    def disconnect(self):
        """Closes the MongoDB connection."""
        if self.client:
            self.client.close()
            self.connection_status = "disconnected"
            logging.info("Disconnected from MongoDB.")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

    def create(self, collection: str, data: dict):
        """
        Inserts a new document into a collection.

        Raises:
            OperationError: If the insert operation fails
        """
        try:
            result = self.db[collection].insert_one(data)
            self._log_operation(f"INSERT in {collection}", {"data": data})
            return result.inserted_id
        except OperationFailure as e:
            logging.error(f"Error creating document in {collection}: {e}")
            raise OperationError(f"Failed to create document in {collection}: {e}") from e

    def read(self, collection: str, query: dict, use_cache: bool = False):
        """
        Reads one or more documents from a collection.

        Raises:
            OperationError: If the read operation fails
        """
        cache_key = (collection, str(query))
        if use_cache and cache_key in self.cache:
            self._log_operation(f"CACHE READ from {collection}", {"query": query})
            return self.cache[cache_key]

        try:
            documents = list(self.db[collection].find(query))
            self._log_operation(f"READ from {collection}", {"query": query})
            if use_cache:
                self.cache[cache_key] = documents
            return documents
        except OperationFailure as e:
            logging.error(f"Error reading from {collection}: {e}")
            raise OperationError(f"Failed to read from {collection}: {e}") from e

    def update(self, collection: str, query: dict, data: dict):
        """
        Updates one or more documents in a collection.

        Raises:
            OperationError: If the update operation fails
        """
        try:
            result = self.db[collection].update_many(query, {"$set": data})
            self._log_operation(f"UPDATE in {collection}", {"query": query, "data": data})
            return result.modified_count
        except OperationFailure as e:
            logging.error(f"Error updating in {collection}: {e}")
            raise OperationError(f"Failed to update in {collection}: {e}") from e

    def delete(self, collection: str, query: dict):
        """
        Deletes one or more documents from a collection.

        Raises:
            OperationError: If the delete operation fails
        """
        try:
            result = self.db[collection].delete_many(query)
            self._log_operation(f"DELETE in {collection}", {"query": query})
            return result.deleted_count
        except OperationFailure as e:
            logging.error(f"Error deleting from {collection}: {e}")
            raise OperationError(f"Failed to delete from {collection}: {e}") from e

    def begin_transaction(self):
        """
        Starts a transaction.

        Note: MongoDB transactions require a replica set or sharded cluster.

        Raises:
            TransactionError: If beginning the transaction fails or is not supported
        """
        try:
            if self.client and self.client.is_mongos:
                self.session = self.client.start_session()
                self.session.start_transaction()
                logging.info("Transaction started.")
            else:
                logging.warning("Transaction not supported: MongoDB instance is not a replica set or sharded cluster.")
                raise TransactionError(
                    "Transaction not supported: MongoDB instance is not a replica set or sharded cluster. "
                    "Transactions require either a replica set or a sharded cluster (mongos)."
                )
        except Exception as e:
            if isinstance(e, TransactionError):
                raise
            logging.error(f"Failed to begin transaction: {e}")
            raise TransactionError(f"Failed to begin transaction: {e}") from e

    def commit(self):
        """
        Commits the current transaction.

        Raises:
            TransactionError: If committing the transaction fails
        """
        try:
            if hasattr(self, 'session') and self.session:
                self.session.commit_transaction()
                self.session.end_session()
                logging.info("Transaction committed.")
            else:
                raise TransactionError("No active transaction to commit.")
        except Exception as e:
            if isinstance(e, TransactionError):
                raise
            logging.error(f"Failed to commit transaction: {e}")
            raise TransactionError(f"Failed to commit transaction: {e}") from e

    def rollback(self):
        """
        Rolls back the current transaction.

        Raises:
            TransactionError: If rolling back the transaction fails
        """
        try:
            if hasattr(self, 'session') and self.session:
                self.session.abort_transaction()
                self.session.end_session()
                logging.info("Transaction rolled back.")
            else:
                raise TransactionError("No active transaction to rollback.")
        except Exception as e:
            if isinstance(e, TransactionError):
                raise
            logging.error(f"Failed to rollback transaction: {e}")
            raise TransactionError(f"Failed to rollback transaction: {e}") from e
    
    def execute_custom_query(self, query_details: dict):
        """
        Executes a custom query provided by the user.
        For MongoDB, this can be an aggregation pipeline or a complex find query.
        """
        collection = query_details.get("collection")
        query = query_details.get("query")
        query_type = query_details.get("type", "find") # or "aggregate"

        if not all([collection, query]):
            raise ValueError("Collection and query must be provided for custom execution.")

        try:
            if query_type == "aggregate":
                result = list(self.db[collection].aggregate(query))
            else: # Default to find
                result = list(self.db[collection].find(query))
            
            self._log_operation("CUSTOM QUERY", {"type": query_type, "collection": collection, "query": query})
            return result
        except OperationFailure as e:
            logging.error(f"Error executing custom query in {collection}: {e}")
            raise

    def get_connection_status(self):
        """Returns the current connection status."""
        return self.connection_status

    def clear_cache(self):
        """Clears the in-memory cache."""
        self.cache.clear()
        self._log_operation("CACHE CLEARED", {})

    def _log_operation(self, operation: str, details: dict):
        """Logs the database operation."""
        self.operation_log.append({
            "operation": operation,
            "details": details
        })
