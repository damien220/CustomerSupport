"""
Exception hierarchy for the DB Accessor package.

This module provides a unified set of exceptions that wrap database-specific errors,
allowing users to write database-agnostic error handling code.
"""


class DatabaseError(Exception):
    """
    Base exception for all database-related errors in the db_accessor package.

    All database-specific exceptions should be caught and re-raised as
    a subclass of this exception to maintain a consistent error handling interface.
    """
    pass


class ConnectionError(DatabaseError):
    """
    Exception raised when there's an error establishing or maintaining
    a database connection.

    Examples:
        - Failed to connect to database server
        - Connection timeout
        - Authentication failure
        - Network issues
    """
    pass


class OperationError(DatabaseError):
    """
    Exception raised when a CRUD operation (Create, Read, Update, Delete) fails.

    Examples:
        - Insert failed due to constraint violation
        - Update failed due to invalid data
        - Delete failed due to foreign key constraints
        - Query execution error
    """
    pass


class TransactionError(DatabaseError):
    """
    Exception raised when transaction management operations fail.

    Examples:
        - Failed to begin transaction
        - Commit failure
        - Rollback failure
        - Transaction not supported by database
    """
    pass


class QueryError(DatabaseError):
    """
    Exception raised when executing a custom query fails.

    This is typically used for database-specific queries that don't fit
    into the standard CRUD operation pattern.

    Examples:
        - Invalid SQL syntax
        - Invalid MongoDB aggregation pipeline
        - Redis command execution error
    """
    pass


class ConfigurationError(DatabaseError):
    """
    Exception raised when there's an error in database configuration.

    Examples:
        - Missing required connection parameters
        - Invalid connection parameter values
        - Unsupported database type
    """
    pass
