"""Process-pool based executor for CPU-bound jobs."""

from __future__ import annotations

import concurrent.futures
from typing import Callable, Optional

from ..models import JobContext, JobResult
from .base_executor import BaseExecutor


class ProcessPoolExecutor(BaseExecutor):
    """Executes jobs in a process pool — ideal for CPU-bound work.

    Note: Job functions and their arguments must be picklable.

    Args:
        max_workers: Maximum number of concurrent worker processes.
                     Defaults to the number of CPUs.
    """

    def __init__(self, max_workers: Optional[int] = None) -> None:
        self._max_workers = max_workers
        self._pool: Optional[concurrent.futures.ProcessPoolExecutor] = None

    def start(self) -> None:
        if self._pool is None:
            self._pool = concurrent.futures.ProcessPoolExecutor(
                max_workers=self._max_workers,
            )

    def shutdown(self, wait: bool = True) -> None:
        if self._pool is not None:
            self._pool.shutdown(wait=wait)
            self._pool = None

    def submit(
        self,
        fn: Callable[[JobContext], JobResult],
        context: JobContext,
        callback: Callable[[JobResult], None] | None = None,
    ) -> None:
        if self._pool is None:
            raise RuntimeError("Executor has not been started")

        future = self._pool.submit(fn, context)

        if callback is not None:
            future.add_done_callback(lambda f: callback(f.result()))

    @property
    def is_running(self) -> bool:
        return self._pool is not None
