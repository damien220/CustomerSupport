"""Abstract base executor."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from ..models import JobContext, JobResult


class BaseExecutor(ABC):
    """Runs jobs. Concrete implementations decide *how* (threads, processes, async)."""

    @abstractmethod
    def start(self) -> None:
        """Initialize resources (thread pool, process pool, etc.)."""
        ...

    @abstractmethod
    def shutdown(self, wait: bool = True) -> None:
        """Release resources. If *wait* is True, block until running jobs finish."""
        ...

    @abstractmethod
    def submit(
        self,
        fn: Callable[["JobContext"], "JobResult"],
        context: "JobContext",
        callback: Callable[["JobResult"], None] | None = None,
    ) -> None:
        """Submit a job for execution.

        Args:
            fn:       Callable that accepts a JobContext and returns a JobResult.
            context:  The runtime context for this execution.
            callback: Optional callback invoked with the JobResult when done.
        """
        ...

    @property
    @abstractmethod
    def is_running(self) -> bool:
        """True if the executor has been started and not yet shut down."""
        ...
