"""Asyncio-based executor for async jobs."""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Coroutine, Optional

from ..models import JobContext, JobResult
from .base_executor import BaseExecutor


class AsyncExecutor(BaseExecutor):
    """Executes jobs as asyncio tasks.

    Designed to be used with ``AsyncScheduler``. The ``fn`` passed to
    ``submit()`` can be either a regular callable or an async callable.
    If it is a regular callable, it is run in the default executor
    (thread pool) to avoid blocking the event loop.

    Args:
        max_concurrent: Maximum number of concurrent async tasks.
        loop:           Optional event loop (auto-detected if None).
    """

    def __init__(
        self,
        max_concurrent: int = 100,
        loop: Optional[asyncio.AbstractEventLoop] = None,
    ) -> None:
        self._max_concurrent = max_concurrent
        self._loop = loop
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._running = False
        self._tasks: set[asyncio.Task] = set()

    def start(self) -> None:
        if self._loop is None:
            try:
                self._loop = asyncio.get_running_loop()
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
        self._semaphore = asyncio.Semaphore(self._max_concurrent)
        self._running = True

    def shutdown(self, wait: bool = True) -> None:
        self._running = False
        if wait and self._tasks:
            # Cancel outstanding tasks if we're shutting down
            for task in self._tasks:
                if not task.done():
                    task.cancel()
        self._tasks.clear()
        self._loop = None
        self._semaphore = None

    def submit(
        self,
        fn: Callable[[JobContext], JobResult],
        context: JobContext,
        callback: Callable[[JobResult], None] | None = None,
    ) -> None:
        if not self._running or self._loop is None:
            raise RuntimeError("AsyncExecutor has not been started")

        task = self._loop.create_task(self._run(fn, context, callback))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _run(
        self,
        fn: Callable[[JobContext], JobResult],
        context: JobContext,
        callback: Callable[[JobResult], None] | None,
    ) -> None:
        """Run the function under the concurrency semaphore."""
        async with self._semaphore:
            if asyncio.iscoroutinefunction(fn):
                result = await fn(context)
            else:
                result = await self._loop.run_in_executor(None, fn, context)

        if callback is not None:
            callback(result)

    @property
    def is_running(self) -> bool:
        return self._running
