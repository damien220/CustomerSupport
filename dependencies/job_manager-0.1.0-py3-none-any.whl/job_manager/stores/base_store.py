"""Abstract base job store — Repository pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from ..models import JobDescriptor


class BaseJobStore(ABC):
    """Persists job descriptors.

    Concrete implementations choose the backing storage
    (memory, SQLite, PostgreSQL, etc.).
    """

    @abstractmethod
    def add(self, descriptor: JobDescriptor) -> None:
        """Store a new job descriptor. Raise if job_id already exists."""
        ...

    @abstractmethod
    def update(self, descriptor: JobDescriptor) -> None:
        """Update an existing job descriptor. Raise if not found."""
        ...

    @abstractmethod
    def remove(self, job_id: str) -> None:
        """Remove a job by ID. Raise if not found."""
        ...

    @abstractmethod
    def get(self, job_id: str) -> JobDescriptor:
        """Retrieve a single job by ID. Raise if not found."""
        ...

    @abstractmethod
    def get_all(self) -> list[JobDescriptor]:
        """Return all stored job descriptors."""
        ...

    @abstractmethod
    def get_due_jobs(self, now: datetime) -> list[JobDescriptor]:
        """Return jobs whose next_run_time <= *now* and are in a runnable state."""
        ...

    @abstractmethod
    def get_next_run_time(self) -> Optional[datetime]:
        """Return the earliest next_run_time across all jobs, or None."""
        ...
