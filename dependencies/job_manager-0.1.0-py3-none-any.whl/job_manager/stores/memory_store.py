"""In-memory job store."""

from __future__ import annotations

import threading
from datetime import datetime
from typing import Optional

from ..enums import JobState
from ..exceptions import JobNotFoundError, ScheduleConflictError
from ..models import JobDescriptor
from .base_store import BaseJobStore

_RUNNABLE_STATES = {JobState.PENDING, JobState.QUEUED, JobState.RETRYING}


class MemoryJobStore(BaseJobStore):
    """Thread-safe in-memory job store.

    Suitable for development, testing, and single-process deployments.
    All data is lost when the process exits.
    """

    def __init__(self) -> None:
        self._jobs: dict[str, JobDescriptor] = {}
        self._lock = threading.Lock()

    def add(self, descriptor: JobDescriptor) -> None:
        with self._lock:
            if descriptor.job_id in self._jobs:
                raise ScheduleConflictError(
                    f"Job '{descriptor.job_id}' already exists",
                    details={"job_id": descriptor.job_id},
                )
            self._jobs[descriptor.job_id] = descriptor

    def update(self, descriptor: JobDescriptor) -> None:
        with self._lock:
            if descriptor.job_id not in self._jobs:
                raise JobNotFoundError(
                    f"Job '{descriptor.job_id}' not found",
                    details={"job_id": descriptor.job_id},
                )
            self._jobs[descriptor.job_id] = descriptor

    def remove(self, job_id: str) -> None:
        with self._lock:
            if job_id not in self._jobs:
                raise JobNotFoundError(
                    f"Job '{job_id}' not found",
                    details={"job_id": job_id},
                )
            del self._jobs[job_id]

    def get(self, job_id: str) -> JobDescriptor:
        with self._lock:
            if job_id not in self._jobs:
                raise JobNotFoundError(
                    f"Job '{job_id}' not found",
                    details={"job_id": job_id},
                )
            return self._jobs[job_id]

    def get_all(self) -> list[JobDescriptor]:
        with self._lock:
            return list(self._jobs.values())

    def get_due_jobs(self, now: datetime) -> list[JobDescriptor]:
        with self._lock:
            return [
                job
                for job in self._jobs.values()
                if (
                    job.next_run_time is not None
                    and job.next_run_time <= now
                    and job.state in _RUNNABLE_STATES
                )
            ]

    def get_next_run_time(self) -> Optional[datetime]:
        with self._lock:
            times = [
                job.next_run_time
                for job in self._jobs.values()
                if job.next_run_time is not None and job.state in _RUNNABLE_STATES
            ]
            return min(times) if times else None
