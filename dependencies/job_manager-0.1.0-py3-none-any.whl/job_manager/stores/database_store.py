"""Persistent job store backed by DB_Package.

Uses the ``db_accessor`` sibling package for database-agnostic persistence.
Falls back with a clear error if the package is not installed.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from ..enums import JobState
from ..exceptions import JobNotFoundError, ScheduleConflictError
from ..models import JobDescriptor
from .base_store import BaseJobStore

_COLLECTION = "job_descriptors"
_RUNNABLE_STATES = {JobState.PENDING.value, JobState.QUEUED.value, JobState.RETRYING.value}

try:
    from db_accessor import AbstractDatabase, get_database
except ImportError:
    AbstractDatabase = None  # type: ignore[assignment,misc]
    get_database = None  # type: ignore[assignment]


class DatabaseJobStore(BaseJobStore):
    """Persistent job store using DB_Package's unified database interface.

    Supports any backend that ``db_accessor`` provides: SQLite, PostgreSQL,
    MySQL, MongoDB, or Redis.

    Usage:
        from db_accessor import get_database

        db = get_database("sqlite")
        db.connect({"database": "jobs.db"})
        store = DatabaseJobStore(db)

    Or let the store create the connection for you:

        store = DatabaseJobStore.from_config(
            db_type="sqlite",
            connection_details={"database": "jobs.db"},
        )
    """

    def __init__(self, database: "AbstractDatabase") -> None:
        if AbstractDatabase is None:
            raise ImportError(
                "DatabaseJobStore requires the 'db_accessor' package. "
                "Install it from the DB_Package sibling project."
            )
        self._db = database

    @classmethod
    def from_config(
        cls,
        db_type: str,
        connection_details: dict[str, Any],
    ) -> "DatabaseJobStore":
        """Factory: create a store from a database type string and connection config."""
        if get_database is None:
            raise ImportError(
                "DatabaseJobStore requires the 'db_accessor' package."
            )
        db = get_database(db_type)
        db.connect(connection_details)
        return cls(db)

    # --- BaseJobStore implementation ------------------------------------------

    def add(self, descriptor: JobDescriptor) -> None:
        existing = self._db.read(_COLLECTION, {"job_id": descriptor.job_id})
        if existing:
            raise ScheduleConflictError(
                f"Job '{descriptor.job_id}' already exists",
                details={"job_id": descriptor.job_id},
            )
        self._db.create(_COLLECTION, descriptor.to_dict())

    def update(self, descriptor: JobDescriptor) -> None:
        existing = self._db.read(_COLLECTION, {"job_id": descriptor.job_id})
        if not existing:
            raise JobNotFoundError(
                f"Job '{descriptor.job_id}' not found",
                details={"job_id": descriptor.job_id},
            )
        self._db.update(
            _COLLECTION,
            {"job_id": descriptor.job_id},
            descriptor.to_dict(),
        )

    def remove(self, job_id: str) -> None:
        existing = self._db.read(_COLLECTION, {"job_id": job_id})
        if not existing:
            raise JobNotFoundError(
                f"Job '{job_id}' not found",
                details={"job_id": job_id},
            )
        self._db.delete(_COLLECTION, {"job_id": job_id})

    def get(self, job_id: str) -> JobDescriptor:
        results = self._db.read(_COLLECTION, {"job_id": job_id})
        if not results:
            raise JobNotFoundError(
                f"Job '{job_id}' not found",
                details={"job_id": job_id},
            )
        row = results[0] if isinstance(results, list) else results
        return JobDescriptor.from_dict(row)

    def get_all(self) -> list[JobDescriptor]:
        results = self._db.read(_COLLECTION, {})
        if not results:
            return []
        rows = results if isinstance(results, list) else [results]
        return [JobDescriptor.from_dict(row) for row in rows]

    def get_due_jobs(self, now: datetime) -> list[JobDescriptor]:
        all_jobs = self.get_all()
        return [
            job
            for job in all_jobs
            if (
                job.next_run_time is not None
                and job.next_run_time <= now
                and job.state.value in _RUNNABLE_STATES
            )
        ]

    def get_next_run_time(self) -> Optional[datetime]:
        all_jobs = self.get_all()
        times = [
            job.next_run_time
            for job in all_jobs
            if job.next_run_time is not None and job.state.value in _RUNNABLE_STATES
        ]
        return min(times) if times else None

    def close(self) -> None:
        """Disconnect from the database."""
        self._db.disconnect()
