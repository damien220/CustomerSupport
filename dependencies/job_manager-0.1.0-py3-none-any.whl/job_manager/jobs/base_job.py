"""Abstract base class for all jobs — Template Method pattern."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Optional

from ..enums import JobState
from ..models import JobContext, JobResult, RetryPolicy


class BaseJob(ABC):
    """Abstract unit of work.

    Subclasses MUST implement ``execute(context)``.
    Optionally override ``pre_execute``, ``post_execute``, or ``on_error``
    for lifecycle hooks.

    The public ``run()`` method is the **template method** — it orchestrates
    the full lifecycle and should not be overridden.
    """

    def __init__(
        self,
        name: Optional[str] = None,
        retry_policy: Optional[RetryPolicy] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.job_id: str = uuid.uuid4().hex
        self.name: str = name or self.__class__.__name__
        self.retry_policy: RetryPolicy = retry_policy or RetryPolicy()
        self.timeout: Optional[float] = timeout

    # --- Template method (do NOT override) ------------------------------------

    def run(self, context: JobContext) -> JobResult:
        """Execute the full job lifecycle.

        Flow: pre_execute -> execute -> post_execute
        On failure: on_error is called and the result reflects the failure.
        """
        started_at = datetime.now(timezone.utc)
        try:
            self.pre_execute(context)
            return_value = self.execute(context)
            self.post_execute(context, return_value)

            return JobResult(
                job_id=context.job_id,
                state=JobState.SUCCEEDED,
                return_value=return_value,
                started_at=started_at,
                finished_at=datetime.now(timezone.utc),
                attempt=context.attempt,
            )

        except Exception as exc:
            self.on_error(context, exc)
            return JobResult(
                job_id=context.job_id,
                state=JobState.FAILED,
                error=exc,
                error_message=str(exc),
                started_at=started_at,
                finished_at=datetime.now(timezone.utc),
                attempt=context.attempt,
            )

    # --- Abstract: must implement ---------------------------------------------

    @abstractmethod
    def execute(self, context: JobContext) -> Any:
        """Core work of the job. This is the only method subclasses must implement."""
        ...

    # --- Optional lifecycle hooks ---------------------------------------------

    def pre_execute(self, context: JobContext) -> None:
        """Called before execute(). Override for setup / validation."""

    def post_execute(self, context: JobContext, result: Any) -> None:
        """Called after a successful execute(). Override for cleanup."""

    def on_error(self, context: JobContext, error: Exception) -> None:
        """Called when execute() raises. Override for custom error handling."""
