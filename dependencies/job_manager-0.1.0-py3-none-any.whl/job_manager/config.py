"""Central configuration for the scheduler."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SchedulerConfig:
    """Configuration dataclass for a scheduler instance.

    Attributes:
        scheduler_id:       Unique name for this scheduler instance.
        max_workers:        Default thread/process pool size for executors.
        job_defaults:       Default settings applied to every job unless overridden.
        tick_interval:      Seconds between scheduler loop iterations.
        shutdown_timeout:   Max seconds to wait for running jobs during shutdown.
        timezone:           IANA timezone string (e.g. "UTC", "US/Eastern").
        misfire_grace_time: Seconds after a missed fire time within which the
                            job is still allowed to run (None = always run).
        coalesce:           If True, coalesce multiple missed runs into one.
    """

    scheduler_id: str = "default"
    max_workers: int = 10
    job_defaults: dict[str, Any] = field(default_factory=lambda: {
        "max_retries": 3,
        "timeout": None,
        "coalesce": True,
        "misfire_grace_time": 60,
    })
    tick_interval: float = 1.0
    shutdown_timeout: float = 30.0
    timezone: str = "UTC"
    misfire_grace_time: Optional[float] = 60.0
    coalesce: bool = True
