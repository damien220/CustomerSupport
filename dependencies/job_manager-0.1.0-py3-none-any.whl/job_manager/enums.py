"""Enumerations used across the Job Manager package."""

from enum import Enum, auto


class JobState(str, Enum):
    """Job lifecycle states.

    Transitions:
        PENDING -> QUEUED -> RUNNING -> SUCCEEDED
                     |          |
                     |          +-> FAILED -> RETRYING -> RUNNING ...
                     |                           |
                     |                           +-> FAILED (max retries)
                     +-> CANCELLED
                     +-> SKIPPED
        PAUSED <-> QUEUED
    """

    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRYING = "retrying"
    PAUSED = "paused"
    SKIPPED = "skipped"

    @property
    def is_terminal(self) -> bool:
        return self in (
            JobState.SUCCEEDED,
            JobState.FAILED,
            JobState.CANCELLED,
            JobState.SKIPPED,
        )

    @property
    def is_active(self) -> bool:
        return self in (JobState.RUNNING, JobState.RETRYING)


class Priority(int, Enum):
    """Job execution priority. Lower value = higher priority."""

    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3

    def __lt__(self, other: "Priority") -> bool:
        if not isinstance(other, Priority):
            return NotImplemented
        return self.value < other.value


class BackoffType(str, Enum):
    """Retry backoff strategies."""

    FIXED = "fixed"
    EXPONENTIAL = "exponential"
    EXPONENTIAL_JITTER = "exponential_jitter"
