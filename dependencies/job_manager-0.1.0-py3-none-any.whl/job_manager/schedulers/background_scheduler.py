"""Background (threaded) scheduler implementation."""

from __future__ import annotations

import threading
from typing import Optional

from ..config import SchedulerConfig
from ..executors.base_executor import BaseExecutor
from ..stores.base_store import BaseJobStore
from .base_scheduler import BaseScheduler


class BackgroundScheduler(BaseScheduler):
    """Runs the scheduling loop in a daemon thread.

    Usage:
        scheduler = BackgroundScheduler(store, executor)
        scheduler.add_job(my_job, IntervalTrigger(seconds=60))
        scheduler.start()
        # ... application continues ...
        scheduler.shutdown()
    """

    def __init__(
        self,
        store: BaseJobStore,
        executor: BaseExecutor,
        config: Optional[SchedulerConfig] = None,
    ) -> None:
        super().__init__(store, executor, config)
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def _start_loop(self) -> None:
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name=f"scheduler-{self._config.scheduler_id}",
            daemon=True,
        )
        self._thread.start()

    def _stop_loop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self._config.shutdown_timeout)
            self._thread = None

    def _run_loop(self) -> None:
        """Main loop — tick at the configured interval until stopped."""
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception:
                pass  # individual tick failures must not kill the loop
            self._stop_event.wait(timeout=self._config.tick_interval)
