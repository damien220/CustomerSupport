"""Asyncio-based scheduler implementation."""

from __future__ import annotations

import asyncio
from typing import Optional

from ..config import SchedulerConfig
from ..executors.base_executor import BaseExecutor
from ..stores.base_store import BaseJobStore
from .base_scheduler import BaseScheduler


class AsyncScheduler(BaseScheduler):
    """Runs the scheduling loop as an asyncio task.

    Usage:
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)
        scheduler.add_job(my_job, IntervalTrigger(seconds=60))

        # Inside an async context:
        await scheduler.start_async()
        # ... application runs ...
        await scheduler.shutdown_async()

    Can also be used with ``start()`` / ``shutdown()`` which internally
    manage the asyncio event loop.
    """

    def __init__(
        self,
        store: BaseJobStore,
        executor: BaseExecutor,
        config: Optional[SchedulerConfig] = None,
    ) -> None:
        super().__init__(store, executor, config)
        self._task: Optional[asyncio.Task] = None
        self._stop_event: Optional[asyncio.Event] = None

    # --- Async-native API -----------------------------------------------------

    async def start_async(self) -> None:
        """Start the scheduler within an already-running event loop."""
        if self._running:
            return
        self._executor.start()
        self._running = True
        self._stop_event = asyncio.Event()
        from ..events.job_event import EventType
        self._emit_scheduler_event(EventType.SCHEDULER_STARTED)
        self._task = asyncio.current_task() and asyncio.ensure_future(self._run_loop())

    async def shutdown_async(self, wait: bool = True) -> None:
        """Stop the scheduler gracefully within an async context."""
        if not self._running:
            return
        self._running = False
        if self._stop_event:
            self._stop_event.set()
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._executor.shutdown(wait=wait)
        from ..events.job_event import EventType
        self._emit_scheduler_event(EventType.SCHEDULER_STOPPED)

    # --- Internal loop --------------------------------------------------------

    async def _run_loop(self) -> None:
        """Async main loop — tick at the configured interval until stopped."""
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception:
                pass
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._config.tick_interval,
                )
            except asyncio.TimeoutError:
                pass

    # --- BaseScheduler abstract methods (sync wrappers) -----------------------

    def _start_loop(self) -> None:
        """Sync start — gets or creates an event loop and schedules the async loop."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        self._stop_event = asyncio.Event()
        self._task = loop.create_task(self._run_loop())

    def _stop_loop(self) -> None:
        """Sync stop — signals the async loop to exit."""
        if self._stop_event:
            self._stop_event.set()
        if self._task and not self._task.done():
            self._task.cancel()
