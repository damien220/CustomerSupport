"""Abstract base scheduler."""

from __future__ import annotations

import signal
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Optional

from ..config import SchedulerConfig
from ..enums import JobState
from ..events.job_event import EventType, JobEvent
from ..events.listener import JobListener
from ..exceptions import ScheduleConflictError, SchedulerNotRunningError
from ..executors.base_executor import BaseExecutor
from ..jobs.base_job import BaseJob
from ..models import JobContext, JobDescriptor, RetryPolicy
from ..stores.base_store import BaseJobStore
from ..triggers.base_trigger import BaseTrigger


class BaseScheduler(ABC):
    """Core orchestrator — maintains the job registry, runs the scheduling loop,
    and dispatches jobs to the executor.

    Subclasses implement ``_start_loop`` and ``_stop_loop`` to control
    how the tick loop runs (thread, asyncio task, etc.).
    """

    def __init__(
        self,
        store: BaseJobStore,
        executor: BaseExecutor,
        config: Optional[SchedulerConfig] = None,
    ) -> None:
        self._store = store
        self._executor = executor
        self._config = config or SchedulerConfig()
        self._listeners: list[JobListener] = []
        self._triggers: dict[str, BaseTrigger] = {}  # job_id -> trigger
        self._jobs: dict[str, BaseJob] = {}  # job_id -> job instance
        self._running = False
        self._original_sigterm = None
        self._original_sigint = None

    # --- Public API -----------------------------------------------------------

    @property
    def is_running(self) -> bool:
        return self._running

    def add_job(
        self,
        job: BaseJob,
        trigger: BaseTrigger,
        *,
        job_id: Optional[str] = None,
        name: Optional[str] = None,
        priority: Optional["Priority"] = None,
        parameters: Optional[dict] = None,
        retry_policy: Optional[RetryPolicy] = None,
    ) -> str:
        """Register a job with its trigger.

        Returns the job_id.
        """
        from ..enums import Priority as PriorityEnum

        _id = job_id or job.job_id
        _name = name or job.name
        _priority = priority if priority is not None else PriorityEnum.NORMAL
        _retry = retry_policy or job.retry_policy

        now = datetime.now(timezone.utc)
        next_run = trigger.get_next_fire_time(None, now)

        descriptor = JobDescriptor(
            job_id=_id,
            name=_name,
            priority=_priority,
            timeout=job.timeout,
            retry_policy=_retry,
            parameters=parameters or {},
            state=JobState.QUEUED if next_run else JobState.PENDING,
            next_run_time=next_run,
            created_at=now,
            updated_at=now,
        )

        self._store.add(descriptor)
        self._triggers[_id] = trigger
        self._jobs[_id] = job

        self._emit(EventType.JOB_SUBMITTED, descriptor)
        return _id

    def remove_job(self, job_id: str) -> None:
        """Unregister a job."""
        self._store.remove(job_id)
        self._triggers.pop(job_id, None)
        self._jobs.pop(job_id, None)

    def pause_job(self, job_id: str) -> None:
        descriptor = self._store.get(job_id)
        descriptor.state = JobState.PAUSED
        descriptor.updated_at = datetime.now(timezone.utc)
        self._store.update(descriptor)
        self._emit(EventType.JOB_PAUSED, descriptor)

    def resume_job(self, job_id: str) -> None:
        descriptor = self._store.get(job_id)
        if descriptor.state != JobState.PAUSED:
            return
        descriptor.state = JobState.QUEUED
        descriptor.updated_at = datetime.now(timezone.utc)
        trigger = self._triggers.get(job_id)
        if trigger:
            descriptor.next_run_time = trigger.get_next_fire_time(
                descriptor.last_run_time, datetime.now(timezone.utc)
            )
        self._store.update(descriptor)
        self._emit(EventType.JOB_RESUMED, descriptor)

    def get_job(self, job_id: str) -> JobDescriptor:
        return self._store.get(job_id)

    def get_all_jobs(self) -> list[JobDescriptor]:
        return self._store.get_all()

    def add_listener(self, listener: JobListener) -> None:
        self._listeners.append(listener)

    def remove_listener(self, listener: JobListener) -> None:
        self._listeners.remove(listener)

    # --- Lifecycle ------------------------------------------------------------

    def start(self, install_signal_handlers: bool = True) -> None:
        """Start the scheduler loop and executor.

        Args:
            install_signal_handlers: If True, install SIGTERM/SIGINT handlers
                that trigger a graceful shutdown. Set to False when running
                inside a thread or when the caller manages signals.
        """
        if self._running:
            return
        self._executor.start()
        self._running = True
        if install_signal_handlers:
            self._install_signal_handlers()
        self._emit_scheduler_event(EventType.SCHEDULER_STARTED)
        self._start_loop()

    def shutdown(self, wait: bool = True) -> None:
        """Stop the scheduler loop and executor.

        Lets currently running jobs finish up to ``config.shutdown_timeout``
        seconds, then forcefully stops.
        """
        if not self._running:
            return
        self._running = False
        self._restore_signal_handlers()
        self._stop_loop()
        self._executor.shutdown(wait=wait)
        self._emit_scheduler_event(EventType.SCHEDULER_STOPPED)

    # --- Signal handling (graceful shutdown) -----------------------------------

    def _install_signal_handlers(self) -> None:
        """Install SIGTERM/SIGINT handlers that trigger shutdown."""
        try:
            self._original_sigterm = signal.getsignal(signal.SIGTERM)
            self._original_sigint = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGTERM, self._signal_handler)
            signal.signal(signal.SIGINT, self._signal_handler)
        except (OSError, ValueError):
            # Can't install signal handlers outside the main thread — that's OK
            pass

    def _restore_signal_handlers(self) -> None:
        """Restore original signal handlers."""
        try:
            if self._original_sigterm is not None:
                signal.signal(signal.SIGTERM, self._original_sigterm)
                self._original_sigterm = None
            if self._original_sigint is not None:
                signal.signal(signal.SIGINT, self._original_sigint)
                self._original_sigint = None
        except (OSError, ValueError):
            pass

    def _signal_handler(self, signum: int, frame) -> None:
        """Handle SIGTERM/SIGINT by initiating graceful shutdown."""
        self.shutdown(wait=True)

    # --- Tick (called by the loop) -------------------------------------------

    def _tick(self) -> None:
        """One iteration of the scheduler loop: find due jobs and dispatch them."""
        now = datetime.now(timezone.utc)

        # Re-evaluate triggers for PENDING jobs (e.g. EventTrigger, DependencyTrigger)
        # that may now have a fire time even though they didn't at registration.
        self._poll_pending_triggers(now)

        due_jobs = self._store.get_due_jobs(now)

        # Sort by priority (lower value = higher priority)
        due_jobs.sort(key=lambda d: d.priority.value)

        for descriptor in due_jobs:
            job = self._jobs.get(descriptor.job_id)
            if job is None:
                continue
            self._dispatch(descriptor, job, now)

    def _poll_pending_triggers(self, now: datetime) -> None:
        """Check triggers of PENDING jobs to see if they are now ready to fire."""
        for descriptor in self._store.get_all():
            if descriptor.state not in (JobState.PENDING, JobState.QUEUED) or descriptor.next_run_time is not None:
                continue
            trigger = self._triggers.get(descriptor.job_id)
            if trigger is None:
                continue
            next_time = trigger.get_next_fire_time(descriptor.last_run_time, now)
            if next_time is not None:
                descriptor.state = JobState.QUEUED
                descriptor.next_run_time = next_time
                descriptor.updated_at = now
                self._store.update(descriptor)

    def _dispatch(self, descriptor: JobDescriptor, job: BaseJob, now: datetime) -> None:
        """Mark a job as running and submit it to the executor."""
        descriptor.state = JobState.RUNNING
        descriptor.current_attempt += 1
        descriptor.updated_at = now
        self._store.update(descriptor)

        self._emit(EventType.JOB_STARTED, descriptor)

        context = JobContext(
            job_id=descriptor.job_id,
            job_name=descriptor.name,
            attempt=descriptor.current_attempt,
            parameters=descriptor.parameters,
            scheduled_time=descriptor.next_run_time,
        )

        self._executor.submit(
            job.run,
            context,
            callback=lambda result: self._on_job_done(descriptor.job_id, result),
        )

    def _on_job_done(self, job_id: str, result) -> None:
        """Handle job completion — update state, schedule retries or next run."""
        from ..models import JobResult

        try:
            descriptor = self._store.get(job_id)
        except Exception:
            return

        now = datetime.now(timezone.utc)
        descriptor.last_run_time = now
        descriptor.updated_at = now

        if result.succeeded:
            descriptor.state = JobState.SUCCEEDED
            self._store.update(descriptor)
            self._emit(EventType.JOB_SUCCEEDED, descriptor)

            # Schedule next run if trigger provides one
            self._schedule_next(descriptor)
        else:
            # Check retry
            policy = descriptor.retry_policy
            if (
                result.error
                and policy.should_retry(result.error)
                and descriptor.current_attempt < policy.max_retries
            ):
                descriptor.state = JobState.RETRYING
                delay = policy.get_delay(descriptor.current_attempt)
                from datetime import timedelta
                descriptor.next_run_time = now + timedelta(seconds=delay)
                self._store.update(descriptor)
                self._emit(EventType.JOB_RETRYING, descriptor)
            else:
                descriptor.state = JobState.FAILED
                descriptor.next_run_time = None
                self._store.update(descriptor)
                self._emit(
                    EventType.JOB_FAILED,
                    descriptor,
                    error_message=result.error_message,
                )

    def _schedule_next(self, descriptor: JobDescriptor) -> None:
        """Compute the next run time from the trigger and update the store."""
        trigger = self._triggers.get(descriptor.job_id)
        if trigger is None:
            descriptor.next_run_time = None
            self._store.update(descriptor)
            return

        now = datetime.now(timezone.utc)
        next_time = trigger.get_next_fire_time(descriptor.last_run_time, now)
        if next_time is not None:
            descriptor.state = JobState.QUEUED
            descriptor.next_run_time = next_time
            descriptor.current_attempt = 0
        else:
            # Trigger returned None — could be exhausted or waiting for an
            # external signal (EventTrigger, DependencyTrigger).
            # Check if the trigger can potentially fire again.
            if self._is_rearmable_trigger(trigger):
                descriptor.state = JobState.PENDING
                descriptor.current_attempt = 0
            # else: leave the current terminal state (SUCCEEDED/FAILED) as-is
            descriptor.next_run_time = None
        descriptor.updated_at = datetime.now(timezone.utc)
        self._store.update(descriptor)

    @staticmethod
    def _is_rearmable_trigger(trigger: BaseTrigger) -> bool:
        """Check if a trigger can potentially fire again in the future.

        EventTrigger and DependencyTrigger may fire again even though they
        currently return None from get_next_fire_time. Time-based triggers
        (Date, Immediate) returning None means they are exhausted.
        """
        from ..triggers.event_trigger import EventTrigger as ET
        from ..triggers.dependency_trigger import DependencyTrigger as DT
        if isinstance(trigger, ET):
            return trigger._max_fires is None or trigger._accepted_count < trigger._max_fires
        if isinstance(trigger, DT):
            return not trigger._fired
        return False

    # --- Event helpers --------------------------------------------------------

    def _emit(
        self,
        event_type: EventType,
        descriptor: JobDescriptor,
        error_message: Optional[str] = None,
    ) -> None:
        event = JobEvent(
            event_type=event_type,
            job_id=descriptor.job_id,
            job_name=descriptor.name,
            state=descriptor.state,
            attempt=descriptor.current_attempt,
            error_message=error_message,
        )
        for listener in self._listeners:
            if listener.accepts(event_type):
                try:
                    listener.on_event(event)
                except Exception:
                    pass  # listeners must not break the scheduler

    def _emit_scheduler_event(self, event_type: EventType) -> None:
        event = JobEvent(
            event_type=event_type,
            job_id="",
            job_name="scheduler",
        )
        for listener in self._listeners:
            if listener.accepts(event_type):
                try:
                    listener.on_event(event)
                except Exception:
                    pass

    # --- Abstract: subclass must implement ------------------------------------

    @abstractmethod
    def _start_loop(self) -> None:
        """Start the tick loop (thread, asyncio task, etc.)."""
        ...

    @abstractmethod
    def _stop_loop(self) -> None:
        """Stop the tick loop."""
        ...
