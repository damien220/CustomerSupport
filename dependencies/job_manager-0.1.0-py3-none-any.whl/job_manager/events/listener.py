"""Job event listeners — Observer pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, Optional

from .job_event import EventType, JobEvent


class JobListener(ABC):
    """Abstract listener that reacts to job lifecycle events."""

    @abstractmethod
    def on_event(self, event: JobEvent) -> None:
        """Handle an incoming job event."""
        ...

    def accepts(self, event_type: EventType) -> bool:
        """Return True if this listener cares about the given event type.

        Default: accept all events. Override to filter.
        """
        return True


class CallbackListener(JobListener):
    """Concrete listener that delegates to a plain callback function.

    Usage:
        listener = CallbackListener(my_func, event_types={EventType.JOB_FAILED})
        scheduler.add_listener(listener)
    """

    def __init__(
        self,
        callback: Callable[[JobEvent], None],
        event_types: Optional[set[EventType]] = None,
    ) -> None:
        self._callback = callback
        self._event_types = event_types

    def on_event(self, event: JobEvent) -> None:
        self._callback(event)

    def accepts(self, event_type: EventType) -> bool:
        if self._event_types is None:
            return True
        return event_type in self._event_types
