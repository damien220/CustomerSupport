"""Job lifecycle events — Observer pattern."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Optional

from ..enums import JobState


class EventType(str, Enum):
    """Types of events emitted during a job's lifecycle."""

    JOB_SUBMITTED = "job_submitted"
    JOB_QUEUED = "job_queued"
    JOB_STARTED = "job_started"
    JOB_SUCCEEDED = "job_succeeded"
    JOB_FAILED = "job_failed"
    JOB_RETRYING = "job_retrying"
    JOB_CANCELLED = "job_cancelled"
    JOB_PAUSED = "job_paused"
    JOB_RESUMED = "job_resumed"
    JOB_SKIPPED = "job_skipped"
    JOB_TIMEOUT = "job_timeout"
    SCHEDULER_STARTED = "scheduler_started"
    SCHEDULER_STOPPED = "scheduler_stopped"


@dataclass(frozen=True)
class JobEvent:
    """Immutable event emitted at job lifecycle transitions."""

    event_type: EventType
    job_id: str
    job_name: str = ""
    state: Optional[JobState] = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    attempt: int = 0
    error_message: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)
