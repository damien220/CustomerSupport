"""Job Manager — Abstract, reusable Task Scheduler & Job Manager.

Quick start:
    from job_manager import (
        BackgroundScheduler, MemoryJobStore, ThreadPoolExecutor,
        BaseJob, IntervalTrigger, JobContext,
    )

    class MyJob(BaseJob):
        def execute(self, context: JobContext):
            print(f"Running {context.job_name}")

    store = MemoryJobStore()
    executor = ThreadPoolExecutor(max_workers=4)
    scheduler = BackgroundScheduler(store, executor)
    scheduler.add_job(MyJob(name="hello"), IntervalTrigger(seconds=10))
    scheduler.start()
"""

# Enums
from .enums import BackoffType, JobState, Priority

# Config
from .config import SchedulerConfig

# Models
from .models import JobContext, JobDescriptor, JobResult, RetryPolicy

# Exceptions
from .exceptions import (
    ExecutionTimeoutError,
    InvalidTriggerError,
    JobError,
    JobNotFoundError,
    MaxRetriesExceededError,
    ScheduleConflictError,
    SchedulerError,
    SchedulerNotRunningError,
)

# Jobs
from .jobs import BaseJob

# Triggers
from .triggers import (
    BaseTrigger,
    CronTrigger,
    DateTrigger,
    DependencyTrigger,
    EventTrigger,
    ImmediateTrigger,
    IntervalTrigger,
)

# Executors
from .executors import AsyncExecutor, BaseExecutor, ProcessPoolExecutor, ThreadPoolExecutor

# Stores
from .stores import BaseJobStore, DatabaseJobStore, MemoryJobStore

# Schedulers
from .schedulers import AsyncScheduler, BackgroundScheduler, BaseScheduler

# Events
from .events import CallbackListener, EventType, JobEvent, JobListener

# Integrations (optional — graceful degradation if sibling packages missing)
from .integrations import CachedJobStore, LoggingMixin, NotificationListener, setup_job_logging

__all__ = [
    # Enums
    "BackoffType",
    "JobState",
    "Priority",
    # Config
    "SchedulerConfig",
    # Models
    "JobContext",
    "JobDescriptor",
    "JobResult",
    "RetryPolicy",
    # Exceptions
    "ExecutionTimeoutError",
    "InvalidTriggerError",
    "JobError",
    "JobNotFoundError",
    "MaxRetriesExceededError",
    "ScheduleConflictError",
    "SchedulerError",
    "SchedulerNotRunningError",
    # Jobs
    "BaseJob",
    # Triggers
    "BaseTrigger",
    "CronTrigger",
    "DateTrigger",
    "DependencyTrigger",
    "EventTrigger",
    "ImmediateTrigger",
    "IntervalTrigger",
    # Executors
    "AsyncExecutor",
    "BaseExecutor",
    "ProcessPoolExecutor",
    "ThreadPoolExecutor",
    # Stores
    "BaseJobStore",
    "DatabaseJobStore",
    "MemoryJobStore",
    # Schedulers
    "AsyncScheduler",
    "BackgroundScheduler",
    "BaseScheduler",
    # Events
    "CallbackListener",
    "EventType",
    "JobEvent",
    "JobListener",
    # Integrations
    "CachedJobStore",
    "LoggingMixin",
    "NotificationListener",
    "setup_job_logging",
]
