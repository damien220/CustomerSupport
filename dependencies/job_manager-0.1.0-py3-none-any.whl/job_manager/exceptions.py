"""Domain-specific exceptions for the Job Manager package.

Extends BaseAppException from the Error-Exception_Handler sibling package
when available; falls back to a minimal standalone base otherwise.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:

    class BaseAppException(Exception):  # type: ignore[no-redef]
        """Minimal fallback when Error-Exception_Handler is not installed."""

        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.code = code
            self.status_code = status_code
            self.details = details or {}
            self.previous = previous


# --- Job-level exceptions ---------------------------------------------------

class JobError(BaseAppException):
    """Base exception for all job-related errors."""

    def __init__(
        self,
        message: str = "A job error occurred",
        *,
        code: str = "JOB_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code=code, status_code=status_code,
            details=details, previous=previous,
        )


class JobNotFoundError(JobError):
    """Raised when a requested job does not exist in the store."""

    def __init__(
        self,
        message: str = "Job not found",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="JOB_NOT_FOUND", status_code=404,
            details=details, previous=previous,
        )


class ExecutionTimeoutError(JobError):
    """Raised when a job exceeds its configured timeout."""

    def __init__(
        self,
        message: str = "Job execution timed out",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="EXECUTION_TIMEOUT", status_code=408,
            details=details, previous=previous,
        )


class MaxRetriesExceededError(JobError):
    """Raised when a job has exhausted all retry attempts."""

    def __init__(
        self,
        message: str = "Maximum retries exceeded",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="MAX_RETRIES_EXCEEDED", status_code=500,
            details=details, previous=previous,
        )


# --- Scheduler-level exceptions ----------------------------------------------

class SchedulerError(BaseAppException):
    """Base exception for scheduler-related errors."""

    def __init__(
        self,
        message: str = "A scheduler error occurred",
        *,
        code: str = "SCHEDULER_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code=code, status_code=status_code,
            details=details, previous=previous,
        )


class ScheduleConflictError(SchedulerError):
    """Raised when a job ID is already registered."""

    def __init__(
        self,
        message: str = "Schedule conflict — job ID already exists",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="SCHEDULE_CONFLICT", status_code=409,
            details=details, previous=previous,
        )


class SchedulerNotRunningError(SchedulerError):
    """Raised when an operation requires a running scheduler."""

    def __init__(
        self,
        message: str = "Scheduler is not running",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="SCHEDULER_NOT_RUNNING", status_code=409,
            details=details, previous=previous,
        )


# --- Trigger-level exceptions ------------------------------------------------

class InvalidTriggerError(BaseAppException):
    """Raised when a trigger configuration is invalid."""

    def __init__(
        self,
        message: str = "Invalid trigger configuration",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message, code="INVALID_TRIGGER", status_code=400,
            details=details, previous=previous,
        )
