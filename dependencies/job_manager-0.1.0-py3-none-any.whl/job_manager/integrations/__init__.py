"""Optional integrations with sibling packages.

Each integration gracefully degrades if its sibling package is not installed.
"""

from .logger_integration import LoggingMixin, setup_job_logging
from .cache_integration import CachedJobStore
from .notification_integration import NotificationListener

__all__ = [
    "LoggingMixin",
    "setup_job_logging",
    "CachedJobStore",
    "NotificationListener",
]
