"""Logger integration with the Logger_Package sibling.

Provides:
    - ``LoggingMixin``: drop-in mixin for BaseScheduler that adds structured,
      context-bound logging to every lifecycle event.
    - ``setup_job_logging()``: convenience function to configure logging for
      the job manager subsystem.

Gracefully falls back to stdlib ``logging`` if ``logger_pkg`` is not installed.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Generator, Optional

try:
    from logger_pkg import (
        get_logger as _get_logger,
        setup_logging as _setup_logging,
        bind_context as _bind_context,
        bound_context as _bound_context,
    )
    _HAS_LOGGER_PKG = True
except ImportError:
    _HAS_LOGGER_PKG = False
    _get_logger = None
    _setup_logging = None
    _bind_context = None
    _bound_context = None


def get_logger(name: str) -> logging.Logger:
    """Get a logger — uses logger_pkg if available, else stdlib."""
    if _HAS_LOGGER_PKG:
        return _get_logger(name)
    return logging.getLogger(name)


def setup_job_logging(**kwargs: Any) -> None:
    """Configure logging for the job manager subsystem.

    Forwards all kwargs to ``logger_pkg.setup_logging()`` if available.
    Otherwise configures stdlib logging at INFO level.
    """
    if _HAS_LOGGER_PKG:
        _setup_logging(**kwargs)
    else:
        logging.basicConfig(
            level=kwargs.get("level", logging.INFO),
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )


@contextmanager
def job_context(**fields: Any) -> Generator[None, None, None]:
    """Bind context fields (job_id, scheduler_id, etc.) for the duration of a block.

    Uses ``logger_pkg.bound_context`` if available, else a no-op.
    """
    if _HAS_LOGGER_PKG and _bound_context is not None:
        with _bound_context(**fields):
            yield
    else:
        yield


class LoggingMixin:
    """Mixin that adds structured logging to a scheduler.

    Add this to a scheduler's MRO to get automatic logging for all
    job lifecycle events. Uses ``logger_pkg`` context propagation when
    available.

    Usage:
        class MyScheduler(LoggingMixin, BackgroundScheduler):
            pass

        scheduler = MyScheduler(store, executor)
        # All events are now logged with context (job_id, scheduler_id, etc.)
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

    @property
    def _log(self) -> logging.Logger:
        if not hasattr(self, "_logger_instance"):
            config = getattr(self, "_config", None)
            scheduler_id = getattr(config, "scheduler_id", "scheduler")
            self._logger_instance = get_logger(f"job_manager.{scheduler_id}")
        return self._logger_instance

    def start(self, install_signal_handlers: bool = True) -> None:
        config = getattr(self, "_config", None)
        scheduler_id = getattr(config, "scheduler_id", "default")
        self._log.info("Scheduler starting", extra={"scheduler_id": scheduler_id})
        super().start(install_signal_handlers=install_signal_handlers)
        self._log.info("Scheduler started", extra={"scheduler_id": scheduler_id})

    def shutdown(self, wait: bool = True) -> None:
        self._log.info("Scheduler shutting down", extra={"wait": wait})
        super().shutdown(wait=wait)
        self._log.info("Scheduler stopped")

    def _dispatch(self, descriptor, job, now) -> None:
        self._log.info(
            "Dispatching job",
            extra={
                "job_id": descriptor.job_id,
                "job_name": descriptor.name,
                "attempt": descriptor.current_attempt + 1,
                "priority": descriptor.priority.value,
            },
        )
        super()._dispatch(descriptor, job, now)

    def _on_job_done(self, job_id: str, result) -> None:
        if result.succeeded:
            self._log.info(
                "Job succeeded",
                extra={
                    "job_id": job_id,
                    "duration_seconds": result.duration_seconds,
                    "attempt": result.attempt,
                },
            )
        else:
            self._log.warning(
                "Job failed",
                extra={
                    "job_id": job_id,
                    "error": result.error_message,
                    "attempt": result.attempt,
                    "duration_seconds": result.duration_seconds,
                },
            )
        super()._on_job_done(job_id, result)
