"""Cache integration with the Cache_manager sibling.

Provides ``CachedJobStore`` — a transparent wrapper around any ``BaseJobStore``
that caches reads via ``cache_manager``'s ``AbstractCache``.

Gracefully falls back to a pass-through if ``cache_manager`` is not installed.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from ..exceptions import JobNotFoundError
from ..models import JobDescriptor
from ..stores.base_store import BaseJobStore

try:
    from cache_manager import AbstractCache, CacheNamespace, get_cache
    _HAS_CACHE = True
except ImportError:
    AbstractCache = None  # type: ignore[assignment,misc]
    CacheNamespace = None  # type: ignore[assignment]
    get_cache = None  # type: ignore[assignment]
    _HAS_CACHE = False


class CachedJobStore(BaseJobStore):
    """Transparent caching wrapper around any BaseJobStore.

    Caches individual ``get()`` reads and invalidates on ``add/update/remove``.
    The underlying store is always the source of truth — the cache is purely
    a read-through acceleration layer.

    Usage with cache_manager installed:
        from cache_manager import get_cache
        from job_manager import MemoryJobStore
        from job_manager.integrations import CachedJobStore

        inner_store = MemoryJobStore()
        cache = get_cache("memory", max_size=500)
        store = CachedJobStore(inner_store, cache, namespace="jobs")

    Usage without cache_manager (pass-through):
        store = CachedJobStore(inner_store)
    """

    def __init__(
        self,
        store: BaseJobStore,
        cache: Optional[Any] = None,
        namespace: str = "job_store",
        ttl: Optional[int] = 300,
    ) -> None:
        self._store = store
        self._ttl = ttl

        if cache is not None and _HAS_CACHE:
            self._cache: Optional[Any] = CacheNamespace(cache, namespace)
        else:
            self._cache = None

    # --- BaseJobStore implementation ------------------------------------------

    def add(self, descriptor: JobDescriptor) -> None:
        self._store.add(descriptor)
        self._cache_put(descriptor)

    def update(self, descriptor: JobDescriptor) -> None:
        self._store.update(descriptor)
        self._cache_put(descriptor)

    def remove(self, job_id: str) -> None:
        self._store.remove(job_id)
        self._cache_delete(job_id)

    def get(self, job_id: str) -> JobDescriptor:
        # Try cache first
        cached = self._cache_get(job_id)
        if cached is not None:
            return cached

        # Cache miss — fetch from store
        descriptor = self._store.get(job_id)
        self._cache_put(descriptor)
        return descriptor

    def get_all(self) -> list[JobDescriptor]:
        # Always go to the source for listing
        return self._store.get_all()

    def get_due_jobs(self, now: datetime) -> list[JobDescriptor]:
        # Always go to the source for due-job queries
        return self._store.get_due_jobs(now)

    def get_next_run_time(self) -> Optional[datetime]:
        return self._store.get_next_run_time()

    # --- Cache helpers --------------------------------------------------------

    def _cache_key(self, job_id: str) -> str:
        return f"desc:{job_id}"

    def _cache_put(self, descriptor: JobDescriptor) -> None:
        if self._cache is None:
            return
        try:
            self._cache.set(self._cache_key(descriptor.job_id), descriptor.to_dict(), ttl=self._ttl)
        except Exception:
            pass  # cache failures must not break the store

    def _cache_get(self, job_id: str) -> Optional[JobDescriptor]:
        if self._cache is None:
            return None
        try:
            data = self._cache.get(self._cache_key(job_id))
            if data is not None:
                return JobDescriptor.from_dict(data)
        except Exception:
            pass
        return None

    def _cache_delete(self, job_id: str) -> None:
        if self._cache is None:
            return
        try:
            self._cache.delete(self._cache_key(job_id))
        except Exception:
            pass

    def clear_cache(self) -> None:
        """Manually clear the entire job cache."""
        if self._cache is not None:
            try:
                self._cache.clear()
            except Exception:
                pass
