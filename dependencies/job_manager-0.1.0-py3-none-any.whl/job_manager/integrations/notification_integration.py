"""Notification integration with the Notification_manager sibling.

Provides ``NotificationListener`` — a ``JobListener`` that sends notifications
on configurable job lifecycle events via the Notification_manager.

Gracefully degrades if ``notification_manager`` is not installed.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Optional

from ..events.job_event import EventType, JobEvent
from ..events.listener import JobListener

try:
    from notification_manager import (
        NotificationManager,
        Notification,
        Recipient,
    )
    from notification_manager import Priority as NMPriority
    _HAS_NOTIFICATIONS = True
except ImportError:
    _HAS_NOTIFICATIONS = False
    NotificationManager = None  # type: ignore[assignment,misc]
    Notification = None  # type: ignore[assignment]
    Recipient = None  # type: ignore[assignment]
    NMPriority = None  # type: ignore[assignment]

# Default event-to-notification mapping
_DEFAULT_EVENTS = {
    EventType.JOB_FAILED,
    EventType.JOB_SUCCEEDED,
    EventType.JOB_TIMEOUT,
}

_EVENT_PRIORITY_MAP = {
    EventType.JOB_FAILED: "HIGH",
    EventType.JOB_TIMEOUT: "HIGH",
    EventType.JOB_SUCCEEDED: "LOW",
    EventType.JOB_STARTED: "LOW",
    EventType.JOB_RETRYING: "NORMAL",
    EventType.SCHEDULER_STOPPED: "NORMAL",
}


class NotificationListener(JobListener):
    """Sends notifications on job lifecycle events.

    Usage:
        from notification_manager import NotificationManager, PluginRegistry

        registry = PluginRegistry()
        registry.register(my_slack_plugin)
        nm = NotificationManager(registry)

        listener = NotificationListener(
            manager=nm,
            recipient_id="ops-team",
            channel="slack",
            event_types={EventType.JOB_FAILED, EventType.JOB_TIMEOUT},
        )
        scheduler.add_listener(listener)

    Without notification_manager installed, this listener is a no-op.
    """

    def __init__(
        self,
        manager: Optional[Any] = None,
        recipient_id: str = "default",
        channel: Optional[str] = None,
        event_types: Optional[set[EventType]] = None,
        title_builder: Optional[Callable[[JobEvent], str]] = None,
        body_builder: Optional[Callable[[JobEvent], str]] = None,
    ) -> None:
        self._manager = manager
        self._recipient_id = recipient_id
        self._channel = channel
        self._event_types = event_types or _DEFAULT_EVENTS
        self._title_builder = title_builder or self._default_title
        self._body_builder = body_builder or self._default_body

    def accepts(self, event_type: EventType) -> bool:
        return event_type in self._event_types

    def on_event(self, event: JobEvent) -> None:
        if not _HAS_NOTIFICATIONS or self._manager is None:
            return

        title = self._title_builder(event)
        body = self._body_builder(event)

        priority_name = _EVENT_PRIORITY_MAP.get(event.event_type, "NORMAL")
        priority = getattr(NMPriority, priority_name, NMPriority.NORMAL)

        notification = Notification(
            title=title,
            body=body,
            recipient=Recipient(id=self._recipient_id),
            channel_hint=self._channel,
            priority=priority,
            metadata={
                "job_id": event.job_id,
                "job_name": event.job_name,
                "event_type": event.event_type.value,
                "attempt": event.attempt,
            },
        )

        # Send asynchronously — don't block the scheduler
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._manager.send(notification))
        except RuntimeError:
            # No running loop — fire and forget in a new thread
            import threading
            threading.Thread(
                target=self._send_sync,
                args=(notification,),
                daemon=True,
            ).start()

    def _send_sync(self, notification: Any) -> None:
        """Send a notification synchronously by creating a temporary event loop."""
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(self._manager.send(notification))
            loop.close()
        except Exception:
            pass  # notification failures must not break the scheduler

    @staticmethod
    def _default_title(event: JobEvent) -> str:
        type_labels = {
            EventType.JOB_FAILED: "Job Failed",
            EventType.JOB_SUCCEEDED: "Job Succeeded",
            EventType.JOB_TIMEOUT: "Job Timed Out",
            EventType.JOB_RETRYING: "Job Retrying",
            EventType.JOB_STARTED: "Job Started",
            EventType.JOB_CANCELLED: "Job Cancelled",
            EventType.SCHEDULER_STARTED: "Scheduler Started",
            EventType.SCHEDULER_STOPPED: "Scheduler Stopped",
        }
        label = type_labels.get(event.event_type, event.event_type.value)
        return f"[Job Manager] {label}: {event.job_name or event.job_id}"

    @staticmethod
    def _default_body(event: JobEvent) -> str:
        lines = [
            f"Job: {event.job_name} ({event.job_id})",
            f"Event: {event.event_type.value}",
            f"Timestamp: {event.timestamp.isoformat()}",
        ]
        if event.attempt:
            lines.append(f"Attempt: {event.attempt}")
        if event.error_message:
            lines.append(f"Error: {event.error_message}")
        return "\n".join(lines)
