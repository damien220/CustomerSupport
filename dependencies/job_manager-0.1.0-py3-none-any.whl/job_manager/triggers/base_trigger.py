"""Abstract base trigger — Strategy pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional


class BaseTrigger(ABC):
    """Determines *when* a job should fire next.

    Each scheduling strategy (cron, interval, date, immediate, etc.)
    is a concrete subclass implementing ``get_next_fire_time``.
    """

    @abstractmethod
    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        """Return the next datetime this trigger should fire.

        Args:
            previous_fire_time: The last time the trigger fired, or None
                                if it has never fired.
            now: The current datetime (UTC).

        Returns:
            The next fire datetime (UTC), or None if the trigger is exhausted.
        """
        ...
