"""Cron-expression based trigger."""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional

from ..exceptions import InvalidTriggerError
from .base_trigger import BaseTrigger

# Mapping for weekday names
_WEEKDAY_MAP = {"MON": 1, "TUE": 2, "WED": 3, "THU": 4, "FRI": 5, "SAT": 6, "SUN": 7}


def _parse_cron_field(field: str, min_val: int, max_val: int) -> set[int]:
    """Parse a single cron field into a set of valid integer values."""
    values: set[int] = set()

    for part in field.split(","):
        part = part.strip()

        # Handle weekday names
        for name, num in _WEEKDAY_MAP.items():
            part = part.replace(name, str(num))

        # Handle range with step: e.g. 1-5/2
        range_step = re.match(r"^(\d+)-(\d+)/(\d+)$", part)
        if range_step:
            start, end, step = int(range_step[1]), int(range_step[2]), int(range_step[3])
            values.update(range(start, end + 1, step))
            continue

        # Handle wildcard with step: e.g. */5
        wild_step = re.match(r"^\*/(\d+)$", part)
        if wild_step:
            step = int(wild_step[1])
            values.update(range(min_val, max_val + 1, step))
            continue

        # Handle plain range: e.g. 1-5
        plain_range = re.match(r"^(\d+)-(\d+)$", part)
        if plain_range:
            start, end = int(plain_range[1]), int(plain_range[2])
            values.update(range(start, end + 1))
            continue

        # Wildcard
        if part == "*":
            values.update(range(min_val, max_val + 1))
            continue

        # Single value
        if part.isdigit():
            values.add(int(part))
            continue

        raise InvalidTriggerError(
            f"Invalid cron field value: '{part}'",
            details={"field": field},
        )

    return values


class CronTrigger(BaseTrigger):
    """Trigger based on a cron expression.

    Supports standard 5-field cron: ``minute hour day_of_month month day_of_week``

    Examples:
        ``"*/5 * * * *"``   — every 5 minutes
        ``"0 9 * * MON-FRI"`` — 9 AM on weekdays
        ``"30 2 1 * *"``    — 2:30 AM on the 1st of every month
    """

    def __init__(self, expression: str, *, end_date: Optional[datetime] = None) -> None:
        parts = expression.strip().split()
        if len(parts) != 5:
            raise InvalidTriggerError(
                f"Cron expression must have 5 fields, got {len(parts)}: '{expression}'",
            )

        self.expression = expression
        self.end_date = end_date
        self._minutes = _parse_cron_field(parts[0], 0, 59)
        self._hours = _parse_cron_field(parts[1], 0, 23)
        self._days = _parse_cron_field(parts[2], 1, 31)
        self._months = _parse_cron_field(parts[3], 1, 12)
        self._weekdays = _parse_cron_field(parts[4], 1, 7)  # 1=Mon .. 7=Sun

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if self.end_date and now > self.end_date:
            return None

        # Start searching from the next minute after 'now' (or previous fire)
        start = max(previous_fire_time, now) if previous_fire_time else now
        candidate = start.replace(second=0, microsecond=0) + timedelta(minutes=1)

        # Scan up to 366 days to find a match
        limit = candidate + timedelta(days=366)
        while candidate < limit:
            if (
                candidate.month in self._months
                and candidate.day in self._days
                and candidate.isoweekday() in self._weekdays
                and candidate.hour in self._hours
                and candidate.minute in self._minutes
            ):
                if self.end_date and candidate > self.end_date:
                    return None
                return candidate
            candidate += timedelta(minutes=1)

        return None
