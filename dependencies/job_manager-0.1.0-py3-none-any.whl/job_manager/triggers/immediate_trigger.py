"""Immediate trigger — fires once, right now."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from .base_trigger import BaseTrigger


class ImmediateTrigger(BaseTrigger):
    """Fires immediately upon registration, then never again."""

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if previous_fire_time is not None:
            return None
        return now
