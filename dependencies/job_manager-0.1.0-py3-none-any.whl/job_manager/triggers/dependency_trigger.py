"""Dependency (DAG) trigger — fires when all upstream jobs have succeeded."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from ..enums import JobState
from ..exceptions import InvalidTriggerError
from .base_trigger import BaseTrigger

if TYPE_CHECKING:
    from ..stores.base_store import BaseJobStore


class DependencyTrigger(BaseTrigger):
    """Fires when **all** upstream dependency jobs reach ``SUCCEEDED`` state.

    This enables DAG-style execution: Job C depends on Jobs A and B,
    so C only runs after both A and B have completed successfully.

    Args:
        upstream_job_ids: Set of job IDs that must succeed before this trigger fires.
        store:            Reference to the job store (used to check upstream states).

    Raises:
        InvalidTriggerError: If upstream_job_ids is empty or contains a cycle
                             (cycle detection is the caller's responsibility at
                             registration time — see ``validate_dag``).
    """

    def __init__(
        self,
        upstream_job_ids: set[str],
        store: "BaseJobStore",
    ) -> None:
        if not upstream_job_ids:
            raise InvalidTriggerError(
                "DependencyTrigger requires at least one upstream job ID",
            )
        self._upstream_ids = frozenset(upstream_job_ids)
        self._store = store
        self._fired = False

    @property
    def upstream_job_ids(self) -> frozenset[str]:
        return self._upstream_ids

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        # Once fired, don't fire again
        if previous_fire_time is not None or self._fired:
            return None

        # Check if all upstream jobs have succeeded
        if self._all_upstreams_succeeded():
            self._fired = True
            return now

        # Not yet ready — return a near-future time so the scheduler re-checks
        return None

    def _all_upstreams_succeeded(self) -> bool:
        """Check the store to see if every upstream job is in SUCCEEDED state."""
        for job_id in self._upstream_ids:
            try:
                descriptor = self._store.get(job_id)
            except Exception:
                return False
            if descriptor.state != JobState.SUCCEEDED:
                return False
        return True

    @staticmethod
    def validate_dag(
        dependencies: dict[str, set[str]],
    ) -> bool:
        """Validate that a dependency graph has no cycles.

        Args:
            dependencies: Mapping of job_id -> set of upstream job_ids.

        Returns:
            True if the graph is a valid DAG (no cycles).

        Raises:
            InvalidTriggerError: If a cycle is detected.
        """
        # Kahn's algorithm for topological sort / cycle detection
        in_degree: dict[str, int] = {}
        graph: dict[str, set[str]] = {}

        all_nodes: set[str] = set()
        for node, upstreams in dependencies.items():
            all_nodes.add(node)
            all_nodes.update(upstreams)

        for node in all_nodes:
            in_degree.setdefault(node, 0)
            graph.setdefault(node, set())

        for node, upstreams in dependencies.items():
            for upstream in upstreams:
                graph.setdefault(upstream, set()).add(node)
                in_degree[node] = in_degree.get(node, 0) + 1

        queue = [n for n, deg in in_degree.items() if deg == 0]
        visited = 0

        while queue:
            current = queue.pop(0)
            visited += 1
            for downstream in graph.get(current, set()):
                in_degree[downstream] -= 1
                if in_degree[downstream] == 0:
                    queue.append(downstream)

        if visited != len(all_nodes):
            raise InvalidTriggerError(
                "Dependency graph contains a cycle",
                details={"nodes": list(all_nodes), "dependencies": {k: list(v) for k, v in dependencies.items()}},
            )
        return True
