"""One-shot date trigger — fires exactly once at a specific datetime."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from .base_trigger import BaseTrigger


class DateTrigger(BaseTrigger):
    """Fires once at a specific datetime, then never again.

    Args:
        run_date: The exact datetime (UTC) to fire.
    """

    def __init__(self, run_date: datetime) -> None:
        self.run_date = run_date

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        # If it already fired, it's exhausted
        if previous_fire_time is not None:
            return None
        # If the run_date is still in the future (or now), return it
        if self.run_date >= now:
            return self.run_date
        return None
