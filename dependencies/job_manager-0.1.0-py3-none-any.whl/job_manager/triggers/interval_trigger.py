"""Interval-based trigger — fires every N seconds/minutes/hours/days."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from ..exceptions import InvalidTriggerError
from .base_trigger import BaseTrigger


class IntervalTrigger(BaseTrigger):
    """Fires repeatedly at a fixed interval.

    Args:
        seconds:    Interval in seconds (can combine with other units).
        minutes:    Interval in minutes.
        hours:      Interval in hours.
        days:       Interval in days.
        start_date: Earliest allowed fire time.
        end_date:   Latest allowed fire time (None = no end).
    """

    def __init__(
        self,
        *,
        seconds: float = 0,
        minutes: float = 0,
        hours: float = 0,
        days: float = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> None:
        total = timedelta(seconds=seconds, minutes=minutes, hours=hours, days=days)
        if total.total_seconds() <= 0:
            raise InvalidTriggerError(
                "Interval must be positive",
                details={"total_seconds": total.total_seconds()},
            )

        self.interval = total
        self.start_date = start_date
        self.end_date = end_date

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        if previous_fire_time is None:
            # First run — fire at start_date or now, whichever is later
            next_time = max(self.start_date, now) if self.start_date else now
        else:
            next_time = previous_fire_time + self.interval
            # If we fell behind, jump forward to the next future slot
            if next_time < now:
                missed = (now - next_time).total_seconds()
                intervals_missed = int(missed / self.interval.total_seconds()) + 1
                next_time += self.interval * intervals_missed

        if self.end_date and next_time > self.end_date:
            return None
        return next_time
