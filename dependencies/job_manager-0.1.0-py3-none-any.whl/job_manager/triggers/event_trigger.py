"""Event-driven trigger — fires in response to named external events."""

from __future__ import annotations

import threading
from datetime import datetime
from typing import Any, Optional

from .base_trigger import BaseTrigger


class EventTrigger(BaseTrigger):
    """Fires when an external event is signalled by name.

    Unlike time-based triggers, this trigger does not compute a future datetime.
    Instead, it waits until ``fire()`` is called explicitly (e.g., by a webhook
    handler, a file-watcher, or a message consumer).

    Args:
        event_name: Logical name of the event this trigger listens for.
        max_fires:  Maximum number of times this trigger can fire (None = unlimited).

    Usage:
        trigger = EventTrigger("file_uploaded")
        scheduler.add_job(my_job, trigger)

        # Later, when the event occurs:
        trigger.fire(payload={"path": "/data/file.csv"})
    """

    def __init__(
        self,
        event_name: str,
        *,
        max_fires: Optional[int] = None,
    ) -> None:
        self.event_name = event_name
        self._max_fires = max_fires
        self._fire_count = 0       # how many times get_next_fire_time consumed
        self._accepted_count = 0   # how many times fire() was accepted
        self._pending = False
        self._payload: dict[str, Any] = {}
        self._lock = threading.Lock()

    def fire(self, payload: Optional[dict[str, Any]] = None) -> bool:
        """Signal that the event has occurred.

        Args:
            payload: Optional data associated with this event occurrence.

        Returns:
            True if the trigger accepted the fire, False if exhausted.
        """
        with self._lock:
            if self._max_fires is not None and self._accepted_count >= self._max_fires:
                return False
            self._pending = True
            self._accepted_count += 1
            self._payload = payload or {}
            return True

    @property
    def payload(self) -> dict[str, Any]:
        """Data from the most recent ``fire()`` call."""
        return self._payload

    @property
    def fire_count(self) -> int:
        return self._fire_count

    def get_next_fire_time(
        self,
        previous_fire_time: Optional[datetime],
        now: datetime,
    ) -> Optional[datetime]:
        with self._lock:
            if not self._pending:
                return None

            if self._max_fires is not None and self._fire_count >= self._max_fires:
                return None

            # Consume the pending signal
            self._pending = False
            self._fire_count += 1
            return now
