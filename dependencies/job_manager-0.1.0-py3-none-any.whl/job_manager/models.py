"""Core data models for the Job Manager package."""

from __future__ import annotations

import random
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional, Type

from .enums import BackoffType, JobState, Priority


@dataclass
class RetryPolicy:
    """Configuration for job retry behavior."""

    max_retries: int = 3
    backoff_type: BackoffType = BackoffType.EXPONENTIAL
    base_delay: float = 1.0
    max_delay: float = 300.0
    retry_on: tuple[Type[Exception], ...] = (Exception,)

    def get_delay(self, attempt: int) -> float:
        """Calculate delay in seconds for the given attempt number."""
        if self.backoff_type == BackoffType.FIXED:
            delay = self.base_delay
        elif self.backoff_type == BackoffType.EXPONENTIAL:
            delay = self.base_delay * (2 ** attempt)
        elif self.backoff_type == BackoffType.EXPONENTIAL_JITTER:
            delay = self.base_delay * (2 ** attempt)
            delay = random.uniform(0, delay)  # noqa: S311
        else:
            delay = self.base_delay

        return min(delay, self.max_delay)

    def should_retry(self, exception: Exception) -> bool:
        """Check if the exception type is retryable."""
        return isinstance(exception, self.retry_on)


@dataclass
class JobResult:
    """Standardized result of a job execution."""

    job_id: str
    state: JobState
    return_value: Any = None
    error: Optional[Exception] = None
    error_message: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    attempt: int = 1

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    @property
    def succeeded(self) -> bool:
        return self.state == JobState.SUCCEEDED


@dataclass
class JobContext:
    """Runtime context passed into a job's execute() method."""

    job_id: str
    job_name: str
    attempt: int = 1
    parameters: dict[str, Any] = field(default_factory=dict)
    scheduled_time: Optional[datetime] = None
    cancellation_event: threading.Event = field(default_factory=threading.Event)

    @property
    def is_cancelled(self) -> bool:
        return self.cancellation_event.is_set()

    def cancel(self) -> None:
        self.cancellation_event.set()

    def __getstate__(self) -> dict:
        """Make JobContext picklable for ProcessPoolExecutor."""
        state = self.__dict__.copy()
        state.pop("cancellation_event", None)
        return state

    def __setstate__(self, state: dict) -> None:
        self.__dict__.update(state)
        self.cancellation_event = threading.Event()


@dataclass
class JobDescriptor:
    """Complete description of a registered job — ties a job, trigger, and metadata together."""

    job_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    name: str = ""
    job_class_path: str = ""
    priority: Priority = Priority.NORMAL
    timeout: Optional[float] = None
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    tags: set[str] = field(default_factory=set)
    parameters: dict[str, Any] = field(default_factory=dict)
    trigger_id: Optional[str] = None
    state: JobState = JobState.PENDING
    current_attempt: int = 0
    next_run_time: Optional[datetime] = None
    last_run_time: Optional[datetime] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "name": self.name,
            "job_class_path": self.job_class_path,
            "priority": self.priority.value,
            "timeout": self.timeout,
            "retry_policy": {
                "max_retries": self.retry_policy.max_retries,
                "backoff_type": self.retry_policy.backoff_type.value,
                "base_delay": self.retry_policy.base_delay,
                "max_delay": self.retry_policy.max_delay,
            },
            "tags": list(self.tags),
            "parameters": self.parameters,
            "trigger_id": self.trigger_id,
            "state": self.state.value,
            "current_attempt": self.current_attempt,
            "next_run_time": self.next_run_time.isoformat() if self.next_run_time else None,
            "last_run_time": self.last_run_time.isoformat() if self.last_run_time else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JobDescriptor":
        return cls(
            job_id=data["job_id"],
            name=data.get("name", ""),
            job_class_path=data.get("job_class_path", ""),
            priority=Priority(data.get("priority", Priority.NORMAL.value)),
            timeout=data.get("timeout"),
            retry_policy=RetryPolicy(
                max_retries=data.get("retry_policy", {}).get("max_retries", 3),
                backoff_type=BackoffType(
                    data.get("retry_policy", {}).get("backoff_type", BackoffType.EXPONENTIAL.value)
                ),
                base_delay=data.get("retry_policy", {}).get("base_delay", 1.0),
                max_delay=data.get("retry_policy", {}).get("max_delay", 300.0),
            ),
            tags=set(data.get("tags", [])),
            parameters=data.get("parameters", {}),
            trigger_id=data.get("trigger_id"),
            state=JobState(data.get("state", JobState.PENDING.value)),
            current_attempt=data.get("current_attempt", 0),
            next_run_time=(
                datetime.fromisoformat(data["next_run_time"])
                if data.get("next_run_time")
                else None
            ),
            last_run_time=(
                datetime.fromisoformat(data["last_run_time"])
                if data.get("last_run_time")
                else None
            ),
            created_at=(
                datetime.fromisoformat(data["created_at"])
                if data.get("created_at")
                else datetime.now(timezone.utc)
            ),
            updated_at=(
                datetime.fromisoformat(data["updated_at"])
                if data.get("updated_at")
                else datetime.now(timezone.utc)
            ),
        )
