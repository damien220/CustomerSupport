"""Temporal field types: Timestamp.

Timestamp enforces timezone-aware datetimes and normalises them to UTC.
The pure validator function is exported for the dataclass backend.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated

from pydantic import AfterValidator


# ---------------------------------------------------------------------------
# Pure validator function
# ---------------------------------------------------------------------------


def validate_timestamp(value: datetime) -> datetime:
    """Validate that ``value`` is timezone-aware and normalise it to UTC.

    Raises:
        ValueError: if ``value`` has no timezone information (naive datetime).
    """
    if value.tzinfo is None:
        raise ValueError(
            "Timestamp must be timezone-aware. "
            "Hint: use datetime(..., tzinfo=timezone.utc) or an ISO-8601 string with a UTC offset."
        )
    return value.astimezone(timezone.utc)


# ---------------------------------------------------------------------------
# Pydantic Annotated type
# ---------------------------------------------------------------------------

Timestamp = Annotated[datetime, AfterValidator(validate_timestamp)]
"""Timezone-aware datetime, normalised to UTC on validation.

Accepts ISO-8601 strings with offsets (``'2026-04-01T12:00:00Z'``,
``'2026-04-01T14:00:00+02:00'``) or ``datetime`` objects with ``tzinfo`` set.
Naive datetimes are rejected.
"""
