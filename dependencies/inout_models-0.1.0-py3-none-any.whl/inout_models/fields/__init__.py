"""Common field-type catalog — reusable across all consumer packages.

Pydantic Annotated types (primary backend)::

    from inout_models.fields import Email, URL, NonEmptyStr, Slug
    from inout_models.fields import PositiveInt, Money
    from inout_models.fields import UUIDField
    from inout_models.fields import Timestamp
    from inout_models.fields import Locale

Pure validator functions (for the dataclass backend ``__post_init__``)::

    from inout_models.fields import validate_email, validate_url
    from inout_models.fields import validate_positive_int, validate_money_amount
    from inout_models.fields import validate_uuid, validate_timestamp, validate_locale
"""

from inout_models.fields.identifiers import UUIDField, validate_uuid
from inout_models.fields.locale import Locale, validate_locale
from inout_models.fields.numeric import Money, PositiveInt, validate_currency_code, validate_money_amount, validate_positive_int
from inout_models.fields.strings import (
    Email,
    NonEmptyStr,
    Slug,
    URL,
    validate_email,
    validate_non_empty_str,
    validate_slug,
    validate_url,
)
from inout_models.fields.temporal import Timestamp, validate_timestamp

__all__ = [
    # String types
    "Email",
    "URL",
    "NonEmptyStr",
    "Slug",
    "validate_email",
    "validate_url",
    "validate_non_empty_str",
    "validate_slug",
    # Numeric types
    "PositiveInt",
    "Money",
    "validate_positive_int",
    "validate_money_amount",
    "validate_currency_code",
    # Identifier types
    "UUIDField",
    "validate_uuid",
    # Temporal types
    "Timestamp",
    "validate_timestamp",
    # Locale types
    "Locale",
    "validate_locale",
]
