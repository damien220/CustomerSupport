"""String field types: Email, URL, NonEmptyStr, Slug.

Each field type is an ``Annotated[str, ...]`` alias usable directly in
AbstractBaseModel subclasses.  The underlying pure-function validators are
exported so AbstractDataclassModel subclasses can call them in ``__post_init__``.
"""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import AfterValidator

# ---------------------------------------------------------------------------
# Pure validator functions (usable in __post_init__ for the dataclass backend)
# ---------------------------------------------------------------------------

# Structural email check: something@something.something, no spaces.
# Intentionally permissive of IDN/punycode TLDs (e.g. xn--90ais) — deep
# RFC-5322 validation requires the email-validator package (not a core dep).
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def validate_email(value: str) -> str:
    """Normalise to lowercase and validate basic email format.

    Raises:
        ValueError: if ``value`` is not a valid email address.
    """
    value = value.strip().lower()
    if not _EMAIL_RE.match(value):
        raise ValueError(f"Invalid email address: {value!r}")
    return value


def validate_url(value: str) -> str:
    """Validate that ``value`` is an http(s) URL with a non-empty host.

    Raises:
        ValueError: if ``value`` does not start with ``http://`` or ``https://``
            or has no host component.
    """
    value = value.strip()
    if not (value.startswith("http://") or value.startswith("https://")):
        raise ValueError(
            f"URL must start with 'http://' or 'https://': {value!r}"
        )
    host_and_rest = value.split("://", 1)[1]
    if not host_and_rest or host_and_rest.startswith("/"):
        raise ValueError(f"URL has no host component: {value!r}")
    return value


def validate_non_empty_str(value: str) -> str:
    """Validate that ``value`` is not empty or whitespace-only.

    The value is returned unchanged (stripping is intentionally left to the
    caller so field content is preserved as entered).

    Raises:
        ValueError: if ``value`` stripped is empty.
    """
    if not value.strip():
        raise ValueError("String must not be empty or whitespace-only")
    return value


def validate_slug(value: str) -> str:
    """Normalise to lowercase and validate slug format.

    A slug contains only lowercase ASCII letters, digits, and hyphens.
    It must not start or end with a hyphen, and consecutive hyphens are not
    allowed.

    Raises:
        ValueError: if ``value`` is not a valid slug after normalisation.
    """
    value = value.strip().lower()
    if not _SLUG_RE.match(value):
        raise ValueError(
            f"Slug must contain only lowercase alphanumeric characters and "
            f"single hyphens (no leading/trailing hyphens): {value!r}"
        )
    return value


# ---------------------------------------------------------------------------
# Pydantic Annotated types (primary backend)
# ---------------------------------------------------------------------------

Email = Annotated[str, AfterValidator(validate_email)]
"""Lowercase, validated email address.  Input is normalised to lowercase."""

URL = Annotated[str, AfterValidator(validate_url)]
"""Validated HTTP/HTTPS URL.  Must have a non-empty host component."""

NonEmptyStr = Annotated[str, AfterValidator(validate_non_empty_str)]
"""Non-empty string.  Whitespace-only values are rejected."""

Slug = Annotated[str, AfterValidator(validate_slug)]
"""URL-safe slug: lowercase alphanumeric characters and hyphens only.
Input is normalised to lowercase before validation."""
