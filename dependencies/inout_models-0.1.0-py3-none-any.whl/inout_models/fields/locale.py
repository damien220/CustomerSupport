"""Locale field type: Locale (BCP-47 language tag).

Validates and normalises BCP-47 language tags.  The subset supported covers
the most common forms used in APIs:

  * Language only:              ``en``, ``zh``
  * Language + region:          ``en-US``, ``fr-FR``, ``zh-CN``
  * Language + script:          ``zh-Hans``, ``sr-Latn``
  * Language + script + region: ``zh-Hans-CN``, ``sr-Latn-RS``

The pure validator function is exported for the dataclass backend.
"""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import AfterValidator

# BCP-47 pattern for the common forms: language[-Script[-REGION]]
# language:   2-3 lowercase ASCII letters
# Script:     4 title-case ASCII letters (optional)
# REGION:     2 uppercase ASCII letters OR 3 digits (optional)
_BCP47_RE = re.compile(
    r"^[a-z]{2,3}"           # language subtag
    r"(?:-[A-Z][a-z]{3})?"   # optional script subtag (Latn, Hans, …)
    r"(?:-(?:[A-Z]{2}|\d{3}))?$"  # optional region subtag (US, CN, 001, …)
)


# ---------------------------------------------------------------------------
# Pure validator function
# ---------------------------------------------------------------------------


def validate_locale(value: str) -> str:
    """Validate a BCP-47 language tag and normalise its casing.

    Casing is normalised to the canonical BCP-47 form:
    - language subtag → lowercase  (``EN`` → ``en``)
    - script subtag  → title-case  (``hans`` → ``Hans``)
    - region subtag  → uppercase   (``us`` → ``US``)

    Raises:
        ValueError: if ``value`` does not conform to the supported BCP-47 subset.
    """
    value = value.strip()
    parts = value.split("-")
    if not parts or len(parts) > 3:
        raise ValueError(f"Invalid BCP-47 locale tag: {value!r}")

    # Normalise casing
    normalised_parts = []
    for i, part in enumerate(parts):
        if i == 0:
            normalised_parts.append(part.lower())
        elif len(part) == 4:          # script subtag
            normalised_parts.append(part.title())
        else:                          # region subtag or unknown
            normalised_parts.append(part.upper())
    normalised = "-".join(normalised_parts)

    if not _BCP47_RE.match(normalised):
        raise ValueError(f"Invalid BCP-47 locale tag: {value!r}")
    return normalised


# ---------------------------------------------------------------------------
# Pydantic Annotated type
# ---------------------------------------------------------------------------

Locale = Annotated[str, AfterValidator(validate_locale)]
"""BCP-47 language tag, normalised to canonical casing on validation.

Examples of accepted values: ``'en'``, ``'en-US'``, ``'zh-Hans-CN'``,
``'sr-Latn-RS'``.  Casing is corrected automatically (``'EN-us'`` → ``'en-US'``).
"""
