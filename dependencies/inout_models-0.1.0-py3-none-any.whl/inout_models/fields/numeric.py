"""Numeric field types: PositiveInt, Money.

Money is a frozen Pydantic model (amount + ISO-4217 currency code) that can be
embedded as a nested field in any AbstractBaseModel.  The pure validator functions
are exported for the dataclass backend.
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import Annotated

from pydantic import AfterValidator, ConfigDict, Field, field_validator

from inout_models.core.base import AbstractBaseModel

# ---------------------------------------------------------------------------
# Pure validator functions
# ---------------------------------------------------------------------------

_CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


def validate_positive_int(value: int) -> int:
    """Validate that ``value`` is a strictly positive integer (> 0).

    Raises:
        ValueError: if ``value`` is zero or negative.
    """
    if value <= 0:
        raise ValueError(f"Value must be positive (> 0), got {value}")
    return value


def validate_money_amount(value: Decimal) -> Decimal:
    """Validate a monetary amount: non-negative, quantised to 2 decimal places.

    Raises:
        ValueError: if ``value`` is negative or cannot be quantised.
    """
    try:
        quantised = value.quantize(Decimal("0.01"))
    except InvalidOperation as exc:
        raise ValueError(f"Cannot quantise money amount {value!r}") from exc
    if quantised < Decimal("0"):
        raise ValueError(f"Money amount must be non-negative, got {quantised}")
    return quantised


def validate_currency_code(value: str) -> str:
    """Validate and normalise an ISO-4217 currency code to uppercase.

    Raises:
        ValueError: if ``value`` is not a 3-letter alphabetic code.
    """
    value = value.strip().upper()
    if not _CURRENCY_RE.match(value):
        raise ValueError(
            f"Currency must be a 3-letter ISO-4217 code (e.g. 'USD'): {value!r}"
        )
    return value


# ---------------------------------------------------------------------------
# Pydantic Annotated types
# ---------------------------------------------------------------------------

PositiveInt = Annotated[int, AfterValidator(validate_positive_int)]
"""Strictly positive integer (> 0)."""


# ---------------------------------------------------------------------------
# Money value type
# ---------------------------------------------------------------------------

class Money(AbstractBaseModel):
    """Immutable monetary value: a non-negative decimal amount with an ISO-4217
    currency code.

    Usage in AbstractBaseModel::

        class Invoice(AbstractBaseModel):
            subtotal: Money
            tax: Money

        inv = Invoice.from_dict({
            "subtotal": {"amount": "49.99", "currency": "USD"},
            "tax":      {"amount": "4.00",  "currency": "USD"},
        })

    Usage standalone::

        price = Money(amount=Decimal("9.99"), currency="EUR")
        price.to_json()  # '{"amount":"9.99","currency":"EUR"}'
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    amount: Decimal = Field(description="Non-negative monetary amount, quantised to 2 d.p.")
    currency: str = Field(description="ISO-4217 three-letter currency code (e.g. 'USD')")

    @field_validator("amount", mode="after")
    @classmethod
    def _amount_non_negative(cls, v: Decimal) -> Decimal:
        return validate_money_amount(v)

    @field_validator("currency", mode="after")
    @classmethod
    def _currency_valid(cls, v: str) -> str:
        return validate_currency_code(v)

    def __add__(self, other: "Money") -> "Money":
        if self.currency != other.currency:
            raise ValueError(
                f"Cannot add Money with different currencies: {self.currency} + {other.currency}"
            )
        return Money(amount=self.amount + other.amount, currency=self.currency)

    def __str__(self) -> str:
        return f"{self.amount} {self.currency}"
