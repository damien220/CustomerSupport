"""Identifier field types: UUIDField.

Accepts UUID objects or valid UUID strings and stores a ``uuid.UUID`` instance.
The pure validator function is exported for the dataclass backend.
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from pydantic import BeforeValidator


# ---------------------------------------------------------------------------
# Pure validator function
# ---------------------------------------------------------------------------


def validate_uuid(value: object) -> UUID:
    """Coerce a UUID string or ``uuid.UUID`` instance to a ``uuid.UUID``.

    Raises:
        ValueError: if ``value`` is not a valid UUID string or UUID instance.
    """
    if isinstance(value, UUID):
        return value
    if isinstance(value, str):
        try:
            return UUID(value)
        except ValueError as exc:
            raise ValueError(f"Invalid UUID string: {value!r}") from exc
    raise ValueError(
        f"Expected a UUID string or uuid.UUID instance, got {type(value).__name__!r}"
    )


# ---------------------------------------------------------------------------
# Pydantic Annotated type
# ---------------------------------------------------------------------------

UUIDField = Annotated[UUID, BeforeValidator(validate_uuid)]
"""UUID field that accepts both ``uuid.UUID`` instances and valid UUID strings."""
