"""ModelProtocol — shared surface implemented by both Pydantic and dataclass backends.

Downstream code should type-hint against ModelProtocol rather than a concrete backend
class so models stay swappable.  Only to_dict() and to_json() are checked at runtime
via isinstance(); from_dict() and from_json() are verified by the static type checker.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ModelProtocol(Protocol):
    """Structural interface shared by AbstractBaseModel and AbstractDataclassModel."""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a Python dict (types preserved, e.g. datetime stays datetime)."""
        ...

    def to_json(self) -> str:
        """Serialize to a JSON string."""
        ...

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ModelProtocol":
        """Construct from a dict, raising ValidationException on failure."""
        ...

    @classmethod
    def from_json(cls, raw: str | bytes) -> "ModelProtocol":
        """Construct from a JSON string or bytes, raising ValidationException on failure."""
        ...
