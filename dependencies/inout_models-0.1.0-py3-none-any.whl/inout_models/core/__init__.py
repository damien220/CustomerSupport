"""Core abstractions: AbstractBaseModel and ModelProtocol."""

from inout_models.core.base import AbstractBaseModel
from inout_models.core.protocol import ModelProtocol

__all__ = ["AbstractBaseModel", "ModelProtocol"]
