"""AbstractBaseModel — Pydantic v2 foundation for all domain models in the ecosystem.

Inherit from this class instead of pydantic.BaseModel to get:
  - Ecosystem-consistent serialization (to_dict / to_json / from_dict / from_json)
  - Validation errors wrapped in ValidationException with structured field details
  - Sensible default ConfigDict (extra=forbid, validate_assignment, populate_by_name)
"""

from __future__ import annotations

from typing import Any, ClassVar, Self

import pydantic
from pydantic import ConfigDict

from inout_models.integrations.errors_ import normalize_validation_error
from inout_models.integrations.logging_ import (
    log_serialize,
    log_validate_failure,
    log_validate_start,
    log_validate_success,
    model_context,
)
from inout_models.integrations.events import (
    emit_model_created,
    emit_model_serialized,
    emit_model_validated,
    emit_model_validation_failed,
    get_default_dispatcher,
)


class AbstractBaseModel(pydantic.BaseModel):
    """Abstract Pydantic v2 base model.

    All domain models, request/response objects, and DTOs in the ecosystem should
    inherit from this class.  Subclasses gain serialization helpers and consistent
    validation error shapes without any extra setup.

    Set ``emit_lifecycle_events = True`` on a subclass to opt in to lifecycle
    events dispatched via the module-level dispatcher configured by
    ``inout_models.integrations.events.set_default_dispatcher()``, or pass
    a dispatcher directly to ``validate_or_raise`` / ``to_json``.

    Usage::

        class UserRequest(AbstractBaseModel):
            name: str
            email: str

        user = UserRequest.from_dict({"name": "Ada", "email": "ada@example.com"})
        payload = user.to_json()
    """

    model_config = ConfigDict(
        extra="forbid",
        frozen=False,
        validate_assignment=True,
        populate_by_name=True,
    )

    #: Set to True on a subclass to emit lifecycle events.  Default False to
    #: avoid surprising overhead on models that don't need event sourcing.
    emit_lifecycle_events: ClassVar[bool] = False

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a Python dict.

        Python types are preserved (datetime stays datetime, UUID stays UUID).
        Use to_json() then json.loads() if you need JSON-safe types.
        """
        return self.model_dump(mode="python")

    def to_json(self, *, dispatcher: Any = None) -> str:
        """Serialize to a JSON string.

        All field types are converted to their JSON-compatible representations
        (datetime → ISO-8601 string, UUID → str, Decimal → str, etc.).

        Args:
            dispatcher: Optional event dispatcher; used only when
                ``emit_lifecycle_events`` is True on this class.
        """
        model_name = self.__class__.__qualname__
        log_serialize(model_name, operation="serialize")
        result = self.model_dump_json()
        if self.__class__.emit_lifecycle_events:
            emit_model_serialized(model_name, dispatcher=dispatcher or get_default_dispatcher())
        return result

    # ------------------------------------------------------------------
    # Construction / deserialization
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Construct an instance from a plain dict.

        Raises:
            ValidationException: if the data does not conform to the model schema.
                ``exc.details["fields"]`` contains per-field error information.
        """
        try:
            return cls.model_validate(data)
        except pydantic.ValidationError as exc:
            raise normalize_validation_error(exc) from exc

    @classmethod
    def from_json(cls, raw: str | bytes) -> Self:
        """Construct an instance from a JSON string or bytes.

        Raises:
            ValidationException: on JSON parse failure or schema violation.
                ``exc.details["fields"]`` contains per-field error information.
        """
        model_name = cls.__qualname__
        with model_context(model_name, operation="deserialize"):
            log_serialize(model_name, operation="deserialize")
            try:
                return cls.model_validate_json(raw)
            except pydantic.ValidationError as exc:
                raise normalize_validation_error(exc) from exc

    @classmethod
    def validate_or_raise(cls, data: dict[str, Any], *, dispatcher: Any = None) -> Self:
        """Validate and construct with structured logging and optional lifecycle events.

        Emits DEBUG log records on success and WARNING on failure.  When
        ``emit_lifecycle_events`` is True on the subclass, also dispatches
        ``model.validated`` on success or ``model.validation_failed`` on error.

        Args:
            data: Input data dict.
            dispatcher: Optional event dispatcher override; falls back to the
                module-level default set by ``set_default_dispatcher()``.

        Raises:
            ValidationException: same as from_dict().
        """
        model_name = cls.__qualname__
        active_dispatcher = dispatcher or get_default_dispatcher()
        with model_context(model_name, operation="validate"):
            log_validate_start(model_name)
            try:
                result = cls.from_dict(data)
                log_validate_success(model_name)
                if cls.emit_lifecycle_events:
                    emit_model_validated(model_name, result.to_dict(), dispatcher=active_dispatcher)
                return result
            except Exception as exc:
                log_validate_failure(model_name, exc)
                if cls.emit_lifecycle_events:
                    emit_model_validation_failed(model_name, str(exc), dispatcher=active_dispatcher)
                raise

    # ------------------------------------------------------------------
    # Dunder niceties
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        fields = ", ".join(
            f"{k}={v!r}" for k, v in self.model_dump(mode="python").items()
        )
        return f"{self.__class__.__name__}({fields})"
