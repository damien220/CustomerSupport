"""inout_models — abstract Pydantic v2 and dataclass models for validation and serialization.

Public API (Phase 1)::

    from inout_models import AbstractBaseModel, Field, ModelProtocol
    from inout_models import ValidationException, normalize_validation_error
    from inout_models.serialization import to_dict_any, to_json_any, from_dict_any, from_json_any
"""

__version__ = "0.1.0"

from pydantic import Field

from inout_models.core.base import AbstractBaseModel
from inout_models.core.protocol import ModelProtocol
from inout_models.dataclass.base import AbstractDataclassModel, dc_field
try:
    from error_handler import ValidationException  # type: ignore[import]
except ImportError:
    from inout_models.errors import ValidationException  # type: ignore[assignment]

from inout_models.integrations.errors_ import normalize_validation_error
from inout_models.fields import (
    Email,
    Locale,
    Money,
    NonEmptyStr,
    PositiveInt,
    Slug,
    Timestamp,
    URL,
    UUIDField,
    validate_currency_code,
    validate_email,
    validate_locale,
    validate_money_amount,
    validate_non_empty_str,
    validate_positive_int,
    validate_slug,
    validate_timestamp,
    validate_url,
    validate_uuid,
)

__all__ = [
    # Core
    "AbstractBaseModel",
    "ModelProtocol",
    # Dataclass variant
    "AbstractDataclassModel",
    "dc_field",
    # Fields
    "Field",
    "Email",
    "URL",
    "NonEmptyStr",
    "Slug",
    "PositiveInt",
    "Money",
    "UUIDField",
    "Timestamp",
    "Locale",
    # Validator functions (dataclass backend)
    "validate_email",
    "validate_url",
    "validate_non_empty_str",
    "validate_slug",
    "validate_positive_int",
    "validate_money_amount",
    "validate_currency_code",
    "validate_uuid",
    "validate_timestamp",
    "validate_locale",
    # Errors
    "ValidationException",
    "normalize_validation_error",
]
