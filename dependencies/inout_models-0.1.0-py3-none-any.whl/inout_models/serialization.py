"""Backend-agnostic serialization helpers.

These functions dispatch through ModelProtocol so callers that hold a model
instance (or class) do not need to know whether it is Pydantic- or
dataclass-backed.

Usage::

    from inout_models.serialization import to_dict_any, from_dict_any

    payload = to_dict_any(some_model_instance)
    rebuilt = from_dict_any(SomeModelClass, payload)
"""

from __future__ import annotations

from typing import Any, TypeVar

from inout_models.core.protocol import ModelProtocol

M = TypeVar("M", bound=ModelProtocol)


def to_dict_any(model: ModelProtocol) -> dict[str, Any]:
    """Serialize any ModelProtocol instance to a Python dict."""
    return model.to_dict()


def to_json_any(model: ModelProtocol) -> str:
    """Serialize any ModelProtocol instance to a JSON string."""
    return model.to_json()


def from_dict_any(cls: type[M], data: dict[str, Any]) -> M:
    """Construct a model instance from a dict.

    ``cls`` must implement the ``from_dict`` classmethod (all AbstractBaseModel
    and AbstractDataclassModel subclasses do).

    Raises:
        ValidationException: propagated from the model's own from_dict().
    """
    return cls.from_dict(data)  # type: ignore[attr-defined]


def from_json_any(cls: type[M], raw: str | bytes) -> M:
    """Construct a model instance from JSON.

    Raises:
        ValidationException: propagated from the model's own from_json().
    """
    return cls.from_json(raw)  # type: ignore[attr-defined]
