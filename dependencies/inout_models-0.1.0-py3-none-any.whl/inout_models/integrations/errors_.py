"""[errors] bridge — upgrades ValidationException to error_handler when installed.

When the ``error_exception_handler`` wheel is on the path (installed via the
``[errors]`` extra), this module routes all model validation failures through
``error_handler.ValidationException`` so they participate in the ecosystem-wide
error handling pipeline.

When the extra is absent the functions fall back to the local
``inout_models.errors.ValidationException``, which has an identical interface.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

import pydantic

try:
    from error_handler import ValidationException as _EHValidationException  # type: ignore[import]
    _ERRORS_AVAILABLE = True
except ImportError:
    _EHValidationException = None  # type: ignore[assignment]
    _ERRORS_AVAILABLE = False


def is_error_handler_available() -> bool:
    """Return True if the error_exception_handler wheel is installed."""
    return _ERRORS_AVAILABLE


def get_validation_exception_class() -> type:
    """Return the active ValidationException class.

    Returns ``error_handler.ValidationException`` when the ``[errors]`` extra
    is installed, otherwise ``inout_models.errors.ValidationException``.
    """
    if _ERRORS_AVAILABLE:
        return _EHValidationException  # type: ignore[return-value]
    from inout_models.errors import ValidationException
    return ValidationException


def normalize_validation_error(
    exc: pydantic.ValidationError,
    message: str = "Validation failed",
) -> Exception:
    """Convert ``pydantic.ValidationError`` into the active ``ValidationException``.

    Produces ``details={"fields": [{"loc": [...], "msg": "...", "type": "..."}]}``
    regardless of which backend provides the exception class, so consumers
    receive a consistent error shape whether or not ``[errors]`` is installed.

    Args:
        exc: The pydantic validation error to convert.
        message: Human-readable summary message.

    Returns:
        An ``error_handler.ValidationException`` when the extra is installed,
        otherwise a local ``inout_models.errors.ValidationException``.
    """
    fields = [
        {
            "loc": list(e["loc"]),
            "msg": e["msg"],
            "type": e["type"],
        }
        for e in exc.errors(include_url=False)
    ]
    details: dict[str, Any] = {"fields": fields}
    exc_class = get_validation_exception_class()
    return exc_class(message=message, details=details, previous=exc)


def make_validation_exception(
    message: str = "Validation failed",
    *,
    details: dict[str, Any] | None = None,
    previous: Exception | None = None,
) -> Exception:
    """Construct a ValidationException from arbitrary message/details.

    Useful for dataclass validation where the error originates from
    ``TypeError`` / ``ValueError`` rather than ``pydantic.ValidationError``.

    Returns the appropriate class (``error_handler`` or local) based on
    whether the ``[errors]`` extra is installed.
    """
    exc_class = get_validation_exception_class()
    return exc_class(message=message, details=details, previous=previous)
