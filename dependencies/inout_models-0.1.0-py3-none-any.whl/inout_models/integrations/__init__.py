"""Optional sibling-package integrations — each import-guarded and a no-op when its wheel isn't installed."""
