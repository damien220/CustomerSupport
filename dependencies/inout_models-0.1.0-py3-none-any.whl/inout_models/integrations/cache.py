"""[cache] bridge — cache_manager integration for model validation/serialization results.

When the ``cache_manager`` wheel is on the path (installed via the ``[cache]``
extra) this module provides a ``ModelCache`` namespace and helper functions
``cached_validate`` / ``cached_serialize`` that let callers opt in to caching
model validation and serialization results.

Default models are **not** cached — callers must explicitly use these helpers.

When the extra is absent ``is_cache_manager_available()`` returns ``False``
and all helper functions fall back to un-cached execution so calling code
works unchanged.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from inout_models.core.base import AbstractBaseModel

try:
    from cache_manager import CacheNamespace, get_cache  # type: ignore[import]
    _CACHE_AVAILABLE = True
except ImportError:
    CacheNamespace = None  # type: ignore[assignment, misc]
    get_cache = None  # type: ignore[assignment]
    _CACHE_AVAILABLE = False


def is_cache_manager_available() -> bool:
    """Return True if the cache_manager wheel is installed."""
    return _CACHE_AVAILABLE


def stable_hash(data: Any) -> str:
    """Return a stable MD5 hex-digest of *data* suitable for use as a cache key.

    Dicts are serialised with sorted keys so ``{"b": 2, "a": 1}`` and
    ``{"a": 1, "b": 2}`` produce the same hash.  Non-JSON-serialisable types
    are coerced to ``str`` via the ``default=str`` fallback.
    """
    serialised = json.dumps(data, sort_keys=True, default=str)
    return hashlib.md5(serialised.encode()).hexdigest()  # noqa: S324 — non-security hash


class ModelCache:
    """Thin wrapper around ``cache_manager.CacheNamespace("inout.models")``.

    Keys are namespaced under ``"inout.models:"`` so this cache never
    collides with other application caches that share the same backend.

    The internal backend is created lazily on the first access via
    :attr:`namespace`.  The default backend is an in-process
    ``MemoryCache``; pass a custom *backend_name* and *backend_kwargs* to
    :meth:`configure` before the first use to change it.

    All methods are no-ops when ``cache_manager`` is not installed.
    """

    _instance: "ModelCache | None" = None

    def __init__(self) -> None:
        self._namespace: Any | None = None
        self._backend_name: str = "memory"
        self._backend_kwargs: dict[str, Any] = {}

    def configure(self, backend: str = "memory", **kwargs: Any) -> None:
        """Configure the underlying cache backend.

        Must be called before the first :attr:`namespace` access to take
        effect.  Calling after first use resets the namespace with the new
        backend.

        Args:
            backend: Backend name understood by ``cache_manager.get_cache``.
            **kwargs: Forwarded verbatim to the backend constructor.
        """
        self._backend_name = backend
        self._backend_kwargs = kwargs
        self._namespace = None  # force re-init on next access

    @property
    def namespace(self):
        """Lazily create and return the namespaced cache."""
        if not _CACHE_AVAILABLE:
            return None
        if self._namespace is None:
            backend = get_cache(self._backend_name, **self._backend_kwargs)
            self._namespace = CacheNamespace(backend, "inout.models")
        return self._namespace

    def get(self, key: str, default: Any = None) -> Any:
        if not _CACHE_AVAILABLE:
            return default
        return self.namespace.get(key, default)

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        if not _CACHE_AVAILABLE:
            return
        self.namespace.set(key, value, ttl=ttl)

    def exists(self, key: str) -> bool:
        if not _CACHE_AVAILABLE:
            return False
        return self.namespace.exists(key)

    def delete(self, key: str) -> bool:
        if not _CACHE_AVAILABLE:
            return False
        return self.namespace.delete(key)

    def clear(self) -> int:
        """Clear all entries in the ``"inout.models"`` namespace."""
        if not _CACHE_AVAILABLE:
            return 0
        return self.namespace.clear()

    @classmethod
    def default(cls) -> "ModelCache":
        """Return the module-level shared ``ModelCache`` instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance


def _validate_cache_key(cls: type, data: dict[str, Any]) -> str:
    return f"{cls.__qualname__}:{stable_hash(data)}"


def _serialize_cache_key(model: "AbstractBaseModel") -> str:
    return f"{model.__class__.__qualname__}:json:{stable_hash(model.to_dict())}"


def cached_validate(
    cls: type,
    data: dict[str, Any],
    *,
    cache: "ModelCache | None" = None,
    ttl: int | None = None,
) -> Any:
    """Validate *data* against *cls*, returning a cached result when available.

    On a cache miss the model is validated normally via ``cls.from_dict(data)``,
    the result is stored as its ``to_dict()`` representation, and the model is
    returned.  On a subsequent call with the same class and input the cached
    dict is re-validated (a fast ``model_validate`` with no IO) and returned.

    Falls back to a plain ``cls.from_dict(data)`` call when ``cache_manager``
    is not installed.

    Args:
        cls: The model class to validate against (must be an AbstractBaseModel subclass).
        data: Input data dict.
        cache: ``ModelCache`` instance to use; defaults to the module-level shared cache.
        ttl: Time-to-live in seconds; ``None`` means never expire.

    Returns:
        A validated model instance.

    Raises:
        ValidationException: if validation fails (same as ``cls.from_dict``).
    """
    _cache = cache or ModelCache.default()
    if not _CACHE_AVAILABLE:
        return cls.from_dict(data)  # type: ignore[attr-defined]

    key = _validate_cache_key(cls, data)
    cached_dict = _cache.get(key)
    if cached_dict is not None:
        return cls.from_dict(cached_dict)  # type: ignore[attr-defined]

    model = cls.from_dict(data)  # type: ignore[attr-defined]
    _cache.set(key, model.to_dict(), ttl=ttl)  # type: ignore[attr-defined]
    return model


def cached_serialize(
    model: "AbstractBaseModel",
    *,
    cache: "ModelCache | None" = None,
    ttl: int | None = None,
) -> str:
    """Serialize *model* to JSON, returning a cached string when available.

    The cache key is derived from the model's ``to_dict()`` output so two
    model instances with identical field values share the same cache entry.

    Falls back to plain ``model.to_json()`` when ``cache_manager`` is not
    installed.

    Args:
        model: The model instance to serialize.
        cache: ``ModelCache`` instance to use; defaults to the module-level shared cache.
        ttl: Time-to-live in seconds; ``None`` means never expire.

    Returns:
        A JSON string.
    """
    _cache = cache or ModelCache.default()
    if not _CACHE_AVAILABLE:
        return model.to_json()

    key = _serialize_cache_key(model)
    cached_json = _cache.get(key)
    if cached_json is not None:
        return cached_json

    result = model.to_json()
    _cache.set(key, result, ttl=ttl)
    return result
