"""[events] bridge — event_dispatcher lifecycle event topics and emit helper.

When the ``event_dispatcher`` wheel is on the path (installed via the
``[events]`` extra) this module emits structured ``DispatchEvent`` objects
on a caller-supplied dispatcher for four model lifecycle moments:

    MODEL_CREATED         — a model instance was just constructed (via __init__)
    MODEL_VALIDATED       — validate_or_raise completed successfully
    MODEL_SERIALIZED      — to_json was called
    MODEL_VALIDATION_FAILED — validate_or_raise or from_dict raised an error

By default models do **not** emit events.  Set the class attribute
``emit_lifecycle_events = True`` on any ``AbstractBaseModel`` subclass to
opt in, and supply a dispatcher via ``set_default_dispatcher()``.

When the extra is absent all helpers remain importable and are no-ops.
"""

from __future__ import annotations

from typing import Any

try:
    from event_dispatcher import DispatchEvent, EventBuilder  # type: ignore[import]
    _EVENTS_AVAILABLE = True
except ImportError:
    DispatchEvent = None  # type: ignore[assignment, misc]
    EventBuilder = None  # type: ignore[assignment, misc]
    _EVENTS_AVAILABLE = False


# ---------------------------------------------------------------------------
# Topic constants
# ---------------------------------------------------------------------------

MODEL_CREATED = "model.created"
MODEL_VALIDATED = "model.validated"
MODEL_SERIALIZED = "model.serialized"
MODEL_VALIDATION_FAILED = "model.validation_failed"

_SOURCE = "inout_models"

# ---------------------------------------------------------------------------
# Module-level default dispatcher (opt-in)
# ---------------------------------------------------------------------------

_default_dispatcher: Any = None


def set_default_dispatcher(dispatcher: Any) -> None:
    """Set the module-level dispatcher used by :func:`emit` when none is passed.

    Pass ``None`` to disable default dispatching.
    """
    global _default_dispatcher
    _default_dispatcher = dispatcher


def get_default_dispatcher() -> Any:
    """Return the current module-level default dispatcher, or ``None``."""
    return _default_dispatcher


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------


def is_event_dispatcher_available() -> bool:
    """Return True if the event_dispatcher wheel is installed."""
    return _EVENTS_AVAILABLE


# ---------------------------------------------------------------------------
# Core emit helper
# ---------------------------------------------------------------------------


def emit(
    topic: str,
    payload: dict[str, Any],
    *,
    dispatcher: Any = None,
    source: str = _SOURCE,
) -> Any:
    """Emit a ``DispatchEvent`` on *dispatcher* (or the module default).

    Args:
        topic: One of the ``MODEL_*`` topic constants.
        payload: Arbitrary dict of event-specific data.
        dispatcher: A dispatcher instance; falls back to
            :func:`get_default_dispatcher` when ``None``.
        source: Event source string (defaults to ``"inout_models"``).

    Returns:
        The ``EmitOutcome`` returned by the dispatcher, or ``None`` if no
        dispatcher is configured or ``event_dispatcher`` is not installed.
    """
    if not _EVENTS_AVAILABLE:
        return None

    active = dispatcher or _default_dispatcher
    if active is None:
        return None

    event = (
        EventBuilder(topic)
        .with_source(source)
        .with_payload(payload)
        .build()
    )
    return active.emit(event)


# ---------------------------------------------------------------------------
# Convenience builders for each lifecycle topic
# ---------------------------------------------------------------------------


def emit_model_created(
    model_name: str,
    model_dict: dict[str, Any],
    *,
    dispatcher: Any = None,
) -> Any:
    """Emit ``model.created`` after a model instance is constructed."""
    return emit(
        MODEL_CREATED,
        {"model_name": model_name, "data": model_dict},
        dispatcher=dispatcher,
    )


def emit_model_validated(
    model_name: str,
    model_dict: dict[str, Any],
    *,
    dispatcher: Any = None,
) -> Any:
    """Emit ``model.validated`` when ``validate_or_raise`` succeeds."""
    return emit(
        MODEL_VALIDATED,
        {"model_name": model_name, "data": model_dict},
        dispatcher=dispatcher,
    )


def emit_model_serialized(
    model_name: str,
    *,
    dispatcher: Any = None,
) -> Any:
    """Emit ``model.serialized`` when ``to_json`` is called."""
    return emit(
        MODEL_SERIALIZED,
        {"model_name": model_name},
        dispatcher=dispatcher,
    )


def emit_model_validation_failed(
    model_name: str,
    error_message: str,
    *,
    dispatcher: Any = None,
) -> Any:
    """Emit ``model.validation_failed`` when validation raises an exception."""
    return emit(
        MODEL_VALIDATION_FAILED,
        {"model_name": model_name, "error": error_message},
        dispatcher=dispatcher,
    )
