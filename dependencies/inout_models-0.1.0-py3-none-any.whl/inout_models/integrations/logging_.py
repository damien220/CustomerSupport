"""[logging] bridge — logger_pkg integration for structured model events.

When the ``logger_pkg`` wheel is on the path (installed via the ``[logging]``
extra), this module routes model lifecycle log events through
``logger_pkg.get_logger`` and attaches ``model_name`` / ``operation`` /
``request_id`` context fields via ``logger_pkg.bound_context`` so every
log record inside a model operation carries rich structured metadata.

When the extra is absent the module falls back to stdlib ``logging``.  All
public functions remain callable; ``model_context`` becomes a no-op context
manager so instrumented code paths work unchanged.
"""

from __future__ import annotations

import logging as _stdlib_logging
from contextlib import contextmanager
from typing import Any, Generator

try:
    import logger_pkg as _lp  # type: ignore[import]
    _LOGGING_AVAILABLE = True
except ImportError:
    _lp = None  # type: ignore[assignment]
    _LOGGING_AVAILABLE = False


def is_logger_pkg_available() -> bool:
    """Return True if the logger_pkg wheel is installed."""
    return _LOGGING_AVAILABLE


def get_logger(name: str = "inout_models"):
    """Return a structured logger for the given name.

    Returns ``logger_pkg.get_logger(name)`` when the ``[logging]`` extra is
    installed, otherwise ``logging.getLogger(name)`` from the stdlib.
    """
    if _LOGGING_AVAILABLE:
        return _lp.get_logger(name)
    return _stdlib_logging.getLogger(name)


@contextmanager
def model_context(
    model_name: str,
    operation: str,
    request_id: str | None = None,
) -> Generator[None, None, None]:
    """Context manager that injects model metadata into log records.

    When ``logger_pkg`` is installed, attaches ``model_name``, ``operation``,
    and (optionally) ``request_id`` to the logging context via
    ``logger_pkg.bound_context`` so every log record emitted inside the
    block carries these fields automatically.

    When ``logger_pkg`` is absent this is a pure no-op context manager.

    Args:
        model_name: Fully-qualified class name of the model being operated on.
        operation: One of ``"validate"``, ``"serialize"``, ``"deserialize"``.
        request_id: Optional caller-supplied correlation / request ID.
    """
    if _LOGGING_AVAILABLE:
        fields: dict[str, Any] = {"model_name": model_name, "operation": operation}
        if request_id is not None:
            fields["request_id"] = request_id
        with _lp.bound_context(**fields):
            yield
    else:
        yield


# Module-level logger — created once and reused by the helper functions below.
_logger = get_logger("inout_models")


def log_validate_start(model_name: str) -> None:
    """Emit a DEBUG record when model validation begins."""
    _logger.debug(
        "Validation started for %s",
        model_name,
        extra={"model_name": model_name, "operation": "validate"},
    )


def log_validate_success(model_name: str) -> None:
    """Emit a DEBUG record when model validation succeeds."""
    _logger.debug(
        "Validation succeeded for %s",
        model_name,
        extra={"model_name": model_name, "operation": "validate"},
    )


def log_validate_failure(model_name: str, exc: Exception) -> None:
    """Emit a WARNING record when model validation fails."""
    _logger.warning(
        "Validation failed for %s: %s",
        model_name,
        exc,
        extra={"model_name": model_name, "operation": "validate"},
    )


def log_serialize(model_name: str, operation: str = "serialize") -> None:
    """Emit a DEBUG record when a model is serialized or deserialized."""
    _logger.debug(
        "%s %s",
        operation.capitalize(),
        model_name,
        extra={"model_name": model_name, "operation": operation},
    )
