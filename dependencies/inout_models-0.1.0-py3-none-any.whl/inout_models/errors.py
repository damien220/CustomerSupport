"""Local ValidationException — same interface as error_handler.ValidationException.

When the [errors] extra is not installed this module provides a drop-in that has
identical attributes and to_dict() shape so application code is unaffected by
whether error_handler is on the path.  Phase 4 (integrations/errors_.py) will
wire model validation through the ecosystem error_handler when it is available.
"""

from __future__ import annotations

from typing import Any

import pydantic


class ValidationException(Exception):
    """Validation error with the project-consistent error envelope shape.

    Attributes match error_handler.ValidationException exactly so it can be
    used as a drop-in replacement.
    """

    code: str = "VALIDATION_ERROR"
    status_code: int = 400

    def __init__(
        self,
        message: str = "Validation failed",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.details = details
        self.previous = previous
        if previous is not None:
            self.__cause__ = previous

    def to_dict(self) -> dict[str, Any]:
        """Return the project-standard error envelope."""
        return {
            "success": False,
            "error": {
                "code": self.code,
                "message": self.message,
                "details": self.details,
                "status_code": self.status_code,
            },
        }


def normalize_validation_error(
    exc: pydantic.ValidationError,
    message: str = "Validation failed",
) -> ValidationException:
    """Convert pydantic.ValidationError into a ValidationException with structured field details.

    Produces details={"fields": [{"loc": [...], "msg": "...", "type": "..."}]} so
    consumers can display or log per-field errors without depending on Pydantic internals.

    Phase 4 will upgrade this to emit error_handler.ValidationException when that
    extra is installed.
    """
    fields = [
        {
            "loc": list(e["loc"]),
            "msg": e["msg"],
            "type": e["type"],
        }
        for e in exc.errors(include_url=False)
    ]
    return ValidationException(
        message=message,
        details={"fields": fields},
        previous=exc,
    )
