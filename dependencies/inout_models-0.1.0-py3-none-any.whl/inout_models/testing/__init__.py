"""Test utilities — pytest fixtures for stubbing optional integrations."""
