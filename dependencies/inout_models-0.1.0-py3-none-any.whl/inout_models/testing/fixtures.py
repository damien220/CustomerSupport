"""Pytest fixtures: stub logger / cache / dispatcher. Implemented alongside integration phases."""
