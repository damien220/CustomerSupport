"""Dataclass variant — stdlib-only (zero runtime deps) model surface."""

from inout_models.dataclass.base import AbstractDataclassModel, dc_field

__all__ = ["AbstractDataclassModel", "dc_field"]
