"""
WithWorkflows — multi-step workflow execution for AbstractUIController.

Wraps ``workflow_manager.WorkflowEngine`` so controller subclasses can
start and resume workflows, including flows that contain ``HumanStep``
approval gates.

HumanStep integration
---------------------
When a workflow halts at a ``HumanStep``, ``start_workflow`` returns a
``WorkflowRun`` with ``status == RunStatus.WAITING``.  The caller should
surface this to the UI layer via ``UIResponse.waiting(workflow_id=run.run_id)``
and later dispatch a ``resume`` action that calls ``resume_workflow``.

Usage::

    wf = WorkflowDefinition("approve", steps=[
        FunctionStep("fetch", fetch_data),
        HumanStep("approve"),
        FunctionStep("publish", publish_data),
    ])

    class MyController(WithWorkflows, AbstractUIController):
        tools = [UITool.from_fn("start_approval", start_approval_fn)]

    async with MyController() as ctrl:
        run = await ctrl.start_workflow(wf, inputs={"record_id": 42})
        if run.status == RunStatus.WAITING:
            return UIResponse.waiting(workflow_id=run.run_id)
"""

from __future__ import annotations

import asyncio
from typing import Any

try:
    from workflow_manager import (
        AbstractWorkflow,
        AsyncExecutor,
        InMemoryStateStore,
        RunStatus,
        StepResult,
        StepStatus,
        WorkflowEngine,
        WorkflowRun,
    )
except ImportError as _err:
    raise ImportError(
        "WithWorkflows requires the 'workflows' extra: "
        "pip install 'ui_controller_base[workflows]'"
    ) from _err


class WithWorkflows:
    """Add ``WorkflowEngine``-backed multi-step flows to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(WithWorkflows, AbstractUIController):
            ...

    Class-level knobs
    -----------------
    workflow_state_store:
        Custom ``AbstractStateStore`` implementation.  Defaults to
        ``InMemoryStateStore``.  Override with a ``DBStateStore`` (requires
        ``WithDatabase``) for persistence across restarts.
    """

    workflow_state_store: Any = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        store = self.workflow_state_store or InMemoryStateStore()
        self._workflow_engine: WorkflowEngine = WorkflowEngine(
            executor=AsyncExecutor(),
            state_store=store,
        )

    # ── Public API ───────────────────────────────────────────────

    async def start_workflow(
        self,
        workflow: AbstractWorkflow,
        inputs: dict[str, Any] | None = None,
    ) -> WorkflowRun:
        """Start *workflow* and return the resulting ``WorkflowRun``.

        If the workflow contains a ``HumanStep``, the run will have
        ``status == RunStatus.WAITING`` and execution will be paused until
        ``resume_workflow`` is called.

        Parameters
        ----------
        workflow:
            A ``WorkflowDefinition`` (or any ``AbstractWorkflow`` subclass).
        inputs:
            Initial inputs passed to the first step's ``StepContext``.

        Returns
        -------
        WorkflowRun
            Run record with current status and step results.
        """
        return await asyncio.to_thread(self._workflow_engine.run, workflow, inputs)

    async def resume_workflow(
        self,
        workflow: AbstractWorkflow,
        run_id: str,
        approval_data: dict[str, Any] | None = None,
    ) -> WorkflowRun:
        """Resume a previously WAITING *workflow* run.

        Before handing off to the engine, this method locates the PENDING
        ``HumanStep`` in the stored run and marks it ``COMPLETED`` so the
        engine can advance past it.

        Parameters
        ----------
        workflow:
            The same ``WorkflowDefinition`` used in ``start_workflow``.
        run_id:
            The ``WorkflowRun.run_id`` returned from ``start_workflow``.
        approval_data:
            Optional mapping stored as the HumanStep's output
            (e.g. ``{"approved_by": "alice", "comment": "LGTM"}``).

        Returns
        -------
        WorkflowRun
            Updated run record — may be COMPLETED or WAITING again if
            there are multiple ``HumanStep`` gates.
        """
        import time

        def _approve_and_resume() -> WorkflowRun:
            store = self._workflow_engine.state_store
            run = store.load(run_id)
            # Mark the first PENDING step as COMPLETED so the engine advances.
            for step_name, result in run.step_results.items():
                if result.status == StepStatus.PENDING:
                    run.record(
                        StepResult(
                            step_name=step_name,
                            status=StepStatus.COMPLETED,
                            output=approval_data or {},
                            started_at=result.started_at,
                            finished_at=time.time(),
                        )
                    )
                    store.save(run)
                    break
            return self._workflow_engine.resume(workflow, run_id)

        return await asyncio.to_thread(_approve_and_resume)

    @property
    def workflow_engine(self) -> WorkflowEngine:
        """The underlying ``WorkflowEngine`` instance."""
        return self._workflow_engine
