"""
WithJobs — background job scheduling for AbstractUIController.

Wraps ``job_manager.AsyncScheduler`` so controller subclasses can submit
and monitor background jobs without importing job_manager directly.

Lifecycle
---------
``open()``  — starts the async scheduler
``close()`` — shuts down the scheduler (non-blocking)

Event bus integration
---------------------
When combined with ``ObservableMixin``, job completion / failure events
are re-emitted on ``self.events`` under the topics:
    ``job.completed``  — payload: {job_id, job_name, result}
    ``job.failed``     — payload: {job_id, job_name, error}

Usage::

    class MyController(WithJobs, ObservableMixin, AbstractUIController):
        tools = [UITool.from_fn("report", generate_report)]

    async with MyController() as ctrl:
        job_id = await ctrl.submit_job(ReportJob())
        response = UIResponse.pending(job_id=job_id)
"""

from __future__ import annotations

from typing import Any

try:
    from job_manager import (
        AsyncExecutor,
        AsyncScheduler,
        BaseJob,
        BaseTrigger,
        CallbackListener,
        EventType,
        ImmediateTrigger,
        MemoryJobStore,
    )
except ImportError as _err:
    raise ImportError(
        "WithJobs requires the 'jobs' extra: pip install 'ui_controller_base[jobs]'"
    ) from _err


class WithJobs:
    """Add ``AsyncScheduler``-backed background jobs to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(WithJobs, ObservableMixin, AbstractUIController):
            ...
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._job_scheduler: AsyncScheduler = AsyncScheduler(
            store=MemoryJobStore(),
            executor=AsyncExecutor(),
        )
        # Wire completion/failure events → self.events if ObservableMixin is present.
        if hasattr(self, "events"):
            self._job_scheduler.add_listener(
                CallbackListener(
                    callback=self._on_job_event_sync,
                    event_types={EventType.JOB_SUCCEEDED, EventType.JOB_FAILED},
                )
            )

    # ── Lifecycle ────────────────────────────────────────────────

    async def open(self) -> None:
        await super().open()  # type: ignore[misc]
        await self._job_scheduler.start_async()

    async def close(self) -> None:
        await self._job_scheduler.shutdown_async(wait=False)
        await super().close()  # type: ignore[misc]

    # ── Public API ───────────────────────────────────────────────

    async def submit_job(
        self,
        job: BaseJob,
        trigger: BaseTrigger | None = None,
    ) -> str:
        """Submit *job* to the scheduler and return its ``job_id``.

        Parameters
        ----------
        job:
            A ``job_manager.BaseJob`` subclass instance.
        trigger:
            Scheduling trigger.  Defaults to ``ImmediateTrigger()`` (run now).

        Returns
        -------
        str
            The scheduler-assigned job ID.  Pass as ``UIResponse.pending(job_id=...)``
            to communicate in-progress status to the caller.
        """
        return self._job_scheduler.add_job(job, trigger or ImmediateTrigger())

    async def on_job_event(self, event: Any) -> None:
        """Called for every ``JOB_SUCCEEDED`` / ``JOB_FAILED`` event.

        Override to invalidate caches, send notifications, etc.
        Default implementation is a no-op.
        """

    @property
    def job_scheduler(self) -> AsyncScheduler:
        """The underlying ``AsyncScheduler`` instance."""
        return self._job_scheduler

    # ── Internal ─────────────────────────────────────────────────

    def _on_job_event_sync(self, event: Any) -> None:
        import asyncio

        # Re-emit on the shared event bus if available.
        if hasattr(self, "events"):
            from event_dispatcher import DispatchEvent

            topic = (
                "job.completed"
                if event.event_type == EventType.JOB_SUCCEEDED
                else "job.failed"
            )
            self.events.emit(
                DispatchEvent(
                    event_kind=topic,
                    payload={
                        "job_id": event.job_id,
                        "job_name": getattr(event, "job_name", ""),
                        "error": getattr(event, "error", None),
                    },
                    source=type(self).__name__,
                )
            )

        # Call the async hook.
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.on_job_event(event))
        except RuntimeError:
            asyncio.run(self.on_job_event(event))
