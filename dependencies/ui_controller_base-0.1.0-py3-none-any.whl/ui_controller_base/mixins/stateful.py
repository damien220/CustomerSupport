"""
StatefulMixin — per-session state management for AbstractUIController.

Adds two methods to the controller:
    await get_state(session_id)  → UIState
    await save_state(state)      → None

The backing store is a ``StateStore`` (a simple protocol).  Two
implementations ship out of the box:

    InMemoryStateStore  — process-local dict, default for dev/tests
    (DB-backed store added in Phase 5 via WithDatabase)

Optimistic locking
------------------
``UIState.version`` is incremented on every ``evolve()`` call.
``save_state`` rejects writes whose version is not exactly one ahead of
the stored version, raising ``UIConflictError`` on concurrent writes.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from ui_controller_base.core.state import UIState
from ui_controller_base.exceptions import UIConflictError


# ── StateStore protocol ───────────────────────────────────────────────────

@runtime_checkable
class StateStore(Protocol):
    """Minimal interface for session-state persistence."""

    def get(self, session_id: str) -> UIState | None: ...
    def set(self, state: UIState) -> None: ...
    def delete(self, session_id: str) -> None: ...


class InMemoryStateStore:
    """Thread-safe in-process state store backed by a plain dict."""

    def __init__(self) -> None:
        self._store: dict[str, UIState] = {}

    def get(self, session_id: str) -> UIState | None:
        return self._store.get(session_id)

    def set(self, state: UIState) -> None:
        self._store[state.session_id] = state

    def delete(self, session_id: str) -> None:
        self._store.pop(session_id, None)

    def __len__(self) -> int:
        return len(self._store)


# ── Mixin ────────────────────────────────────────────────────────────────

class StatefulMixin:
    """Add per-session ``UIState`` get/save to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(StatefulMixin, AbstractUIController):
            ...

    By default an ``InMemoryStateStore`` is used.  Pass a custom store::

        class MyController(StatefulMixin, AbstractUIController):
            state_store = MyDbStateStore()

    Or set it after construction::

        ctrl = MyController()
        ctrl._state_store = MyDbStateStore()
    """

    # Class-level default — subclasses may override.
    state_store: StateStore | None = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Use the class-level store if declared, otherwise default to memory.
        if self.state_store is not None:
            self._state_store: StateStore = self.state_store
        else:
            self._state_store = InMemoryStateStore()

    async def get_state(self, session_id: str) -> UIState:
        """Load or create the ``UIState`` for *session_id*."""
        state = self._state_store.get(session_id)
        if state is None:
            state = UIState(session_id=session_id)
            self._state_store.set(state)
        return state

    async def save_state(self, state: UIState) -> None:
        """Persist *state*, enforcing optimistic locking.

        Raises
        ------
        UIConflictError
            If the stored version is not exactly one behind *state.version*
            (i.e. a concurrent write happened between get and save).
        """
        existing = self._state_store.get(state.session_id)
        if existing is not None and existing.version != state.version - 1:
            raise UIConflictError(
                f"State version conflict for session '{state.session_id}'",
                details={
                    "session_id": state.session_id,
                    "expected_previous": state.version - 1,
                    "found": existing.version,
                },
            )
        self._state_store.set(state)
