"""
WithDatabase — database connection management for AbstractUIController.

Wraps ``db_accessor.get_database`` so controller subclasses can declare a
database type and connection details at the class level and access a live
connection through the ``db`` property.

Lifecycle
---------
``open()``  — connects the database (``get_database(db_type).connect(db_connection)``)
``close()`` — calls ``db.disconnect()``

Usage::

    class MyController(WithDatabase, AbstractUIController):
        db_type = "sqlite"
        db_connection = {"file": "/tmp/myapp.db"}

    async with MyController() as ctrl:
        rows = ctrl.db.read("users", {"active": True})
"""

from __future__ import annotations

from typing import Any

try:
    from db_accessor import AbstractDatabase, get_database
except ImportError as _err:
    raise ImportError(
        "WithDatabase requires the 'db' extra: "
        "pip install 'ui_controller_base[db]'"
    ) from _err


class WithDatabase:
    """Add a ``db_accessor``-backed database connection to ``AbstractUIController``.

    Class-level knobs
    -----------------
    db_type : str
        Database driver type accepted by ``get_database()``.
        Default ``"sqlite"``.
    db_connection : dict
        Connection details passed to ``AbstractDatabase.connect()``.
        Default ``{"file": ":memory:"}`` (in-process SQLite, good for tests).

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(WithDatabase, AbstractUIController):
            db_type = "postgres"
            db_connection = {"host": "localhost", "database": "myapp", ...}
    """

    db_type: str = "sqlite"
    db_connection: dict = {"file": ":memory:"}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._db: AbstractDatabase | None = None

    # ── Lifecycle ────────────────────────────────────────────────

    async def open(self) -> None:
        await super().open()  # type: ignore[misc]
        self._db = get_database(self.db_type)
        self._db.connect(self.db_connection)

    async def close(self) -> None:
        if self._db is not None:
            self._db.disconnect()
            self._db = None
        await super().close()  # type: ignore[misc]

    # ── Public API ───────────────────────────────────────────────

    @property
    def db(self) -> AbstractDatabase:
        """The connected ``AbstractDatabase`` instance.

        Raises
        ------
        RuntimeError
            If accessed before ``open()`` has been called.
        """
        if self._db is None:
            raise RuntimeError(
                "Database is not connected. "
                "Call await controller.open() or use the async context manager."
            )
        return self._db
