"""
CacheableMixin — response caching for AbstractUIController.

Creates three namespaced caches over a single ``cache_manager`` backend:

    ui.session   — session state snapshots (long TTL, cross-rerun)
    ui.view      — rendered view results (medium TTL, per view+payload+session)
    ui.tool      — tool execution results (configurable TTL)

Streamlit note
--------------
Streamlit re-runs the entire script on every user interaction.
``view_cache`` is the primary defence: a cached render result is
returned on re-runs whose (view, payload_hash, session_id) key
matches, so expensive backend calls are not repeated.

Usage
-----
    class MyController(CacheableMixin, AbstractUIController):
        cache_backend = "memory"   # default; override to "redis", "sqlite" …
        cache_ttl_view = 300       # seconds
        cache_ttl_tool = 60
        cache_ttl_session = 3600
"""

from __future__ import annotations

from typing import Any

from cache_manager import AbstractCache, CacheNamespace, get_cache


class CacheableMixin:
    """Add namespaced caches to ``AbstractUIController``.

    Class-level knobs
    -----------------
    cache_backend : str
        ``cache_manager`` backend name.  Default ``"memory"``.
    cache_max_size : int
        Max items for memory backend.  Default 1000.
    cache_ttl_view : int
        Seconds before a cached view render expires.  Default 300.
    cache_ttl_tool : int
        Seconds before a cached tool result expires.  Default 60.
    cache_ttl_session : int
        Seconds before a cached session snapshot expires.  Default 3600.
    """

    cache_backend: str = "memory"
    cache_max_size: int = 1000
    cache_ttl_view: int = 300
    cache_ttl_tool: int = 60
    cache_ttl_session: int = 3600

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        base = get_cache(self.cache_backend, max_size=self.cache_max_size)
        self._cache: AbstractCache = base
        self.session_cache: CacheNamespace = CacheNamespace(base, "ui.session")
        self.view_cache: CacheNamespace = CacheNamespace(base, "ui.view")
        self.tool_cache: CacheNamespace = CacheNamespace(base, "ui.tool")

    @property
    def cache(self) -> AbstractCache:
        """The raw underlying cache backend (all namespaces share it)."""
        return self._cache

    def make_view_key(self, view: str, payload: dict[str, Any], session_id: str) -> str:
        """Build a deterministic cache key for a rendered view.

        Combines the view route, a hash of the payload, and the session ID
        so that different sessions and different payloads get distinct entries.
        """
        import hashlib, json
        payload_hash = hashlib.md5(
            json.dumps(payload, sort_keys=True, default=str).encode()
        ).hexdigest()[:8]
        return f"{view}:{payload_hash}:{session_id}"
