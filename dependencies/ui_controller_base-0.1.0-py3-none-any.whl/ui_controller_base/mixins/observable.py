"""
ObservableMixin — event-bus integration for AbstractUIController.

Exposes a ``LocalDispatcher`` as ``self.events`` and a ``subscribe()``
convenience method so controller code can:

    @self.subscribe("ui.action.*")
    def on_action(event): ...

    await self.events.emit_async(DispatchEvent(...))

The UIDispatcher created by AbstractUIController uses ``self.events``
as its event bus, so action lifecycle events (ui.action.received,
ui.action.completed, ui.action.failed) flow through the same bus as
any custom subscribers.
"""

from __future__ import annotations

from typing import Any, Callable

from event_dispatcher import DispatchEvent, LocalDispatcher


class ObservableMixin:
    """Add an event bus (``self.events``) to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(ObservableMixin, AbstractUIController):
            ...

        ctrl = MyController()

        @ctrl.subscribe("ui.action.completed")
        def on_done(event: DispatchEvent):
            print(f"action completed: {event.payload}")
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.events: LocalDispatcher = LocalDispatcher()

    def subscribe(
        self,
        event_pattern: str,
        handler_fn: Callable[[DispatchEvent], Any] | None = None,
    ) -> Any:
        """Register a handler for events matching *event_pattern*.

        Can be used as a regular call or as a decorator::

            ctrl.subscribe("ui.action.*", my_handler)

            @ctrl.subscribe("ui.action.*")
            def my_handler(event): ...

        Supports wildcard patterns (``"ui.*"``, ``"ui.**"``).
        """
        return self.events.subscribe(event_pattern, handler_fn)
