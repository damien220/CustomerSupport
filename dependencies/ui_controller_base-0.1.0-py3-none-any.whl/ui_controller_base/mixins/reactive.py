"""
ReactiveMixin — subscribe the controller to backend-originated events.

When combined with ``ObservableMixin``, ``ReactiveMixin`` subscribes to
``backend.**`` events on the shared event bus so the controller can push
fresh fragments to the UI layer without waiting for an explicit user action.

Typical use-cases
-----------------
- A background job finishes and emits ``backend.job.completed`` → the
  controller invalidates the view cache and marks the session dirty.
- A database record changes (via CDC) → the controller triggers a
  Streamlit rerun or SSE push to open FastAPI connections.

Override ``on_backend_event`` to add custom logic::

    class MyController(ReactiveMixin, ObservableMixin, AbstractUIController):
        async def on_backend_event(self, event: DispatchEvent) -> None:
            if event.event_kind == "backend.order.updated":
                self.view_cache.delete(...)  # invalidate stale render
"""

from __future__ import annotations

from typing import Any

from event_dispatcher import DispatchEvent


class ReactiveMixin:
    """Subscribe to ``backend.**`` events and call ``on_backend_event``.

    Must be combined with ``ObservableMixin`` (which provides ``self.events``)
    and placed **before** it in the MRO::

        class MyController(ReactiveMixin, ObservableMixin, AbstractUIController):
            ...
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Register the listener once the event bus (from ObservableMixin) is ready.
        if hasattr(self, "events"):
            self.events.subscribe("backend.**", self._handle_backend_event)

    def _handle_backend_event(self, event: DispatchEvent) -> None:
        """Sync trampoline — schedules the async hook as a fire-and-forget task."""
        import asyncio
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.on_backend_event(event))
        except RuntimeError:
            # No running loop — called from a sync context; run directly.
            asyncio.run(self.on_backend_event(event))

    async def on_backend_event(self, event: DispatchEvent) -> None:
        """Called for every ``backend.**`` event.

        Override to invalidate caches, trigger reruns, or emit UI events.
        Default implementation is a no-op.
        """
