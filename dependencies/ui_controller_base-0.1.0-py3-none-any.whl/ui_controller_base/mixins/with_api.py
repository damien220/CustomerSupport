"""
WithApiClients — named HTTP client registry for AbstractUIController.

Wraps ``api_client_base.AsyncAPIClient`` so controller subclasses can
register named API clients at class- or instance-level and look them up
by name without carrying client instances as bare attributes.

Lifecycle
---------
``open()``  — calls ``await client.connect()`` for all registered clients
``close()`` — calls ``await client.disconnect()`` for all clients

Usage::

    from api_client_base import APIClientConfig, BearerTokenAuth

    class MyController(WithApiClients, AbstractUIController):
        pass

    ctrl = MyController()
    ctrl.register_api_client(
        "payments",
        APIClientConfig(
            base_url="https://api.payments.io",
            auth_strategy=BearerTokenAuth(token=os.environ["PAYMENTS_TOKEN"]),
        ),
    )
    async with ctrl:
        resp = await ctrl.get_api_client("payments").request("GET", "/balance")
"""

from __future__ import annotations

from typing import Any

try:
    from api_client_base import APIClientConfig, AsyncAPIClient
except ImportError as _err:
    raise ImportError(
        "WithApiClients requires the 'api' extra: "
        "pip install 'ui_controller_base[api]'"
    ) from _err


class WithApiClients:
    """Add a named ``AsyncAPIClient`` registry to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(WithApiClients, AbstractUIController):
            ...
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._api_clients: dict[str, AsyncAPIClient] = {}

    # ── Lifecycle ────────────────────────────────────────────────

    async def open(self) -> None:
        await super().open()  # type: ignore[misc]
        for client in self._api_clients.values():
            await client.connect()

    async def close(self) -> None:
        for client in self._api_clients.values():
            await client.disconnect()
        await super().close()  # type: ignore[misc]

    # ── Public API ───────────────────────────────────────────────

    def register_api_client(
        self,
        name: str,
        client_or_config: AsyncAPIClient | APIClientConfig,
    ) -> None:
        """Register an API client under *name*.

        Accepts either a pre-built ``AsyncAPIClient`` or an ``APIClientConfig``
        (a client will be constructed from the config automatically).

        Parameters
        ----------
        name:
            Stable identifier used to look up the client (e.g. ``"payments"``).
        client_or_config:
            A ready-made ``AsyncAPIClient`` or an ``APIClientConfig``.
        """
        if isinstance(client_or_config, APIClientConfig):
            client = AsyncAPIClient(client_or_config)
        else:
            client = client_or_config
        self._api_clients[name] = client

    def get_api_client(self, name: str) -> AsyncAPIClient:
        """Return the ``AsyncAPIClient`` registered under *name*.

        Raises
        ------
        KeyError
            If no client is registered under *name*.
        """
        if name not in self._api_clients:
            available = list(self._api_clients)
            raise KeyError(
                f"No API client named {name!r}. "
                f"Available: {available or '(none registered)'}"
            )
        return self._api_clients[name]
