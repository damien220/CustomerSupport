"""
WithNotifications — push notification support for AbstractUIController.

Wraps ``notification_manager.NotificationManager`` so controller subclasses
can send notifications via any registered channel plugin without importing
notification_manager directly.

Lifecycle
---------
``open()``  — calls ``await notification_manager.start()``
``close()`` — calls ``await notification_manager.stop()``

Usage::

    from notification_manager.plugins import ConsolePlugin

    class MyController(WithNotifications, AbstractUIController):
        pass

    async with MyController() as ctrl:
        ctrl.register_channel("console", ConsolePlugin())
        await ctrl.send_notification(
            "Job done", "Report generation finished",
            recipient_id="ops",
        )
"""

from __future__ import annotations

from typing import Any

try:
    from notification_manager import (
        DeliveryReceipt,
        Notification,
        NotificationManager,
        PluginRegistry,
        Priority,
        Recipient,
    )
except ImportError as _err:
    raise ImportError(
        "WithNotifications requires the 'notifications' extra: "
        "pip install 'ui_controller_base[notifications]'"
    ) from _err


class WithNotifications:
    """Add ``NotificationManager``-backed push notifications to ``AbstractUIController``.

    Place **before** ``AbstractUIController`` in the class bases::

        class MyController(WithNotifications, AbstractUIController):
            ...
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._notification_registry: PluginRegistry = PluginRegistry()
        self._notification_manager: NotificationManager = NotificationManager(
            registry=self._notification_registry,
        )

    # ── Lifecycle ────────────────────────────────────────────────

    async def open(self) -> None:
        await super().open()  # type: ignore[misc]
        await self._notification_manager.start()

    async def close(self) -> None:
        await self._notification_manager.stop()
        await super().close()  # type: ignore[misc]

    # ── Public API ───────────────────────────────────────────────

    def register_channel(self, channel_id: str, plugin: Any) -> None:
        """Register a ``ChannelPlugin`` under *channel_id*.

        Must be called **before** ``open()`` (i.e. before the notification
        manager starts).

        Parameters
        ----------
        channel_id:
            Stable identifier for this channel (e.g. ``"slack"``, ``"email"``).
        plugin:
            A ``notification_manager.plugins.ChannelPlugin`` instance.
        """
        self._notification_registry.register(channel_id, plugin)

    async def send_notification(
        self,
        title: str,
        body: str,
        recipient_id: str,
        *,
        priority: Priority = Priority.NORMAL,
        channel: str | None = None,
    ) -> DeliveryReceipt:
        """Send a notification to *recipient_id*.

        Parameters
        ----------
        title:
            Subject / headline of the notification.
        body:
            Main body text.
        recipient_id:
            Stable application-defined recipient identifier.
        priority:
            ``Priority.LOW | NORMAL | HIGH | CRITICAL``.  Default ``NORMAL``.
        channel:
            Optional channel hint (e.g. ``"slack"``).  When omitted the
            manager routes via the registered default.

        Returns
        -------
        DeliveryReceipt
            Delivery status and attempt log from the channel plugin.
        """
        notification = Notification(
            title=title,
            body=body,
            recipient=Recipient(id=recipient_id),
            priority=priority,
            channel_hint=channel,
        )
        return await self._notification_manager.send(notification)

    @property
    def notification_manager(self) -> NotificationManager:
        """The underlying ``NotificationManager`` instance."""
        return self._notification_manager
