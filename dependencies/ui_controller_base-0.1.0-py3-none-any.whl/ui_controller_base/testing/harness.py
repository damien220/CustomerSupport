"""
InMemoryAdapter + ControllerTestHarness — lightweight test utilities.

Usage::

    from ui_controller_base.testing import ControllerTestHarness

    async def test_greet():
        async with ControllerTestHarness(MyController) as harness:
            resp = await harness.dispatch("greet", name="Ada")
            assert "Ada" in resp.fragments[0].content

Or directly::

    from ui_controller_base.testing import InMemoryAdapter

    async def test_greet():
        async with InMemoryAdapter(MyController()) as adapter:
            resp = await adapter.dispatch("greet", name="World")
            assert resp.status == UIStatus.OK
"""

from __future__ import annotations

from typing import Any

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.adapter import AbstractFrameworkAdapter
from ui_controller_base.core.response import UIResponse
from ui_controller_base.types import UIStatus


class InMemoryAdapter(AbstractFrameworkAdapter):
    """Thin test double for ``AbstractUIController`` that dispatches in-process.

    - No framework, no I/O — just direct ``ahandle`` calls.
    - Records every ``(UIAction, UIResponse)`` pair in ``.history``.
    - Implements the async context manager protocol for lifecycle management.

    Parameters
    ----------
    controller:
        An ``AbstractUIController`` instance to wrap.
    session_id:
        Default session ID injected into actions when not specified.
    """

    def __init__(
        self,
        controller: Any | None = None,
        *,
        session_id: str = "test-session",
    ) -> None:
        super().__init__()
        self._session_id = session_id
        self._history: list[tuple[UIAction, UIResponse]] = []
        if controller is not None:
            self.mount(controller)

    # ── AbstractFrameworkAdapter ──────────────────────────────────

    def translate_request(self, native: dict) -> UIAction:
        return UIAction(
            name=native.get("name", ""),
            payload=native.get("payload", {}),
            session_id=native.get("session_id", self._session_id),
        )

    def translate_response(self, response: UIResponse) -> UIResponse:
        return response

    def serve(self) -> None:
        raise NotImplementedError(
            "InMemoryAdapter has no serve() — use dispatch() for in-process testing."
        )

    # ── Lifecycle ─────────────────────────────────────────────────

    async def open(self) -> None:
        """Open the mounted controller (idempotent)."""
        if not getattr(self._controller, "_is_open", False):
            await self._controller.open()

    async def close(self) -> None:
        """Close the mounted controller (idempotent)."""
        if getattr(self._controller, "_is_open", False):
            await self._controller.close()

    async def __aenter__(self) -> "InMemoryAdapter":
        await self.open()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # ── Dispatch helper ───────────────────────────────────────────

    async def dispatch(
        self,
        action_name: str,
        *,
        session_id: str | None = None,
        **kwargs: Any,
    ) -> UIResponse:
        """Dispatch *action_name* with *kwargs* as payload and return the response.

        Parameters
        ----------
        action_name:
            Registered tool / action name.
        session_id:
            Override the default session ID for this call.
        **kwargs:
            Action payload — forwarded verbatim to the tool function.
        """
        action = UIAction(
            name=action_name,
            payload=kwargs,
            session_id=session_id or self._session_id,
        )
        response = await self.controller.ahandle(action)
        self._history.append((action, response))
        return response

    async def render_view(self, route: str, *, session_id: str | None = None) -> UIResponse:
        """Render the view at *route* and return its ``UIResponse``.

        Parameters
        ----------
        route:
            View route, e.g. ``"/home"``.
        session_id:
            Override the default session ID.
        """
        from ui_controller_base.core.context import UIContext
        from ui_controller_base.core.state import UIState

        sid = session_id or self._session_id
        ctx = UIContext.create(session_id=sid, events=self.controller.events)
        state: UIState = UIState(session_id=sid)
        if hasattr(self.controller, "_state_store"):
            loaded = self.controller._state_store.get(sid)
            if loaded is not None:
                state = loaded

        view = await self.controller.view_registry.get_by_route(route)
        response = await view.render(ctx, state)
        return response

    # ── Inspection helpers ────────────────────────────────────────

    @property
    def history(self) -> list[tuple[UIAction, UIResponse]]:
        """All ``(UIAction, UIResponse)`` pairs dispatched so far."""
        return list(self._history)

    def clear_history(self) -> None:
        """Reset the dispatch history."""
        self._history.clear()

    def last_response(self) -> UIResponse | None:
        """The most recent ``UIResponse``, or ``None`` if nothing dispatched yet."""
        return self._history[-1][1] if self._history else None

    def responses_for(self, action_name: str) -> list[UIResponse]:
        """All responses for a given action name."""
        return [resp for act, resp in self._history if act.name == action_name]

    def assert_ok(self, response: UIResponse | None = None) -> UIResponse:
        """Assert that *response* (or the last response) has status SUCCESS."""
        resp = response if response is not None else self.last_response()
        assert resp is not None, "No response recorded — did you call dispatch()?"
        assert resp.status == UIStatus.SUCCESS, (
            f"Expected SUCCESS, got {resp.status}. Errors: {resp.errors}"
        )
        return resp

    def assert_error(self, response: UIResponse | None = None) -> UIResponse:
        """Assert that *response* (or the last response) has status ERROR."""
        resp = response if response is not None else self.last_response()
        assert resp is not None, "No response recorded"
        assert resp.status == UIStatus.ERROR, (
            f"Expected ERROR, got {resp.status}"
        )
        return resp


class ControllerTestHarness:
    """Async context manager that constructs a controller and wraps it in an ``InMemoryAdapter``.

    Usage::

        async with ControllerTestHarness(MyController) as adapter:
            resp = await adapter.dispatch("greet", name="Ada")

    Parameters
    ----------
    controller_class:
        ``AbstractUIController`` subclass (not an instance).
    session_id:
        Default session ID for all dispatches.
    **init_kwargs:
        Passed to ``controller_class(**init_kwargs)`` on entry.
    """

    def __init__(
        self,
        controller_class: type,
        *,
        session_id: str = "test-session",
        **init_kwargs: Any,
    ) -> None:
        self._ctrl_class = controller_class
        self._session_id = session_id
        self._init_kwargs = init_kwargs
        self._adapter: InMemoryAdapter | None = None

    async def __aenter__(self) -> InMemoryAdapter:
        ctrl = self._ctrl_class(**self._init_kwargs)
        self._adapter = InMemoryAdapter(ctrl, session_id=self._session_id)
        await self._adapter.open()
        return self._adapter

    async def __aexit__(self, *_: object) -> None:
        if self._adapter is not None:
            await self._adapter.close()
