"""
UI-layer exception hierarchy.

All exceptions extend ``error_handler.BaseAppException`` so they integrate
with ``ErrorHandler.handle()`` and produce consistent ``{"status_code", "body"}``
dicts that every adapter can translate to its native error surface.

Hierarchy
---------
BaseAppException  (error_handler)
└── UIException               — root for all UI-layer errors (500)
    ├── UIValidationError     — invalid payload / form input (400)
    ├── UIAuthError           — authentication required (401)
    ├── UIForbiddenError      — authorised but not permitted (403)
    ├── UINotFoundError       — view or resource not found (404)
    ├── UIActionNotFoundError — unknown action name dispatched (404)
    ├── UIConflictError       — duplicate / stale-state conflict (409)
    └── UIBackendError        — upstream service failure (502)
"""

from __future__ import annotations

from typing import Any

from error_handler import BaseAppException


class UIException(BaseAppException):
    """Root exception for all UI Controller Base errors."""

    def __init__(
        self,
        message: str = "An unexpected UI error occurred",
        *,
        code: str = "UI_ERROR",
        status_code: int = 500,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            details=details,
            previous=previous,
        )


class UIValidationError(UIException):
    """Raised when the action payload fails validation (HTTP 400)."""

    def __init__(
        self,
        message: str = "Invalid request payload",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_VALIDATION_ERROR",
            status_code=400,
            details=details,
            previous=previous,
        )


class UIAuthError(UIException):
    """Raised when a request is unauthenticated (HTTP 401)."""

    def __init__(
        self,
        message: str = "Authentication required",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_AUTH_ERROR",
            status_code=401,
            details=details,
            previous=previous,
        )


class UIForbiddenError(UIException):
    """Raised when a request is authenticated but not authorised (HTTP 403)."""

    def __init__(
        self,
        message: str = "Access forbidden",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_FORBIDDEN",
            status_code=403,
            details=details,
            previous=previous,
        )


class UINotFoundError(UIException):
    """Raised when a view or resource cannot be found (HTTP 404)."""

    def __init__(
        self,
        message: str = "Not found",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_NOT_FOUND",
            status_code=404,
            details=details,
            previous=previous,
        )


class UIActionNotFoundError(UINotFoundError):
    """Raised when the dispatcher receives an unregistered action name."""

    def __init__(
        self,
        action_name: str,
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            f"Unknown action: '{action_name}'",
            details={"action": action_name, **(details or {})},
            previous=previous,
        )
        self.code = "UI_ACTION_NOT_FOUND"


class UIConflictError(UIException):
    """Raised on duplicate submission or stale-state conflict (HTTP 409)."""

    def __init__(
        self,
        message: str = "Conflict",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_CONFLICT",
            status_code=409,
            details=details,
            previous=previous,
        )


class UIBackendError(UIException):
    """Raised when an upstream backend service fails (HTTP 502)."""

    def __init__(
        self,
        message: str = "Backend service unavailable",
        *,
        details: dict[str, Any] | None = None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(
            message,
            code="UI_BACKEND_ERROR",
            status_code=502,
            details=details,
            previous=previous,
        )
