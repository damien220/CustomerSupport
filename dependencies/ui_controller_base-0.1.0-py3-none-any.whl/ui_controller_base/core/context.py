"""
UIContext — per-request scoped container passed through every controller call.

UIContext is intentionally a plain dataclass (not a Pydantic model) because it
carries live objects (logger, cache, event bus) that cannot be serialized.

Usage
-----
The adapter creates a UIContext for each incoming request:

    async with UIContext.create(session_id="abc", user="alice") as ctx:
        response = await controller.ahandle(action, ctx)

Inside the ``async with`` block, ``logger_pkg.bind_context`` attaches
``request_id`` and ``session_id`` to every log record emitted in the current
async task, then restores the previous context on exit.

The ``cache`` and ``events`` slots are intentionally typed ``Any``; they are
populated in Phase 3/4 by the controller and mixins, keeping this module
dependency-free from those subsystems.
"""

from __future__ import annotations

import logging
from contextvars import Token
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from logger_pkg import bind_context, get_logger, new_correlation_id, reset_context


def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


@dataclass
class UIContext:
    """Per-request context bag.

    Attributes
    ----------
    request_id:
        Unique ID for this request/action; auto-generated if not supplied.
    session_id:
        Identifies the user session across multiple actions.
    user:
        Opaque user identifier; ``None`` for anonymous requests.
    logger:
        ``logging.Logger`` bound to this module; log records automatically
        carry ``request_id``/``session_id`` via ``logger_pkg``'s context vars.
    cache:
        Cache namespace injected by the controller (Phase 4).
    events:
        Event dispatcher injected by the controller (Phase 3).
    clock:
        UTC timestamp when this context was created; useful for latency
        measurements and audit logging.
    """

    request_id: str = field(default_factory=new_correlation_id)
    session_id: str = field(default_factory=new_correlation_id)
    user: str | None = None
    logger: logging.Logger = field(default_factory=lambda: get_logger(__name__))
    cache: Any = None
    events: Any = None
    clock: datetime = field(default_factory=_utcnow)

    # Internal: token returned by bind_context so we can restore on exit.
    _token: Token | None = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------
    # Context manager — binds request_id/session_id into logger_pkg vars
    # ------------------------------------------------------------------

    def __enter__(self) -> "UIContext":
        self._token = bind_context(
            request_id=self.request_id,
            session_id=self.session_id,
            user=self.user,
        )
        return self

    def __exit__(self, *_: object) -> None:
        if self._token is not None:
            reset_context(self._token)
            self._token = None

    async def __aenter__(self) -> "UIContext":
        return self.__enter__()

    async def __aexit__(self, *args: object) -> None:
        self.__exit__(*args)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        *,
        session_id: str | None = None,
        user: str | None = None,
        request_id: str | None = None,
        cache: Any = None,
        events: Any = None,
        logger_name: str = __name__,
    ) -> "UIContext":
        """Construct a UIContext with sensible defaults.

        Parameters
        ----------
        session_id:
            Re-use an existing session ID (e.g. from ``st.session_state``).
            A new UUID4 is generated when omitted.
        user:
            Optional user identity string.
        request_id:
            Override the auto-generated correlation ID.
        cache:
            Pre-built cache namespace (injected by controller, optional).
        events:
            Event dispatcher instance (injected by controller, optional).
        logger_name:
            Name passed to ``logger_pkg.get_logger``; defaults to this module.
        """
        return cls(
            request_id=request_id or new_correlation_id(),
            session_id=session_id or new_correlation_id(),
            user=user,
            logger=get_logger(logger_name),
            cache=cache,
            events=events,
        )
