"""
ui_controller_base.core
=======================
Value objects, context, and adapter protocol.  Nothing here imports from the
outer mixins, registry, or tools sub-packages.
"""

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.adapter import AbstractFrameworkAdapter
from ui_controller_base.core.context import UIContext
from ui_controller_base.core.dispatcher import UIDispatcher
from ui_controller_base.core.response import UIFragment, UIResponse
from ui_controller_base.core.state import UIState
from ui_controller_base.core.view import AbstractView

__all__ = [
    "AbstractFrameworkAdapter",
    "AbstractView",
    "UIAction",
    "UIContext",
    "UIDispatcher",
    "UIFragment",
    "UIResponse",
    "UIState",
]
