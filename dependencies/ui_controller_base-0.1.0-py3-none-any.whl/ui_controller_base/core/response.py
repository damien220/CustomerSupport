"""
UIResponse and UIFragment — immutable value objects returned by
``AbstractUIController.ahandle()`` and ``AbstractView.render()``.

Adapters translate these into their native render primitives:
- Streamlit  → ``st.write``, ``st.dataframe``, ``st.error``, …
- FastAPI     → JSON response body
- CLI         → ``rich`` console output
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ui_controller_base.types import FragmentType, UIStatus


class UIFragment(BaseModel):
    """A single renderable unit within a UIResponse.

    Attributes
    ----------
    type:
        Semantic type that the adapter uses to choose the render strategy.
    content:
        The payload to render.  Shape depends on ``type``:
        - ``TEXT``    → ``str`` (plain text or markdown)
        - ``TABLE``   → ``list[dict]`` or dict with ``"columns"``/``"rows"``
        - ``CHART``   → dict compatible with Vega-Altair / Plotly spec
        - ``FORM``    → dict describing field definitions
        - ``HTML``    → ``str`` (raw HTML — adapter must opt-in)
        - ``ERROR``   → dict from ``ErrorHandler.handle()["body"]``
        - ``PROGRESS``→ ``{"value": float, "label": str}`` (0.0–1.0)
        - ``NOTIFICATION`` → ``{"message": str, "level": str}``
    key:
        Optional stable identifier for keyed updates (e.g. Streamlit
        ``key=`` argument) so the adapter can target specific widgets.
    """

    model_config = ConfigDict(frozen=True)

    type: FragmentType
    content: Any
    key: str | None = None


class UIResponse(BaseModel):
    """Complete response from a controller action or view render.

    Attributes
    ----------
    status:
        High-level outcome; adapters use this to set HTTP status codes,
        choose render branches, or show error state.
    fragments:
        Ordered list of renderable units.  May be empty for redirect/pending.
    redirect:
        If set, the adapter should navigate to this view route instead of
        rendering ``fragments``.
    toast:
        Short one-line status message to surface as a toast / snackbar.
    errors:
        Structured error dicts produced by ``ErrorHandler.handle()``.
        Each entry has ``{"status_code": int, "body": {...}}``.
    job_id:
        Populated when ``status == PENDING`` — identifies the background
        job the adapter can poll for completion.
    workflow_id:
        Populated when ``status == WAITING`` — identifies the suspended
        workflow the user must resume.
    """

    model_config = ConfigDict(frozen=True)

    status: UIStatus = UIStatus.SUCCESS
    fragments: list[UIFragment] = Field(default_factory=list)
    redirect: str | None = None
    toast: str | None = None
    errors: list[dict[str, Any]] = Field(default_factory=list)
    job_id: str | None = None
    workflow_id: str | None = None

    # ------------------------------------------------------------------
    # Convenience constructors
    # ------------------------------------------------------------------

    @classmethod
    def ok(cls, *fragments: UIFragment, toast: str | None = None) -> "UIResponse":
        """Return a successful response with the given fragments."""
        return cls(status=UIStatus.SUCCESS, fragments=list(fragments), toast=toast)

    @classmethod
    def text(cls, content: str, *, key: str | None = None, toast: str | None = None) -> "UIResponse":
        """Shorthand: a successful response with a single TEXT fragment."""
        return cls.ok(UIFragment(type=FragmentType.TEXT, content=content, key=key), toast=toast)

    @classmethod
    def error(cls, *error_dicts: dict[str, Any], toast: str | None = None) -> "UIResponse":
        """Return an error response containing the given error dicts."""
        fragments = [
            UIFragment(type=FragmentType.ERROR, content=e.get("body", e))
            for e in error_dicts
        ]
        return cls(
            status=UIStatus.ERROR,
            fragments=fragments,
            errors=list(error_dicts),
            toast=toast,
        )

    @classmethod
    def redirect_to(cls, route: str, *, toast: str | None = None) -> "UIResponse":
        """Return a redirect response pointing to *route*."""
        return cls(status=UIStatus.REDIRECT, redirect=route, toast=toast)

    @classmethod
    def pending(cls, job_id: str, *, toast: str | None = None) -> "UIResponse":
        """Return a pending response for a running background job."""
        return cls(status=UIStatus.PENDING, job_id=job_id, toast=toast)

    @classmethod
    def waiting(cls, workflow_id: str, *, toast: str | None = None) -> "UIResponse":
        """Return a waiting response for a suspended HumanStep workflow."""
        return cls(status=UIStatus.WAITING, workflow_id=workflow_id, toast=toast)
