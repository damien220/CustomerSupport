"""
UIState — per-session mutable state container.

StatefulMixin (Phase 4) manages a StateStore that persists and loads UIState
objects.  The ``version`` field enables optimistic concurrency: a stale
write (version mismatch) should raise ``UIConflictError``.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class UIState(BaseModel):
    """Session-scoped state bag.

    Attributes
    ----------
    session_id:
        Unique identifier for the user session.
    data:
        Arbitrary key-value store — views and tools read/write here.
    version:
        Monotonically increasing counter; incremented on every ``StateStore``
        write.  Used for optimistic locking to detect concurrent updates.
    """

    model_config = ConfigDict(frozen=True)

    session_id: str
    data: dict[str, Any] = Field(default_factory=dict)
    version: int = 0

    def evolve(self, **updates: Any) -> "UIState":
        """Return a new UIState with ``data`` merged with *updates*."""
        return self.model_copy(
            update={"data": {**self.data, **updates}, "version": self.version + 1}
        )
