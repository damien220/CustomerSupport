"""
AbstractView — the discoverable, lifecycle-managed UI surface unit.

AbstractView extends ``plugin_loader.AbstractPlugin`` so every view
participates in the plugin state machine:

    DISCOVERED → LOADED → VALIDATED → INITIALIZED → ACTIVE ↔ DISABLED

This gives views:
  - dependency-ordered startup / shutdown via ``ViewRegistry``
  - sandboxed execution (broken views don't crash the host)
  - tag-based filtering (e.g. ``"admin"``, ``"dashboard"``)
  - hot-enable / hot-disable without restarting the application

Concrete subclasses must define
---------------------------------
    plugin_name: str          — unique view identifier, e.g. "home"
    route: str                — URL path, e.g. "/home"

And implement
--------------
    async render(ctx, state) -> UIResponse

They MAY override the lifecycle hooks
---------------------------------------
    async initialize(config)  — acquire resources, connect to backends
    async start()             — called when the view becomes ACTIVE
    async stop()              — graceful shutdown
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from plugin_loader import AbstractPlugin

from ui_controller_base.core.context import UIContext
from ui_controller_base.core.response import UIResponse
from ui_controller_base.core.state import UIState


class AbstractView(AbstractPlugin):
    """Base class for all UI views.

    Attributes
    ----------
    plugin_name:
        Unique identifier; **must** be set on every concrete subclass.
    route:
        URL-style path the adapter maps to this view, e.g. ``"/home"``.
    plugin_tags:
        Arbitrary labels for filtering; always includes ``"view"``.
    actions:
        Mapping of action-name → tool for view-local actions.
        Populated in Phase 3; empty dict by default.
    """

    route: str = ""
    plugin_tags: tuple[str, ...] = ("view",)
    plugin_description: str = ""
    plugin_version: str = "0.1.0"
    actions: dict[str, Any] = {}

    # ── The one required method ───────────────────────────────────

    @abstractmethod
    async def render(self, ctx: UIContext, state: UIState) -> UIResponse:
        """Produce a UIResponse for this view."""

    # ── Plugin lifecycle — no-op defaults ────────────────────────

    async def initialize(self, config: dict[str, Any] | None = None) -> None:
        """One-time setup. Override to acquire resources."""

    async def start(self) -> None:
        """Begin active operation. Override if needed."""

    async def stop(self) -> None:
        """Graceful shutdown. Override to release resources."""
