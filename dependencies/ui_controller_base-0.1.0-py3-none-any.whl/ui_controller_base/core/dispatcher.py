"""
UIDispatcher — routes UIActions to tools and translates results to UIResponses.

Responsibilities
----------------
1. Resolve ``action.name`` → ``AbstractTool`` via ``ToolRegistry``.
2. Build a ``ToolContext`` from the ``UIContext`` (forwards ``correlation_id``,
   ``session_id``, ``user``; injects the ``UIContext`` for middleware).
3. Wrap the tool with ``ContextBinderMiddleware`` and ``ErrorNormalizerMiddleware``
   before calling ``.execute()``.
4. Emit ``ui.action.received``, ``ui.action.completed``, ``ui.action.failed``
   events on the ``AbstractEventDispatcher``.
5. Normalize exceptions to ``UIActionNotFoundError`` / ``UIBackendError``,
   then build and return a ``UIResponse``.

The dispatcher is intentionally named ``UIDispatcher`` (not ``EventDispatcher``)
to avoid collision with ``event_dispatcher.AbstractEventDispatcher``.

Usage
-----
    dispatcher = UIDispatcher(tool_registry=registry, events=local_dispatcher)

    action = UIAction(name="greet", payload={"name": "Ada"})
    ctx    = UIContext.create(session_id="s1")
    response = await dispatcher.dispatch(action, ctx)
"""

from __future__ import annotations

from typing import Any

from error_handler import ErrorHandler
from event_dispatcher import DispatchEvent, LocalDispatcher
from event_dispatcher import AbstractEventDispatcher
from tool_interface_adapter import ToolContext, ToolRegistry, ToolResult

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.context import UIContext
from ui_controller_base.core.response import UIFragment, UIResponse
from ui_controller_base.core.state import UIState
from ui_controller_base.exceptions import UIActionNotFoundError, UIBackendError
from ui_controller_base.integrations.events import (
    UI_ACTION_COMPLETED,
    UI_ACTION_FAILED,
    UI_ACTION_RECEIVED,
)
from ui_controller_base.tools.middleware import (
    ContextBinderMiddleware,
    ErrorNormalizerMiddleware,
)
from ui_controller_base.types import FragmentType, UIStatus


class UIDispatcher:
    """Routes ``UIAction`` objects to registered tools and returns ``UIResponse``.

    Parameters
    ----------
    tool_registry:
        Registry of available tools.  Each tool's ``spec.name`` must match
        an ``action.name`` that will be dispatched.
    events:
        Event dispatcher for emitting action lifecycle events.
        Defaults to a fresh ``LocalDispatcher`` when omitted.
    source:
        Identifier embedded in emitted ``DispatchEvent.source`` fields.
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        events: AbstractEventDispatcher | None = None,
        source: str = "ui_controller_base",
    ) -> None:
        self._tools = tool_registry
        self._events: AbstractEventDispatcher = events or LocalDispatcher()
        self._source = source

    # ── Public API ────────────────────────────────────────────────

    async def dispatch(self, action: UIAction, ctx: UIContext) -> UIResponse:
        """Execute the action and return a UIResponse.

        Parameters
        ----------
        action:
            The user-originated action to handle.
        ctx:
            Per-request context (logger, correlation ID, session, …).

        Returns
        -------
        UIResponse
            Always returns a response; never raises (exceptions are
            translated into ``UIResponse.error(…)``).
        """
        await self._emit(
            UI_ACTION_RECEIVED,
            correlation_id=action.correlation_id,
            payload={"action": action.name, "view": action.view},
        )

        try:
            tool = self._resolve_tool(action)
            tool_ctx = self._build_tool_context(action, ctx)
            wrapped = self._wrap_middleware(tool)
            result: ToolResult = await wrapped.execute(action.payload, tool_ctx)
            response = self._result_to_response(result, action)
        except UIActionNotFoundError as exc:
            response = self._exception_to_response(exc)
        except Exception as exc:
            backend_exc = UIBackendError(
                f"Unexpected error dispatching '{action.name}'",
                previous=exc,
            )
            response = self._exception_to_response(backend_exc)

        event_kind = (
            UI_ACTION_COMPLETED if response.status == UIStatus.SUCCESS
            or response.status in (UIStatus.PENDING, UIStatus.WAITING, UIStatus.REDIRECT)
            else UI_ACTION_FAILED
        )
        await self._emit(
            event_kind,
            correlation_id=action.correlation_id,
            payload={
                "action": action.name,
                "status": response.status.value,
            },
        )

        return response

    # ── Internal helpers ──────────────────────────────────────────

    def _resolve_tool(self, action: UIAction) -> Any:
        """Look up the tool for *action.name*; raise ``UIActionNotFoundError`` if missing."""
        try:
            return self._tools.get(action.name)
        except Exception:
            raise UIActionNotFoundError(action.name)

    def _build_tool_context(self, action: UIAction, ctx: UIContext) -> ToolContext:
        """Build a ``ToolContext`` pre-populated with UIContext metadata."""
        return ToolContext(
            correlation_id=action.correlation_id,
            caller=action.user or action.view or "ui",
            metadata={
                "ui_context": ctx,
                "session_id": action.session_id,
                "action_name": action.name,
                "view": action.view,
            },
        )

    def _wrap_middleware(self, tool: Any) -> Any:
        """Wrap *tool* with the standard UI middleware stack."""
        return ContextBinderMiddleware(ErrorNormalizerMiddleware(tool))

    def _result_to_response(self, result: ToolResult, action: UIAction) -> UIResponse:
        """Convert a ``ToolResult`` to a ``UIResponse``."""
        if not result.success:
            ui_error: dict[str, Any] = result.metadata.get("ui_error") or {}
            if not ui_error:
                # Build a minimal error dict from the ToolResult.error
                err_msg = result.error.message if result.error else "Tool execution failed"
                ui_error = ErrorHandler.handle(UIBackendError(err_msg))
            return UIResponse.error(ui_error)

        data = result.data

        # If the tool already returned a UIResponse, use it directly.
        if isinstance(data, UIResponse):
            return data

        # If it returned a UIFragment, wrap it.
        if isinstance(data, UIFragment):
            return UIResponse.ok(data)

        # Plain string → TEXT fragment.
        if isinstance(data, str):
            return UIResponse.text(data)

        # Anything else → TEXT fragment with repr.
        return UIResponse.text(str(data) if data is not None else "")

    def _exception_to_response(self, exc: Exception) -> UIResponse:
        """Convert an exception into an error UIResponse."""
        normalized = ErrorHandler.handle(exc)
        return UIResponse.error(normalized)

    async def _emit(
        self,
        event_kind: str,
        *,
        correlation_id: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        """Emit a DispatchEvent; swallow any dispatcher errors to stay non-blocking."""
        try:
            event = DispatchEvent(
                event_kind=event_kind,
                source=self._source,
                correlation_id=correlation_id,
                payload=payload or {},
            )
            await self._events.emit_async(event)
        except Exception:
            pass  # event emission must never crash the dispatch path
