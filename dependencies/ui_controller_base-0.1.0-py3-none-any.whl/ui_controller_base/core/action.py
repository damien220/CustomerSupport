"""
UIAction — immutable value object representing a single user-originated event.

Created by a framework adapter when it translates a native interaction
(button click, form submit, HTTP POST, CLI command) and passed to
``AbstractUIController.ahandle()``.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field
from logger_pkg import new_correlation_id


class UIAction(BaseModel):
    """Immutable description of a user-originated action.

    Attributes
    ----------
    name:
        Identifier of the action to dispatch, e.g. ``"greet"`` or
        ``"generate_report"``.  Must match a registered tool/handler.
    view:
        Route of the view that originated this action, e.g. ``"/home"``.
        Empty string if the action is view-agnostic.
    payload:
        Arbitrary key-value parameters supplied by the user.
    correlation_id:
        Unique ID that traces this action across logs, events, and spans.
        Auto-generated via ``logger_pkg.new_correlation_id()`` if omitted.
    session_id:
        Identifies the user session; set by the adapter from its native
        session mechanism (``st.session_state``, cookie, CLI state file).
    user:
        Optional opaque user identifier.  Populated by the adapter when
        auth is available; ``None`` for anonymous requests.
    """

    model_config = ConfigDict(frozen=True)

    name: str
    view: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    correlation_id: str = Field(default_factory=new_correlation_id)
    session_id: str | None = None
    user: str | None = None
