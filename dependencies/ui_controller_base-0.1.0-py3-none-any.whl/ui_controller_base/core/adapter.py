"""
AbstractFrameworkAdapter — protocol for binding a controller to a UI framework.

Each concrete adapter (Streamlit, FastAPI, CLI) implements this interface.
Adapters are the only layer allowed to import framework-specific packages;
the controller and views remain framework-agnostic.

Lifecycle
---------
    adapter = StreamlitAdapter()
    adapter.mount(controller)   # attach controller, build routes/widgets
    adapter.serve()             # hand control to the framework event loop
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.response import UIResponse

if TYPE_CHECKING:
    pass  # AbstractUIController imported lazily to avoid circular imports


class AbstractFrameworkAdapter(ABC):
    """Binding between ``AbstractUIController`` and a concrete UI framework.

    Adapters translate framework-native interactions into ``UIAction`` objects,
    pass them to the controller, then translate the returned ``UIResponse``
    back into framework-native render calls.

    The controller reference is set by ``mount()`` so the same adapter class
    can be instantiated before the controller is ready.
    """

    def __init__(self) -> None:
        self._controller: Any = None

    # ── Lifecycle ────────────────────────────────────────────────

    def mount(self, controller: Any) -> None:
        """Attach *controller* to this adapter.

        Must be called before ``serve()``.  Concrete adapters may override
        to perform additional binding (e.g. registering routes).
        """
        self._controller = controller

    @abstractmethod
    def serve(self) -> None:
        """Hand control to the framework event loop.

        For Streamlit this is a no-op (Streamlit owns the loop).
        For FastAPI this starts uvicorn.
        For CLI this invokes the Typer app.
        """

    # ── Translation ──────────────────────────────────────────────

    @abstractmethod
    def translate_request(self, native: Any) -> UIAction:
        """Convert a framework-native input into a ``UIAction``.

        Parameters
        ----------
        native:
            Framework-specific request object (e.g. a FastAPI ``Request``,
            a dict of Streamlit widget values, or a Typer context).
        """

    @abstractmethod
    def translate_response(self, response: UIResponse) -> Any:
        """Convert a ``UIResponse`` into a framework-native render output.

        Parameters
        ----------
        response:
            Controller response to render.

        Returns
        -------
        Any
            Framework-specific value (e.g. a FastAPI ``JSONResponse``,
            a Streamlit component tree, or a Rich console output).
        """

    # ── Convenience ──────────────────────────────────────────────

    @property
    def controller(self) -> Any:
        """The mounted controller instance. Raises if not yet mounted."""
        if self._controller is None:
            raise RuntimeError(
                f"{type(self).__name__}.mount(controller) must be called before accessing .controller"
            )
        return self._controller
