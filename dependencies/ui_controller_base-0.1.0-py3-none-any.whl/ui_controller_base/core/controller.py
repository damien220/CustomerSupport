"""
AbstractUIController — the central orchestrator.

The same controller subclass can be mounted on Streamlit, FastAPI, or CLI
without any branching on the framework:

    class MyController(AbstractUIController):
        views = [HomeView, ReportView]
        tools = [UITool.from_fn("greet", greet_fn)]

    StreamlitAdapter(MyController()).serve()
    FastAPIAdapter(MyController()).mount(app)
    CLIAdapter(MyController()).serve()

Architecture
------------
AbstractUIController owns three sub-systems:

    ViewRegistry    — discovers, initialises, and routes to AbstractView instances
    ToolRegistry    — registers AbstractTool instances for the dispatcher
    UIDispatcher    — resolves UIAction → tool → UIResponse + emits events

All three are wired together in ``open()``.

Lifecycle (mirrors abstract_agent.AbstractAgent)
-------------------------------------------------
    __init__()           — register class-level views/tools; build sub-systems
    open()               — prepare all views (initialize → start)
    [handle / ahandle]*  — dispatch actions
    close()              — stop all views, teardown resources

    Per-turn hooks (override freely):
        setup(action, ctx)    — called before dispatch
        teardown(action, ctx) — called after dispatch (even on error)
        on_error(exc, action) — called when dispatch raises

Async-first with a sync bridge
-------------------------------
    await controller.ahandle(action, ctx)   # primary async entry point
          controller.handle(action, ctx)    # sync bridge via asgiref
"""

from __future__ import annotations

import logging
from typing import Any

from asgiref.sync import async_to_sync
from event_dispatcher import LocalDispatcher
from logger_pkg import get_logger
from tool_interface_adapter import ToolRegistry

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.context import UIContext
from ui_controller_base.core.dispatcher import UIDispatcher
from ui_controller_base.core.response import UIResponse
from ui_controller_base.core.state import UIState
from ui_controller_base.exceptions import UIBackendError
from ui_controller_base.registry.view_registry import ViewRegistry


class AbstractUIController:
    """Reusable base controller that wires views, tools, and the dispatcher.

    Class-level declarations
    ------------------------
    views : list[type[AbstractView]]
        View classes to register on construction.  Each must be a concrete
        ``AbstractView`` subclass with a ``plugin_name`` and ``route``.

    tools : list[AbstractTool | FunctionTool]
        Tool instances to register on construction.  Use ``UITool.from_fn``
        for quick function-based tools.

    Minimal subclass::

        class MyController(AbstractUIController):
            views = [HomeView]
            tools = [UITool.from_fn("greet", greet_fn)]
    """

    views: list[Any] = []
    tools: list[Any] = []

    def __init__(self) -> None:
        self._log: logging.Logger = get_logger(
            f"ui_controller.{type(self).__name__}"
        )

        # Sub-systems — wired together in open()
        self._view_registry: ViewRegistry = ViewRegistry()
        self._tool_registry: ToolRegistry = ToolRegistry()

        # Event bus — ObservableMixin replaces this with a real dispatcher;
        # we keep a default so the controller works without the mixin.
        if not hasattr(self, "events"):
            self.events: LocalDispatcher = LocalDispatcher()

        self._dispatcher: UIDispatcher = UIDispatcher(
            tool_registry=self._tool_registry,
            events=self.events,
            source=type(self).__name__,
        )

        # Register class-level declarations
        self._register_views()
        self._register_tools()

        self._is_open: bool = False

    # ── Lifecycle ────────────────────────────────────────────────

    async def open(self) -> None:
        """Prepare all views (initialize → start).

        Call once before the first ``ahandle`` — or use the async context
        manager which calls it automatically::

            async with MyController() as ctrl:
                response = await ctrl.ahandle(action, ctx)
        """
        if self._is_open:
            return
        await self._view_registry.prepare()
        self._is_open = True
        self._log.debug("%s opened", type(self).__name__)

    async def close(self) -> None:
        """Stop all views and release resources."""
        if not self._is_open:
            return
        await self._view_registry.stop_all()
        self._is_open = False
        self._log.debug("%s closed", type(self).__name__)

    async def __aenter__(self) -> "AbstractUIController":
        await self.open()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # ── Per-turn hooks (override freely) ─────────────────────────

    async def setup(self, action: UIAction, ctx: UIContext) -> None:
        """Called before every ``ahandle`` dispatch.  Override as needed."""

    async def teardown(self, action: UIAction, ctx: UIContext) -> None:
        """Called after every ``ahandle`` dispatch (even on error)."""

    async def on_error(self, exc: Exception, action: UIAction) -> None:
        """Called when dispatch raises.  Default logs and re-raises."""
        self._log.error(
            "dispatch error: %s",
            exc,
            extra={"action": action.name, "exc_type": type(exc).__name__},
        )

    # ── Main entry points ────────────────────────────────────────

    async def ahandle(
        self,
        action: UIAction,
        ctx: UIContext | None = None,
    ) -> UIResponse:
        """Async entry point — dispatch *action* and return a ``UIResponse``.

        Parameters
        ----------
        action:
            User-originated action (name, payload, session_id, …).
        ctx:
            Per-request context.  A new context is created from
            ``action.session_id`` when omitted.

        Returns
        -------
        UIResponse
            Always returns a response; exceptions are translated into
            ``UIResponse.error(…)`` rather than propagating.
        """
        if ctx is None:
            ctx = UIContext.create(
                session_id=action.session_id,
                user=action.user,
                request_id=action.correlation_id,
                events=self.events,
            )

        await self.setup(action, ctx)
        try:
            response = await self._dispatcher.dispatch(action, ctx)
        except Exception as exc:
            await self.on_error(exc, action)
            normalized = UIBackendError(
                f"Unhandled error in {type(self).__name__}",
                previous=exc,
            )
            from error_handler import ErrorHandler
            response = UIResponse.error(ErrorHandler.handle(normalized))
        finally:
            await self.teardown(action, ctx)

        return response

    def handle(
        self,
        action: UIAction,
        ctx: UIContext | None = None,
    ) -> UIResponse:
        """Sync bridge for ``ahandle`` (Streamlit / CLI / WSGI contexts).

        Uses ``asgiref.async_to_sync`` to run ``ahandle`` from a synchronous
        call site.  Do not call from inside a running event loop — use
        ``await ahandle(...)`` there instead.
        """
        return async_to_sync(self.ahandle)(action, ctx)

    # ── View access ──────────────────────────────────────────────

    @property
    def view_registry(self) -> ViewRegistry:
        """The controller's ``ViewRegistry``."""
        return self._view_registry

    @property
    def tool_registry(self) -> ToolRegistry:
        """The controller's ``ToolRegistry``."""
        return self._tool_registry

    @property
    def dispatcher(self) -> UIDispatcher:
        """The controller's ``UIDispatcher``."""
        return self._dispatcher

    @property
    def routes(self) -> list[str]:
        """All registered view routes."""
        return self._view_registry.routes

    # ── Internal helpers ─────────────────────────────────────────

    def _register_views(self) -> None:
        for view_cls in type(self).views:
            self._view_registry.register(view_cls)

    def _register_tools(self) -> None:
        for tool in type(self).tools:
            self._tool_registry.register(tool, force=True)
