"""
Canonical event topic strings for UI Controller Base.

All DispatchEvents emitted by the package use these constants so
subscribers can pattern-match reliably.  Wildcard patterns work too:

    dispatcher.subscribe("ui.action.*", handler)  # all action events
    dispatcher.subscribe("ui.**", handler)         # every UI event
"""

from __future__ import annotations

# Action lifecycle
UI_ACTION_RECEIVED = "ui.action.received"
UI_ACTION_COMPLETED = "ui.action.completed"
UI_ACTION_FAILED = "ui.action.failed"

# View lifecycle
UI_VIEW_MOUNTED = "ui.view.mounted"
UI_VIEW_UNMOUNTED = "ui.view.unmounted"

# State
UI_STATE_CHANGED = "ui.state.changed"

# Convenience collection for "subscribe to everything UI"
ALL_UI_TOPICS = (
    UI_ACTION_RECEIVED,
    UI_ACTION_COMPLETED,
    UI_ACTION_FAILED,
    UI_VIEW_MOUNTED,
    UI_VIEW_UNMOUNTED,
    UI_STATE_CHANGED,
)
