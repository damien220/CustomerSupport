"""
ui_controller_base.integrations
================================
Thin glue modules, one per sibling dependency package.
Each module exports constants, helpers, or wrappers that keep the
rest of the package from importing sibling packages directly.
"""
