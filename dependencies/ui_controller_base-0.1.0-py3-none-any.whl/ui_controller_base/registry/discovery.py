"""
Discovery helpers — pre-configured strategies for finding AbstractView subclasses.

Usage
-----
    strategy = make_view_discovery(view_dirs=["./views"])
    manager.add_discovery_strategy(strategy)
    manager.discover()

The standard entry-point group ``"ui_controller_base.views"`` lets third-party
packages advertise views without any directory scanning:

    [project.entry-points."ui_controller_base.views"]
    my_dashboard = "mypkg.views:DashboardView"
"""

from __future__ import annotations

from plugin_loader import CompositeStrategy, DirectoryStrategy, EntryPointStrategy

VIEW_ENTRY_POINT_GROUP = "ui_controller_base.views"


def make_view_discovery(
    view_dirs: list[str] | None = None,
    *,
    entry_point_group: str = VIEW_ENTRY_POINT_GROUP,
    base_class: type | None = None,
    recursive: bool = True,
) -> CompositeStrategy:
    """Build a ``CompositeStrategy`` that discovers AbstractView subclasses.

    Parameters
    ----------
    view_dirs:
        Filesystem directories to scan for ``*.py`` files.  Each file is
        imported and inspected for ``AbstractView`` subclasses.
    entry_point_group:
        Entry-point group name for installed-package discovery.
        Defaults to ``"ui_controller_base.views"``.
    base_class:
        Filter; only classes that are a subclass of *base_class* are kept.
        Pass ``AbstractView`` (imported by the caller) to restrict to views.
    recursive:
        Whether to scan subdirectories when using ``DirectoryStrategy``.

    Returns
    -------
    CompositeStrategy
        Ready to be added to a ``PluginManager`` via
        ``manager.add_discovery_strategy(strategy)``.
    """
    strategies: list[DirectoryStrategy | EntryPointStrategy] = []

    if view_dirs:
        strategies.append(
            DirectoryStrategy(
                view_dirs,
                base_class=base_class,
                recursive=recursive,
            )
        )

    strategies.append(
        EntryPointStrategy(
            entry_point_group,
            base_class=base_class,
        )
    )

    return CompositeStrategy(strategies)
