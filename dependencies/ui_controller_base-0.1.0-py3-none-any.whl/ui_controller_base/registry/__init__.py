"""
ui_controller_base.registry
============================
View discovery, registration, and lifecycle management.
"""

from ui_controller_base.registry.discovery import VIEW_ENTRY_POINT_GROUP, make_view_discovery
from ui_controller_base.registry.view_registry import ViewRegistry

__all__ = [
    "ViewRegistry",
    "make_view_discovery",
    "VIEW_ENTRY_POINT_GROUP",
]
