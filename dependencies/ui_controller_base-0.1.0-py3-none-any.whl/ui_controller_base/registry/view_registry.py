"""
ViewRegistry — lifecycle-managed registry of AbstractView instances.

Wraps ``plugin_loader.PluginManager`` with a view-specific API that adds:
  - Route-based lookup (``get_by_route("/home")``)
  - A ``prepare()`` convenience method (initialize + start in one call)
  - An async context manager for automatic graceful shutdown
  - Discovery wiring via ``make_view_discovery``

Typical usage inside a controller
-----------------------------------
    registry = ViewRegistry()
    registry.register(HomeView)
    registry.register(ReportView)
    await registry.prepare()                 # initialize → start

    view = await registry.get_by_route("/home")
    response = await view.render(ctx, state)

    await registry.stop_all()               # or use `async with registry:`
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from plugin_loader import (
    AbstractDiscoveryStrategy,
    PluginManager,
    PluginManagerConfig,
    PluginRecord,
    PluginState,
)

from ui_controller_base.exceptions import UINotFoundError

if TYPE_CHECKING:
    from ui_controller_base.core.view import AbstractView


class ViewRegistry:
    """Registry and lifecycle manager for ``AbstractView`` instances.

    Parameters
    ----------
    manager:
        Optional pre-built ``PluginManager``.  When omitted a default
        manager is created (suppress errors, log lifecycle events).
    """

    def __init__(self, manager: PluginManager | None = None) -> None:
        self._manager: PluginManager = manager or PluginManager(
            PluginManagerConfig(
                strict_validation=False,
                log_lifecycle=True,
                error_policy="suppress",
                allow_override=True,
            )
        )
        # route → plugin_name  (built at register-time from the class attr)
        self._route_map: dict[str, str] = {}

    # ── Registration ─────────────────────────────────────────────

    def register(self, view_class: type, config: dict[str, Any] | None = None) -> PluginRecord:
        """Manually register a view class.

        Parameters
        ----------
        view_class:
            Concrete ``AbstractView`` subclass (not an instance).
        config:
            Optional config dict passed to ``view.initialize(config)``.

        Returns
        -------
        PluginRecord
        """
        record = self._manager.register(view_class, config=config)
        route: str = getattr(view_class, "route", "")
        if route:
            self._route_map[route] = view_class.plugin_name
        return record

    def add_discovery_strategy(self, strategy: AbstractDiscoveryStrategy) -> None:
        """Attach an additional discovery strategy (e.g. ``DirectoryStrategy``)."""
        self._manager.add_discovery_strategy(strategy)

    def discover(self) -> None:
        """Run all configured discovery strategies (sync) and register findings."""
        result = self._manager.discover()
        self._rebuild_route_map()
        return result

    async def discover_async(self) -> None:
        """Run all configured discovery strategies (async) and register findings."""
        result = await self._manager.discover_async()
        self._rebuild_route_map()
        return result

    # ── Lifecycle ────────────────────────────────────────────────

    async def initialize_all(self, config: dict[str, Any] | None = None) -> list:
        """Initialize all registered views in dependency order."""
        return await self._manager.initialize_all(config)

    async def start_all(self) -> list:
        """Start all initialized views."""
        return await self._manager.start_all()

    async def stop_all(self) -> list:
        """Stop all active views in reverse dependency order."""
        return await self._manager.stop_all()

    async def prepare(self, config: dict[str, Any] | None = None) -> None:
        """Initialize then start all registered views in one call."""
        await self.initialize_all(config)
        await self.start_all()

    # ── Async context manager ────────────────────────────────────

    async def __aenter__(self) -> "ViewRegistry":
        await self.prepare()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.stop_all()

    # ── Lookup ───────────────────────────────────────────────────

    def get_by_name(self, name: str) -> "AbstractView":
        """Return the live view instance for *name*.

        Raises ``UINotFoundError`` if not registered or not yet initialized.
        """
        try:
            return self._manager.get_plugin(name)
        except Exception as exc:
            raise UINotFoundError(
                f"View '{name}' not found or not yet initialized.",
                details={"view_name": name},
                previous=exc,
            ) from exc

    async def get_by_route(self, route: str) -> "AbstractView":
        """Return the live view instance for *route* (e.g. ``"/home"``).

        Raises ``UINotFoundError`` if no view is registered for this route.
        """
        name = self._route_map.get(route)
        if name is None:
            raise UINotFoundError(
                f"No view registered for route '{route}'.",
                details={"route": route, "registered_routes": list(self._route_map)},
            )
        return self.get_by_name(name)

    # ── Queries ──────────────────────────────────────────────────

    def list_views(
        self,
        *,
        state: PluginState | None = PluginState.ACTIVE,
        tag: str | None = None,
    ) -> list[PluginRecord]:
        """Return plugin records matching the given filters.

        Parameters
        ----------
        state:
            Filter by lifecycle state.  Defaults to ``ACTIVE``.
            Pass ``None`` to list all registered views regardless of state.
        tag:
            Filter by tag (e.g. ``"admin"``).
        """
        return self._manager.list_plugins(state=state, tag=tag)

    @property
    def routes(self) -> list[str]:
        """All registered route strings."""
        return list(self._route_map.keys())

    @property
    def names(self) -> list[str]:
        """All registered plugin_name strings."""
        return list(self._route_map.values())

    # ── Internal ─────────────────────────────────────────────────

    def _rebuild_route_map(self) -> None:
        """Re-sync the route map from all records (called after discovery)."""
        for record in self._manager.list_plugins(state=None):
            route: str = getattr(record.plugin_class, "route", "")
            if route:
                self._route_map[route] = record.plugin_name
