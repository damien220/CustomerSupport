"""
UI Controller Base
==================
Reusable, abstract controller layer that standardizes the interface between
backend logic and any UI surface (Streamlit, FastAPI, CLI, …).

The same AbstractUIController subclass can be mounted on:
    StreamlitAdapter(MyController()).serve()
    FastAPIAdapter(MyController()).mount(app)
    CLIAdapter(MyController()).serve()
"""

__version__ = "0.1.0"

# Phase 1 — types, value objects, exceptions
from ui_controller_base.types import FragmentType, UIStatus
from ui_controller_base.exceptions import (
    UIException,
    UIValidationError,
    UIAuthError,
    UIForbiddenError,
    UINotFoundError,
    UIActionNotFoundError,
    UIConflictError,
    UIBackendError,
)
from ui_controller_base.core import (
    AbstractFrameworkAdapter,
    AbstractView,
    UIAction,
    UIContext,
    UIDispatcher,
    UIFragment,
    UIResponse,
    UIState,
)
from ui_controller_base.registry import VIEW_ENTRY_POINT_GROUP, ViewRegistry, make_view_discovery
from ui_controller_base.tools import ContextBinderMiddleware, ErrorNormalizerMiddleware, UITool

# Phase 4 — controller + mixins
from ui_controller_base.core.controller import AbstractUIController
from ui_controller_base.adapters.cli import CLIAdapter, FileStateStore
from ui_controller_base.adapters.fastapi import FastAPIAdapter
from ui_controller_base.adapters.streamlit import StreamlitAdapter

from ui_controller_base.mixins import (
    CacheableMixin,
    InMemoryStateStore,
    ObservableMixin,
    ReactiveMixin,
    StateStore,
    StatefulMixin,
    WithApiClients,
    WithDatabase,
    WithJobs,
    WithNotifications,
    WithWorkflows,
)

# Phase 9 — testing utilities
from ui_controller_base.testing import ControllerTestHarness, InMemoryAdapter

__all__ = [
    # version
    "__version__",
    # enums
    "FragmentType",
    "UIStatus",
    # exceptions
    "UIException",
    "UIValidationError",
    "UIAuthError",
    "UIForbiddenError",
    "UINotFoundError",
    "UIActionNotFoundError",
    "UIConflictError",
    "UIBackendError",
    # core abstractions (Phase 2)
    "AbstractFrameworkAdapter",
    "AbstractView",
    # value objects
    "UIAction",
    "UIContext",
    "UIFragment",
    "UIResponse",
    "UIState",
    # registry (Phase 2)
    "ViewRegistry",
    "make_view_discovery",
    "VIEW_ENTRY_POINT_GROUP",
    # tools + dispatcher (Phase 3)
    "UIDispatcher",
    "UITool",
    "ContextBinderMiddleware",
    "ErrorNormalizerMiddleware",
    # controller + mixins (Phase 4)
    "AbstractUIController",
    "CacheableMixin",
    "InMemoryStateStore",
    "ObservableMixin",
    "ReactiveMixin",
    "StateStore",
    "StatefulMixin",
    # capability mixins (Phase 5)
    "WithApiClients",
    "WithDatabase",
    "WithJobs",
    "WithNotifications",
    "WithWorkflows",
    # adapters (Phase 6+)
    "CLIAdapter",
    "FileStateStore",
    "FastAPIAdapter",
    "StreamlitAdapter",
    # testing utilities (Phase 9)
    "InMemoryAdapter",
    "ControllerTestHarness",
]
