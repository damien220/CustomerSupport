"""
``ui-controller`` — scaffolding and runner CLI.

Commands
--------
    ui-controller init <name>       Scaffold a new controller project
    ui-controller run-streamlit     Run the Streamlit adapter
    ui-controller run-fastapi       Run the FastAPI adapter (prints uvicorn command)
    ui-controller run-cli           Run the CLI adapter
    ui-controller list-views        List views registered on a controller module

Entry point defined in pyproject.toml::

    [project.scripts]
    ui-controller = "ui_controller_base.cli:app"
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import typer
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table

app = typer.Typer(
    name="ui-controller",
    help="UI Controller Base — scaffolding and runner",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


# ── init ─────────────────────────────────────────────────────────────────────

_CONTROLLER_TEMPLATE = '''\
"""
{name} controller.
"""
from typing import Any
from ui_controller_base import AbstractUIController, CacheableMixin, StatefulMixin, UIResponse, UITool
from {name_lower}.views.home_view import HomeView


async def greet(name: str = "World", **_: Any) -> UIResponse:
    return UIResponse.text(f"Hello, {{name}}!", toast=f"Greeted {{name}}")


class {name}Controller(CacheableMixin, StatefulMixin, AbstractUIController):
    views = [HomeView]
    tools = [UITool.from_fn("greet", greet, description="Greet a user by name")]
'''

_HOME_VIEW_TEMPLATE = '''\
"""HomeView."""
from ui_controller_base import UIResponse
from ui_controller_base.core.context import UIContext
from ui_controller_base.core.response import UIFragment
from ui_controller_base.core.state import UIState
from ui_controller_base.core.view import AbstractView
from ui_controller_base.types import FragmentType


class HomeView(AbstractView):
    plugin_name = "home"
    route = "/home"
    plugin_description = "Welcome page"

    async def render(self, ctx: UIContext, state: UIState) -> UIResponse:
        return UIResponse.ok(
            UIFragment(type=FragmentType.TEXT, content="## Welcome\\n\\nUse the form below."),
            UIFragment(
                type=FragmentType.FORM,
                content={{
                    "action": "greet",
                    "fields": [{{"name": "name", "type": "text", "label": "Your name"}}],
                    "submit_label": "Greet me!",
                }},
            ),
        )
'''

_RUN_STREAMLIT_TEMPLATE = '''\
"""Streamlit entry point.  Run: streamlit run run_streamlit.py"""
from {name_lower}.controller import {name}Controller
from ui_controller_base.adapters.streamlit import StreamlitAdapter

StreamlitAdapter({name}Controller(), title="{name} App").serve()
'''

_RUN_FASTAPI_TEMPLATE = '''\
"""FastAPI entry point.  Run: uvicorn run_fastapi:app"""
from fastapi import FastAPI
from {name_lower}.controller import {name}Controller
from ui_controller_base.adapters.fastapi import FastAPIAdapter

app = FastAPI(title="{name}")
FastAPIAdapter({name}Controller()).mount_app(app)
'''

_RUN_CLI_TEMPLATE = '''\
"""CLI entry point.  Run: python run_cli.py greet --name Ada"""
from {name_lower}.controller import {name}Controller
from ui_controller_base.adapters.cli import CLIAdapter

CLIAdapter({name}Controller()).serve()
'''


@app.command("init")
def init(
    name: str = typer.Argument(..., help="Project / controller name (PascalCase)"),
    output_dir: Path = typer.Option(
        Path("."), "--out", "-o", help="Directory to create the project in"
    ),
) -> None:
    """Scaffold a new UI Controller project with Streamlit, FastAPI, and CLI entry points."""
    name_lower = name.lower().replace(" ", "_").replace("-", "_")
    project_dir = output_dir / name_lower
    views_dir = project_dir / "views"

    if project_dir.exists():
        console.print(f"[yellow]Directory '{project_dir}' already exists — skipping.[/yellow]")
        raise typer.Exit(code=1)

    views_dir.mkdir(parents=True)
    (views_dir / "__init__.py").write_text("")
    (project_dir / "__init__.py").write_text("")

    def _write(path: Path, content: str) -> None:
        path.write_text(content.format(name=name, name_lower=name_lower))
        console.print(f"  [green]created[/green] {path}")

    _write(project_dir / "controller.py", _CONTROLLER_TEMPLATE)
    _write(project_dir / "views" / "home_view.py", _HOME_VIEW_TEMPLATE)
    _write(project_dir / "run_streamlit.py", _RUN_STREAMLIT_TEMPLATE)
    _write(project_dir / "run_fastapi.py", _RUN_FASTAPI_TEMPLATE)
    _write(project_dir / "run_cli.py", _RUN_CLI_TEMPLATE)

    console.print(f"\n[bold green]✓ Project '{name}' created at {project_dir}[/bold green]")
    console.print("\nNext steps:")
    console.print(f"  streamlit run {project_dir}/run_streamlit.py")
    console.print(f"  uvicorn {name_lower}.run_fastapi:app")
    console.print(f"  python {project_dir}/run_cli.py greet --name Ada")


# ── run-streamlit ─────────────────────────────────────────────────────────────

@app.command("run-streamlit")
def run_streamlit(
    app_module: str = typer.Argument(..., help="Python module path to the run_streamlit.py file"),
    port: int = typer.Option(8501, "--port", "-p"),
) -> None:
    """Launch a UI Controller app with Streamlit."""
    import sys  # noqa: PLC0415

    cmd = [sys.executable, "-m", "streamlit", "run", app_module, "--server.port", str(port)]
    console.print(f"[cyan]Running:[/cyan] {' '.join(cmd)}")
    subprocess.run(cmd, check=False)


# ── run-fastapi ───────────────────────────────────────────────────────────────

@app.command("run-fastapi")
def run_fastapi(
    app_module: str = typer.Argument(..., help="Module:app path, e.g. myapp.run_fastapi:app"),
    host: str = typer.Option("127.0.0.1", "--host"),
    port: int = typer.Option(8000, "--port", "-p"),
    reload: bool = typer.Option(False, "--reload"),
) -> None:
    """Launch a UI Controller app with uvicorn."""
    import sys

    cmd = [sys.executable, "-m", "uvicorn", app_module, "--host", host, "--port", str(port)]
    if reload:
        cmd.append("--reload")
    console.print(f"[cyan]Running:[/cyan] {' '.join(cmd)}")
    subprocess.run(cmd, check=False)


# ── run-cli ───────────────────────────────────────────────────────────────────

@app.command("run-cli")
def run_cli_cmd(
    script: str = typer.Argument(..., help="Path to the run_cli.py script"),
    args: list[str] = typer.Argument(None, help="Arguments forwarded to the CLI script"),
) -> None:
    """Run a UI Controller CLI adapter script."""
    import sys

    cmd = [sys.executable, script] + (args or [])
    console.print(f"[cyan]Running:[/cyan] {' '.join(cmd)}")
    subprocess.run(cmd, check=False)


# ── list-views ────────────────────────────────────────────────────────────────

@app.command("list-views")
def list_views(
    controller_module: str = typer.Argument(
        ..., help="Dotted module path to the controller, e.g. myapp.controller.MyController"
    ),
) -> None:
    """List views and actions registered on a controller class."""
    import importlib

    module_path, _, class_name = controller_module.rpartition(".")
    try:
        mod = importlib.import_module(module_path)
        ctrl_cls = getattr(mod, class_name)
        ctrl = ctrl_cls()
    except Exception as exc:
        console.print(f"[red]Failed to import {controller_module}: {exc}[/red]")
        raise typer.Exit(code=1) from exc

    table = Table(title=f"Views — {class_name}", show_header=True)
    table.add_column("Route", style="cyan")
    table.add_column("Plugin Name")
    table.add_column("Description")
    for view_cls in type(ctrl).views:
        table.add_row(
            getattr(view_cls, "route", ""),
            getattr(view_cls, "plugin_name", ""),
            getattr(view_cls, "plugin_description", ""),
        )
    console.print(table)

    tool_table = Table(title=f"Tools — {class_name}", show_header=True)
    tool_table.add_column("Name", style="green")
    tool_table.add_column("Description")
    for spec in ctrl.tool_registry.list_tools():
        tool_table.add_row(spec.name, spec.description or "")
    console.print(tool_table)


if __name__ == "__main__":
    app()
