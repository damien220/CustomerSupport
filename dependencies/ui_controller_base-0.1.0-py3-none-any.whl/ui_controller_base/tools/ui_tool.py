"""
UITool — base class for all UI Controller tools.

Every backend operation exposed through the controller is a ``UITool``:
a thin subclass of ``tool_interface_adapter.AbstractTool`` that adds:

- A shorthand ``from_fn()`` factory to create tools from plain callables.
- Access to the ``UIContext`` injected by ``ContextBinderMiddleware`` via
  ``context.metadata["ui_context"]``.

Usage — subclass approach
--------------------------
    class GreetTool(UITool):
        @property
        def spec(self):
            return ToolSpec(
                name="greet",
                description="Return a greeting",
                input_schema={"type": "object", "properties": {"name": {"type": "string"}}},
            )

        async def _execute(self, params, context):
            ui_ctx = context.metadata.get("ui_context")
            name = params.get("name", "World")
            return f"Hello, {name}!"

Usage — factory approach
------------------------
    async def greet(name: str = "World") -> str:
        return f"Hello, {name}!"

    greet_tool = UITool.from_fn("greet", greet, description="Return a greeting")
"""

from __future__ import annotations

from typing import Any, Callable

from tool_interface_adapter import AbstractTool, FunctionTool, ToolContext, ToolSpec


class UITool(AbstractTool):
    """Base class for UI Controller tools.

    Concrete subclasses must implement:
        - ``spec`` property → :class:`tool_interface_adapter.ToolSpec`
        - ``_execute(params, context)`` → raw result (any type)

    The ``UIContext`` for the current request is available inside
    ``_execute`` via ``context.metadata.get("ui_context")``.
    """

    # ── Factory ──────────────────────────────────────────────────

    @classmethod
    def from_fn(
        cls,
        name: str,
        fn: Callable[..., Any],
        *,
        description: str = "",
        input_schema: dict[str, Any] | None = None,
        idempotent: bool = False,
        timeout: float = 30.0,
    ) -> "FunctionTool":
        """Create a ``FunctionTool`` from a plain callable.

        The resulting tool is fully compatible with ``UIDispatcher`` and
        the middleware chain.

        Parameters
        ----------
        name:
            Unique action name, e.g. ``"greet"`` or ``"generate_report"``.
        fn:
            Sync or async callable.  ``FunctionAdapter`` wraps sync callables
            with ``loop.run_in_executor`` automatically.
        description:
            Human-readable description for ``ui-controller list-views``.
        input_schema:
            JSON Schema dict for parameter validation.  An open ``object``
            schema is used when omitted.
        idempotent:
            Set to ``True`` for read-only / cacheable operations.
        timeout:
            Per-call timeout in seconds.
        """
        spec = ToolSpec(
            name=name,
            description=description,
            input_schema=input_schema or {"type": "object", "properties": {}},
            idempotent=idempotent,
            timeout=timeout,
        )
        return FunctionTool(spec=spec, fn=fn)
