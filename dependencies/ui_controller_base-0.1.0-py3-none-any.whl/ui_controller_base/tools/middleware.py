"""
UI-specific tool middleware.

ContextBinderMiddleware
    Extracts the ``UIContext`` stored in ``ToolContext.metadata["ui_context"]``
    and activates it as an async context manager so that every log record
    emitted during tool execution carries the current ``request_id`` and
    ``session_id``.

ErrorNormalizerMiddleware
    Normalizes a failed ``ToolResult`` (including unhandled exceptions that
    somehow escape the inner execution chain) into the ``error_handler``
    structured format and attaches it to ``ToolResult.metadata["ui_error"]``.
    The ``UIDispatcher`` reads this to build ``UIResponse.errors``.

Typical stack (outermost → innermost)
--------------------------------------
    ContextBinderMiddleware
      └─ ErrorNormalizerMiddleware
           └─ UITool / FunctionTool
"""

from __future__ import annotations

from typing import Any

from error_handler import ErrorHandler
from tool_interface_adapter import AbstractToolMiddleware, ToolContext, ToolResult


class ContextBinderMiddleware(AbstractToolMiddleware):
    """Activate the ``UIContext`` logging context during tool execution.

    Reads ``context.metadata["ui_context"]`` (populated by ``UIDispatcher``)
    and enters it as an async context manager.  This ensures that every
    ``logger_pkg.get_logger()`` call inside the tool emits records annotated
    with ``request_id``, ``session_id``, and ``user``.

    Safe to use without a UIContext — when the key is absent the middleware
    is a transparent pass-through.
    """

    def _wrap(self, tool: Any) -> "ContextBinderMiddleware":
        return ContextBinderMiddleware(tool)

    async def _intercept(
        self, params: dict[str, Any], context: ToolContext
    ) -> ToolResult:
        ui_ctx = context.metadata.get("ui_context")
        if ui_ctx is not None:
            async with ui_ctx:
                return await self._call_next(params, context)
        return await self._call_next(params, context)


class ErrorNormalizerMiddleware(AbstractToolMiddleware):
    """Normalize failed ``ToolResult`` objects into the ``error_handler`` shape.

    .. note::
        Also implements ``_wrap`` required by ``AbstractToolMiddleware``.

    When the inner tool returns a ``ToolResult`` with ``success=False``, this
    middleware wraps the error information into the standard
    ``{"status_code": int, "body": {"error": {"code", "message", "details"}}}``
    dict and stores it under ``ToolResult.metadata["ui_error"]``.

    The ``UIDispatcher`` then reads ``metadata["ui_error"]`` to populate
    ``UIResponse.errors`` without needing to know the tool's internals.

    Also catches any exception that somehow escapes the inner chain and
    wraps it the same way.
    """

    def _wrap(self, tool: Any) -> "ErrorNormalizerMiddleware":
        return ErrorNormalizerMiddleware(tool)

    async def _intercept(
        self, params: dict[str, Any], context: ToolContext
    ) -> ToolResult:
        try:
            result = await self._call_next(params, context)
        except Exception as exc:
            normalized = ErrorHandler.handle(exc)
            return ToolResult.fail(
                normalized["body"]["error"]["code"],
                normalized["body"]["error"]["message"],
                details=normalized["body"]["error"].get("details"),
            )

        if not result.success and result.error is not None:
            # Build a synthetic exception so ErrorHandler produces its shape.
            from ui_controller_base.exceptions import UIBackendError
            proxy = UIBackendError(
                result.error.message,
                details=result.error.details or {},
            )
            normalized = ErrorHandler.handle(proxy)
            # Attach without mutating the frozen result — build a new one.
            updated_meta = {**result.metadata, "ui_error": normalized}
            result = ToolResult(
                success=result.success,
                data=result.data,
                error=result.error,
                duration_ms=result.duration_ms,
                metadata=updated_meta,
                cached=result.cached,
            )

        return result
