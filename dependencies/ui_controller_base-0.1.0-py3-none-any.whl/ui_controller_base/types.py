"""
Shared enums and lightweight types used across the package.

Nothing in this module imports from sibling modules — it is the base of the
dependency graph and safe to import from anywhere.
"""

from __future__ import annotations

from enum import Enum


class UIStatus(str, Enum):
    """High-level outcome of a controller action or render call."""

    SUCCESS = "success"
    ERROR = "error"
    REDIRECT = "redirect"
    PENDING = "pending"       # action handed off to a background job
    WAITING = "waiting"       # paused at a HumanStep, awaiting user input


class FragmentType(str, Enum):
    """Semantic type of a single renderable unit inside a UIResponse."""

    TEXT = "text"             # plain text or markdown
    TABLE = "table"           # tabular / DataFrame-like data
    CHART = "chart"           # chart / visualisation
    FORM = "form"             # input form definition
    HTML = "html"             # raw HTML (adapter must opt-in)
    ERROR = "error"           # error card / banner
    PROGRESS = "progress"     # progress bar / spinner
    NOTIFICATION = "notification"  # toast / alert
