"""
CLIAdapter — mount an AbstractUIController as a Typer CLI application.

Each registered tool becomes a Typer command whose options are derived
from the underlying Python function's type-annotated signature.

Usage::

    # run_cli.py
    from ui_controller_base.adapters.cli import CLIAdapter
    from myapp.controller import MyController

    CLIAdapter(MyController()).serve()

    # python run_cli.py greet --name Ada
    # python run_cli.py greet --help

State persistence
-----------------
The CLI adapter uses a ``FileStateStore`` that serialises ``UIState``
objects to ``~/.config/<app_name>/state.json`` so state survives between
invocations.  The ``app_name`` defaults to ``type(controller).__name__``.

Session ID
----------
CLI sessions use the current user's login name as the session ID so
repeated invocations from the same user share state.
"""

from __future__ import annotations

import inspect
import json
import os
from pathlib import Path
from typing import Any, Callable

import typer
from rich.console import Console

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.adapter import AbstractFrameworkAdapter
from ui_controller_base.core.response import UIResponse
from ui_controller_base.core.state import UIState
from ui_controller_base.mixins.stateful import InMemoryStateStore, StateStore

from .formatters import format_response


# ── File-backed StateStore ────────────────────────────────────────────────────

class FileStateStore:
    """Persist ``UIState`` to a JSON file in ``~/.config/<app>/state.json``.

    Falls back to ``InMemoryStateStore`` if the directory can't be created.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            self._path = None  # type: ignore[assignment]

    def _load(self) -> dict:
        if self._path is None or not self._path.exists():
            return {}
        try:
            return json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self, data: dict) -> None:
        if self._path is None:
            return
        try:
            self._path.write_text(json.dumps(data, default=str))
        except OSError:
            pass

    def get(self, session_id: str) -> UIState | None:
        data = self._load()
        raw = data.get(session_id)
        if raw is None:
            return None
        return UIState(
            session_id=raw["session_id"],
            data=raw.get("data", {}),
            version=raw.get("version", 0),
        )

    def set(self, state: UIState) -> None:
        data = self._load()
        data[state.session_id] = {
            "session_id": state.session_id,
            "data": state.data,
            "version": state.version,
        }
        self._save(data)

    def delete(self, session_id: str) -> None:
        data = self._load()
        data.pop(session_id, None)
        self._save(data)


# ── Command builder ───────────────────────────────────────────────────────────

_SIMPLE_TYPES = {str, int, float, bool}
_SIMPLE_TYPE_NAMES = {"str", "int", "float", "bool"}


def _resolve_annotation(ann: Any) -> type | None:
    """Resolve a possibly-stringified annotation to a simple type, or None."""
    if ann in _SIMPLE_TYPES:
        return ann
    if isinstance(ann, str) and ann in _SIMPLE_TYPE_NAMES:
        return {"str": str, "int": int, "float": float, "bool": bool}[ann]
    if ann is inspect.Parameter.empty:
        return str
    return None


def _call_handle(ctrl: Any, action: Any) -> Any:
    """Call ctrl.handle() safely whether or not a running event loop is present."""
    import asyncio
    import concurrent.futures

    try:
        asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, ctrl.ahandle(action)).result()
    except RuntimeError:
        return ctrl.handle(action)


def _build_command(
    ctrl: Any,
    tool_name: str,
    session_id: str,
    console: Console,
    fn: Callable | None,
) -> Callable:
    """Build a Typer command function for *tool_name*.

    If *fn* is provided its type-annotated parameters become typed CLI
    options.  Otherwise a single ``--payload JSON`` option is used.
    """

    if fn is not None:
        sig = inspect.signature(fn)
        clean_params = [
            p
            for p in sig.parameters.values()
            if p.kind
            not in (inspect.Parameter.VAR_KEYWORD, inspect.Parameter.VAR_POSITIONAL)
            and _resolve_annotation(p.annotation) is not None
        ]
    else:
        clean_params = []

    if clean_params:
        # Build a wrapper with a reconstructed signature so Typer can
        # introspect it and generate typed --option flags.
        new_params = []
        for p in clean_params:
            ann = _resolve_annotation(p.annotation) or str
            default = p.default if p.default is not inspect.Parameter.empty else ...
            new_params.append(
                inspect.Parameter(
                    p.name,
                    kind=inspect.Parameter.KEYWORD_ONLY,
                    default=default,
                    annotation=ann,
                )
            )
        new_sig = inspect.Signature(
            parameters=new_params,
            return_annotation=None,
        )

        def cmd(**kwargs: Any) -> None:
            response: UIResponse = _call_handle(
                ctrl, UIAction(name=tool_name, payload=kwargs, session_id=session_id)
            )
            format_response(response, console)

        cmd.__signature__ = new_sig  # type: ignore[attr-defined]
        cmd.__name__ = tool_name.replace("-", "_")
        cmd.__doc__ = (fn.__doc__ or f"Run the '{tool_name}' action.") if fn else f"Run '{tool_name}'."
        return cmd

    # Fallback: single --payload JSON string option.
    def cmd_generic(
        payload: str = typer.Option("{}", "--payload", "-p", help="JSON-encoded action parameters"),
    ) -> None:
        try:
            params = json.loads(payload)
        except json.JSONDecodeError as exc:
            console.print(f"[red]Invalid JSON payload: {exc}[/red]")
            raise typer.Exit(code=1) from exc

        response: UIResponse = _call_handle(
            ctrl, UIAction(name=tool_name, payload=params, session_id=session_id)
        )
        format_response(response, console)

    cmd_generic.__name__ = tool_name.replace("-", "_")
    cmd_generic.__doc__ = f"Run the '{tool_name}' action.  Pass parameters as --payload '{{\"key\": \"val\"}}'."
    return cmd_generic


# ── CLIAdapter ────────────────────────────────────────────────────────────────

class CLIAdapter(AbstractFrameworkAdapter):
    """Adapter that exposes an ``AbstractUIController`` as a Typer CLI app.

    Parameters
    ----------
    controller:
        An ``AbstractUIController`` instance.
    app_name:
        Used for the state file path (``~/.config/<app_name>/state.json``).
        Defaults to ``type(controller).__name__``.
    console:
        Rich ``Console``.  Defaults to stdout.
    """

    def __init__(
        self,
        controller: Any | None = None,
        *,
        app_name: str | None = None,
        console: Console | None = None,
    ) -> None:
        self._app_name = app_name
        self._console = console or Console()
        self._controller: Any = None
        self._typer_app: typer.Typer | None = None
        if controller is not None:
            self.mount(controller)

    # ── AbstractFrameworkAdapter ──────────────────────────────────

    def mount(self, controller: Any) -> "CLIAdapter":
        self._controller = controller
        app_name = self._app_name or type(controller).__name__
        self._app_name = app_name
        self._typer_app = self._build_typer_app(controller, app_name)
        return self

    def translate_request(self, native: dict) -> UIAction:
        """Build a ``UIAction`` from a plain dict (tool_name + payload)."""
        return UIAction(
            name=native.get("name", ""),
            payload=native.get("payload", {}),
            session_id=native.get("session_id"),
        )

    def translate_response(self, resp: UIResponse) -> None:
        """Render *resp* to the Rich console."""
        format_response(resp, self._console)

    def serve(self) -> None:
        """Launch the Typer CLI app (``sys.argv`` parsing)."""
        if self._typer_app is None:
            raise RuntimeError("No controller mounted. Call CLIAdapter(controller).serve().")
        self._typer_app()

    # ── Internal ──────────────────────────────────────────────────

    def _get_session_id(self) -> str:
        return os.environ.get("USER") or os.environ.get("USERNAME") or "cli-user"

    def _build_typer_app(self, ctrl: Any, app_name: str) -> typer.Typer:
        # Wire the file state store if the controller uses StatefulMixin.
        state_path = Path.home() / ".config" / app_name / "state.json"
        if hasattr(ctrl, "_state_store"):
            ctrl._state_store = FileStateStore(state_path)

        session_id = self._get_session_id()
        console = self._console

        # Open the controller synchronously.
        from asgiref.sync import async_to_sync

        app = typer.Typer(
            name=app_name,
            help=f"{app_name} — powered by UI Controller Base",
            no_args_is_help=True,
            add_completion=False,
        )

        @app.callback()
        def _bootstrap() -> None:
            if not getattr(ctrl, "_is_open", False):
                import asyncio
                import concurrent.futures

                try:
                    asyncio.get_running_loop()
                    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                        pool.submit(asyncio.run, ctrl.open()).result()
                except RuntimeError:
                    async_to_sync(ctrl.open)()

        # Register one command per tool.
        for spec in ctrl.tool_registry.list_tools():
            tool = ctrl.tool_registry.get(spec.name)
            # Try to reach the underlying Python function.
            fn: Callable | None = None
            adapter = getattr(tool, "_adapter", None)
            if adapter is not None:
                fn = getattr(adapter, "_fn", None)

            cmd_fn = _build_command(ctrl, spec.name, session_id, console, fn)
            app.command(
                name=spec.name,
                help=spec.description or f"Run the '{spec.name}' action.",
            )(cmd_fn)

        return app
