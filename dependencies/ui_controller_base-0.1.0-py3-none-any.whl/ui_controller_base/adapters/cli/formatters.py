"""
Rich-based formatter for UIResponse → terminal output.

``format_response(response, console)`` is the single entry point.

Fragment rendering
------------------
TEXT        → Rich Markdown
TABLE       → Rich Table
CHART       → ASCII sparkline / pretty-print (charts can't be in a terminal)
FORM        → prompt for each field and return collected values
HTML        → strip tags, render as text
ERROR       → Rich Panel in bold red
PROGRESS    → Rich ProgressBar (static snapshot)
NOTIFICATION→ st.info/warning/error → rich style equivalents
"""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from ui_controller_base.core.response import UIResponse
from ui_controller_base.types import FragmentType

_DEFAULT_CONSOLE = Console()


# ── Per-type formatters ────────────────────────────────────────────────────────

def _fmt_text(content: Any, console: Console) -> None:
    try:
        console.print(Markdown(str(content)))
    except Exception:
        console.print(str(content))


def _fmt_table(content: Any, console: Console) -> None:
    table = Table(show_header=True, header_style="bold cyan")
    if isinstance(content, list) and content:
        for col in content[0].keys():
            table.add_column(str(col))
        for row in content:
            table.add_row(*[str(v) for v in row.values()])
    elif isinstance(content, dict) and "rows" in content:
        for col in content.get("columns", []):
            table.add_column(str(col))
        for row in content["rows"]:
            table.add_row(*[str(v) for v in row])
    else:
        table.add_column("Data")
        table.add_row(str(content))
    console.print(table)


def _fmt_chart(content: Any, console: Console) -> None:
    console.print("[dim]Chart data (terminal rendering not available):[/dim]")
    if isinstance(content, dict) and "data" in content:
        _fmt_table(content["data"], console)
    else:
        console.print(str(content))


def _fmt_error(content: Any, console: Console) -> None:
    if isinstance(content, dict):
        msg = content.get("message") or content.get("error", {}).get("message", str(content))
    else:
        msg = str(content)
    console.print(Panel(f"[bold red]{msg}[/bold red]", title="Error", border_style="red"))


def _fmt_progress(content: Any, console: Console) -> None:
    if isinstance(content, dict):
        value = float(content.get("value", 0.0))
        label = content.get("label", "Progress")
    else:
        value = float(content)
        label = "Progress"
    pct = int(value * 100)
    bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
    console.print(f"[cyan]{label}[/cyan] [{bar}] {pct}%")


def _fmt_notification(content: Any, console: Console) -> None:
    if isinstance(content, dict):
        msg = content.get("message", str(content))
        level = content.get("level", "info")
    else:
        msg = str(content)
        level = "info"
    style_map = {"info": "blue", "warning": "yellow", "error": "red", "success": "green"}
    style = style_map.get(level, "blue")
    console.print(f"[{style}]ℹ {msg}[/{style}]")


def _fmt_html(content: Any, console: Console) -> None:
    import re

    text = re.sub(r"<[^>]+>", "", str(content))
    console.print(text)


_FORMATTERS = {
    FragmentType.TEXT: _fmt_text,
    FragmentType.TABLE: _fmt_table,
    FragmentType.CHART: _fmt_chart,
    FragmentType.ERROR: _fmt_error,
    FragmentType.PROGRESS: _fmt_progress,
    FragmentType.NOTIFICATION: _fmt_notification,
    FragmentType.HTML: _fmt_html,
}


# ── Public entry point ────────────────────────────────────────────────────────

def format_response(
    response: UIResponse,
    console: Console | None = None,
) -> None:
    """Render all fragments of *response* to the Rich console.

    Parameters
    ----------
    response:
        The ``UIResponse`` to display.
    console:
        Rich ``Console`` instance.  Defaults to a shared stdout console.
    """
    c = console or _DEFAULT_CONSOLE

    if response.toast:
        c.print(f"[dim italic]✓ {response.toast}[/dim italic]")

    if response.status.value == "pending":
        c.print(f"[cyan]⏳ Job submitted (id: {response.job_id})[/cyan]")
        return

    if response.status.value == "waiting":
        c.print(f"[yellow]⏸  Workflow waiting for approval (id: {response.workflow_id})[/yellow]")
        return

    for fragment in response.fragments:
        fmt = _FORMATTERS.get(fragment.type, _fmt_text)
        fmt(fragment.content, c)


def prompt_form(fields: list[dict], console: Console | None = None) -> dict[str, Any]:
    """Interactively prompt for form field values using Rich/Typer.

    Parameters
    ----------
    fields:
        List of field dicts (``name``, ``label``, ``type``, ``default``).

    Returns
    -------
    dict
        Collected values keyed by field name.
    """
    import typer

    c = console or _DEFAULT_CONSOLE
    values: dict[str, Any] = {}
    for field in fields:
        fname = field["name"]
        label = field.get("label", fname)
        default = field.get("default", "")
        ftype = field.get("type", "text")

        if ftype == "checkbox":
            values[fname] = typer.confirm(label, default=bool(default))
        elif ftype == "number":
            raw = typer.prompt(label, default=str(default or 0))
            try:
                values[fname] = int(raw) if "." not in raw else float(raw)
            except ValueError:
                values[fname] = raw
        else:
            values[fname] = typer.prompt(label, default=str(default))
    return values
