"""
FastAPIAdapter — mount an AbstractUIController on a FastAPI application.

Route layout
------------
For each registered ``AbstractView`` with ``route = "/foo"``:

    GET  /foo                        → view.render(ctx, state)
    POST /foo/action/{action_name}   → controller.ahandle(UIAction(...))

Workflow endpoints (when ``WithWorkflows`` is present):

    GET  /workflows/{run_id}/pending → returns run status
    POST /workflows/{run_id}/resume  → calls controller.resume_workflow(...)

Health check:

    GET  /health                     → {"status": "ok", "routes": [...]}

Usage::

    # main.py
    from fastapi import FastAPI
    from ui_controller_base.adapters.fastapi import FastAPIAdapter
    from myapp.controller import MyController

    app = FastAPI()
    FastAPIAdapter(MyController()).mount(app)

    # uvicorn main:app
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.adapter import AbstractFrameworkAdapter
from ui_controller_base.core.context import UIContext
from ui_controller_base.core.response import UIResponse
from ui_controller_base.core.state import UIState

from .deps import get_ui_context_factory
from .schemas import (
    ActionRequest,
    FragmentOut,
    HealthOut,
    UIResponseOut,
    WorkflowResumeRequest,
)


def _to_response_out(response: UIResponse) -> UIResponseOut:
    """Convert a ``UIResponse`` to the JSON-serialisable ``UIResponseOut``."""
    return UIResponseOut(
        status=response.status.value,
        fragments=[
            FragmentOut(type=f.type.value, content=f.content, key=f.key)
            for f in response.fragments
        ],
        redirect=response.redirect,
        toast=response.toast,
        errors=response.errors,
        job_id=response.job_id,
        workflow_id=response.workflow_id,
    )


class FastAPIAdapter(AbstractFrameworkAdapter):
    """Adapter that exposes an ``AbstractUIController`` as a FastAPI sub-application.

    Parameters
    ----------
    controller:
        An ``AbstractUIController`` instance.
    prefix:
        URL prefix for all generated routes.  Default ``""`` (root).
    tags:
        OpenAPI tags applied to all generated routes.
    lifespan:
        When ``True`` (default) the adapter registers a FastAPI *lifespan*
        context manager that calls ``controller.open()`` on startup and
        ``controller.close()`` on shutdown.  Set to ``False`` if you
        manage the controller lifecycle yourself.
    """

    def __init__(
        self,
        controller: Any | None = None,
        *,
        prefix: str = "",
        tags: list[str] | None = None,
        lifespan: bool = True,
    ) -> None:
        self._prefix = prefix.rstrip("/")
        self._tags = tags or ["ui-controller"]
        self._lifespan = lifespan
        self._controller: Any = None
        self._router: APIRouter | None = None
        if controller is not None:
            self.mount(controller)

    # ── AbstractFrameworkAdapter ──────────────────────────────────

    def mount(self, controller: Any) -> "FastAPIAdapter":  # type: ignore[override]
        """Mount *controller* and return ``self`` (fluent).

        When called with a ``FastAPI`` app as the first positional arg
        (the base-class contract) this instead calls ``mount_app``.
        This override disambiguates the two use cases.
        """
        if isinstance(controller, FastAPI):
            return self.mount_app(controller)
        self._controller = controller
        self._router = self._build_router()
        return self

    def mount_app(self, app: FastAPI) -> "FastAPIAdapter":
        """Attach the generated ``APIRouter`` to *app* and wire the lifespan."""
        if self._controller is None:
            raise RuntimeError(
                "No controller mounted. Call FastAPIAdapter(controller).mount_app(app)."
            )
        if self._router is None:
            self._router = self._build_router()

        if self._lifespan:
            from contextlib import asynccontextmanager

            original_lifespan = getattr(app, "router", None)

            @asynccontextmanager
            async def _lifespan(application: FastAPI):  # type: ignore[name-defined]
                await self._controller.open()
                yield
                await self._controller.close()

            app.router.lifespan_context = _lifespan

        app.include_router(self._router)
        return self

    def translate_request(self, native: Request) -> UIAction:
        """Build a ``UIAction`` from a FastAPI ``Request`` (best-effort).

        Prefer the typed ``ActionRequest`` body injection in route handlers
        over this generic path.
        """
        session_id = native.headers.get("x-session-id") or (
            native.client.host if native.client else None
        )
        return UIAction(name="", session_id=session_id)

    def translate_response(self, resp: UIResponse) -> UIResponseOut:
        return _to_response_out(resp)

    def serve(self) -> None:
        """Not applicable for FastAPI — use ``mount_app(app)`` instead."""
        raise NotImplementedError(
            "FastAPIAdapter does not implement serve(). "
            "Use FastAPIAdapter(controller).mount_app(app) and run with uvicorn."
        )

    # ── Router builder ────────────────────────────────────────────

    def _build_router(self) -> APIRouter:
        ctrl = self._controller
        router = APIRouter(prefix=self._prefix, tags=self._tags)
        get_ui_context = get_ui_context_factory(ctrl)

        # Health endpoint
        @router.get("/health", response_model=HealthOut, tags=["health"])
        async def health() -> HealthOut:
            return HealthOut(status="ok", routes=ctrl.routes)

        # Per-view endpoints
        for route in ctrl.routes:
            self._add_view_routes(router, route, ctrl, get_ui_context)

        # Workflow endpoints (WithWorkflows)
        if hasattr(ctrl, "workflow_engine"):
            self._add_workflow_routes(router, ctrl, get_ui_context)

        return router

    @staticmethod
    def _add_view_routes(
        router: APIRouter,
        route: str,
        ctrl: Any,
        get_ui_context: Any,
    ) -> None:
        # Strip leading slash for path parameter safety; FastAPI re-adds it.
        path = route if route.startswith("/") else f"/{route}"

        @router.get(
            path,
            response_model=UIResponseOut,
            summary=f"Render view {route}",
        )
        async def render_view(
            ctx: UIContext = Depends(get_ui_context),
            _route: str = route,  # capture by value
        ) -> UIResponseOut:
            try:
                view = await ctrl.view_registry.get_by_route(_route)
            except Exception as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

            state = UIState(session_id=ctx.session_id or "anonymous")
            response = await view.render(ctx, state)
            return _to_response_out(response)

        @router.post(
            f"{path}/action/{{action_name}}",
            response_model=UIResponseOut,
            summary=f"Dispatch action on view {route}",
        )
        async def dispatch_action(
            action_name: str,
            body: ActionRequest,
            ctx: UIContext = Depends(get_ui_context),
            _route: str = route,
        ) -> UIResponseOut:
            action = UIAction(
                name=action_name,
                view=_route,
                payload=body.payload,
                session_id=body.session_id or ctx.session_id,
                user=body.user or ctx.user,
            )
            response = await ctrl.ahandle(action, ctx)
            return _to_response_out(response)

    @staticmethod
    def _add_workflow_routes(
        router: APIRouter,
        ctrl: Any,
        get_ui_context: Any,
    ) -> None:
        from workflow_manager import RunStatus

        @router.get(
            "/workflows/{run_id}/pending",
            summary="Check workflow run status",
        )
        async def workflow_status(run_id: str) -> dict:
            try:
                run = ctrl.workflow_engine.state_store.load(run_id)
            except Exception as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            return {
                "run_id": run.run_id,
                "status": run.status.value,
                "waiting": run.status == RunStatus.WAITING,
            }

        @router.post(
            "/workflows/{run_id}/resume",
            response_model=UIResponseOut,
            summary="Resume a waiting workflow run",
        )
        async def resume_workflow(
            run_id: str,
            body: WorkflowResumeRequest,
            ctx: UIContext = Depends(get_ui_context),
        ) -> UIResponseOut:
            if not hasattr(ctrl, "resume_workflow"):
                raise HTTPException(
                    status_code=501,
                    detail="Controller does not support WithWorkflows.",
                )
            # We need the original workflow object — stored in the action payload.
            # For now, surface a WAITING response; callers must re-dispatch via action.
            try:
                run = ctrl.workflow_engine.state_store.load(run_id)
            except Exception as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

            response = UIResponse.waiting(
                workflow_id=run_id,
                toast="Workflow resumed — dispatch the original action to continue.",
            )
            return _to_response_out(response)
