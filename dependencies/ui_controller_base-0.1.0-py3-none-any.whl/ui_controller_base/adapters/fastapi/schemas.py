"""
Pydantic request/response schemas for the FastAPI adapter.

These are intentionally separate from the core value objects so the HTTP
layer can evolve independently (e.g. add OpenAPI descriptions, rename
JSON fields) without touching the framework-agnostic core.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ActionRequest(BaseModel):
    """JSON body for ``POST /{route}/action/{action_name}``."""

    payload: dict[str, Any] = Field(default_factory=dict, description="Action parameters")
    session_id: str | None = Field(None, description="Client session identifier")
    user: str | None = Field(None, description="Authenticated user identifier")


class FragmentOut(BaseModel):
    """Serialised ``UIFragment``."""

    type: str
    content: Any
    key: str | None = None


class UIResponseOut(BaseModel):
    """Serialised ``UIResponse`` — the JSON envelope returned by all endpoints."""

    status: str
    fragments: list[FragmentOut] = Field(default_factory=list)
    redirect: str | None = None
    toast: str | None = None
    errors: list[dict[str, Any]] = Field(default_factory=list)
    job_id: str | None = None
    workflow_id: str | None = None


class WorkflowResumeRequest(BaseModel):
    """JSON body for ``POST /workflows/{run_id}/resume``."""

    approval_data: dict[str, Any] = Field(
        default_factory=dict,
        description="Data provided by the approver (e.g. comments, decisions).",
    )


class HealthOut(BaseModel):
    status: str = "ok"
    routes: list[str] = Field(default_factory=list)
