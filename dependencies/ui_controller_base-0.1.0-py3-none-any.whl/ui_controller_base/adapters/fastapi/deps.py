"""
FastAPI dependency-injection helpers.

``get_ui_context`` is a ``Depends``-compatible factory that builds a
``UIContext`` from the incoming HTTP request and injects it into route
handlers.

Usage::

    from fastapi import Depends
    from ui_controller_base.adapters.fastapi.deps import get_ui_context_factory

    get_ui_context = get_ui_context_factory(controller)

    @router.get("/home")
    async def home(ctx: UIContext = Depends(get_ui_context)):
        ...
"""

from __future__ import annotations

from typing import Any, Callable

from fastapi import Request

from ui_controller_base.core.context import UIContext


def get_ui_context_factory(controller: Any) -> Callable:
    """Return a FastAPI dependency that produces a ``UIContext`` per request.

    The dependency reads the ``X-Session-Id`` header (falling back to the
    client's host address) as the session identifier and the ``X-User``
    header as the optional user identifier.

    Parameters
    ----------
    controller:
        The mounted ``AbstractUIController`` instance.  The dependency
        captures a reference so it can pass ``controller.events`` to the
        context.
    """

    async def get_ui_context(request: Request) -> UIContext:
        session_id: str = (
            request.headers.get("x-session-id")
            or request.headers.get("x-request-id")
            or request.client.host
            if request.client
            else "anonymous"
        )
        user: str | None = request.headers.get("x-user")
        correlation_id: str | None = request.headers.get("x-correlation-id")

        return UIContext.create(
            session_id=session_id,
            user=user,
            request_id=correlation_id,
            events=controller.events,
        )

    return get_ui_context
