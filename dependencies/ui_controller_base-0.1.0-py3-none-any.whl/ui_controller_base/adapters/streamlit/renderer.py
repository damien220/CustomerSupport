"""
Streamlit fragment renderer.

``render_response(response)`` is the single entry point — it iterates over
``UIResponse.fragments`` and calls the appropriate ``st.*`` function for each
``FragmentType``.

Fragment content contracts
--------------------------
TEXT        → str (markdown)
TABLE       → list[dict]  or  {"columns": [...], "rows": [[...]]}
CHART       → dict (Vega-Lite spec)  or  {"type": "bar"|"line"|"area", "data": list[dict]}
FORM        → {"action": str, "fields": [{"name", "type", "label", "default"?, "options"?}],
               "submit_label"?: str}
HTML        → str (raw HTML)
ERROR       → dict from ErrorHandler — {"code", "message", "details"?}  or  str
PROGRESS    → {"value": float (0–1), "label"?: str}
NOTIFICATION→ {"message": str, "level"?: "info"|"warning"|"error"|"success"}
"""

from __future__ import annotations

from typing import Any, Callable

import streamlit as st

from ui_controller_base.core.response import UIResponse
from ui_controller_base.types import FragmentType


# ── Per-type renderers ────────────────────────────────────────────────────────

def _render_text(content: Any) -> None:
    st.markdown(str(content))


def _render_table(content: Any) -> None:
    if isinstance(content, list):
        st.dataframe(content, use_container_width=True)
    elif isinstance(content, dict) and "rows" in content:
        import pandas as pd

        df = pd.DataFrame(content["rows"], columns=content.get("columns"))
        st.dataframe(df, use_container_width=True)
    else:
        st.dataframe(content, use_container_width=True)


def _render_chart(content: Any) -> None:
    if not isinstance(content, dict):
        st.write(content)
        return
    if "mark" in content or "$schema" in content:
        # Vega-Lite spec
        st.vega_lite_chart(content, use_container_width=True)
    elif "type" in content and "data" in content:
        chart_type = content["type"]
        data = content["data"]
        import pandas as pd

        df = pd.DataFrame(data) if isinstance(data, list) else data
        fn: dict[str, Callable] = {
            "bar": st.bar_chart,
            "line": st.line_chart,
            "area": st.area_chart,
        }
        fn.get(chart_type, st.bar_chart)(df, use_container_width=True)
    else:
        st.write(content)


def _render_form(content: Any, *, action_callback: Callable[[str, dict], None] | None = None) -> None:
    """Render a form and call *action_callback* on submit."""
    if not isinstance(content, dict):
        st.write(content)
        return

    action_name: str = content.get("action", "")
    fields: list[dict] = content.get("fields", [])
    submit_label: str = content.get("submit_label", "Submit")
    form_key = f"_uicb_form_{action_name}"

    with st.form(key=form_key):
        values: dict[str, Any] = {}
        for field in fields:
            fname = field["name"]
            ftype = field.get("type", "text")
            label = field.get("label", fname)
            default = field.get("default")
            options = field.get("options", [])

            if ftype == "text":
                values[fname] = st.text_input(label, value=default or "")
            elif ftype == "textarea":
                values[fname] = st.text_area(label, value=default or "")
            elif ftype == "number":
                values[fname] = st.number_input(label, value=default or 0)
            elif ftype == "checkbox":
                values[fname] = st.checkbox(label, value=bool(default))
            elif ftype == "select":
                idx = options.index(default) if default in options else 0
                values[fname] = st.selectbox(label, options=options, index=idx)
            elif ftype == "multiselect":
                values[fname] = st.multiselect(label, options=options, default=default or [])
            elif ftype == "slider":
                lo = field.get("min", 0)
                hi = field.get("max", 100)
                values[fname] = st.slider(label, min_value=lo, max_value=hi, value=default or lo)
            else:
                values[fname] = st.text_input(label, value=str(default or ""))

        submitted = st.form_submit_button(submit_label)

    if submitted and action_callback is not None:
        action_callback(action_name, values)


def _render_html(content: Any) -> None:
    st.html(str(content))


def _render_error(content: Any) -> None:
    if isinstance(content, dict):
        msg = content.get("message") or content.get("error", {}).get("message", str(content))
    else:
        msg = str(content)
    st.error(msg)


def _render_progress(content: Any) -> None:
    if isinstance(content, dict):
        value = float(content.get("value", 0.0))
        label = content.get("label", "")
        st.progress(min(max(value, 0.0), 1.0), text=label or None)
    else:
        st.progress(float(content))


def _render_notification(content: Any) -> None:
    if isinstance(content, dict):
        msg = content.get("message", str(content))
        level = content.get("level", "info")
    else:
        msg = str(content)
        level = "info"

    fn_map: dict[str, Callable] = {
        "info": st.info,
        "warning": st.warning,
        "error": st.error,
        "success": st.success,
    }
    fn_map.get(level, st.info)(msg)


_RENDERERS: dict[FragmentType, Callable] = {
    FragmentType.TEXT: _render_text,
    FragmentType.TABLE: _render_table,
    FragmentType.CHART: _render_chart,
    FragmentType.HTML: _render_html,
    FragmentType.ERROR: _render_error,
    FragmentType.PROGRESS: _render_progress,
    FragmentType.NOTIFICATION: _render_notification,
}


# ── Public entry point ────────────────────────────────────────────────────────

def render_response(
    response: UIResponse,
    *,
    action_callback: Callable[[str, dict], None] | None = None,
) -> None:
    """Render all fragments of *response* using the appropriate ``st.*`` calls.

    Parameters
    ----------
    response:
        The ``UIResponse`` to render.
    action_callback:
        Optional callable invoked when a FORM fragment is submitted.
        Signature: ``(action_name: str, values: dict) -> None``.
    """
    if response.toast:
        st.toast(response.toast)

    for fragment in response.fragments:
        if fragment.type == FragmentType.FORM:
            _render_form(fragment.content, action_callback=action_callback)
        else:
            renderer = _RENDERERS.get(fragment.type, _render_text)
            renderer(fragment.content)
