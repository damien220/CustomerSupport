"""
StreamlitSession — session state helpers for the Streamlit adapter.

Centralises all ``st.session_state`` keys so they never collide with
consumer code and are easy to inspect during development.
"""

from __future__ import annotations

import uuid
from typing import Any

import streamlit as st

_NS = "_uicb"  # namespace prefix for all keys


def _key(name: str) -> str:
    return f"{_NS}_{name}"


# ── Session ID ────────────────────────────────────────────────────────────────

def get_session_id() -> str:
    """Return the stable session ID, creating one on the first rerun."""
    k = _key("session_id")
    if k not in st.session_state:
        st.session_state[k] = str(uuid.uuid4())
    return st.session_state[k]


# ── Open flag ─────────────────────────────────────────────────────────────────

def is_controller_open() -> bool:
    return st.session_state.get(_key("ctrl_open"), False)


def mark_controller_open() -> None:
    st.session_state[_key("ctrl_open")] = True


# ── Current view ──────────────────────────────────────────────────────────────

def get_current_view() -> str | None:
    return st.session_state.get(_key("view"))


def set_current_view(route: str) -> None:
    st.session_state[_key("view")] = route


# ── Last action response ──────────────────────────────────────────────────────

def get_action_response() -> Any:
    """Return and clear the stored action response (if any)."""
    return st.session_state.pop(_key("action_response"), None)


def set_action_response(response: Any) -> None:
    st.session_state[_key("action_response")] = response


# ── Toast queue ───────────────────────────────────────────────────────────────

def enqueue_toast(message: str) -> None:
    queue: list[str] = st.session_state.get(_key("toasts"), [])
    queue.append(message)
    st.session_state[_key("toasts")] = queue


def drain_toasts() -> list[str]:
    return st.session_state.pop(_key("toasts"), [])
