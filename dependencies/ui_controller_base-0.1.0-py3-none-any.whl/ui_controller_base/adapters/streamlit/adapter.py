"""
StreamlitAdapter — mount an AbstractUIController on Streamlit.

Usage::

    # app.py  (run with: streamlit run app.py)
    from ui_controller_base.adapters.streamlit import StreamlitAdapter
    from myapp.controller import MyController

    StreamlitAdapter(MyController()).serve()

Architecture
------------
Streamlit reruns the *entire* script on every user interaction.
The adapter defends against this in two ways:

1. **Controller open state** — ``open()`` is called once per browser session
   and the flag is stored in ``st.session_state``.

2. **View-render cache** — if the controller mixes in ``CacheableMixin``,
   rendered ``UIResponse`` objects are cached under
   ``(route, payload_hash, session_id)`` so expensive backend calls are
   skipped on reruns that carry the same inputs.

Action dispatch
---------------
When a FORM fragment is submitted the adapter calls::

    controller.handle(UIAction(name=action_name, view=route,
                               payload=values, session_id=session_id))

The resulting ``UIResponse`` is stored in ``st.session_state`` and shown on
the next rerun above the current view render.
"""

from __future__ import annotations

from typing import Any

import streamlit as st
from asgiref.sync import async_to_sync

from ui_controller_base.core.action import UIAction
from ui_controller_base.core.adapter import AbstractFrameworkAdapter
from ui_controller_base.core.response import UIResponse

from .renderer import render_response
from .session import (
    drain_toasts,
    enqueue_toast,
    get_action_response,
    get_current_view,
    get_session_id,
    is_controller_open,
    mark_controller_open,
    set_action_response,
    set_current_view,
)


class StreamlitAdapter(AbstractFrameworkAdapter):
    """Adapter that renders an ``AbstractUIController`` as a Streamlit app.

    Parameters
    ----------
    controller:
        An ``AbstractUIController`` subclass *instance*.  The adapter
        calls ``open()`` once per browser session and ``handle()`` on
        every dispatched action.
    title:
        Streamlit page title (``st.set_page_config``).
    page_icon:
        Streamlit page icon emoji or URL.
    layout:
        Streamlit layout — ``"centered"`` (default) or ``"wide"``.
    """

    def __init__(
        self,
        controller: Any | None = None,
        *,
        title: str = "UI Controller App",
        page_icon: str = "🖥️",
        layout: str = "centered",
    ) -> None:
        self._title = title
        self._page_icon = page_icon
        self._layout = layout
        self._controller: Any = None
        if controller is not None:
            self.mount(controller)

    # ── AbstractFrameworkAdapter ──────────────────────────────────

    def mount(self, controller: Any) -> "StreamlitAdapter":
        self._controller = controller
        return self

    def translate_request(self, native: dict) -> UIAction:
        """Build a ``UIAction`` from a plain dict (used internally)."""
        return UIAction(**native)

    def translate_response(self, resp: UIResponse) -> None:
        """Render *resp* to the Streamlit surface (called internally)."""
        render_response(resp)

    def serve(self) -> None:
        """Entry point — call this at module level in your ``app.py``.

        Streamlit will invoke this function on every rerun.  The adapter
        is safe to call repeatedly; stateful data lives in
        ``st.session_state``.
        """
        ctrl = self.controller  # raises if not mounted

        st.set_page_config(
            page_title=self._title,
            page_icon=self._page_icon,
            layout=self._layout,
        )

        # Open the controller once per browser session.
        if not is_controller_open():
            async_to_sync(ctrl.open)()
            mark_controller_open()

        session_id = get_session_id()
        routes = ctrl.routes

        if not routes:
            st.warning("No views registered on this controller.")
            return

        # Resolve current route.
        current_route = get_current_view()
        if current_route not in routes:
            current_route = routes[0]
            set_current_view(current_route)

        # Sidebar navigation.
        if len(routes) > 1:
            self._render_nav(routes, current_route, session_id)

        # Drain toast queue from previous rerun.
        for msg in drain_toasts():
            st.toast(msg)

        # Show the response from the last action (if any).
        last_response = get_action_response()
        if last_response is not None:
            self._render_action_response(last_response)
            st.divider()

        # Render the current view.
        self._render_current_view(current_route, session_id)

    # ── Internal helpers ──────────────────────────────────────────

    def _render_nav(
        self,
        routes: list[str],
        current_route: str,
        session_id: str,
    ) -> None:
        with st.sidebar:
            st.header("Navigation")
            for route in routes:
                label = route.lstrip("/").replace("-", " ").replace("_", " ").title() or route
                is_active = route == current_route
                if st.button(
                    f"{'▶ ' if is_active else ''}{label}",
                    key=f"_uicb_nav_{route}",
                    use_container_width=True,
                    type="primary" if is_active else "secondary",
                ):
                    set_current_view(route)
                    # Invalidate cached render for the new view.
                    if hasattr(self._controller, "view_cache"):
                        key = self._controller.make_view_key(route, {}, session_id)
                        self._controller.view_cache.delete(key)
                    st.rerun()

    def _render_current_view(self, route: str, session_id: str) -> None:
        ctrl = self._controller

        # Try the view-render cache (CacheableMixin).
        if hasattr(ctrl, "view_cache") and hasattr(ctrl, "make_view_key"):
            cache_key = ctrl.make_view_key(route, {}, session_id)
            cached: UIResponse | None = ctrl.view_cache.get(cache_key)
            if cached is not None:
                render_response(
                    cached,
                    action_callback=lambda name, vals: self._dispatch_action(
                        name, vals, route, session_id
                    ),
                )
                return

        # Fetch the view instance and render it.
        try:
            view = async_to_sync(ctrl.view_registry.get_by_route)(route)
        except Exception as exc:
            st.error(f"View not found for route '{route}': {exc}")
            return

        from ui_controller_base.core.context import UIContext
        from ui_controller_base.core.state import UIState

        ctx = UIContext.create(session_id=session_id, events=ctrl.events)
        state = UIState(session_id=session_id)

        response: UIResponse = async_to_sync(view.render)(ctx, state)

        # Store in cache.
        if hasattr(ctrl, "view_cache") and hasattr(ctrl, "make_view_key"):
            cache_key = ctrl.make_view_key(route, {}, session_id)
            ctrl.view_cache.set(cache_key, response)

        render_response(
            response,
            action_callback=lambda name, vals: self._dispatch_action(
                name, vals, route, session_id
            ),
        )

        # Handle redirect from the view render.
        if response.redirect and response.redirect != route:
            set_current_view(response.redirect)
            st.rerun()

    def _dispatch_action(
        self, action_name: str, payload: dict, view: str, session_id: str
    ) -> None:
        """Sync-dispatch *action_name* and store the response for the next rerun."""
        ctrl = self._controller
        action = UIAction(
            name=action_name,
            view=view,
            payload=payload,
            session_id=session_id,
        )
        response: UIResponse = ctrl.handle(action)
        set_action_response(response)

        # Invalidate the view cache so the next rerun reflects the change.
        if hasattr(ctrl, "view_cache") and hasattr(ctrl, "make_view_key"):
            ctrl.view_cache.delete(ctrl.make_view_key(view, {}, session_id))

        if response.toast:
            enqueue_toast(response.toast)

        if response.redirect:
            set_current_view(response.redirect)

        st.rerun()

    @staticmethod
    def _render_action_response(response: UIResponse) -> None:
        """Render the result of the last action at the top of the page."""
        if response.status.value == "error":
            render_response(response)
        elif response.status.value == "pending":
            st.info(f"⏳ Job submitted (id: {response.job_id})")
        elif response.status.value == "waiting":
            st.info(f"⏸ Workflow waiting for approval (id: {response.workflow_id})")
        elif response.fragments:
            render_response(response)
