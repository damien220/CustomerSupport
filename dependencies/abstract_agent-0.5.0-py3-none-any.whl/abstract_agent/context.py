"""AgentContext — per-session runtime state carried through the agent lifecycle."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class AgentContext:
    """Mutable runtime state bag shared across all lifecycle calls within a session.

    A single ``AgentContext`` is created when an agent is instantiated and
    lives for the agent's entire lifetime.  Each ``run()`` call increments
    ``turn`` so downstream code can distinguish turns within a session.

    Attributes:
        session_id: Unique identifier for the current session (UUID4 string).
        turn:       Number of completed ``run()`` calls for this session.
        metadata:   Arbitrary key/value pairs set by the application or agent.
    """

    session_id: str
    turn: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def new(cls, **metadata: Any) -> AgentContext:
        """Create a fresh context with a new random session ID.

        Args:
            **metadata: Optional key/value pairs attached to the context.

        Returns:
            A new ``AgentContext`` instance with ``turn=0``.
        """
        return cls(session_id=str(uuid.uuid4()), metadata=dict(metadata))

    def increment_turn(self) -> None:
        """Increment the turn counter after a completed ``run()`` call."""
        self.turn += 1
