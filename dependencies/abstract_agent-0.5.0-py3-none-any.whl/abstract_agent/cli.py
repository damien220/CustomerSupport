"""abstract-agent CLI — bootstrap and utility commands.

Entry point: ``abstract-agent`` (registered in ``pyproject.toml``).

Commands
--------
``abstract-agent init [TARGET_DIR]``
    Scaffold config files for a new agent project using
    ``config_manager.ConfigManagerFactory``.

    Generates (inside *TARGET_DIR*):

    * ``config/agent.yaml``  — YAML agent configuration
    * ``.env.example``       — placeholder secrets file
    * ``src/config.py``      — Python config loader  (when ``--lang python``)

Usage::

    abstract-agent init ./my_project
    abstract-agent init ./my_project --name chatbot --profiles
    abstract-agent init . --secrets env_only --lang python
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_factory():
    """Create a ConfigManagerFactory with the AbstractAgent strategy registered."""
    from src.config_manager_factory import ConfigManagerFactory
    from abstract_agent._agent_strategy import AbstractAgentConfigStrategy

    factory = ConfigManagerFactory()
    factory.registry.register("abstract_agent", AbstractAgentConfigStrategy)
    return factory


def _run_init(args: argparse.Namespace) -> int:
    """Execute the ``init`` sub-command.

    Args:
        args: Parsed CLI arguments.

    Returns:
        Exit code (0 = success, 1 = error).
    """
    target = Path(args.target_dir).resolve()

    print(f"\nabstract-agent init → {target}\n")

    try:
        factory = _build_factory()
        files = factory.create(
            app_type="abstract_agent",
            target_dir=target,
            language=args.lang,
            profiles=args.profiles,
            secrets=args.secrets,
            validation=args.validation,
        )
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if not files:
        print("No files generated — check your target directory.")
        return 1

    print(f"Generated {len(files)} file(s):")
    for f in files:
        rel = f.relative_to(target) if f.is_absolute() else f
        print(f"  ✓ {rel}")

    print(
        "\nNext steps:\n"
        "  1. Edit config/agent.yaml to set your model, memory, and cache options.\n"
        "  2. Copy .env.example to .env and fill in your API key.\n"
        "  3. Subclass AbstractAgent and implement process() / respond().\n"
    )
    return 0


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    """Main entry point for the ``abstract-agent`` CLI."""
    parser = argparse.ArgumentParser(
        prog="abstract-agent",
        description="Abstract Agent — tools for building AI agent projects",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── init ──────────────────────────────────────────────────────────
    init_p = sub.add_parser(
        "init",
        help="Scaffold config files for a new agent project",
        description=(
            "Generate YAML, .env, and Python config files for a new "
            "abstract_agent project using config_manager templates."
        ),
    )
    init_p.add_argument(
        "target_dir",
        nargs="?",
        default=".",
        help="Directory to scaffold into (default: current directory)",
    )
    init_p.add_argument(
        "--lang",
        default="python",
        choices=["python", "nodejs", "go", "rust"],
        help="Target language for the config loader (default: python)",
    )
    init_p.add_argument(
        "--profiles",
        action="store_true",
        default=False,
        help="Generate dev/staging/prod environment profiles",
    )
    init_p.add_argument(
        "--secrets",
        default="env_file",
        choices=["env_only", "env_file", "external", "none"],
        help="Secrets handling mode (default: env_file)",
    )
    init_p.add_argument(
        "--validation",
        default="strict",
        choices=["strict", "warn", "none"],
        help="Config validation mode (default: strict)",
    )

    args = parser.parse_args(argv)

    if args.command == "init":
        sys.exit(_run_init(args))
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
