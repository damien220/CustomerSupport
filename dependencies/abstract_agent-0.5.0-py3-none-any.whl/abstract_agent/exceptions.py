"""Agent-specific exception hierarchy.

All exceptions extend ``error_handler.BaseAppException`` so they produce
the same structured JSON error body when passed through ``ErrorHandler.handle()``.
"""

from __future__ import annotations

from typing import Any, Optional

from error_handler import BaseAppException


class AgentException(BaseAppException):
    """Root exception for all agent errors."""

    def __init__(
        self,
        message: str = "An agent error occurred",
        *,
        code: str = "AGENT_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            details=details,
            previous=previous,
        )


class AgentConfigError(AgentException):
    """Raised when the agent is misconfigured at initialisation time."""

    def __init__(
        self,
        message: str = "Invalid agent configuration",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_CONFIG_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class AgentSetupError(AgentException):
    """Raised when ``setup()`` fails before the agent can process input."""

    def __init__(
        self,
        message: str = "Agent setup failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_SETUP_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class AgentProcessError(AgentException):
    """Raised when ``process()`` raises an unhandled exception."""

    def __init__(
        self,
        message: str = "Agent failed to process input",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_PROCESS_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class AgentRespondError(AgentException):
    """Raised when ``respond()`` raises an unhandled exception."""

    def __init__(
        self,
        message: str = "Agent failed to produce a response",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_RESPOND_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class AgentTimeoutError(AgentException):
    """Raised when a ``process()`` or ``respond()`` call exceeds the timeout."""

    def __init__(
        self,
        message: str = "Agent operation timed out",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_TIMEOUT",
            status_code=504,
            details=details,
            previous=previous,
        )


class AgentMemoryError(AgentException):
    """Raised when a memory read or write operation fails."""

    def __init__(
        self,
        message: str = "Agent memory operation failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="AGENT_MEMORY_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )
