"""abstract_agent — reusable abstract base class for building AI agents.

Public surface (Phase 1 + 2 + 3 + 4 + 5)::

    from abstract_agent import (
        AbstractAgent,
        AgentConfig, DbConfig, CacheConfig, NotificationConfig,
        AgentContext,
        AbstractAgentMemory, InMemoryMemory, DatabaseMemory, MemoryEntry,
        AbstractAgentTool,
    )
    from abstract_agent.mixins import CacheableMixin, ObservableMixin, SchedulableMixin, ToolEnabledMixin
    from abstract_agent.exceptions import (
        AgentException, AgentProcessError, AgentRespondError, ...
    )

Phase 4 — tool invocation example::

    from abstract_agent import AbstractAgent, AgentConfig, AbstractAgentTool
    from abstract_agent.mixins import ToolEnabledMixin

    class EchoTool(AbstractAgentTool):
        plugin_name = "echo"
        plugin_description = "Echo the input back."

        async def execute(self, input: str) -> str:
            return f"echo: {input}"

    class ToolAgent(ToolEnabledMixin, AbstractAgent):
        async def process(self, input: str) -> str:
            if self.has_tool("echo"):
                return await self.invoke_tool("echo", input)
            return input

        async def respond(self, result: str) -> str:
            return result

    cfg = AgentConfig(agent_name="toolbot", tools_dir="./tools")
    agent = ToolAgent(cfg)
    agent._tool_bridge._manager  # inspect registry if needed

Phase 3 — LLM caching example::

    from abstract_agent import AbstractAgent, AgentConfig, CacheConfig
    from abstract_agent.mixins import CacheableMixin

    class CachedAgent(CacheableMixin, AbstractAgent):
        async def process(self, input: str) -> dict:
            messages = self.build_messages(input)
            response = await self.api_client.post(
                "/chat/completions",
                json={"model": self.config.model, "messages": messages},
            )
            return response.body

        async def respond(self, result: dict) -> str:
            return result["choices"][0]["message"]["content"]

    cfg = AgentConfig(
        model="gpt-4o",
        cache_config=CacheConfig(enabled=True, backend="memory", ttl=3600),
    )
    async with CachedAgent(cfg, api_client=client) as agent:
        reply1 = await agent.run("What is 2+2?")   # calls LLM
        reply2 = await agent.run("What is 2+2?")   # served from cache
        print(agent.token_tracker.tokens_saved)

CLI usage::

    abstract-agent init ./my_project    # scaffold config files
"""

from .agent import AbstractAgent
from .config import AgentConfig, CacheConfig, DbConfig, NotificationConfig
from .context import AgentContext
from .exceptions import (
    AgentConfigError,
    AgentException,
    AgentMemoryError,
    AgentProcessError,
    AgentRespondError,
    AgentSetupError,
    AgentTimeoutError,
)
from .memory import AbstractAgentMemory, DatabaseMemory, InMemoryMemory, MemoryEntry
from .mixins import CacheableMixin, ObservableMixin, SchedulableMixin, ToolEnabledMixin
from .tools import AbstractAgentTool

__version__ = "0.5.0"

__all__ = [
    # Core
    "AbstractAgent",
    "AgentConfig",
    "DbConfig",
    "CacheConfig",
    "NotificationConfig",
    "AgentContext",
    # Memory
    "AbstractAgentMemory",
    "InMemoryMemory",
    "DatabaseMemory",
    "MemoryEntry",
    # Mixins
    "CacheableMixin",
    "ObservableMixin",
    "SchedulableMixin",
    "ToolEnabledMixin",
    # Tools
    "AbstractAgentTool",
    # Exceptions
    "AgentException",
    "AgentConfigError",
    "AgentSetupError",
    "AgentProcessError",
    "AgentRespondError",
    "AgentTimeoutError",
    "AgentMemoryError",
]
