"""AbstractAgent — the core base class every agent must subclass."""

from __future__ import annotations

import logging
import logging.handlers
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .config import AgentConfig
from .context import AgentContext
from .exceptions import AgentProcessError, AgentRespondError, AgentSetupError
from .integrations.error_handler import handle_agent_error
from .integrations.logger import (
    bind_context,
    configure_agent_logging,
    get_agent_logger,
    reset_context,
)
from .memory import AbstractAgentMemory, InMemoryMemory, build_memory_from_config

if TYPE_CHECKING:
    from api_client_base import AbstractAPIClient


class AbstractAgent(ABC):
    """Reusable abstract base class for AI agents.

    Subclasses **must** implement :meth:`process` and :meth:`respond`.
    Everything else — lifecycle management, logging, error normalisation,
    memory, and API transport — is handled by this class.

    Lifecycle per ``run()`` call::

        setup()  →  process(input)  →  respond(result)  →  teardown()
                               ↓ on any exception ↓
                             on_error()  →  teardown()  →  re-raise

    **Phase 2 additions:**

    * ``api_client`` — inject any ``AbstractAPIClient`` subclass to give the
      agent access to an LLM or external service without hardcoding HTTP logic.
    * ``memory_backend = "database"`` + ``db_config`` — persist conversation
      history across process restarts using any ``db_accessor`` backend.
    * :meth:`build_messages` — convenience helper that prepends conversation
      history in ``[{"role": ..., "content": ...}]`` format ready for LLM APIs.
    * :meth:`open` / :meth:`close` — explicit connection lifecycle for the
      API client; also supported via the async context manager.

    Usage::

        class MyLLMAgent(AbstractAgent):
            async def process(self, input: str) -> dict:
                messages = self.build_messages(input, system_prompt="You are helpful.")
                response = await self.api_client.post(
                    "/chat/completions",
                    json={"model": self.config.model, "messages": messages},
                )
                self.memory.append(self.context.session_id, "user", input)
                self.memory.append(
                    self.context.session_id, "assistant",
                    response.body["choices"][0]["message"]["content"],
                )
                return response.body

            async def respond(self, result: dict) -> str:
                return result["choices"][0]["message"]["content"]

        cfg = AgentConfig(agent_name="mybot", model="gpt-4o")
        async with MyLLMAgent(cfg, api_client=client) as agent:
            reply = await agent.run("Hello!")

    Args:
        config:     Configuration for this agent instance.
        api_client: Optional pre-built API client.  The agent stores it as
                    ``self.api_client`` for use in :meth:`process`.
                    Call :meth:`open` (or use the async context manager) to
                    connect it before calling :meth:`run`.
        memory:     Optional memory backend.  When omitted the backend
                    described by ``config.memory_backend`` is created
                    automatically.
        context:    Optional pre-built session context.  A fresh context with
                    a new ``session_id`` is created automatically when omitted.
    """

    def __init__(
        self,
        config: Optional[AgentConfig] = None,
        *,
        api_client: Optional[AbstractAPIClient] = None,
        memory: Optional[AbstractAgentMemory] = None,
        context: Optional[AgentContext] = None,
    ) -> None:
        self.config: AgentConfig = config or AgentConfig()
        self.context: AgentContext = context or AgentContext.new(
            agent=self.config.agent_name
        )

        # API client — injected, not owned (caller manages connect/disconnect
        # externally or via open()/close()).
        self.api_client: Optional[AbstractAPIClient] = api_client

        # Memory — build from config if not explicitly provided.
        if memory is not None:
            self.memory: AbstractAgentMemory = memory
        else:
            self.memory = build_memory_from_config(self.config)

        # Set up structured logging via logger_pkg.
        self._listener: Optional[logging.handlers.QueueListener] = (
            configure_agent_logging(self.config)
        )
        self._log: logging.Logger = get_agent_logger(self.config.agent_name)

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    async def open(self) -> None:
        """Connect the API client if one is configured.

        Call this once before the first :meth:`run` when using
        ``api_client`` outside the async context manager::

            agent = MyAgent(cfg, api_client=client)
            await agent.open()
            reply = await agent.run("Hi")
            await agent.close()

        No-op if no ``api_client`` is set.
        """
        if self.api_client is not None:
            await self.api_client.connect()

    async def close(self) -> None:
        """Disconnect the API client and stop the background log queue.

        Called automatically by ``__aexit__``.  Safe to call more than once.
        """
        if self.api_client is not None:
            await self.api_client.disconnect()
        if self._listener is not None:
            self._listener.stop()
            self._listener = None

    async def __aenter__(self) -> AbstractAgent:
        await self.open()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Public entry point — do not override
    # ------------------------------------------------------------------

    async def run(self, input: Any) -> Any:
        """Orchestrate the full agent lifecycle for a single turn.

        This method is intentionally **not** abstract so all agents share
        identical lifecycle semantics.  Customise behaviour by overriding
        :meth:`setup`, :meth:`teardown`, and :meth:`on_error` instead.

        Args:
            input: Raw input for this turn (string, dict, or any type your
                   :meth:`process` implementation accepts).

        Returns:
            The value returned by :meth:`respond`.

        Raises:
            AgentSetupError:   If :meth:`setup` raises.
            AgentProcessError: If :meth:`process` raises.
            AgentRespondError: If :meth:`respond` raises.
        """
        ctx_token = bind_context(
            session_id=self.context.session_id,
            agent=self.config.agent_name,
            turn=self.context.turn,
        )

        self._log.info(
            "run started",
            extra={"input_type": type(input).__name__},
        )

        try:
            # --- setup ---
            try:
                await self.setup()
            except AgentSetupError:
                raise
            except Exception as exc:
                wrapped = AgentSetupError(
                    str(exc),
                    details={"agent": self.config.agent_name},
                    previous=exc,
                )
                await self._handle_error(wrapped, input)
                raise wrapped from exc

            # --- process (via _execute_process so mixins can intercept) ---
            try:
                result = await self._execute_process(input)
            except (AgentProcessError, AgentSetupError):
                raise
            except Exception as exc:
                wrapped = AgentProcessError(
                    str(exc),
                    details={
                        "agent": self.config.agent_name,
                        "input_type": type(input).__name__,
                    },
                    previous=exc,
                )
                await self._handle_error(wrapped, input)
                raise wrapped from exc

            # --- respond (via _execute_respond so mixins can intercept) ---
            try:
                output = await self._execute_respond(result)
            except AgentRespondError:
                raise
            except Exception as exc:
                wrapped = AgentRespondError(
                    str(exc),
                    details={
                        "agent": self.config.agent_name,
                        "result_type": type(result).__name__,
                    },
                    previous=exc,
                )
                await self._handle_error(wrapped, input)
                raise wrapped from exc

            self._log.info("run completed")
            return output

        finally:
            self.context.increment_turn()
            await self.teardown()
            reset_context(ctx_token)

    # ------------------------------------------------------------------
    # Internal dispatch — overridden by mixins (e.g. CacheableMixin)
    # ------------------------------------------------------------------

    async def _execute_process(self, input: Any) -> Any:
        """Dispatch hook called by ``run()`` instead of ``process()`` directly.

        Mixins override this method to wrap ``process()`` with cross-cutting
        behaviour (caching, retries, tracing, …) without touching the agent's
        concrete implementation.  The default simply delegates to
        ``self.process()``.

        Concrete agents should **not** override this method — implement
        :meth:`process` instead.
        """
        return await self.process(input)

    async def _execute_respond(self, result: Any) -> Any:
        """Dispatch hook called by ``run()`` instead of ``respond()`` directly.

        Mirrors :meth:`_execute_process`.  Mixins (e.g. :class:`ObservableMixin`)
        override this to emit post-respond events or perform other cross-cutting
        work around :meth:`respond` without subclassing the concrete agent.

        Concrete agents should **not** override this method — implement
        :meth:`respond` instead.
        """
        return await self.respond(result)

    # ------------------------------------------------------------------
    # Abstract interface — subclasses must implement these two methods
    # ------------------------------------------------------------------

    @abstractmethod
    async def process(self, input: Any) -> Any:
        """Transform raw input into an intermediate result.

        This is where the LLM call, tool dispatch, or any heavy computation
        lives.  Use :meth:`build_messages` to prepend conversation history
        before passing to the LLM::

            async def process(self, input: str) -> dict:
                messages = self.build_messages(input)
                response = await self.api_client.post(
                    "/chat/completions",
                    json={"model": self.config.model, "messages": messages},
                )
                return response.body

        Args:
            input: The value passed to :meth:`run`.

        Returns:
            Any intermediate value suitable for :meth:`respond`.
        """

    @abstractmethod
    async def respond(self, result: Any) -> Any:
        """Convert the intermediate result into the final output.

        Use this to format, serialise, or post-process the value produced
        by :meth:`process` before it is returned to the caller.

        Args:
            result: The value returned by :meth:`process`.

        Returns:
            The final output returned to the caller of :meth:`run`.
        """

    # ------------------------------------------------------------------
    # Lifecycle hooks — override as needed
    # ------------------------------------------------------------------

    async def setup(self) -> None:
        """Called once at the start of every :meth:`run` call.

        Override to open per-turn resources or perform pre-turn checks.
        The default implementation is a no-op.  The API client connection
        is managed separately via :meth:`open` / :meth:`close`.
        """

    async def teardown(self) -> None:
        """Called at the end of every :meth:`run` call — even on error.

        Override to flush per-turn resources.  The default is a no-op.
        """

    async def on_error(self, error: Exception, input: Any) -> None:
        """Called when :meth:`process` or :meth:`respond` raises.

        Override to add custom alerting, dead-letter queueing, or fallback
        logic.  The default implementation is a no-op; the structured error
        body is already logged by :meth:`_handle_error` before this hook runs.

        Args:
            error: The exception (already wrapped as an ``AgentException``
                   subclass).
            input: The original value passed to :meth:`run`.
        """

    # ------------------------------------------------------------------
    # Phase 2 helpers — available to subclasses
    # ------------------------------------------------------------------

    def build_messages(
        self,
        user_input: str,
        *,
        system_prompt: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Build a messages array with conversation history prepended.

        Produces the ``[{"role": ..., "content": ...}]`` format expected by
        OpenAI-compatible and most other LLM chat APIs.  History is read from
        ``self.memory`` for the current ``session_id``.

        Args:
            user_input:    The user's message for this turn.
            system_prompt: Optional system prompt inserted as the first message.
                           When omitted no system message is added.

        Returns:
            A list of message dicts ready to pass as the ``messages`` field of
            a chat-completion request.

        Example::

            messages = self.build_messages(
                input,
                system_prompt="You are a concise assistant.",
            )
            response = await self.api_client.post(
                "/chat/completions",
                json={"model": self.config.model, "messages": messages},
            )
        """
        messages: List[Dict[str, Any]] = []
        if system_prompt is not None:
            messages.append({"role": "system", "content": system_prompt})
        messages.extend(self.memory.get_history_as_dicts(self.context.session_id))
        messages.append({"role": "user", "content": user_input})
        return messages

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _handle_error(self, error: Exception, input: Any) -> None:
        """Normalise *error* and delegate to :meth:`on_error`."""
        result = handle_agent_error(
            error,
            agent_name=self.config.agent_name,
            session_id=self.context.session_id,
            turn=self.context.turn,
        )
        self._log.error(
            "agent error",
            extra={
                "error_code": result["body"]["error"]["code"],
                "status_code": result["status_code"],
            },
        )
        await self.on_error(error, input)
