"""AbstractAgentTool — base class that all agent tools must subclass."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from plugin_loader import AbstractPlugin


class AbstractAgentTool(AbstractPlugin):
    """Base class for every tool an agent can invoke.

    Extend this class to create a new tool, then either:

    * Drop the file inside the agent project's ``tools/`` directory so it is
      discovered automatically via :class:`~plugin_loader.DirectoryStrategy`.
    * Advertise it in a package's ``pyproject.toml`` entry-point group
      ``"abstract_agent.tools"`` so it is discovered via
      :class:`~plugin_loader.EntryPointStrategy`.

    Subclasses **must** define:

    * ``plugin_name`` (:class:`str`) — unique identifier used to invoke the
      tool (e.g. ``"web_search"``).
    * :meth:`execute` — the tool logic itself.

    Class attributes ``description``, ``plugin_version``, ``plugin_tags``, and
    ``plugin_capabilities`` are optional but improve discoverability.

    The ``initialize``, ``start``, and ``stop`` lifecycle methods from
    :class:`~plugin_loader.AbstractPlugin` default to no-ops here; override
    them only when your tool needs to acquire or release resources (e.g. open
    an HTTP session, connect to a DB).

    Example::

        # tools/web_search.py
        from abstract_agent import AbstractAgentTool

        class WebSearchTool(AbstractAgentTool):
            plugin_name = "web_search"
            plugin_description = "Search the web and return top results."

            async def execute(self, input: str) -> str:
                # ... call external search API ...
                return "result1\\nresult2"

    Invoking from ``process()``::

        class MyAgent(ToolEnabledMixin, AbstractAgent):
            async def process(self, input: str) -> str:
                if self.has_tool("web_search"):
                    search_result = await self.invoke_tool("web_search", input)
                    return f"Search results: {search_result}"
                return input

            async def respond(self, result: str) -> str:
                return result
    """

    async def initialize(self, config: dict[str, Any] | None = None) -> None:
        """One-time setup.  Override to acquire resources on load."""

    async def start(self) -> None:
        """Begin active operation.  No-op by default."""

    async def stop(self) -> None:
        """Graceful shutdown.  No-op by default."""

    @abstractmethod
    async def execute(self, input: Any) -> Any:
        """Run the tool and return the result.

        This is the only method concrete tools **must** implement.

        Args:
            input: Tool-specific input value — a query string, a parameter
                   dict, or any type the tool accepts.

        Returns:
            Tool output to be included in the LLM context by the agent's
            ``process()`` implementation.
        """
