"""Agent memory — abstract interface and concrete implementations.

Phase 1: ``InMemoryMemory``  — no external dependencies, process-local.
Phase 2: ``DatabaseMemory``  — persistent, backed by ``db_accessor``.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class MemoryEntry:
    """A single turn stored in the conversation history.

    Attributes:
        role:      Speaker role — ``"system"``, ``"user"``, ``"assistant"``, or
                   ``"tool"``.
        content:   The message payload (string or structured data).
        timestamp: UTC time the entry was recorded.
        metadata:  Arbitrary key/value pairs (e.g. token counts, tool name).
    """

    role: str
    content: Any
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Return the entry as a plain dict compatible with LLM message arrays."""
        return {"role": self.role, "content": self.content}


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------

class AbstractAgentMemory(ABC):
    """Contract that all memory backends must satisfy.

    Implementations are keyed by ``session_id`` so one memory object can
    serve an entire multi-session agent without additional wrappers.
    """

    def initialize(self) -> None:
        """Set up any required backend resources (e.g. database tables).

        Called once during ``AbstractAgent.__init__``.  Default is a no-op;
        persistent backends override this to create schemas on first run.
        """

    @abstractmethod
    def get_history(self, session_id: str) -> List[MemoryEntry]:
        """Return all stored entries for *session_id* in insertion order."""

    @abstractmethod
    def append(
        self,
        session_id: str,
        role: str,
        content: Any,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryEntry:
        """Store a new entry and return it.

        Args:
            session_id: Identifies the conversation session.
            role:       Speaker role (``"user"``, ``"assistant"``, etc.).
            content:    Message payload.
            metadata:   Optional extra fields attached to the entry.

        Returns:
            The newly created ``MemoryEntry``.
        """

    @abstractmethod
    def clear(self, session_id: str) -> int:
        """Delete all entries for *session_id*.

        Returns:
            Number of entries removed.
        """

    # ------------------------------------------------------------------
    # Convenience helpers (shared by all implementations)
    # ------------------------------------------------------------------

    def get_history_as_dicts(self, session_id: str) -> List[Dict[str, Any]]:
        """Return history as ``[{"role": ..., "content": ...}]`` dicts.

        This format is accepted directly by most LLM chat APIs.
        """
        return [entry.to_dict() for entry in self.get_history(session_id)]

    def last_entry(self, session_id: str) -> Optional[MemoryEntry]:
        """Return the most recent entry, or ``None`` if the session is empty."""
        history = self.get_history(session_id)
        return history[-1] if history else None

    def turn_count(self, session_id: str) -> int:
        """Return the number of stored entries for *session_id*."""
        return len(self.get_history(session_id))


# ---------------------------------------------------------------------------
# Phase 1 — in-process, no external dependencies
# ---------------------------------------------------------------------------

class InMemoryMemory(AbstractAgentMemory):
    """Thread-unsafe in-process memory store backed by a plain dict.

    Suitable for development, testing, and single-threaded use cases.
    All data is lost when the process exits.  For persistent storage use
    ``DatabaseMemory`` (Phase 2).
    """

    def __init__(self) -> None:
        self._store: Dict[str, List[MemoryEntry]] = defaultdict(list)

    def get_history(self, session_id: str) -> List[MemoryEntry]:
        return list(self._store[session_id])

    def append(
        self,
        session_id: str,
        role: str,
        content: Any,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryEntry:
        entry = MemoryEntry(role=role, content=content, metadata=metadata or {})
        self._store[session_id].append(entry)
        return entry

    def clear(self, session_id: str) -> int:
        count = len(self._store[session_id])
        self._store[session_id] = []
        return count


# ---------------------------------------------------------------------------
# Phase 2 — persistent storage via db_accessor
# ---------------------------------------------------------------------------

_DDL_TEMPLATE = """\
CREATE TABLE IF NOT EXISTS {table} (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT    NOT NULL,
    role       TEXT    NOT NULL,
    content    TEXT    NOT NULL,
    timestamp  TEXT    NOT NULL,
    metadata   TEXT    NOT NULL DEFAULT '{{}}'
)
"""


class DatabaseMemory(AbstractAgentMemory):
    """Persistent memory backend backed by any ``db_accessor`` database.

    History is stored in a single flat table keyed by ``session_id``.
    Rows are ordered by the ``timestamp`` column (ISO 8601 UTC strings sort
    lexicographically, preserving insertion order at microsecond precision).

    **Schema creation** — on ``initialize()`` the backend attempts to create
    the table via ``execute_script()`` (SQLite) or ``execute_custom_query()``
    (other SQL backends).  If the backend supports neither, the table must be
    created externally before the first ``append()`` call.

    Args:
        db:    A connected ``AbstractDatabase`` instance.
        table: Table / collection name (default: ``"agent_memory"``).

    Usage::

        from db_accessor import get_database
        from abstract_agent.memory import DatabaseMemory

        db = get_database("sqlite")
        db.connect({"file": "memory.db"})

        mem = DatabaseMemory(db)
        mem.initialize()          # creates table if absent

        mem.append("s1", "user", "hello")
        mem.get_history("s1")     # [MemoryEntry(...)]
    """

    def __init__(self, db: Any, *, table: str = "agent_memory") -> None:
        self._db = db
        self._table = table

    # ------------------------------------------------------------------
    # Schema management
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Create the memory table if it does not already exist."""
        ddl = _DDL_TEMPLATE.format(table=self._table)
        # SQLite exposes execute_script(); other SQL backends use execute_custom_query().
        if hasattr(self._db, "execute_script"):
            self._db.execute_script(ddl)
        else:
            try:
                self._db.execute_custom_query({"query": ddl.strip(), "params": ()})
            except NotImplementedError:
                # Backend does not support DDL — table must be pre-created.
                pass

    # ------------------------------------------------------------------
    # AbstractAgentMemory implementation
    # ------------------------------------------------------------------

    def get_history(self, session_id: str) -> List[MemoryEntry]:
        rows = self._db.read(self._table, {"session_id": session_id})
        # Sort by ISO 8601 timestamp string (lexicographic == chronological for UTC).
        rows.sort(key=lambda r: r["timestamp"])
        return [self._row_to_entry(row) for row in rows]

    def append(
        self,
        session_id: str,
        role: str,
        content: Any,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryEntry:
        entry = MemoryEntry(role=role, content=content, metadata=metadata or {})
        self._db.create(
            self._table,
            {
                "session_id": session_id,
                "role": role,
                "content": json.dumps(content),
                "timestamp": entry.timestamp.isoformat(),
                "metadata": json.dumps(metadata or {}),
            },
        )
        # Commit so the row is immediately visible to subsequent reads.
        try:
            self._db.commit()
        except Exception:
            pass  # Not all backends require explicit commits.
        return entry

    def clear(self, session_id: str) -> int:
        count = len(self.get_history(session_id))
        if count:
            self._db.delete(self._table, {"session_id": session_id})
            try:
                self._db.commit()
            except Exception:
                pass
        return count

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_entry(row: Dict[str, Any]) -> MemoryEntry:
        content = json.loads(row["content"])
        metadata = json.loads(row.get("metadata") or "{}")
        ts_str = row.get("timestamp", "")
        try:
            timestamp = datetime.fromisoformat(ts_str)
        except (ValueError, TypeError):
            timestamp = datetime.now(timezone.utc)
        return MemoryEntry(role=row["role"], content=content, timestamp=timestamp, metadata=metadata)


# ---------------------------------------------------------------------------
# Factory helper used by AbstractAgent
# ---------------------------------------------------------------------------

def build_memory_from_config(config: Any) -> AbstractAgentMemory:
    """Construct the right memory backend from an ``AgentConfig``.

    Args:
        config: An ``AgentConfig`` instance.

    Returns:
        ``InMemoryMemory`` when ``memory_backend == "in_memory"``, or a
        connected-and-initialized ``DatabaseMemory`` otherwise.
    """
    if config.memory_backend == "database":
        from db_accessor import get_database

        db = get_database(config.db_config.backend)
        db.connect(config.db_config.connection_details)
        mem = DatabaseMemory(db, table=config.db_config.table)
        mem.initialize()
        return mem
    return InMemoryMemory()
