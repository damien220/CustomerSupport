"""AgentConfig — typed configuration dataclass for AbstractAgent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


# ---------------------------------------------------------------------------
# Phase 2 — database memory
# ---------------------------------------------------------------------------

@dataclass
class DbConfig:
    """Connection settings for the ``DatabaseMemory`` backend.

    Passed to ``db_accessor.get_database()`` and then to
    ``AbstractDatabase.connect()`` when ``memory_backend == "database"``.

    Attributes:
        backend:            Database driver — ``"sqlite"`` (default, no process
                            needed), or any other ``db_accessor`` backend.
        connection_details: Driver-specific dict passed to ``connect()``.
                            SQLite: ``{"file": "/path/to.db"}`` or
                            ``{"file": ":memory:"}``.
        table:              Table name used to store memory entries.
    """

    backend: Literal["sqlite", "postgres", "mysql", "mongodb", "redis"] = "sqlite"
    connection_details: Dict[str, Any] = field(
        default_factory=lambda: {"file": ":memory:"}
    )
    table: str = "agent_memory"


# ---------------------------------------------------------------------------
# Phase 3 — LLM response caching
# ---------------------------------------------------------------------------

@dataclass
class CacheConfig:
    """Settings for the ``CacheableMixin`` LLM response cache.

    Attributes:
        enabled:       Master switch. When ``False`` the mixin is a no-op
                       regardless of other settings.
        backend:       Cache backend — ``"memory"`` (default, in-process) or
                       ``"sqlite"`` / ``"redis"`` / ``"file"`` for persistent
                       and distributed setups.
        ttl:           Default TTL in seconds for cached LLM responses.
                       ``None`` means no expiry.
        max_size:      Maximum number of entries for the ``memory`` backend.
                       ``None`` means unlimited.
        namespace:     Cache key prefix scoping this agent's entries.
        sqlite_path:   Path to the SQLite database file when
                       ``backend == "sqlite"``.
        redis_host:    Redis host when ``backend == "redis"``.
        redis_port:    Redis port when ``backend == "redis"``.
        redis_password: Optional Redis password.
        file_cache_dir: Directory for the file-based cache backend.
    """

    enabled: bool = False
    backend: Literal["memory", "sqlite", "redis", "file"] = "memory"
    ttl: Optional[int] = 3600
    max_size: Optional[int] = 10_000
    namespace: str = "llm"
    sqlite_path: str = "./agent_cache.db"
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: Optional[str] = None
    file_cache_dir: str = "./cache"


# ---------------------------------------------------------------------------
# Phase 5 — notifications
# ---------------------------------------------------------------------------

@dataclass
class NotificationConfig:
    """Settings for the :class:`~abstract_agent.integrations.notifier.AgentNotifier`.

    Used by :func:`~abstract_agent.integrations.notifier.build_notifier_from_config`
    to create a ready-to-use notifier when combined with an
    :class:`~abstract_agent.mixins.ObservableMixin` agent.

    Attributes:
        enabled:             Master switch.  When ``False`` no subscriptions
                             are created by ``build_notifier_from_config``.
        notify_on_error:     Subscribe to ``"agent.errored"`` (default ``True``).
        notify_on_responded: Subscribe to ``"agent.responded"`` (default ``False``).
        recipient_id:        Stable identifier for the notification recipient.
        recipient_channels:  Preferred delivery channels in priority order.
                             Defaults to ``["console"]``.
    """

    enabled: bool = False
    notify_on_error: bool = True
    notify_on_responded: bool = False
    recipient_id: str = "agent-admin"
    recipient_channels: List[str] = field(default_factory=lambda: ["console"])


# ---------------------------------------------------------------------------
# Main agent configuration
# ---------------------------------------------------------------------------

@dataclass
class AgentConfig:
    """All tuneable parameters for an agent instance.

    Only ``agent_name`` and ``model`` are commonly set; every other field
    has a sensible default suitable for development use.

    Attributes:
        agent_name:     Human-readable identifier used in logs and context.
        model:          LLM model name forwarded to the API client.
        max_tokens:     Maximum tokens the model may generate per call.
        temperature:    Sampling temperature (0.0 = deterministic).
        timeout:        Per-request timeout in seconds.
        memory_backend: ``"in_memory"`` (default) or ``"database"``
                        (persistent, uses ``db_config``).
        db_config:      Database connection settings used when
                        ``memory_backend == "database"``.
        cache_config:       LLM response cache settings used by
                            ``CacheableMixin``.
        tools_dir:              Path to a local directory scanned for
                                :class:`AbstractAgentTool` subclasses by
                                ``ToolEnabledMixin``.  Empty string disables
                                directory discovery.
        tools_entry_point:      Entry-point group scanned for installed tool
                                packages.  Defaults to
                                ``"abstract_agent.tools"``.
        notification_config:    Notification delivery settings used by
                                :class:`~abstract_agent.integrations.notifier.AgentNotifier`
                                when combined with ``ObservableMixin``.
        log_level:              Minimum log level for the agent's logger.
        log_format:     ``"console"`` or ``"json"``.
        metadata:       Arbitrary key/value pairs attached to every log
                        record and agent context.
    """

    agent_name: str = "agent"
    model: str = "gpt-4o"
    max_tokens: int = 4096
    temperature: float = 0.7
    timeout: float = 30.0
    memory_backend: Literal["in_memory", "database"] = "in_memory"
    db_config: DbConfig = field(default_factory=DbConfig)
    cache_config: CacheConfig = field(default_factory=CacheConfig)
    # Phase 4 — tool discovery
    tools_dir: str = ""
    tools_entry_point: str = "abstract_agent.tools"
    # Phase 5 — notifications
    notification_config: NotificationConfig = field(default_factory=NotificationConfig)
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_format: Literal["console", "json"] = "console"
    metadata: Dict[str, Any] = field(default_factory=dict)
