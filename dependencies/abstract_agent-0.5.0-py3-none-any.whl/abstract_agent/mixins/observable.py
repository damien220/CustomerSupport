"""ObservableMixin — emit lifecycle events from any AbstractAgent.

How it works
------------
``ObservableMixin`` intercepts four agent lifecycle points and emits a
:class:`~event_dispatcher.DispatchEvent` at each one::

    setup()            → agent.started   (after setup completes)
    _execute_process() → agent.processed (input + result in payload)
    _execute_respond() → agent.responded (final output in payload)
    on_error()         → agent.errored   (error details in payload)

All events share the same ``source`` (the agent name), ``correlation_id``
(the session ID), and ``metadata`` (turn number).

External code subscribes to events via :meth:`subscribe`::

    class MyAgent(ObservableMixin, AbstractAgent):
        ...

    agent = MyAgent(cfg)
    agent.subscribe("agent.errored", lambda e: print("Error!", e.payload))
    agent.subscribe("agent.*", lambda e: audit_log(e))  # wildcard

MRO placement
-------------
Place :class:`ObservableMixin` **before** ``AbstractAgent``::

    class MyAgent(ObservableMixin, AbstractAgent):
        ...

Combining with other mixins::

    class MyAgent(CacheableMixin, ObservableMixin, ToolEnabledMixin, AbstractAgent):
        ...

Event kinds
-----------
* ``"agent.started"``   — ``payload: {}``
* ``"agent.processed"`` — ``payload: {"input_type": str, "result_type": str}``
* ``"agent.responded"`` — ``payload: {"output_type": str}``
* ``"agent.errored"``   — ``payload: {"error": str, "error_type": str, "code": str}``
"""

from __future__ import annotations

from typing import Any, Callable

from event_dispatcher import DispatchEvent, LocalDispatcher


class ObservableMixin:
    """Mixin that makes any :class:`~abstract_agent.agent.AbstractAgent` emit lifecycle events.

    Attach it **before** ``AbstractAgent`` in the class bases::

        class MyAgent(ObservableMixin, AbstractAgent):
            async def process(self, input: str) -> str:
                return input.upper()

            async def respond(self, result: str) -> str:
                return result

    Subscribe to events::

        agent = MyAgent(AgentConfig(agent_name="mybot"))

        @agent.subscribe("agent.errored")
        def on_error(event: DispatchEvent) -> None:
            print(f"Agent errored: {event.payload['error']}")

        await agent.run("hello")

    The :attr:`dispatcher` is public so callers can also set up middleware,
    inspect stats, or wire in additional subscribers after construction.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.dispatcher: LocalDispatcher = LocalDispatcher()

    # ------------------------------------------------------------------
    # Subscription helper
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_pattern: str,
        handler_fn: Callable[[DispatchEvent], Any],
    ) -> Any:
        """Register a handler for events matching *event_pattern*.

        Supports wildcard patterns (``"agent.*"``) via the underlying
        :class:`~event_dispatcher.LocalDispatcher`.

        Args:
            event_pattern: Event kind pattern to match (e.g. ``"agent.errored"``
                           or ``"agent.*"`` for all agent events).
            handler_fn:    Callable receiving a :class:`~event_dispatcher.DispatchEvent`.
                           May be sync or async.

        Returns:
            :class:`~event_dispatcher.HandlerSubscription` — pass to
            :meth:`~event_dispatcher.LocalDispatcher.unsubscribe` to remove.
        """
        return self.dispatcher.subscribe(event_pattern, handler_fn)

    # ------------------------------------------------------------------
    # Lifecycle interception
    # ------------------------------------------------------------------

    async def setup(self) -> None:
        """Call ``super().setup()`` then emit ``agent.started``."""
        await super().setup()  # type: ignore[misc]
        self._emit("agent.started", {})

    async def _execute_process(self, input: Any) -> Any:
        """Delegate to ``super()._execute_process()``, then emit ``agent.processed``."""
        result = await super()._execute_process(input)  # type: ignore[misc]
        self._emit(
            "agent.processed",
            {
                "input_type": type(input).__name__,
                "result_type": type(result).__name__,
            },
        )
        return result

    async def _execute_respond(self, result: Any) -> Any:
        """Delegate to ``super()._execute_respond()``, then emit ``agent.responded``."""
        output = await super()._execute_respond(result)  # type: ignore[misc]
        self._emit(
            "agent.responded",
            {"output_type": type(output).__name__},
        )
        return output

    async def on_error(self, error: Exception, input: Any) -> None:
        """Emit ``agent.errored`` then delegate to ``super().on_error()``."""
        code = getattr(error, "code", type(error).__name__)
        self._emit(
            "agent.errored",
            {
                "error": str(error),
                "error_type": type(error).__name__,
                "code": code,
            },
        )
        await super().on_error(error, input)  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _emit(self, kind: str, payload: dict) -> None:
        """Build and emit a :class:`~event_dispatcher.DispatchEvent`."""
        agent_name: str = getattr(getattr(self, "config", None), "agent_name", "agent")
        session_id: str = getattr(getattr(self, "context", None), "session_id", "")
        turn: int = getattr(getattr(self, "context", None), "turn", 0)

        event = DispatchEvent(
            event_kind=kind,
            source=agent_name,
            correlation_id=session_id,
            payload=payload,
            metadata={"turn": turn},
        )
        self.dispatcher.emit(event)
