"""ToolEnabledMixin — equip any AbstractAgent with dynamically loaded tools.

How it works
------------
``ToolEnabledMixin`` overrides :meth:`setup` and :meth:`teardown` to drive the
:class:`~abstract_agent.integrations.plugin_bridge.PluginBridge` lifecycle::

    setup()     → super().setup()    → bridge.load()   (discover + initialise)
    teardown()  → bridge.unload()    → super().teardown()  (stop all tools)

This means every :meth:`~abstract_agent.agent.AbstractAgent.run` call starts
with a fully populated tool registry and ends with a clean shutdown.

Concrete agents call :meth:`invoke_tool` from inside ``process()`` to run a
tool and include its output in the LLM context::

    class MyAgent(ToolEnabledMixin, AbstractAgent):
        async def process(self, input: str) -> str:
            if self.has_tool("web_search"):
                results = await self.invoke_tool("web_search", input)
                return f"Query: {input}\\nSearch results: {results}"
            return input

        async def respond(self, result: str) -> str:
            return result

Tool discovery
--------------
Tools are discovered from two sources, configured on :class:`AgentConfig`:

* ``tools_dir`` — path to a local ``tools/`` directory.  Every ``.py`` file
  that contains a concrete :class:`~abstract_agent.tools.AbstractAgentTool`
  subclass is imported and registered.
* ``tools_entry_point`` — entry-point group (default
  ``"abstract_agent.tools"``) scanned for installed packages that advertise
  tools.

MRO placement
-------------
Place :class:`ToolEnabledMixin` **before** ``AbstractAgent`` in the base
classes, and **after** other mixins that also override ``setup``/``teardown``
if you want those to run first::

    class MyAgent(CacheableMixin, ToolEnabledMixin, AbstractAgent):
        ...
"""

from __future__ import annotations

from typing import Any, List

from plugin_loader import PluginRecord

from ..integrations.plugin_bridge import PluginBridge


class ToolEnabledMixin:
    """Mixin that gives any :class:`~abstract_agent.agent.AbstractAgent` a tool registry.

    Place it **before** ``AbstractAgent`` in the class bases::

        class MyAgent(ToolEnabledMixin, AbstractAgent):
            async def process(self, input: str) -> str:
                if self.has_tool("calculator"):
                    return await self.invoke_tool("calculator", input)
                return input

            async def respond(self, result: str) -> str:
                return result

    Configure tool discovery in :class:`~abstract_agent.config.AgentConfig`::

        cfg = AgentConfig(
            agent_name="mybot",
            tools_dir="./tools",          # scan local tools/ directory
            tools_entry_point="myapp.tools",  # or a custom entry-point group
        )
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        cfg = getattr(self, "config", None)
        self._tool_bridge: PluginBridge = PluginBridge(cfg)

    # ------------------------------------------------------------------
    # Lifecycle hooks — drive PluginBridge from setup/teardown
    # ------------------------------------------------------------------

    async def setup(self) -> None:
        """Load all tools, then delegate to ``super().setup()``."""
        await self._tool_bridge.load()
        await super().setup()  # type: ignore[misc]

    async def teardown(self) -> None:
        """Unload all tools after ``super().teardown()``."""
        await super().teardown()  # type: ignore[misc]
        await self._tool_bridge.unload()

    # ------------------------------------------------------------------
    # Tool invocation — forwarded to PluginBridge
    # ------------------------------------------------------------------

    async def invoke_tool(self, name: str, input: Any) -> Any:
        """Invoke a registered tool by name.

        Call this from :meth:`~abstract_agent.agent.AbstractAgent.process`
        to run a tool and incorporate its output into the LLM context::

            search_result = await self.invoke_tool("web_search", user_query)
            messages = self.build_messages(
                f"{user_query}\\n\\nContext:\\n{search_result}"
            )

        Args:
            name:  Tool name (``plugin_name`` attribute of the tool class).
            input: Tool-specific input.

        Returns:
            Whatever the tool's ``execute()`` returns.

        Raises:
            RuntimeError:        If called before ``setup()`` (shouldn't
                                 happen when using ``run()``).
            PluginNotFoundError: If no tool named *name* is registered.
        """
        return await self._tool_bridge.invoke_tool(name, input)

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def has_tool(self, name: str) -> bool:
        """Return ``True`` if a tool named *name* is available."""
        return self._tool_bridge.has_tool(name)

    def list_tools(self) -> List[PluginRecord]:
        """Return plugin records for all registered tools."""
        return self._tool_bridge.list_tools()

    def tool_names(self) -> List[str]:
        """Return a list of all registered tool names."""
        return self._tool_bridge.tool_names()
