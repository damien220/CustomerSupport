"""SchedulableMixin — background task scheduling for any AbstractAgent.

How it works
------------
``SchedulableMixin`` wraps ``job_manager.AsyncScheduler`` and ties its
lifecycle to the agent's :meth:`~abstract_agent.agent.AbstractAgent.open`
and :meth:`~abstract_agent.agent.AbstractAgent.close` calls::

    open()   → await scheduler.start_async()
    close()  → await scheduler.shutdown_async(wait=False)

Concrete agents (or their ``process()`` / ``setup()`` methods) enqueue
background work via :meth:`schedule_task`::

    class MyAgent(SchedulableMixin, AbstractAgent):
        async def setup(self) -> None:
            await super().setup()
            self.schedule_task(SummariseMemoryJob(), CronTrigger("0 * * * *"))

        async def process(self, input: str) -> str:
            return input

        async def respond(self, result: str) -> str:
            return result

MRO placement
-------------
Place :class:`SchedulableMixin` **before** ``AbstractAgent``::

    class MyAgent(SchedulableMixin, AbstractAgent):
        ...

Scheduler access
----------------
The underlying :class:`~job_manager.AsyncScheduler` is available as
``self._scheduler`` for advanced use (pausing jobs, adding listeners, etc.).
"""

from __future__ import annotations

from typing import Any, List, Optional

from job_manager import (
    AsyncExecutor,
    AsyncScheduler,
    BaseJob,
    MemoryJobStore,
)
from job_manager.models import JobDescriptor
from job_manager.triggers.base_trigger import BaseTrigger


class SchedulableMixin:
    """Mixin that gives any :class:`~abstract_agent.agent.AbstractAgent` a background task scheduler.

    Place it **before** ``AbstractAgent`` in the class bases::

        class MyAgent(SchedulableMixin, AbstractAgent):
            async def process(self, input: str) -> str:
                # Enqueue a one-off or recurring background job
                self.schedule_task(CleanupJob(), IntervalTrigger(seconds=300))
                return input

            async def respond(self, result: str) -> str:
                return result

    The scheduler starts when :meth:`~abstract_agent.agent.AbstractAgent.open`
    is called (or when entering the async context manager) and shuts down
    gracefully when :meth:`~abstract_agent.agent.AbstractAgent.close` is called.

    Example with async context manager::

        async with MyAgent(cfg) as agent:
            await agent.run("hello")   # scheduler is running here
        # scheduler stopped after __aexit__
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        store = MemoryJobStore()
        executor = AsyncExecutor()
        self._scheduler: AsyncScheduler = AsyncScheduler(store, executor)

    # ------------------------------------------------------------------
    # Connection lifecycle — start/stop the scheduler with the agent
    # ------------------------------------------------------------------

    async def open(self) -> None:
        """Start the background scheduler, then call ``super().open()``."""
        await self._scheduler.start_async()
        await super().open()  # type: ignore[misc]

    async def close(self) -> None:
        """Call ``super().close()``, then shut the scheduler down."""
        await super().close()  # type: ignore[misc]
        await self._scheduler.shutdown_async(wait=False)

    # ------------------------------------------------------------------
    # Public scheduling API
    # ------------------------------------------------------------------

    def schedule_task(
        self,
        job: BaseJob,
        trigger: BaseTrigger,
        *,
        job_id: Optional[str] = None,
        name: Optional[str] = None,
        parameters: Optional[dict] = None,
    ) -> str:
        """Enqueue a background job to run on the given trigger schedule.

        Args:
            job:        A :class:`~job_manager.BaseJob` subclass instance
                        defining the work to perform.
            trigger:    When to run — e.g.
                        :class:`~job_manager.IntervalTrigger`,
                        :class:`~job_manager.CronTrigger`, or
                        :class:`~job_manager.ImmediateTrigger`.
            job_id:     Optional stable identifier; auto-generated if omitted.
            name:       Human-readable name for logs and dashboards.
            parameters: Extra key/value pairs forwarded to
                        :class:`~job_manager.JobContext`.

        Returns:
            The job ID string (useful for later :meth:`remove_task` calls).

        Example::

            self.schedule_task(
                SummariseMemoryJob(),
                CronTrigger("0 * * * *"),   # every hour on the hour
                name="hourly-summarise",
            )
        """
        return self._scheduler.add_job(
            job,
            trigger,
            job_id=job_id,
            name=name,
            parameters=parameters,
        )

    def remove_task(self, job_id: str) -> None:
        """Unregister a previously scheduled job by its ID.

        Args:
            job_id: The identifier returned by :meth:`schedule_task`.
        """
        self._scheduler.remove_job(job_id)

    def scheduled_jobs(self) -> List[JobDescriptor]:
        """Return descriptors for all currently scheduled jobs."""
        return self._scheduler.get_all_jobs()

    def scheduled_job_ids(self) -> List[str]:
        """Return the IDs of all currently scheduled jobs."""
        return [d.job_id for d in self.scheduled_jobs()]
