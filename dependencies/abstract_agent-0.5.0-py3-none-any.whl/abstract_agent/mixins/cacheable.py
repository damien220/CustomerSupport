"""CacheableMixin — transparently cache LLM responses between ``process()`` calls.

How it works
------------
``AbstractAgent.run()`` calls ``self._execute_process(input)`` instead of
``self.process(input)`` directly.  ``CacheableMixin`` overrides
``_execute_process()`` via MRO and wraps it with a cache check::

    class MyAgent(CacheableMixin, AbstractAgent):
        async def process(self, input: str) -> dict:
            ...          # only called on cache miss

The MRO for ``MyAgent`` is ``MyAgent → CacheableMixin → AbstractAgent``, so
when ``run()`` calls ``self._execute_process(input)``:

1. ``CacheableMixin._execute_process()`` is found first.
2. On hit  → return cached ``LLMCacheEntry.response`` (+ record savings).
3. On miss → call ``super()._execute_process(input)`` which delegates to
   ``AbstractAgent._execute_process()`` → ``self.process(input)``
   (the concrete agent's implementation).
4. Store the fresh result before returning.

Cache key
---------
Built by ``LLMCacheKeyBuilder`` from ``(model, messages, temperature,
max_tokens)``.  Override ``_get_cache_key_params()`` to customise.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from cache_manager.llm.entry import LLMCacheEntry
from cache_manager.llm.key_builder import LLMCacheKeyBuilder
from cache_manager.llm.token_tracker import TokenTracker
from cache_manager.types import CacheStats

from ..integrations.cache import build_cache_from_config


def _extract_token_counts(result: Any) -> tuple[int, int]:
    """Best-effort extraction of (input_tokens, output_tokens) from an LLM response."""
    if isinstance(result, dict):
        usage = result.get("usage", {})
        inp = usage.get("input_tokens", usage.get("prompt_tokens", 0))
        out = usage.get("output_tokens", usage.get("completion_tokens", 0))
        return int(inp), int(out)
    usage = getattr(result, "usage", None)
    if usage is not None:
        inp = getattr(usage, "input_tokens", getattr(usage, "prompt_tokens", 0))
        out = getattr(usage, "output_tokens", getattr(usage, "completion_tokens", 0))
        return int(inp), int(out)
    return 0, 0


class CacheableMixin:
    """Mixin that adds transparent LLM response caching to any ``AbstractAgent``.

    Place it **before** ``AbstractAgent`` in the class bases::

        class ChatAgent(CacheableMixin, AbstractAgent):
            async def process(self, input: str) -> dict:
                messages = self.build_messages(input)
                response = await self.api_client.post(
                    "/chat/completions",
                    json={"model": self.config.model, "messages": messages},
                )
                return response.body

            async def respond(self, result: dict) -> str:
                return result["choices"][0]["message"]["content"]

    Enable caching via ``AgentConfig``::

        cfg = AgentConfig(
            model="gpt-4o",
            cache_config=CacheConfig(
                enabled=True,
                backend="memory",
                ttl=3600,
            ),
        )
        agent = ChatAgent(cfg, api_client=client)

    Inspect savings::

        stats = agent.get_cache_stats()    # CacheStats (hits, misses, …)
        saved = agent.token_tracker.tokens_saved
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

        cfg = getattr(self, "config", None)
        cache_cfg = getattr(cfg, "cache_config", None)

        # Always create a token tracker so it is accessible even when disabled.
        self.token_tracker: TokenTracker = TokenTracker()

        if cache_cfg is not None and cache_cfg.enabled:
            self._cache = build_cache_from_config(cache_cfg)
            self._key_builder: Optional[LLMCacheKeyBuilder] = LLMCacheKeyBuilder(
                prefix=cache_cfg.namespace
            )
        else:
            self._cache = None
            self._key_builder = None

    # ------------------------------------------------------------------
    # MRO interception point
    # ------------------------------------------------------------------

    async def _execute_process(self, input: Any) -> Any:
        """Intercept ``_execute_process`` to add a cache layer.

        Falls through to ``super()._execute_process(input)`` (i.e.
        ``AbstractAgent._execute_process`` → ``self.process``) on cache miss.
        """
        if self._cache is None or self._key_builder is None:
            # Cache disabled — pass straight through.
            return await super()._execute_process(input)  # type: ignore[misc]

        params = self._get_cache_key_params(input)
        key = self._key_builder.build_key(**params)

        # --- Cache hit ---
        cached = self._cache.get(key)
        if cached is not None:
            if isinstance(cached, LLMCacheEntry):
                self.token_tracker.record_saving(
                    cached.input_tokens,
                    cached.output_tokens,
                    cached.estimated_cost,
                )
                return cached.response
            # Raw value stored by an earlier serializer
            return cached

        # --- Cache miss: call the real process() ---
        result = await super()._execute_process(input)  # type: ignore[misc]

        # Store with token metadata
        in_tok, out_tok = _extract_token_counts(result)
        model = getattr(getattr(self, "config", None), "model", "unknown")
        cost = self.token_tracker.estimate_cost(model, in_tok, out_tok)

        entry = LLMCacheEntry(
            response=result,
            model=model,
            input_tokens=in_tok,
            output_tokens=out_tok,
            estimated_cost=cost,
        )
        ttl = getattr(getattr(self, "config", None).cache_config, "ttl", 3600)
        self._cache.set(key, entry, ttl=ttl)
        return result

    # ------------------------------------------------------------------
    # Key builder hook — override to customise per-agent
    # ------------------------------------------------------------------

    def _get_cache_key_params(self, input: Any) -> Dict[str, Any]:
        """Extract cache-key parameters from the raw ``process()`` input.

        Default behaviour:

        * ``list`` input → treated as a messages array.
        * ``dict`` with ``"messages"`` key → unpacked directly.
        * Anything else → wrapped as ``[{"role": "user", "content": str(input)}]``.

        Override this method to customise key construction, e.g. to strip
        volatile metadata fields before hashing.

        Args:
            input: The value received by ``run()``.

        Returns:
            Dict of LLM call parameters for ``LLMCacheKeyBuilder.build_key()``.
        """
        cfg = getattr(self, "config", None)
        model = getattr(cfg, "model", "unknown")
        temperature = getattr(cfg, "temperature", 0.0)
        max_tokens = getattr(cfg, "max_tokens", None)

        if isinstance(input, list):
            messages = input
        elif isinstance(input, dict) and "messages" in input:
            messages = input["messages"]
            model = input.get("model", model)
        else:
            messages = [{"role": "user", "content": str(input)}]

        params: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        return params

    # ------------------------------------------------------------------
    # Observability helpers
    # ------------------------------------------------------------------

    def get_cache_stats(self) -> Optional[CacheStats]:
        """Return accumulated cache statistics, or ``None`` if disabled."""
        if self._cache is None:
            return None
        return self._cache.get_stats()

    def invalidate_cache(self, namespace: Optional[str] = None) -> int:
        """Clear the cache, optionally scoped to *namespace*.

        Args:
            namespace: Key prefix to clear.  ``None`` clears everything.

        Returns:
            Number of entries removed, or ``0`` if cache is disabled.
        """
        if self._cache is None:
            return 0
        return self._cache.clear(namespace)
