"""Optional mixins that augment ``AbstractAgent`` with cross-cutting capabilities.

Compose them before ``AbstractAgent`` in the MRO::

    class MyAgent(CacheableMixin, ObservableMixin, ToolEnabledMixin, SchedulableMixin, AbstractAgent):
        ...
"""

from .cacheable import CacheableMixin
from .observable import ObservableMixin
from .schedulable import SchedulableMixin
from .tool_enabled import ToolEnabledMixin

__all__ = ["CacheableMixin", "ObservableMixin", "SchedulableMixin", "ToolEnabledMixin"]
