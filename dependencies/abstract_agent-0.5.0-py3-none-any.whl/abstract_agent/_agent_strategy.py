"""AbstractAgentConfigStrategy — config_manager strategy for agent projects.

Registered under the ``"abstract_agent"`` app type key so the
``ConfigManagerFactory`` can scaffold agent-specific config files.
"""

from __future__ import annotations

from src.strategies.base import (
    ConfigFormat,
    ConfigRecommendation,
    ConfigStrategy,
    SecretsHandling,
    TemplateFile,
    UserOptions,
    ValidationMode,
)


class AbstractAgentConfigStrategy(ConfigStrategy):
    """Config scaffolding strategy for ``abstract_agent`` projects.

    Default layout (``target_dir/``)::

        config/agent.yaml      — main agent settings (YAML)
        .env.example           — secret placeholders (.env template)
        src/config.py          — Python config loader (when lang=python)

    The generated YAML carries agent-specific sections:
    ``agent``, ``memory``, ``cache``, ``api``, and ``logging``.
    """

    def get_recommendation(self) -> ConfigRecommendation:
        return ConfigRecommendation(
            app_type="abstract_agent",
            display_name="Abstract Agent (AI Agent Project)",
            primary_format=ConfigFormat.YAML,
            secondary_formats=[ConfigFormat.ENV],
            files=["config/agent.yaml", ".env.example"],
            needs_profiles=True,
            needs_secrets=True,
            validation=ValidationMode.STRICT,
            description=(
                "YAML config + .env template for an AI agent with LLM API, "
                "persistent memory, and optional response caching."
            ),
        )

    def get_template_files(self, options: UserOptions) -> list[TemplateFile]:
        files: list[TemplateFile] = [
            TemplateFile("config_files/yaml/default.yaml.j2", "config/agent.yaml"),
        ]
        if options.secrets != SecretsHandling.NONE:
            files.append(
                TemplateFile("config_files/env/env_example.j2", ".env.example")
            )
        if options.language == "python":
            files.append(
                TemplateFile("loaders/python/config_loader.py.j2", "src/config.py")
            )
        return files

    def get_context(self, options: UserOptions) -> dict:
        return {
            # Generic fields expected by the shared templates
            "app_name": "my_agent",
            "app_type": "abstract_agent",
            "primary_format": "yaml",
            "language": options.language,
            "profiles": options.profiles,
            "secrets": options.secrets.value,
            "validation": options.validation.value,
            "env_prefix": "AGENT",
            "database": True,
            "cors": False,
            # Agent-specific sections surfaced as template variables
            "agent_name": "my_agent",
            "model": "gpt-4o",
            "max_tokens": 4096,
            "temperature": 0.7,
            "memory_backend": "in_memory",
            "cache_enabled": False,
            "cache_backend": "memory",
            "cache_ttl": 3600,
            "log_level": "INFO",
            "log_format": "console",
        }
