"""PluginBridge — tool registry lifecycle manager for AbstractAgent.

Responsibilities
----------------
* **Discovery** — scans the agent's local ``tools/`` directory via
  :class:`~plugin_loader.DirectoryStrategy` and any installed packages that
  advertise tools via the ``"abstract_agent.tools"`` entry-point group.
* **Lifecycle** — ``load()`` discovers and initialises all tools;
  ``unload()`` stops them cleanly.
* **Invocation** — ``invoke_tool(name, input)`` calls a tool's
  :meth:`~abstract_agent.tools.AbstractAgentTool.execute` method, wrapped in
  a :class:`~plugin_loader.PluginSandbox` so a misbehaving tool cannot crash
  the hosting agent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from plugin_loader import (
    CompositeStrategy,
    DirectoryStrategy,
    EntryPointStrategy,
    ErrorPolicy,
    PluginManager,
    PluginManagerConfig,
    PluginRecord,
    PluginSandbox,
)
from plugin_loader.exceptions import PluginNotFoundError  # noqa: F401 (re-exported)

from ..tools import AbstractAgentTool

if TYPE_CHECKING:
    from ..config import AgentConfig


class PluginBridge:
    """Manages the tool plugin registry for one agent instance.

    Instantiated by :class:`~abstract_agent.mixins.ToolEnabledMixin` during
    ``__init__`` and driven through :meth:`load` / :meth:`unload` from the
    agent's :meth:`~abstract_agent.agent.AbstractAgent.setup` and
    :meth:`~abstract_agent.agent.AbstractAgent.teardown` hooks.

    Args:
        config: Agent configuration supplying ``tools_dir`` and
                ``tools_entry_point``.
    """

    #: Default entry-point group scanned for installed tool packages.
    ENTRY_POINT_GROUP: str = "abstract_agent.tools"

    def __init__(self, config: AgentConfig) -> None:
        self._config = config
        self._manager: Optional[PluginManager] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def load(self) -> None:
        """Discover and initialise all tools.

        Builds a :class:`~plugin_loader.PluginManager` with a
        :class:`~plugin_loader.CompositeStrategy` combining:

        * :class:`~plugin_loader.DirectoryStrategy` scanning ``config.tools_dir``
          (skipped when the field is empty or absent).
        * :class:`~plugin_loader.EntryPointStrategy` scanning
          ``config.tools_entry_point`` (defaults to
          ``"abstract_agent.tools"``).

        After discovery, ``initialize_all()`` is called so every tool
        receives its :meth:`~abstract_agent.tools.AbstractAgentTool.initialize`
        call before the agent's ``process()`` can use it.

        Called automatically by :class:`~abstract_agent.mixins.ToolEnabledMixin`
        from :meth:`~abstract_agent.agent.AbstractAgent.setup`.
        """
        pm_config = PluginManagerConfig(
            auto_initialize=True,
            auto_start=False,
            error_policy="suppress",
            strict_validation=False,
            log_lifecycle=True,
        )
        self._manager = PluginManager(pm_config)

        strategies = []
        tools_dir: str = getattr(self._config, "tools_dir", "")
        ep_group: str = getattr(
            self._config, "tools_entry_point", self.ENTRY_POINT_GROUP
        )

        if tools_dir:
            strategies.append(
                DirectoryStrategy(
                    tools_dir,
                    base_class=AbstractAgentTool,
                    recursive=False,
                )
            )

        if ep_group:
            strategies.append(
                EntryPointStrategy(
                    ep_group,
                    base_class=AbstractAgentTool,
                )
            )

        if strategies:
            composite = CompositeStrategy(strategies)
            self._manager.add_discovery_strategy(composite)
            await self._manager.discover_async()

        await self._manager.initialize_all()

    async def unload(self) -> None:
        """Stop all active tools and release the registry.

        Calls ``stop_all()`` on the underlying :class:`~plugin_loader.PluginManager`
        and then discards the reference so subsequent :meth:`load` calls start
        fresh.

        Called automatically by :class:`~abstract_agent.mixins.ToolEnabledMixin`
        from :meth:`~abstract_agent.agent.AbstractAgent.teardown`.
        """
        if self._manager is not None:
            await self._manager.stop_all()
            self._manager = None

    # ------------------------------------------------------------------
    # Tool invocation
    # ------------------------------------------------------------------

    async def invoke_tool(self, name: str, input: Any) -> Any:
        """Invoke a registered tool by name.

        The call is wrapped in a :class:`~plugin_loader.PluginSandbox` with
        ``ErrorPolicy.RAISE`` so that errors inside the tool propagate back to
        the agent's ``process()`` method (where they can be caught and handled
        or forwarded to the LLM as context).

        Args:
            name:  Tool name — must match the tool's ``plugin_name`` attribute.
            input: Tool-specific input value (string, dict, or any type the
                   tool's :meth:`~abstract_agent.tools.AbstractAgentTool.execute`
                   accepts).

        Returns:
            Whatever the tool's ``execute()`` method returns.

        Raises:
            RuntimeError:        If :meth:`load` has not been called yet.
            PluginNotFoundError: If no tool named *name* is registered.
        """
        if self._manager is None:
            raise RuntimeError(
                "PluginBridge is not loaded. "
                "Call load() first or use ToolEnabledMixin (which calls it in setup())."
            )

        instance: AbstractAgentTool = self._manager.get_plugin(name)
        record = self._manager.get_record(name)
        sandbox = PluginSandbox(ErrorPolicy.PROPAGATE, record)

        result: Any = None
        async with sandbox.safe_execute_async(f"execute:{name}"):
            result = await instance.execute(input)

        return result

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def list_tools(self) -> List[PluginRecord]:
        """Return :class:`~plugin_loader.PluginRecord` objects for all tools.

        Returns an empty list when the bridge is not loaded.
        """
        if self._manager is None:
            return []
        return self._manager.list_plugins()

    def has_tool(self, name: str) -> bool:
        """Return ``True`` if a tool named *name* is registered and available."""
        if self._manager is None:
            return False
        return self._manager.has_plugin(name)

    def tool_names(self) -> List[str]:
        """Return the names of all currently registered tools."""
        return [r.plugin_name for r in self.list_tools()]
