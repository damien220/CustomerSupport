"""error_exception_handler integration — normalise agent errors.

Wraps ``ErrorHandler.handle()`` with agent-specific context so the rest of
the package never imports ``error_handler`` directly.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from error_handler import ErrorHandler
from error_handler.types import HandlerResult

from ..exceptions import AgentException


def handle_agent_error(
    error: Exception,
    *,
    agent_name: str = "agent",
    session_id: Optional[str] = None,
    turn: Optional[int] = None,
) -> HandlerResult:
    """Normalise *error* into a structured ``HandlerResult``.

    If *error* is already an ``AgentException`` (or any
    ``BaseAppException``) it is passed through unchanged.  Any other
    exception is wrapped in an ``AgentException`` first so the returned
    body always has a consistent shape.

    Args:
        error:      The exception to normalise.
        agent_name: Name of the agent — injected into ``details``.
        session_id: Current session ID — injected into ``details`` if given.
        turn:       Current turn number — injected into ``details`` if given.

    Returns:
        ``HandlerResult`` with ``status_code`` and a structured ``body``.
    """
    if not isinstance(error, AgentException):
        extra: Dict[str, Any] = {"agent": agent_name}
        if session_id is not None:
            extra["session_id"] = session_id
        if turn is not None:
            extra["turn"] = turn
        error = AgentException(
            str(error) or "An unexpected agent error occurred",
            details=extra,
            previous=error,
        )
    return ErrorHandler.handle(error)


__all__ = ["handle_agent_error"]
