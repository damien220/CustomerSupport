"""cache_manager integration — build and configure cache backends for the agent.

Provides ``build_cache_from_config()`` so the rest of the package never
imports ``cache_manager`` directly, keeping the dependency easy to swap.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cache_manager import AbstractCache, get_cache

if TYPE_CHECKING:
    from ..config import CacheConfig


def build_cache_from_config(config: CacheConfig) -> AbstractCache:
    """Construct a ``cache_manager`` backend from a ``CacheConfig``.

    Args:
        config: The agent's ``CacheConfig`` instance.

    Returns:
        A ready-to-use ``AbstractCache`` instance (already initialised —
        no separate ``connect()`` call required for ``memory`` and ``file``
        backends).
    """
    kwargs: dict = {}

    if config.max_size is not None:
        kwargs["max_size"] = config.max_size
    if config.ttl is not None:
        kwargs["default_ttl"] = config.ttl

    if config.backend == "sqlite":
        kwargs["db_path"] = config.sqlite_path

    elif config.backend == "redis":
        kwargs["host"] = config.redis_host
        kwargs["port"] = config.redis_port
        if config.redis_password:
            kwargs["password"] = config.redis_password

    elif config.backend == "file":
        kwargs["cache_dir"] = config.file_cache_dir

    return get_cache(config.backend, **kwargs)


__all__ = ["build_cache_from_config"]
