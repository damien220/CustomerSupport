"""Integration bridges between abstract_agent and its dependency packages."""
