"""AgentNotifier — bridge between agent lifecycle events and notification channels.

``AgentNotifier`` subscribes to :class:`~event_dispatcher.LocalDispatcher`
events emitted by :class:`~abstract_agent.mixins.ObservableMixin` and routes
them through :class:`~notification_manager.NotificationManager` to whatever
delivery channels are configured (console, email, Slack, webhook, …).

Typical usage
-------------
Build an ``AgentNotifier`` and attach it to an :class:`ObservableMixin` agent::

    from abstract_agent.integrations.notifier import AgentNotifier, build_notifier_from_config

    class MyAgent(ObservableMixin, AbstractAgent):
        ...

    agent = MyAgent(cfg)
    notifier = build_notifier_from_config(cfg, agent.dispatcher)
    notifier.attach()   # subscribe to agent.errored (and optionally agent.responded)

    await agent.run("hello")

The :func:`build_notifier_from_config` factory creates a
:class:`~notification_manager.NotificationManager` backed by the channel
configured in ``AgentConfig.notification_config`` (defaults to
:class:`~notification_manager.example_plugin.ConsolePlugin`).
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, List, Optional

from notification_manager import NotificationManager, PluginRegistry
from notification_manager.example_plugin import ConsolePlugin
from notification_manager.models import Notification, Priority, Recipient
from notification_manager.models.notification import NotificationStatus

from event_dispatcher import DispatchEvent, LocalDispatcher

if TYPE_CHECKING:
    from ..config import AgentConfig, NotificationConfig


class AgentNotifier:
    """Subscribes to agent lifecycle events and delivers notifications.

    Args:
        dispatcher:           The :class:`~event_dispatcher.LocalDispatcher`
                              owned by :class:`~abstract_agent.mixins.ObservableMixin`.
        notification_manager: Pre-built :class:`~notification_manager.NotificationManager`
                              for delivery.
        recipient:            Default :class:`~notification_manager.models.Recipient`
                              for all notifications.
        agent_name:           Used as the notification title prefix.
    """

    def __init__(
        self,
        dispatcher: LocalDispatcher,
        notification_manager: NotificationManager,
        recipient: Recipient,
        *,
        agent_name: str = "agent",
    ) -> None:
        self._dispatcher = dispatcher
        self._notification_manager = notification_manager
        self._recipient = recipient
        self._agent_name = agent_name
        self._subscriptions: List[Any] = []

    # ------------------------------------------------------------------
    # Attach / detach
    # ------------------------------------------------------------------

    def attach(
        self,
        *,
        on_error: bool = True,
        on_responded: bool = False,
    ) -> None:
        """Subscribe to agent events.

        Args:
            on_error:     Subscribe to ``"agent.errored"`` (default ``True``).
            on_responded: Subscribe to ``"agent.responded"`` (default ``False``).
        """
        if on_error:
            sub = self._dispatcher.subscribe("agent.errored", self._on_error)
            self._subscriptions.append(sub)
        if on_responded:
            sub = self._dispatcher.subscribe("agent.responded", self._on_responded)
            self._subscriptions.append(sub)

    def detach(self) -> None:
        """Unsubscribe all handlers registered by :meth:`attach`."""
        for sub in self._subscriptions:
            self._dispatcher.unsubscribe(sub)
        self._subscriptions.clear()

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _on_error(self, event: DispatchEvent) -> None:
        """Handler for ``agent.errored`` events."""
        error_msg = event.payload.get("error", "Unknown error")
        error_type = event.payload.get("error_type", "Exception")
        turn = event.metadata.get("turn", "?")

        notification = Notification(
            title=f"[{self._agent_name}] Error on turn {turn}: {error_type}",
            body=error_msg,
            recipient=self._recipient,
            priority=Priority.HIGH,
            metadata={
                "agent": self._agent_name,
                "session_id": event.correlation_id or "",
                "turn": turn,
                "error_type": error_type,
            },
        )
        self._send(notification)

    def _on_responded(self, event: DispatchEvent) -> None:
        """Handler for ``agent.responded`` events."""
        output_type = event.payload.get("output_type", "unknown")
        turn = event.metadata.get("turn", "?")

        notification = Notification(
            title=f"[{self._agent_name}] Responded on turn {turn}",
            body=f"Output type: {output_type}",
            recipient=self._recipient,
            priority=Priority.LOW,
            metadata={
                "agent": self._agent_name,
                "session_id": event.correlation_id or "",
                "turn": turn,
            },
        )
        self._send(notification)

    # ------------------------------------------------------------------
    # Delivery helper
    # ------------------------------------------------------------------

    def _send(self, notification: Notification) -> None:
        """Fire-and-forget delivery: schedules the coroutine on the running loop.

        Falls back to a synchronous no-op when no event loop is running
        (e.g. during unit tests without asyncio).
        """
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self._notification_manager.send(notification))
            else:
                loop.run_until_complete(self._notification_manager.send(notification))
        except RuntimeError:
            pass


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_notifier_from_config(
    config: AgentConfig,
    dispatcher: LocalDispatcher,
) -> AgentNotifier:
    """Build an :class:`AgentNotifier` from ``AgentConfig.notification_config``.

    Creates a :class:`~notification_manager.NotificationManager` backed by
    the channel plugin specified in the notification config (defaults to
    :class:`~notification_manager.example_plugin.ConsolePlugin`).

    Args:
        config:     Agent configuration.
        dispatcher: The dispatcher owned by the :class:`~abstract_agent.mixins.ObservableMixin`
                    agent (``agent.dispatcher``).

    Returns:
        A ready-to-use :class:`AgentNotifier` (call :meth:`~AgentNotifier.attach`
        to start subscribing).
    """
    notif_cfg = getattr(config, "notification_config", None)
    recipient_id: str = getattr(notif_cfg, "recipient_id", "agent-admin")
    recipient_channels: list = getattr(notif_cfg, "recipient_channels", [])

    registry = PluginRegistry()
    registry.register("console", ConsolePlugin())
    nm = NotificationManager(registry)

    recipient = Recipient(
        id=recipient_id,
        channels=recipient_channels or ["console"],
    )

    return AgentNotifier(
        dispatcher=dispatcher,
        notification_manager=nm,
        recipient=recipient,
        agent_name=config.agent_name,
    )
