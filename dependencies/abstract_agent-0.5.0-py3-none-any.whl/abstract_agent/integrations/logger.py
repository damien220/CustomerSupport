"""logger_pkg integration — configure and vend loggers for agent use.

Wraps ``logger_pkg.setup_logging`` and ``logger_pkg.get_logger`` so the
rest of the package never imports ``logger_pkg`` directly, making the
dependency easy to swap in tests.
"""

from __future__ import annotations

import logging
import logging.handlers
from typing import Optional

from logger_pkg import bind_context, build_config, get_logger, reset_context, setup_logging
from logger_pkg.context import bound_context  # re-exported for agent use

from ..config import AgentConfig


def configure_agent_logging(
    config: AgentConfig,
) -> Optional[logging.handlers.QueueListener]:
    """Set up the ``logger_pkg`` pipeline for *config*.

    Called once during ``AbstractAgent.__init__``.  Returns the
    ``QueueListener`` if async queuing is enabled so the agent can stop it
    cleanly in ``teardown()``.

    Args:
        config: The agent's ``AgentConfig`` instance.

    Returns:
        ``QueueListener`` if the async queue is enabled, else ``None``.
    """
    log_cfg = build_config(
        level=config.log_level,
        format=config.log_format,
        async_queue_enabled=True,
        extra_fields={"agent": config.agent_name, **config.metadata},
    )
    return setup_logging(config=log_cfg, logger_name=f"abstract_agent.{config.agent_name}")


def get_agent_logger(agent_name: str) -> logging.Logger:
    """Return the logger for *agent_name*.

    Args:
        agent_name: The value of ``AgentConfig.agent_name``.

    Returns:
        A standard ``logging.Logger`` pre-scoped to the agent namespace.
    """
    return get_logger(f"abstract_agent.{agent_name}")


# Re-export context helpers so callers only need to import from this module.
__all__ = [
    "bind_context",
    "bound_context",
    "reset_context",
    "configure_agent_logging",
    "get_agent_logger",
]
