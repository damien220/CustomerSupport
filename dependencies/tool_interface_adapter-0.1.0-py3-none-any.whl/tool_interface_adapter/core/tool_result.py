"""Normalized execution output for tool calls."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolError:
    """Structured error attached to a failed :class:`ToolResult`."""

    code: str
    message: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.details:
            result["details"] = self.details
        return result


@dataclass
class ToolResult:
    """Normalized output returned by every tool execution.

    Attributes:
        success: Whether the execution completed without error.
        data: The tool's return value (arbitrary).
        error: Structured error information when ``success`` is ``False``.
        duration_ms: Wall-clock execution time in milliseconds.
        metadata: Adapter-specific extras (token count, cost, etc.).
        cached: ``True`` when the result was served from cache.
    """

    success: bool
    data: Any = None
    error: ToolError | None = None
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    cached: bool = False

    # ── Convenience factories ───────────────────────────────────────────

    @classmethod
    def ok(cls, data: Any, *, duration_ms: float = 0.0, **metadata: Any) -> ToolResult:
        """Create a successful result."""
        return cls(success=True, data=data, duration_ms=duration_ms, metadata=metadata)

    @classmethod
    def fail(
        cls,
        code: str,
        message: str,
        *,
        details: dict[str, Any] | None = None,
        duration_ms: float = 0.0,
    ) -> ToolResult:
        """Create a failed result."""
        return cls(
            success=False,
            error=ToolError(code=code, message=message, details=details or {}),
            duration_ms=duration_ms,
        )
