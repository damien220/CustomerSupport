"""Abstract base class for provider-specific adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from ..types.configs import AdapterConfig
from .tool_spec import ToolSpec


@dataclass
class AdapterRequest:
    """Normalised request object sent to an adapter's :pymeth:`send`."""

    method: str = "POST"
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)
    body: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AdapterResponse:
    """Normalised response returned by an adapter's :pymeth:`send`."""

    status_code: int = 200
    headers: dict[str, str] = field(default_factory=dict)
    body: Any = None
    raw: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 400


class AbstractAdapter(ABC):
    """Translates between the unified tool interface and a specific provider.

    Subclasses implement the five abstract methods to handle a single
    external service.  The adapter lifecycle is:

    1. :pymeth:`connect` — authenticate / open connections.
    2. :pymeth:`translate_request` → :pymeth:`send` → :pymeth:`translate_response`
       (repeated per tool call).
    3. :pymeth:`disconnect` — release resources.
    """

    def __init__(self, config: AdapterConfig | None = None) -> None:
        self._config = config or AdapterConfig()
        self._connected: bool = False

    # ── Lifecycle ───────────────────────────────────────────────────────

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection / authenticate with the provider."""
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        """Release connection resources."""
        ...

    # ── Request / Response ──────────────────────────────────────────────

    @abstractmethod
    async def send(self, request: AdapterRequest) -> AdapterResponse:
        """Send a normalised request and return a normalised response."""
        ...

    @abstractmethod
    def translate_request(
        self, params: dict[str, Any], spec: ToolSpec
    ) -> AdapterRequest:
        """Convert tool parameters into a provider-specific request."""
        ...

    @abstractmethod
    def translate_response(
        self, response: AdapterResponse, spec: ToolSpec
    ) -> Any:
        """Convert a provider response into the tool's normalised output."""
        ...

    # ── Properties ──────────────────────────────────────────────────────

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def config(self) -> AdapterConfig:
        return self._config

    # ── Context manager ─────────────────────────────────────────────────

    async def __aenter__(self) -> AbstractAdapter:
        await self.connect()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.disconnect()

    def __repr__(self) -> str:
        return f"<{type(self).__name__} connected={self._connected}>"
