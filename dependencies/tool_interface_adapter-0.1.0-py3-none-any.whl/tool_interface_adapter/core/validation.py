"""JSON Schema-based input / output validation.

This module provides a lightweight JSON Schema validator that covers
the most common schema keywords without requiring an external library
like ``jsonschema``.  It handles: ``type``, ``required``, ``properties``,
``items``, ``enum``, ``minimum``/``maximum``, ``minLength``/``maxLength``,
``minItems``/``maxItems``, ``pattern``, ``additionalProperties``,
``anyOf``, ``oneOf``, and ``allOf``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

_JSON_TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
    "null": type(None),
}


@dataclass
class ValidationResult:
    """Outcome of a validation check."""

    valid: bool = True
    errors: list[str] = field(default_factory=list)

    def add_error(self, message: str) -> None:
        self.valid = False
        self.errors.append(message)

    def merge(self, other: ValidationResult) -> None:
        if not other.valid:
            self.valid = False
            self.errors.extend(other.errors)


class SchemaValidator:
    """Validate a value against a JSON Schema dict.

    This is intentionally lightweight — it covers the subset of JSON Schema
    that is useful for tool parameter validation, not the full spec.
    """

    def validate(self, value: Any, schema: dict[str, Any], path: str = "$") -> ValidationResult:
        result = ValidationResult()

        if not schema:
            return result

        # ── type ────────────────────────────────────────────────────────
        expected_type = schema.get("type")
        if expected_type:
            if isinstance(expected_type, list):
                py_types = tuple(
                    t for name in expected_type for t in ((_JSON_TYPE_MAP[name],) if isinstance(_JSON_TYPE_MAP[name], type) else _JSON_TYPE_MAP[name])
                )
                # bool must not match "integer" / "number"
                if isinstance(value, bool) and "boolean" not in expected_type:
                    result.add_error(f"{path}: expected type {expected_type}, got bool")
                    return result
                if not isinstance(value, py_types):
                    result.add_error(f"{path}: expected type {expected_type}, got {type(value).__name__}")
                    return result
            else:
                # bool is a subclass of int — reject it for integer/number
                if isinstance(value, bool) and expected_type in ("integer", "number"):
                    result.add_error(f"{path}: expected type {expected_type}, got bool")
                    return result
                py_type = _JSON_TYPE_MAP.get(expected_type)
                if py_type is not None and not isinstance(value, py_type):
                    result.add_error(f"{path}: expected type {expected_type}, got {type(value).__name__}")
                    return result

        # ── enum ────────────────────────────────────────────────────────
        if "enum" in schema and value not in schema["enum"]:
            result.add_error(f"{path}: value {value!r} not in enum {schema['enum']}")

        # ── string constraints ──────────────────────────────────────────
        if isinstance(value, str):
            if "minLength" in schema and len(value) < schema["minLength"]:
                result.add_error(f"{path}: string length {len(value)} < minLength {schema['minLength']}")
            if "maxLength" in schema and len(value) > schema["maxLength"]:
                result.add_error(f"{path}: string length {len(value)} > maxLength {schema['maxLength']}")
            if "pattern" in schema and not re.search(schema["pattern"], value):
                result.add_error(f"{path}: string does not match pattern {schema['pattern']!r}")

        # ── numeric constraints ─────────────────────────────────────────
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in schema and value < schema["minimum"]:
                result.add_error(f"{path}: value {value} < minimum {schema['minimum']}")
            if "maximum" in schema and value > schema["maximum"]:
                result.add_error(f"{path}: value {value} > maximum {schema['maximum']}")
            if "exclusiveMinimum" in schema and value <= schema["exclusiveMinimum"]:
                result.add_error(f"{path}: value {value} <= exclusiveMinimum {schema['exclusiveMinimum']}")
            if "exclusiveMaximum" in schema and value >= schema["exclusiveMaximum"]:
                result.add_error(f"{path}: value {value} >= exclusiveMaximum {schema['exclusiveMaximum']}")

        # ── object constraints ──────────────────────────────────────────
        if isinstance(value, dict):
            # required
            for req in schema.get("required", []):
                if req not in value:
                    result.add_error(f"{path}: missing required property '{req}'")

            # properties
            props = schema.get("properties", {})
            for prop_name, prop_schema in props.items():
                if prop_name in value:
                    result.merge(self.validate(value[prop_name], prop_schema, f"{path}.{prop_name}"))

            # additionalProperties
            additional = schema.get("additionalProperties")
            if additional is False:
                extra = set(value.keys()) - set(props.keys())
                if extra:
                    result.add_error(f"{path}: unexpected properties {extra}")

        # ── array constraints ───────────────────────────────────────────
        if isinstance(value, list):
            if "minItems" in schema and len(value) < schema["minItems"]:
                result.add_error(f"{path}: array length {len(value)} < minItems {schema['minItems']}")
            if "maxItems" in schema and len(value) > schema["maxItems"]:
                result.add_error(f"{path}: array length {len(value)} > maxItems {schema['maxItems']}")
            items_schema = schema.get("items")
            if items_schema:
                for i, item in enumerate(value):
                    result.merge(self.validate(item, items_schema, f"{path}[{i}]"))

        # ── composition keywords ────────────────────────────────────────
        if "anyOf" in schema:
            if not any(self.validate(value, sub, path).valid for sub in schema["anyOf"]):
                result.add_error(f"{path}: value does not match any of the 'anyOf' schemas")

        if "oneOf" in schema:
            matches = sum(1 for sub in schema["oneOf"] if self.validate(value, sub, path).valid)
            if matches != 1:
                result.add_error(f"{path}: value must match exactly one 'oneOf' schema, matched {matches}")

        if "allOf" in schema:
            for sub in schema["allOf"]:
                result.merge(self.validate(value, sub, path))

        return result
