"""Abstract base class for all tools."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any

from ..exceptions import ToolExecutionError, ToolValidationError
from ..types.enums import HealthStatus, ToolState
from .tool_context import ToolContext
from .tool_result import ToolResult
from .tool_spec import ToolSpec
from .validation import SchemaValidator, ValidationResult


class AbstractTool(ABC):
    """Universal contract that every tool must implement.

    Subclasses **must** provide :pyattr:`spec` and :pymeth:`_execute`.
    The public :pymeth:`execute` method handles validation, timing,
    and error normalisation automatically.
    """

    def __init__(self) -> None:
        self._state: ToolState = ToolState.UNINITIALIZED
        self._validator = SchemaValidator()

    # ── Abstract interface ──────────────────────────────────────────────

    @property
    @abstractmethod
    def spec(self) -> ToolSpec:
        """Return the tool's declarative specification."""
        ...

    @abstractmethod
    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        """Perform the actual work.  Subclasses implement this.

        Returns:
            The tool's raw output (will be wrapped in a :class:`ToolResult`).
        """
        ...

    # ── Public API ──────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return self.spec.name

    @property
    def state(self) -> ToolState:
        return self._state

    async def execute(
        self, params: dict[str, Any], context: ToolContext | None = None
    ) -> ToolResult:
        """Validate, execute, and normalise the result.

        This is the entry-point consumers call.  It wraps :pymeth:`_execute`
        with input validation, timing, output validation, and error handling.
        """
        ctx = context or ToolContext()

        # Validate input
        input_check = await self.validate_input(params)
        if not input_check.valid:
            return ToolResult.fail(
                "TOOL_VALIDATION_ERROR",
                f"Input validation failed for '{self.name}'",
                details={"errors": input_check.errors},
            )

        self._state = ToolState.EXECUTING
        start = time.monotonic()
        try:
            raw = await self._execute(params, ctx)
            duration = (time.monotonic() - start) * 1000

            # Validate output
            output_check = await self.validate_output(raw)
            if not output_check.valid:
                self._state = ToolState.ERROR
                return ToolResult.fail(
                    "TOOL_VALIDATION_ERROR",
                    f"Output validation failed for '{self.name}'",
                    details={"errors": output_check.errors},
                    duration_ms=duration,
                )

            self._state = ToolState.READY
            return ToolResult.ok(raw, duration_ms=duration)

        except Exception as exc:
            self._state = ToolState.ERROR
            duration = (time.monotonic() - start) * 1000
            return ToolResult.fail(
                "TOOL_EXECUTION_ERROR",
                str(exc),
                details={"tool": self.name, "exception_type": type(exc).__name__},
                duration_ms=duration,
            )

    async def validate_input(self, params: dict[str, Any]) -> ValidationResult:
        """Validate *params* against :pyattr:`spec.input_schema`."""
        return self._validator.validate(params, self.spec.input_schema)

    async def validate_output(self, result: Any) -> ValidationResult:
        """Validate the raw execution output against :pyattr:`spec.output_schema`."""
        if self.spec.output_schema is None:
            return ValidationResult(valid=True)
        return self._validator.validate(result, self.spec.output_schema)

    async def health_check(self) -> HealthStatus:
        """Check whether the tool's backing service is reachable.

        The default implementation returns :attr:`HealthStatus.HEALTHY`
        when the tool is not in an error state.  Subclasses should
        override for real connectivity probes.
        """
        if self._state == ToolState.ERROR:
            return HealthStatus.UNHEALTHY
        return HealthStatus.HEALTHY

    def __repr__(self) -> str:
        return f"<{type(self).__name__} name={self.name!r} state={self._state.value}>"
