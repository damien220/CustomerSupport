"""Declarative tool metadata specification."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..types.configs import RateLimitSpec


@dataclass(frozen=True)
class ToolSpec:
    """Fully describes a tool without importing or instantiating it.

    Attributes:
        name: Unique dotted identifier (e.g. ``"openai.chat_completion"``).
        description: Human-readable purpose of the tool.
        version: Semantic version string.
        input_schema: JSON Schema dict describing accepted parameters.
        output_schema: Optional JSON Schema dict describing the return value.
        tags: Capability tags for discovery (e.g. ``{"llm", "text-generation"}``).
        auth_required: Whether authentication is needed to use this tool.
        auth_type: Hint for the authentication mechanism (``"api_key"``, ``"oauth2"``, …).
        rate_limit: Optional rate-limit constraints.
        timeout: Default execution timeout in seconds.
        idempotent: If ``True`` the tool is safe to retry and cache.
        metadata: Arbitrary extension point for adapter-specific data.
    """

    name: str
    description: str
    version: str = "0.1.0"
    input_schema: dict[str, Any] = field(default_factory=lambda: {"type": "object", "properties": {}})
    output_schema: dict[str, Any] | None = None
    tags: frozenset[str] = frozenset()
    auth_required: bool = False
    auth_type: str | None = None
    rate_limit: RateLimitSpec | None = None
    timeout: float = 30.0
    idempotent: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def matches_tags(self, required: set[str]) -> bool:
        """Return ``True`` if this spec has **all** the *required* tags."""
        return required.issubset(self.tags)
