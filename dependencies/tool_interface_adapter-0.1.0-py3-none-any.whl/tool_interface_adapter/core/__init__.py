"""Core abstractions — the foundation of tool-interface-adapter."""

from .abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from .abstract_tool import AbstractTool
from .tool_context import ToolContext
from .tool_result import ToolError, ToolResult
from .tool_spec import ToolSpec
from .validation import SchemaValidator, ValidationResult

__all__ = [
    # ABCs
    "AbstractAdapter",
    "AbstractTool",
    # Request / Response
    "AdapterRequest",
    "AdapterResponse",
    # Data models
    "ToolContext",
    "ToolError",
    "ToolResult",
    "ToolSpec",
    # Validation
    "SchemaValidator",
    "ValidationResult",
]
