"""Execution context carried through the tool pipeline."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from ..types.enums import CachePolicy


@dataclass
class ToolContext:
    """Cross-cutting state threaded through tool execution.

    Attributes:
        correlation_id: Unique trace identifier across chained calls.
        caller: Optional identifier for the invoking entity.
        timeout_override: Per-call timeout that overrides the spec default.
        cache_policy: Controls caching behaviour for this specific call.
        metadata: Arbitrary key-value pairs visible to middleware.
    """

    correlation_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    caller: str | None = None
    timeout_override: float | None = None
    cache_policy: CachePolicy = CachePolicy.DEFAULT
    metadata: dict[str, Any] = field(default_factory=dict)
