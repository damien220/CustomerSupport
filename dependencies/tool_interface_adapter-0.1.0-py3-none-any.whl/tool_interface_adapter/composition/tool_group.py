"""ToolGroup — parallel execution of independent tools."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .chain_step import ToolLike


@dataclass
class GroupResult:
    """Aggregated result of a :class:`ToolGroup` execution.

    Attributes:
        success: ``True`` when *all* tools succeeded.
        results: Mapping of tool name → :class:`~ToolResult`.
    """

    success: bool
    results: dict[str, ToolResult] = field(default_factory=dict)

    @property
    def all_succeeded(self) -> bool:
        """``True`` when every result is successful."""
        return all(r.success for r in self.results.values())

    @property
    def failed(self) -> dict[str, ToolResult]:
        """Subset of *results* that were not successful."""
        return {k: v for k, v in self.results.items() if not v.success}

    @property
    def succeeded(self) -> dict[str, ToolResult]:
        """Subset of *results* that were successful."""
        return {k: v for k, v in self.results.items() if v.success}


class ToolGroup:
    """Runs a collection of tools in parallel and gathers all results.

    Each tool can receive the same input params or individual per-tool params.

    Example::

        group = ToolGroup([weather_tool, news_tool, stocks_tool])
        result = await group.execute({"location": "Berlin"})
        for name, r in result.results.items():
            print(name, r.data)

    With per-tool params::

        group = ToolGroup([tool_a, tool_b])
        result = await group.execute([{"x": 1}, {"x": 2}])
    """

    def __init__(
        self,
        tools: list[ToolLike] | None = None,
        *,
        fail_fast: bool = False,
    ) -> None:
        self._tools: list[ToolLike] = list(tools or [])
        self._fail_fast = fail_fast

    # ── Builder API ────────────────────────────────────────────────────────

    def add(self, tool: ToolLike) -> ToolGroup:
        """Add a tool to the group. Returns *self* for fluent chaining."""
        self._tools.append(tool)
        return self

    # ── Execution ──────────────────────────────────────────────────────────

    async def execute(
        self,
        params: dict[str, Any] | list[dict[str, Any]],
        context: ToolContext | None = None,
    ) -> GroupResult:
        """Execute all tools concurrently.

        Args:
            params: Shared params dict (broadcast to every tool) or a list of
                per-tool param dicts (must match the number of tools).
            context: Optional shared :class:`~ToolContext`.

        Returns:
            :class:`GroupResult` with every tool's result.
        """
        ctx = context or ToolContext()

        if not self._tools:
            return GroupResult(success=True, results={})

        param_list: list[dict[str, Any]]
        if isinstance(params, list):
            if len(params) != len(self._tools):
                raise ValueError(
                    f"ToolGroup has {len(self._tools)} tools but received "
                    f"{len(params)} param dicts"
                )
            param_list = params
        else:
            param_list = [params] * len(self._tools)

        if self._fail_fast:
            raw = await self._gather_fail_fast(param_list, ctx)
        else:
            raw = await asyncio.gather(
                *(tool.execute(p, ctx) for tool, p in zip(self._tools, param_list))
            )

        results = {
            self._name(i, tool): r
            for i, (tool, r) in enumerate(zip(self._tools, raw))
        }
        return GroupResult(success=all(r.success for r in raw), results=results)

    async def _gather_fail_fast(
        self, param_list: list[dict], ctx: ToolContext
    ) -> list[ToolResult]:
        """Run concurrently; cancel remaining on first failure."""
        tasks = [
            asyncio.ensure_future(tool.execute(p, ctx))
            for tool, p in zip(self._tools, param_list)
        ]
        results: list[ToolResult | None] = [None] * len(tasks)
        try:
            for coro in asyncio.as_completed(tasks):
                r = await coro
                # Store by finding its index
                for i, t in enumerate(tasks):
                    if t.done() and results[i] is None:
                        results[i] = t.result() if not t.exception() else None
                if r is not None and not r.success:
                    # Cancel remaining
                    for t in tasks:
                        if not t.done():
                            t.cancel()
                    # Collect whatever finished
                    break
        finally:
            pass
        # Fill any None slots (cancelled) with a cancelled result
        for i, t in enumerate(tasks):
            if results[i] is None:
                if t.done() and not t.cancelled():
                    try:
                        results[i] = t.result()
                    except Exception as exc:
                        results[i] = ToolResult.fail("TOOL_EXECUTION_ERROR", str(exc))
                else:
                    results[i] = ToolResult.fail(
                        "TOOL_EXECUTION_ERROR", "Cancelled due to fail_fast"
                    )
        return results  # type: ignore[return-value]

    @staticmethod
    def _name(idx: int, tool: ToolLike) -> str:
        try:
            return tool.spec.name
        except Exception:
            return f"tool_{idx}"

    def __repr__(self) -> str:
        names = ", ".join(self._name(i, t) for i, t in enumerate(self._tools))
        return f"<ToolGroup [{names}] fail_fast={self._fail_fast}>"
