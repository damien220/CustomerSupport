"""ToolChain — sequential execution with output-to-input piping."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .chain_step import ChainStep, ToolLike


@dataclass
class ChainResult:
    """Aggregated result of a :class:`ToolChain` execution.

    Attributes:
        success: ``True`` when every executed step succeeded.
        results: Mapping of step name → :class:`~ToolResult`.
        final: The last step's :class:`~ToolResult` (the chain's output).
        stopped_at: Name of the step that caused an early stop (on failure).
    """

    success: bool
    results: dict[str, ToolResult] = field(default_factory=dict)
    final: ToolResult | None = None
    stopped_at: str | None = None


class ToolChain:
    """Runs a sequence of tools where each step's output feeds the next step's input.

    Example::

        chain = ToolChain()
        chain.add(fetch_tool)
        chain.add(
            transform_tool,
            name="transform",
            input_map={"text": "body"},       # maps prev_output["body"] → input["text"]
        )
        chain.add(
            summarise_tool,
            input_map=lambda out, _: {"content": out["transformed"]},
        )
        result = await chain.execute({"url": "https://example.com"})
        print(result.final.data)
    """

    def __init__(self, steps: list[ChainStep] | None = None) -> None:
        self._steps: list[ChainStep] = list(steps or [])

    # ── Builder API ────────────────────────────────────────────────────────

    def add(
        self,
        tool: ToolLike,
        *,
        name: str | None = None,
        input_map: dict[str, str] | Callable | None = None,
        condition: Callable[[Any], bool] | None = None,
        on_error: str = "stop",
    ) -> ToolChain:
        """Append a step. Returns *self* for fluent chaining."""
        self._steps.append(
            ChainStep(tool=tool, name=name, input_map=input_map,
                      condition=condition, on_error=on_error)
        )
        return self

    # ── Execution ──────────────────────────────────────────────────────────

    async def execute(
        self, initial_params: dict[str, Any], context: ToolContext | None = None
    ) -> ChainResult:
        """Execute all steps in sequence.

        Args:
            initial_params: Input for the first step.
            context: Optional shared :class:`~ToolContext`.

        Returns:
            :class:`ChainResult` with per-step results and the final output.
        """
        ctx = context or ToolContext()
        results: dict[str, ToolResult] = {}
        current_output: Any = initial_params
        final: ToolResult | None = None

        for i, step in enumerate(self._steps):
            step_name = step.name or f"step_{i}"

            # Optional skip condition (evaluated against the *current* output)
            if step.condition is not None and not step.condition(current_output):
                continue

            # First step always receives initial_params; later steps receive
            # the mapped output of the previous executed step.
            if i == 0:
                params = initial_params
            else:
                params = step.resolve_input(current_output, initial_params)

            result = await step.tool.execute(params, ctx)
            results[step_name] = result
            final = result

            if not result.success:
                if step.on_error == "skip":
                    # Leave current_output unchanged and continue
                    continue
                # "stop" (default) — abort
                return ChainResult(
                    success=False,
                    results=results,
                    final=result,
                    stopped_at=step_name,
                )

            current_output = result.data

        success = final.success if final is not None else True
        return ChainResult(success=success, results=results, final=final)

    # ── Schema compatibility ───────────────────────────────────────────────

    def validate_schema_compatibility(self) -> list[str]:
        """Return a list of compatibility issues between adjacent step schemas.

        Checks that every *required* property of step[i+1]'s ``input_schema``
        is either present in step[i]'s ``output_schema`` or covered by an
        explicit ``input_map`` on step[i+1].

        Returns an empty list when no issues are found.
        """
        issues: list[str] = []
        for i in range(len(self._steps) - 1):
            curr = self._steps[i]
            nxt = self._steps[i + 1]
            curr_out = getattr(getattr(curr.tool, "spec", None), "output_schema", None)
            nxt_in = getattr(getattr(nxt.tool, "spec", None), "input_schema", None)

            if curr_out is None or nxt_in is None:
                continue  # nothing to check

            required = nxt_in.get("required", [])
            curr_props = set(curr_out.get("properties", {}).keys())

            # Keys explicitly provided by the input_map count as satisfied
            if isinstance(nxt.input_map, dict):
                mapped_targets = set(nxt.input_map.keys())
            else:
                mapped_targets: set[str] = set()

            for req in required:
                if req not in curr_props and req not in mapped_targets:
                    curr_name = curr.name or f"step_{i}"
                    nxt_name = nxt.name or f"step_{i + 1}"
                    issues.append(
                        f"'{curr_name}' → '{nxt_name}': required input '{req}' "
                        f"not in output schema and not covered by input_map"
                    )
        return issues

    def __repr__(self) -> str:
        names = " → ".join(s.name or f"step_{i}" for i, s in enumerate(self._steps))
        return f"<ToolChain [{names}]>"
