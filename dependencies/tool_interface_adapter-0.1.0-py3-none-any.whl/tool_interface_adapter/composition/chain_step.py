"""ChainStep — unit of work inside a ToolChain."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Union

from ..core.abstract_tool import AbstractTool

# Forward-reference compatible alias for anything tool-like
ToolLike = Any


def _resolve_input(
    input_map: dict[str, str] | Callable | None,
    prev_output: Any,
    initial_params: dict[str, Any],
) -> dict[str, Any]:
    """Translate the previous step's output into the next step's input params.

    Resolution rules (in order):
    1. If *input_map* is a callable, call it with ``(prev_output, initial_params)``
       and return the result.
    2. If *input_map* is a ``dict``, treat values as source-keys in *prev_output*
       and produce ``{target_key: prev_output[source_key]}``.
    3. If *input_map* is ``None`` and *prev_output* is a ``dict``, pass it through.
    4. Otherwise wrap *prev_output* as ``{"input": prev_output}``.
    """
    if callable(input_map):
        return input_map(prev_output, initial_params)
    if isinstance(input_map, dict):
        if isinstance(prev_output, dict):
            return {tgt: prev_output.get(src) for tgt, src in input_map.items()}
        return {}
    if isinstance(prev_output, dict):
        return prev_output
    return {"input": prev_output}


@dataclass
class ChainStep:
    """Describes a single step in a :class:`~ToolChain`.

    Attributes:
        tool: The tool (or middleware-wrapped tool) to execute.
        name: Optional human-readable label used as a key in the result dict.
        input_map: How to derive this step's input from the previous step's output.
            - ``None`` — pass the previous output through (dict passthrough or wrap).
            - ``dict[str, str]`` — ``{target_key: source_key}`` remap.
            - ``Callable[[prev_output, initial_params], dict]`` — full transform.
        condition: Optional predicate ``(prev_output) -> bool``.  When it returns
            ``False`` the step is skipped and the current output passes through.
        on_error: What to do when the step fails.
            - ``"stop"`` (default) — abort the chain and return a failure result.
            - ``"skip"`` — ignore the failure and continue with the next step.
    """

    tool: ToolLike
    name: str | None = None
    input_map: dict[str, str] | Callable | None = None
    condition: Callable[[Any], bool] | None = None
    on_error: str = "stop"  # "stop" | "skip"

    def resolve_input(
        self, prev_output: Any, initial_params: dict[str, Any]
    ) -> dict[str, Any]:
        """Build this step's input params from *prev_output*."""
        return _resolve_input(self.input_map, prev_output, initial_params)
