"""Pipeline — named steps with branching, conditionals, and error handling."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .chain_step import ToolLike, _resolve_input


@dataclass
class PipelineBranch:
    """A conditional edge between two pipeline steps.

    Attributes:
        condition: Predicate ``(result: ToolResult) -> bool``.  When it
            returns ``True`` execution jumps to *next_step*.
        next_step: Name of the step to execute next.
    """

    condition: Callable[[ToolResult], bool]
    next_step: str


@dataclass
class PipelineStep:
    """A single node in a :class:`Pipeline`.

    Attributes:
        name: Unique identifier used for lookups and result keys.
        tool: The tool to execute.
        input_map: How to derive input from the previous step's output (same
            semantics as :attr:`ChainStep.input_map`).
        branches: Ordered list of conditional edges.  The first branch whose
            condition is satisfied determines the next step.  When no branch
            matches, execution advances to the next step in insertion order
            (or stops if this is the last step).
        on_error: Behaviour on failure — ``"stop"`` (default) aborts the
            pipeline; ``"skip"`` advances to the next step in order.
    """

    name: str
    tool: ToolLike
    input_map: dict[str, str] | Callable | None = None
    branches: list[PipelineBranch] = field(default_factory=list)
    on_error: str = "stop"  # "stop" | "skip"


@dataclass
class PipelineResult:
    """Aggregated result of a :class:`Pipeline` execution.

    Attributes:
        success: ``True`` when the pipeline completed without an error stop.
        results: Mapping of step name → :class:`~ToolResult`.
        path: Names of steps executed in order.
        final: The last executed step's :class:`~ToolResult`.
    """

    success: bool
    results: dict[str, ToolResult] = field(default_factory=dict)
    path: list[str] = field(default_factory=list)
    final: ToolResult | None = None


class Pipeline:
    """Directed workflow with named steps, conditional branching, and error policies.

    Steps are added via :pymeth:`step` and branches via :pymeth:`branch`.
    Execution begins at the first-added step (or the explicit *entry* step).

    Example::

        pipeline = Pipeline()
        pipeline.step("fetch", fetch_tool)
        pipeline.step("summarise", summarise_tool, input_map={"text": "body"})
        pipeline.step("translate", translate_tool)
        pipeline.branch("summarise",
                        condition=lambda r: r.data.get("lang") != "en",
                        next_step="translate")

        result = await pipeline.execute({"url": "..."})
        print(result.path)   # ["fetch", "summarise", "translate"]  or  ["fetch", "summarise"]
    """

    def __init__(self, entry: str | None = None) -> None:
        self._steps: dict[str, PipelineStep] = {}
        self._order: list[str] = []   # insertion order
        self._entry = entry

    # ── Builder API ────────────────────────────────────────────────────────

    def step(
        self,
        name: str,
        tool: ToolLike,
        *,
        input_map: dict[str, str] | Callable | None = None,
        on_error: str = "stop",
    ) -> Pipeline:
        """Add (or replace) a named step. Returns *self* for fluent chaining."""
        ps = PipelineStep(name=name, tool=tool, input_map=input_map, on_error=on_error)
        if name not in self._steps:
            self._order.append(name)
        self._steps[name] = ps
        if self._entry is None:
            self._entry = name
        return self

    def branch(
        self,
        from_step: str,
        condition: Callable[[ToolResult], bool],
        next_step: str,
    ) -> Pipeline:
        """Add a conditional branch from *from_step* to *next_step*.

        Branches are evaluated in the order they are added; the first matching
        branch wins.  Returns *self* for fluent chaining.
        """
        self._steps[from_step].branches.append(
            PipelineBranch(condition=condition, next_step=next_step)
        )
        return self

    # ── Execution ──────────────────────────────────────────────────────────

    async def execute(
        self, initial_params: dict[str, Any], context: ToolContext | None = None
    ) -> PipelineResult:
        """Execute the pipeline starting from the entry step.

        Args:
            initial_params: Input provided to the first step.
            context: Optional shared :class:`~ToolContext`.

        Returns:
            :class:`PipelineResult` with per-step results, execution path, and
            the final step's result.
        """
        ctx = context or ToolContext()
        results: dict[str, ToolResult] = {}
        path: list[str] = []
        current_output: Any = initial_params
        current_name: str | None = self._entry

        visited: set[str] = set()  # cycle guard

        while current_name is not None:
            if current_name not in self._steps:
                break
            if current_name in visited:
                # Cycle detected — stop to avoid infinite loop
                break
            visited.add(current_name)

            step = self._steps[current_name]
            path.append(current_name)

            # First step always receives initial_params
            if len(path) == 1:
                params = initial_params
            else:
                params = _resolve_input(step.input_map, current_output, initial_params)

            result = await step.tool.execute(params, ctx)
            results[current_name] = result

            if not result.success:
                if step.on_error == "skip":
                    current_name = self._next_in_order(current_name)
                    continue
                # "stop" — abort
                return PipelineResult(
                    success=False,
                    results=results,
                    path=path,
                    final=result,
                )

            current_output = result.data

            # Evaluate branches; first match wins
            next_name: str | None = None
            for branch in step.branches:
                try:
                    if branch.condition(result):
                        next_name = branch.next_step
                        break
                except Exception:
                    pass

            if next_name is None:
                # No branch taken — advance to next step in insertion order
                next_name = self._next_in_order(current_name)

            current_name = next_name

        final = results[path[-1]] if path else None
        return PipelineResult(
            success=final.success if final is not None else True,
            results=results,
            path=path,
            final=final,
        )

    # ── Helpers ────────────────────────────────────────────────────────────

    def _next_in_order(self, name: str) -> str | None:
        idx = self._order.index(name)
        if idx + 1 < len(self._order):
            return self._order[idx + 1]
        return None

    def __repr__(self) -> str:
        names = " → ".join(self._order)
        return f"<Pipeline [{names}]>"
