"""Tool discovery via the ``plugin_loader`` package.

When ``plugin_loader`` is installed, this module provides helpers that
leverage its directory / entry-point / package discovery strategies to
find :class:`AbstractTool` subclasses and auto-register them in a
:class:`ToolRegistry`.

When ``plugin_loader`` is *not* installed the helpers raise
:class:`ImportError` with a clear message.
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
from pathlib import Path
from typing import Any

from ..core.abstract_tool import AbstractTool
from ..exceptions import ToolConfigError
from .tool_registry import ToolRegistry

try:
    from plugin_loader import (
        DirectoryStrategy,
        EntryPointStrategy,
        PackageStrategy,
        PluginManagerConfig,
        create_plugin_manager,
    )
    _HAS_PLUGIN_LOADER = True
except ImportError:  # pragma: no cover
    _HAS_PLUGIN_LOADER = False


def has_plugin_loader() -> bool:
    """Return ``True`` if the ``plugin_loader`` package is available."""
    return _HAS_PLUGIN_LOADER


# ── Plugin-loader based discovery ───────────────────────────────────────

def discover_tools_from_directory(
    directory: str | Path,
    *,
    registry: ToolRegistry | None = None,
    recursive: bool = True,
    file_pattern: str = "*.py",
) -> list[AbstractTool]:
    """Scan *directory* for ``AbstractTool`` subclasses using ``plugin_loader``.

    Discovered tool classes are instantiated (no-arg constructor) and
    optionally registered in *registry*.

    Requires: ``pip install tool-interface-adapter[plugins]``

    Returns:
        List of instantiated tool instances.

    Raises:
        ImportError: If ``plugin_loader`` is not installed.
    """
    if not _HAS_PLUGIN_LOADER:
        raise ImportError(
            "plugin_loader is required for directory discovery. "
            "Install with: pip install tool-interface-adapter[plugins]"
        )

    strategy = DirectoryStrategy(
        plugin_dirs=str(directory),
        recursive=recursive,
        file_pattern=file_pattern,
        base_class=AbstractTool,
    )
    result = strategy.discover()
    return _instantiate_and_register(result.discovered_classes, registry)


def discover_tools_from_entry_points(
    group: str = "tool_interface_adapter.tools",
    *,
    registry: ToolRegistry | None = None,
) -> list[AbstractTool]:
    """Discover tools registered as setuptools entry points.

    Third-party packages can advertise tools via ``pyproject.toml``::

        [project.entry-points."tool_interface_adapter.tools"]
        my_tool = "my_package.tools:MyTool"

    Requires: ``pip install tool-interface-adapter[plugins]``

    Returns:
        List of instantiated tool instances.

    Raises:
        ImportError: If ``plugin_loader`` is not installed.
    """
    if not _HAS_PLUGIN_LOADER:
        raise ImportError(
            "plugin_loader is required for entry-point discovery. "
            "Install with: pip install tool-interface-adapter[plugins]"
        )

    strategy = EntryPointStrategy(
        entry_point_group=group,
        base_class=AbstractTool,
    )
    result = strategy.discover()
    return _instantiate_and_register(result.discovered_classes, registry)


def discover_tools_from_package(
    package: str,
    *,
    registry: ToolRegistry | None = None,
    recursive: bool = True,
) -> list[AbstractTool]:
    """Discover tools inside a Python package (by import path).

    Requires: ``pip install tool-interface-adapter[plugins]``

    Returns:
        List of instantiated tool instances.

    Raises:
        ImportError: If ``plugin_loader`` is not installed.
    """
    if not _HAS_PLUGIN_LOADER:
        raise ImportError(
            "plugin_loader is required for package discovery. "
            "Install with: pip install tool-interface-adapter[plugins]"
        )

    strategy = PackageStrategy(
        scan_packages=package,
        base_class=AbstractTool,
        recursive=recursive,
    )
    result = strategy.discover()
    return _instantiate_and_register(result.discovered_classes, registry)


# ── Lightweight built-in discovery (no plugin_loader needed) ────────────

def discover_tools_from_module(
    module_path: str,
    *,
    registry: ToolRegistry | None = None,
) -> list[AbstractTool]:
    """Discover tools by importing a Python module and scanning for subclasses.

    This is a zero-dependency alternative that does **not** require
    ``plugin_loader``.

    Args:
        module_path: Dotted import path (e.g. ``"myapp.tools"``).
        registry: If given, discovered tools are auto-registered.

    Returns:
        List of instantiated tool instances.
    """
    mod = importlib.import_module(module_path)
    classes = [
        obj
        for _, obj in inspect.getmembers(mod, inspect.isclass)
        if issubclass(obj, AbstractTool) and obj is not AbstractTool and not inspect.isabstract(obj)
    ]
    return _instantiate_and_register(classes, registry)


# ── Internal helpers ────────────────────────────────────────────────────

def _instantiate_and_register(
    classes: list[type],
    registry: ToolRegistry | None,
) -> list[AbstractTool]:
    """Instantiate tool classes and optionally register them."""
    tools: list[AbstractTool] = []
    for cls in classes:
        if not (isinstance(cls, type) and issubclass(cls, AbstractTool)):
            continue
        if inspect.isabstract(cls):
            continue
        try:
            instance = cls()
            tools.append(instance)
            if registry is not None:
                registry.register(instance, force=True)
        except Exception:
            # Skip classes that can't be instantiated with no args
            continue
    return tools
