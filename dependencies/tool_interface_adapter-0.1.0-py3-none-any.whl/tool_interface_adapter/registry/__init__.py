"""Tool registry, decorators, and discovery."""

from .tool_registry import ToolRegistry
from .decorators import (
    get_default_registry,
    register_tool,
    set_default_registry,
)
from .discovery import (
    discover_tools_from_directory,
    discover_tools_from_entry_points,
    discover_tools_from_module,
    discover_tools_from_package,
    has_plugin_loader,
)

__all__ = [
    "ToolRegistry",
    # Decorators
    "get_default_registry",
    "register_tool",
    "set_default_registry",
    # Discovery
    "discover_tools_from_directory",
    "discover_tools_from_entry_points",
    "discover_tools_from_module",
    "discover_tools_from_package",
    "has_plugin_loader",
]
