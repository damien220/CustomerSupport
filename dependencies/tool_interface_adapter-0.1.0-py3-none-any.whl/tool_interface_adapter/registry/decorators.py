"""Decorators for declarative tool registration."""

from __future__ import annotations

from typing import Any

from ..core.abstract_tool import AbstractTool
from .tool_registry import ToolRegistry

# Module-level default registry used by the decorator when no explicit
# registry is supplied.  Consumers can replace this or provide their own.
_default_registry: ToolRegistry | None = None


def get_default_registry() -> ToolRegistry:
    """Return (and lazily create) the module-level default registry."""
    global _default_registry
    if _default_registry is None:
        _default_registry = ToolRegistry()
    return _default_registry


def set_default_registry(registry: ToolRegistry) -> None:
    """Replace the module-level default registry."""
    global _default_registry
    _default_registry = registry


def register_tool(
    registry: ToolRegistry | None = None,
    *,
    force: bool = False,
) -> Any:
    """Class decorator that registers an :class:`AbstractTool` subclass.

    The decorator instantiates the class (with no arguments) and registers
    the resulting tool instance in *registry* (or the default registry).

    Usage::

        @register_tool()
        class MyTool(AbstractTool):
            ...

        # With explicit registry
        my_reg = ToolRegistry()

        @register_tool(my_reg)
        class AnotherTool(AbstractTool):
            ...

    Args:
        registry: Registry to register with.  Falls back to the default.
        force: If ``True``, overwrite any existing tool with the same name.

    Returns:
        The original class (unmodified).
    """
    target_registry = registry if registry is not None else get_default_registry()

    def decorator(cls: type) -> type:
        if not (isinstance(cls, type) and issubclass(cls, AbstractTool)):
            raise TypeError(
                f"@register_tool can only decorate AbstractTool subclasses, "
                f"got {cls!r}"
            )
        instance = cls()
        target_registry.register(instance, force=force)
        return cls

    return decorator
