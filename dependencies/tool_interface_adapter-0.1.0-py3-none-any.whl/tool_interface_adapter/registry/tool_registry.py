"""Central registry for tool discovery and management."""

from __future__ import annotations

import fnmatch
from typing import Any, Callable

from ..core.abstract_tool import AbstractTool
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolNotFoundError, ToolConfigError


# Type alias for registry event listeners
RegistryListener = Callable[[str, str, AbstractTool], None]


class ToolRegistry:
    """Central registry where tools are registered, queried, and managed.

    Supports:
    - Registration / unregistration by name.
    - Lookup by exact name.
    - Filtering by tags.
    - Glob-style name search.
    - Event listeners for register/unregister events.

    Example::

        registry = ToolRegistry()
        registry.register(my_tool)
        tool = registry.get("my_tool.name")
        specs = registry.list_tools(tags={"llm"})
    """

    def __init__(self) -> None:
        self._tools: dict[str, AbstractTool] = {}
        self._listeners: list[RegistryListener] = []

    # ── Registration ────────────────────────────────────────────────────

    def register(self, tool: AbstractTool, *, force: bool = False) -> None:
        """Register a tool instance.

        Args:
            tool: The tool to register.
            force: If ``True``, overwrite an existing registration with the
                   same name.  Otherwise raise :class:`ToolConfigError`.
        """
        name = tool.spec.name
        if name in self._tools and not force:
            raise ToolConfigError(
                f"Tool '{name}' is already registered",
                details={"tool": name},
            )
        self._tools[name] = tool
        self._notify("registered", name, tool)

    def unregister(self, name: str) -> None:
        """Remove a tool by name.

        Raises:
            ToolNotFoundError: If *name* is not in the registry.
        """
        tool = self._tools.pop(name, None)
        if tool is None:
            raise ToolNotFoundError(
                f"Tool '{name}' not found in registry",
                details={"tool": name},
            )
        self._notify("unregistered", name, tool)

    # ── Query ───────────────────────────────────────────────────────────

    def get(self, name: str) -> AbstractTool:
        """Return the tool registered under *name*.

        Raises:
            ToolNotFoundError: If *name* is not in the registry.
        """
        tool = self._tools.get(name)
        if tool is None:
            raise ToolNotFoundError(
                f"Tool '{name}' not found in registry",
                details={"tool": name, "available": list(self._tools.keys())},
            )
        return tool

    def has(self, name: str) -> bool:
        """Return ``True`` if a tool with *name* is registered."""
        return name in self._tools

    def list_tools(self, *, tags: set[str] | None = None) -> list[ToolSpec]:
        """Return specs for all registered tools, optionally filtered by *tags*.

        When *tags* is given, only tools whose spec contains **all** the
        required tags are returned.
        """
        specs: list[ToolSpec] = []
        for tool in self._tools.values():
            if tags is None or tool.spec.matches_tags(tags):
                specs.append(tool.spec)
        return specs

    def search(self, query: str) -> list[ToolSpec]:
        """Search tools by glob pattern against their name.

        Supports ``*`` and ``?`` wildcards.  Example: ``"openai.*"``
        matches ``"openai.chat"`` and ``"openai.embeddings"``.
        """
        results: list[ToolSpec] = []
        for name, tool in self._tools.items():
            if fnmatch.fnmatch(name, query):
                results.append(tool.spec)
        return results

    @property
    def tool_names(self) -> list[str]:
        """Return sorted list of all registered tool names."""
        return sorted(self._tools.keys())

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return self.has(name)

    def __iter__(self):
        return iter(self._tools.values())

    # ── Event listeners ─────────────────────────────────────────────────

    def add_listener(self, listener: RegistryListener) -> None:
        """Add a callback invoked on register/unregister events.

        The listener receives ``(event: str, name: str, tool: AbstractTool)``.
        """
        self._listeners.append(listener)

    def remove_listener(self, listener: RegistryListener) -> None:
        """Remove a previously added listener."""
        self._listeners.remove(listener)

    def _notify(self, event: str, name: str, tool: AbstractTool) -> None:
        for listener in self._listeners:
            listener(event, name, tool)

    # ── Bulk operations ─────────────────────────────────────────────────

    def register_many(self, tools: list[AbstractTool], *, force: bool = False) -> int:
        """Register multiple tools.  Returns the count of newly registered tools."""
        count = 0
        for tool in tools:
            self.register(tool, force=force)
            count += 1
        return count

    def clear(self) -> int:
        """Unregister all tools.  Returns the count of tools removed."""
        count = len(self._tools)
        self._tools.clear()
        return count

    def __repr__(self) -> str:
        return f"<ToolRegistry tools={len(self._tools)}>"
