"""Job integration — schedule recurring health checks and cache warm-ups."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..types.enums import HealthStatus

logger = logging.getLogger(__name__)

# Optional integration with job_manager sibling package
try:
    from job_manager import (  # type: ignore[import]
        AsyncScheduler,
        BaseJob,
        IntervalTrigger,
        JobContext,
    )
    _has_job_manager = True
except ImportError:
    _has_job_manager = False


# ── Job classes (used when job_manager is available) ─────────────────────────

if _has_job_manager:
    class _HealthCheckJob(BaseJob):
        """Periodic health-check job for a single tool."""

        def __init__(self, tool: Any, on_unhealthy: Any | None = None) -> None:
            self._tool = tool
            self._on_unhealthy = on_unhealthy

        async def execute(self, context: JobContext) -> Any:
            status = await self._tool.health_check()
            if status == HealthStatus.UNHEALTHY and self._on_unhealthy is not None:
                try:
                    if asyncio.iscoroutinefunction(self._on_unhealthy):
                        await self._on_unhealthy(self._tool, status)
                    else:
                        self._on_unhealthy(self._tool, status)
                except Exception as exc:
                    logger.warning("on_unhealthy callback error: %s", exc)
            logger.info(
                "Health check for '%s': %s", self._tool.spec.name, status.value
            )
            return {"tool": self._tool.spec.name, "status": status.value}

    class _CacheWarmUpJob(BaseJob):
        """Pre-executes a tool with fixed params to warm the cache."""

        def __init__(self, tool: Any, warm_params: dict) -> None:
            self._tool = tool
            self._warm_params = warm_params

        async def execute(self, context: JobContext) -> Any:
            from ..core.tool_context import ToolContext
            from ..types.enums import CachePolicy
            ctx = ToolContext(cache_policy=CachePolicy.REFRESH)
            result = await self._tool.execute(self._warm_params, ctx)
            logger.info(
                "Cache warm-up for '%s': %s",
                self._tool.spec.name,
                "ok" if result.success else "failed",
            )
            return {
                "tool": self._tool.spec.name,
                "success": result.success,
            }


class ToolJobManager:
    """Schedules recurring operations for tools via ``job_manager``.

    When ``job_manager`` is not installed, falls back to lightweight
    :mod:`asyncio` tasks so basic health-check and warm-up loops remain
    available without the extra dependency.

    Args:
        scheduler: Optional :class:`~job_manager.AsyncScheduler` instance.
            When ``None`` the built-in asyncio fallback is used.

    Example::

        jm = ToolJobManager()
        jm.schedule_health_check(my_tool, interval_seconds=60)
        jm.schedule_cache_warmup(
            my_tool,
            warm_params={"city": "Berlin"},
            interval_seconds=300,
        )
        await jm.start()
        # ... later
        await jm.stop()
    """

    def __init__(self, scheduler: Any | None = None) -> None:
        if scheduler is None and _has_job_manager:
            from job_manager import MemoryJobStore, ThreadPoolExecutor as _TPE  # type: ignore[import]
            self._scheduler: Any = AsyncScheduler(
                store=MemoryJobStore(), executor=_TPE()
            )
        else:
            self._scheduler = scheduler  # may be None → asyncio fallback
        self._tasks: list[asyncio.Task] = []
        self._running = False

    # ── Scheduling API ───────────────────────────────────────────────────

    def schedule_health_check(
        self,
        tool: Any,
        *,
        interval_seconds: float = 60.0,
        on_unhealthy: Any | None = None,
        job_id: str | None = None,
    ) -> str:
        """Schedule a periodic health check for *tool*.

        Args:
            tool: Any tool-like object with a ``health_check()`` method.
            interval_seconds: How often to run the check.
            on_unhealthy: Optional callback ``(tool, status)`` invoked when
                the health check returns ``UNHEALTHY``.
            job_id: Optional job identifier.  Auto-generated if omitted.

        Returns:
            The job identifier string.
        """
        jid = job_id or f"health_check.{tool.spec.name}"
        if _has_job_manager and self._scheduler is not None:
            job = _HealthCheckJob(tool, on_unhealthy)
            trigger = IntervalTrigger(seconds=interval_seconds)
            self._scheduler.add_job(job, trigger, job_id=jid, name=jid)
        else:
            # Asyncio fallback — store as (kind, tool, params, interval)
            self._tasks.append(
                asyncio.ensure_future(
                    self._asyncio_loop(
                        jid,
                        tool.health_check,
                        [],
                        interval_seconds,
                    )
                )
                if self._running
                else None  # will be started in start()
            )
            # Re-register for deferred start
            self._pending: list[tuple] = getattr(self, "_pending", [])
            self._pending.append(
                ("health", tool, None, interval_seconds, on_unhealthy, jid)
            )
        return jid

    def schedule_cache_warmup(
        self,
        tool: Any,
        *,
        warm_params: dict[str, Any],
        interval_seconds: float = 300.0,
        job_id: str | None = None,
    ) -> str:
        """Schedule a periodic cache warm-up execution for *tool*.

        Args:
            tool: Any tool-like object with an ``execute()`` method.
            warm_params: Params to pass when pre-executing the tool.
            interval_seconds: How often to run the warm-up.
            job_id: Optional job identifier.  Auto-generated if omitted.

        Returns:
            The job identifier string.
        """
        jid = job_id or f"cache_warmup.{tool.spec.name}"
        if _has_job_manager and self._scheduler is not None:
            job = _CacheWarmUpJob(tool, warm_params)
            trigger = IntervalTrigger(seconds=interval_seconds)
            self._scheduler.add_job(job, trigger, job_id=jid, name=jid)
        else:
            self._pending = getattr(self, "_pending", [])
            self._pending.append(
                ("warmup", tool, warm_params, interval_seconds, None, jid)
            )
        return jid

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the scheduler (or asyncio fallback loops)."""
        self._running = True
        if _has_job_manager and self._scheduler is not None:
            await self._scheduler.start_async()
        else:
            for kind, tool, params, interval, on_unhealthy, jid in getattr(self, "_pending", []):
                if kind == "health":
                    task = asyncio.ensure_future(
                        self._health_loop(tool, interval, on_unhealthy)
                    )
                else:
                    task = asyncio.ensure_future(
                        self._warmup_loop(tool, params, interval)
                    )
                self._tasks.append(task)

    async def stop(self) -> None:
        """Stop all scheduled jobs."""
        self._running = False
        if _has_job_manager and self._scheduler is not None:
            await self._scheduler.shutdown_async()
        for task in self._tasks:
            if task is not None and not task.done():
                task.cancel()
        self._tasks.clear()

    @property
    def is_running(self) -> bool:
        if _has_job_manager and self._scheduler is not None:
            return self._scheduler.is_running()
        return self._running

    # ── Asyncio fallback loops ────────────────────────────────────────────

    @staticmethod
    async def _health_loop(
        tool: Any, interval: float, on_unhealthy: Any | None
    ) -> None:
        while True:
            try:
                status = await tool.health_check()
                logger.info("Health [%s]: %s", tool.spec.name, status.value)
                if status == HealthStatus.UNHEALTHY and on_unhealthy is not None:
                    try:
                        if asyncio.iscoroutinefunction(on_unhealthy):
                            await on_unhealthy(tool, status)
                        else:
                            on_unhealthy(tool, status)
                    except Exception as exc:
                        logger.warning("on_unhealthy error: %s", exc)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Health check error [%s]: %s", tool.spec.name, exc)
            await asyncio.sleep(interval)

    @staticmethod
    async def _warmup_loop(tool: Any, params: dict, interval: float) -> None:
        from ..core.tool_context import ToolContext
        from ..types.enums import CachePolicy
        while True:
            try:
                ctx = ToolContext(cache_policy=CachePolicy.REFRESH)
                result = await tool.execute(params, ctx)
                logger.info(
                    "Warm-up [%s]: %s",
                    tool.spec.name,
                    "ok" if result.success else "failed",
                )
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Warm-up error [%s]: %s", tool.spec.name, exc)
            await asyncio.sleep(interval)

    @staticmethod
    async def _asyncio_loop(
        jid: str, fn: Any, args: list, interval: float
    ) -> None:
        while True:
            try:
                result = fn(*args)
                if asyncio.iscoroutine(result):
                    await result
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Job [%s] error: %s", jid, exc)
            await asyncio.sleep(interval)

    def __repr__(self) -> str:
        backend = "job_manager" if (_has_job_manager and self._scheduler) else "asyncio"
        return f"<ToolJobManager backend={backend!r} running={self._running}>"
