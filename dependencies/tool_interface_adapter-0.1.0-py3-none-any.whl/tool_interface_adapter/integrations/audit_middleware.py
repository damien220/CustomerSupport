"""Audit middleware — persists tool execution records via db_accessor."""

from __future__ import annotations

import datetime
import logging
import uuid
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..middleware.abstract_middleware import AbstractToolMiddleware, ToolLike

logger = logging.getLogger(__name__)

# Optional integration with db_accessor sibling package
try:
    from db_accessor import AbstractDatabase  # type: ignore[import]
    _has_db_accessor = True
except ImportError:
    _has_db_accessor = False


class AuditMiddleware(AbstractToolMiddleware):
    """Writes an execution record to a database after every tool call.

    Uses ``db_accessor`` when provided; falls back to an in-process list so
    that audit history is always available even without a database backend.

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        db: Optional :class:`~db_accessor.AbstractDatabase` instance.
        collection: Collection / table name for audit records.  Default
            ``"tool_executions"``.

    Audit record schema::

        {
            "id": str,             # UUID
            "tool": str,           # tool name
            "correlation_id": str,
            "success": bool,
            "duration_ms": float,
            "error_code": str | None,
            "timestamp": str,      # ISO-8601 UTC
        }
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        db: Any | None = None,
        collection: str = "tool_executions",
    ) -> None:
        super().__init__(wrapped)
        self._db = db
        self._collection = collection
        # In-process fallback store
        self._records: list[dict[str, Any]] = []

    @property
    def records(self) -> list[dict[str, Any]]:
        """In-process audit records (populated when no db is configured)."""
        return list(self._records)

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        import time
        start = time.monotonic()
        result = await self._call_next(params, context)
        duration_ms = (time.monotonic() - start) * 1000

        record: dict[str, Any] = {
            "id": uuid.uuid4().hex,
            "tool": self.name,
            "correlation_id": context.correlation_id,
            "success": result.success,
            "duration_ms": round(duration_ms, 3),
            "error_code": result.error.code if result.error else None,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        await self._persist(record)
        return result

    async def _persist(self, record: dict[str, Any]) -> None:
        if _has_db_accessor and self._db is not None:
            try:
                self._db.create(self._collection, record)
                return
            except Exception as exc:
                logger.warning("AuditMiddleware: db write failed: %s", exc)

        # Fallback: keep in-process
        self._records.append(record)

    def _wrap(self, tool: ToolLike) -> AuditMiddleware:
        return AuditMiddleware(tool, db=self._db, collection=self._collection)
