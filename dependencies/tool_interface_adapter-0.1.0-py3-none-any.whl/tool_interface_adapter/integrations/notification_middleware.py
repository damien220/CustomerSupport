"""Notification middleware — alerts on failures and SLA breaches."""

from __future__ import annotations

import logging
import time
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..middleware.abstract_middleware import AbstractToolMiddleware, ToolLike

logger = logging.getLogger(__name__)

# Optional integration with notification_manager sibling package
try:
    from notification_manager import (  # type: ignore[import]
        NotificationManager,
        Notification,
        Recipient,
    )
    _has_notification_manager = True
except ImportError:
    _has_notification_manager = False


class NotificationMiddleware(AbstractToolMiddleware):
    """Sends alerts when a tool fails or breaches its SLA.

    Falls back to a ``logging.WARNING`` when ``notification_manager`` is not
    installed or no manager is provided.

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        recipient_id: Identifier of the alert recipient (e.g. an email or
            channel ID understood by your notification plugins).
        notify_on_failure: Send an alert on every tool failure.  Default ``True``.
        sla_threshold_ms: Execution time (ms) above which an SLA-breach alert
            is sent.  ``None`` disables SLA monitoring.
        manager: Optional pre-configured :class:`~notification_manager.NotificationManager`.
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        recipient_id: str = "ops",
        notify_on_failure: bool = True,
        sla_threshold_ms: float | None = None,
        manager: Any | None = None,
    ) -> None:
        super().__init__(wrapped)
        self._recipient_id = recipient_id
        self._notify_on_failure = notify_on_failure
        self._sla_threshold_ms = sla_threshold_ms
        self._manager = manager

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        start = time.monotonic()
        result = await self._call_next(params, context)
        duration_ms = (time.monotonic() - start) * 1000

        if self._notify_on_failure and not result.success:
            error_code = result.error.code if result.error else "UNKNOWN"
            await self._send_alert(
                title=f"Tool '{self.name}' failed",
                body=(
                    f"Tool '{self.name}' failed with code {error_code}.\n"
                    f"Correlation ID: {context.correlation_id}"
                ),
                metadata={"error_code": error_code, "tool": self.name,
                          "correlation_id": context.correlation_id},
            )

        if (
            self._sla_threshold_ms is not None
            and result.success
            and duration_ms > self._sla_threshold_ms
        ):
            await self._send_alert(
                title=f"SLA breach: '{self.name}'",
                body=(
                    f"Tool '{self.name}' took {duration_ms:.1f}ms, "
                    f"exceeding the {self._sla_threshold_ms}ms SLA.\n"
                    f"Correlation ID: {context.correlation_id}"
                ),
                metadata={"duration_ms": duration_ms,
                          "sla_ms": self._sla_threshold_ms,
                          "tool": self.name},
            )

        return result

    async def _send_alert(
        self, title: str, body: str, metadata: dict[str, Any]
    ) -> None:
        if _has_notification_manager and self._manager is not None:
            try:
                recipient = Recipient(id=self._recipient_id)
                notification = Notification(
                    title=title,
                    body=body,
                    recipient=recipient,
                    metadata=metadata,
                )
                await self._manager.send(notification)
                return
            except Exception as exc:
                logger.warning("NotificationMiddleware: send failed: %s", exc)

        # Fallback: structured log
        logger.warning(
            "ALERT — %s | %s | metadata=%s", title, body.replace("\n", " "), metadata
        )

    def _wrap(self, tool: ToolLike) -> NotificationMiddleware:
        return NotificationMiddleware(
            tool,
            recipient_id=self._recipient_id,
            notify_on_failure=self._notify_on_failure,
            sla_threshold_ms=self._sla_threshold_ms,
            manager=self._manager,
        )
