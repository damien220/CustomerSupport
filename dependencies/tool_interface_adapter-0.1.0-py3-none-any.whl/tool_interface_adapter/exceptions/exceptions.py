"""Exception hierarchy for the tool interface adapter package.

Extends ``BaseAppException`` from ``error_exception_handler`` when available,
otherwise falls back to a minimal local base so the package works standalone.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:  # pragma: no cover – standalone mode

    class BaseAppException(Exception):  # type: ignore[no-redef]
        """Minimal fallback when error_exception_handler is not installed."""

        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.message = message
            self.code = code
            self.status_code = status_code
            self.details = details
            self.previous = previous
            if previous is not None:
                self.__cause__ = previous

        def to_dict(self) -> dict[str, Any]:
            result: dict[str, Any] = {
                "code": self.code,
                "message": self.message,
                "status_code": self.status_code,
            }
            if self.details:
                result["details"] = self.details
            return result


# ── Root ────────────────────────────────────────────────────────────────

class ToolAdapterError(BaseAppException):
    """Root exception for all tool-interface-adapter errors."""

    def __init__(
        self,
        message: str = "A tool adapter error occurred",
        *,
        code: str = "TOOL_ADAPTER_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            details=details,
            previous=previous,
        )


# ── Configuration / Setup ──────────────────────────────────────────────

class ToolConfigError(ToolAdapterError):
    """Raised when tool or adapter configuration is invalid."""

    def __init__(
        self,
        message: str = "Invalid tool configuration",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_CONFIG_ERROR",
            status_code=400,
            details=details,
            previous=previous,
        )


class ToolNotFoundError(ToolAdapterError):
    """Raised when a requested tool does not exist in the registry."""

    def __init__(
        self,
        message: str = "Tool not found",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_NOT_FOUND",
            status_code=404,
            details=details,
            previous=previous,
        )


# ── Validation ─────────────────────────────────────────────────────────

class ToolValidationError(ToolAdapterError):
    """Raised when input or output fails schema validation."""

    def __init__(
        self,
        message: str = "Validation failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_VALIDATION_ERROR",
            status_code=422,
            details=details,
            previous=previous,
        )


class ToolSchemaError(ToolAdapterError):
    """Raised when a tool's JSON schema definition itself is invalid."""

    def __init__(
        self,
        message: str = "Invalid tool schema",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_SCHEMA_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


# ── Execution ──────────────────────────────────────────────────────────

class ToolExecutionError(ToolAdapterError):
    """Raised when tool execution fails."""

    def __init__(
        self,
        message: str = "Tool execution failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_EXECUTION_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class ToolTimeoutError(ToolExecutionError):
    """Raised when tool execution exceeds the configured timeout."""

    def __init__(
        self,
        message: str = "Tool execution timed out",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            details=details,
            previous=previous,
        )
        self.code = "TOOL_TIMEOUT_ERROR"
        self.status_code = 504


# ── Connection / Auth ──────────────────────────────────────────────────

class ToolConnectionError(ToolAdapterError):
    """Raised when the adapter cannot connect to the backing service."""

    def __init__(
        self,
        message: str = "Connection to tool backend failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_CONNECTION_ERROR",
            status_code=503,
            details=details,
            previous=previous,
        )


class ToolAuthenticationError(ToolAdapterError):
    """Raised when authentication with the backing service fails."""

    def __init__(
        self,
        message: str = "Tool authentication failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="TOOL_AUTH_ERROR",
            status_code=401,
            details=details,
            previous=previous,
        )
