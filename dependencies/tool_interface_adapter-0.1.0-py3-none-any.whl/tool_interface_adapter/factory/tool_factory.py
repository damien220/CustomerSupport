"""Factory functions for creating tool instances from specs and configs."""

from __future__ import annotations

from typing import Any, Callable

from ..core.abstract_adapter import AbstractAdapter
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolConfigError
from ..types.configs import AdapterConfig


class AdapterBackedTool(AbstractTool):
    """Concrete tool that delegates execution to an :class:`AbstractAdapter`.

    Created by :func:`create_tool` when a spec + adapter are provided.
    """

    def __init__(self, spec: ToolSpec, adapter: AbstractAdapter) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = adapter

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        if not self._adapter.is_connected:
            await self._adapter.connect()
        request = self._adapter.translate_request(params, self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self):
        from ..types.enums import HealthStatus
        if not self._adapter.is_connected:
            return HealthStatus.UNHEALTHY
        return await super().health_check()


# ── Adapter type registry ───────────────────────────────────────────────

_adapter_types: dict[str, type[AbstractAdapter]] = {}


def register_adapter_type(name: str, cls: type[AbstractAdapter]) -> None:
    """Register an adapter class under a string name for factory lookup.

    Example::

        register_adapter_type("http", HttpApiAdapter)
    """
    _adapter_types[name] = cls


def list_adapter_types() -> list[str]:
    """Return sorted list of registered adapter type names."""
    return sorted(_adapter_types.keys())


def get_adapter_type(name: str) -> type[AbstractAdapter]:
    """Return the adapter class registered under *name*.

    Raises:
        ToolConfigError: If *name* is not registered.
    """
    cls = _adapter_types.get(name)
    if cls is None:
        raise ToolConfigError(
            f"Unknown adapter type '{name}'",
            details={"available": list_adapter_types()},
        )
    return cls


# ── Factory functions ───────────────────────────────────────────────────

def create_adapter(config: AdapterConfig) -> AbstractAdapter:
    """Instantiate an adapter from an :class:`AdapterConfig`.

    The ``adapter_type`` field is looked up in the adapter type registry.

    Raises:
        ToolConfigError: If the adapter type is not registered.
    """
    cls = get_adapter_type(config.adapter_type)
    return cls(config=config)


def create_tool(
    spec: ToolSpec,
    adapter: AbstractAdapter | None = None,
    *,
    adapter_config: AdapterConfig | None = None,
) -> AbstractTool:
    """Create a tool from a spec and an adapter (or adapter config).

    Provide either a pre-built *adapter* instance **or** an
    *adapter_config* from which one will be created via :func:`create_adapter`.

    Args:
        spec: Declarative tool specification.
        adapter: Pre-built adapter instance.
        adapter_config: Config used to create an adapter via the factory.

    Returns:
        An :class:`AdapterBackedTool` ready for use.

    Raises:
        ToolConfigError: If neither *adapter* nor *adapter_config* is given.
    """
    if adapter is None and adapter_config is not None:
        adapter = create_adapter(adapter_config)
    if adapter is None:
        raise ToolConfigError(
            "Either 'adapter' or 'adapter_config' must be provided to create_tool",
        )
    return AdapterBackedTool(spec=spec, adapter=adapter)
