"""Built-in adapter implementations."""

from .function_adapter import FunctionAdapter, FunctionTool
from .http_adapter import HttpApiAdapter, HttpTool
from .subprocess_adapter import SubprocessAdapter, SubprocessTool
from .ml_model_adapter import MLModelAdapter, MLModelTool

# Optional adapters — only importable when extra dependencies are installed
_optional: list[str] = []
try:
    from .grpc_adapter import GrpcAdapter, GrpcTool  # noqa: F401
    _optional += ["GrpcAdapter", "GrpcTool"]
except Exception:
    pass

try:
    from .websocket_adapter import WebSocketAdapter, WebSocketTool  # noqa: F401
    _optional += ["WebSocketAdapter", "WebSocketTool"]
except Exception:
    pass

__all__ = [
    "FunctionAdapter",
    "FunctionTool",
    "HttpApiAdapter",
    "HttpTool",
    "SubprocessAdapter",
    "SubprocessTool",
    "MLModelAdapter",
    "MLModelTool",
] + _optional

# ── Auto-register adapter types in the factory ─────────────────────────

def _register_builtin_adapter_types() -> None:
    """Register built-in adapters so ``create_adapter()`` can resolve them."""
    from ..factory.tool_factory import register_adapter_type
    register_adapter_type("function", FunctionAdapter)
    register_adapter_type("http", HttpApiAdapter)
    register_adapter_type("subprocess", SubprocessAdapter)
    register_adapter_type("ml_model", MLModelAdapter)

_register_builtin_adapter_types()
