"""Adapter for WebSocket endpoints.

Requires the ``websockets`` extra::

    pip install tool-interface-adapter[websockets]

When ``websockets`` is not installed the adapter raises :class:`ToolConfigError`
at construction time with a clear install hint.
"""

from __future__ import annotations

import json
from typing import Any

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolConfigError, ToolConnectionError, ToolExecutionError, ToolTimeoutError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus

try:
    import websockets  # type: ignore[import]
    import websockets.asyncio.client as _ws_client  # type: ignore[import]
    _has_websockets = True
except ImportError:
    _has_websockets = False


def _require_websockets() -> None:
    if not _has_websockets:
        raise ToolConfigError(
            "websockets is not installed. Install it with: pip install websockets>=12.0",
            details={"hint": "pip install tool-interface-adapter[websockets]"},
        )


class WebSocketAdapter(AbstractAdapter):
    """Adapter that communicates with a WebSocket endpoint.

    Sends a message, waits for one response, and returns it.  For
    streaming use-cases subclass and override :pymeth:`send`.

    Config ``connection_params`` keys:
        url (str): WebSocket URL, e.g. ``"ws://localhost:8000/ws"``.
        message_format (str): ``"json"`` (default), ``"text"``, or ``"bytes"``.
        response_timeout (float): Seconds to wait for a response.  Default 30.
        extra_headers (dict | None): Additional HTTP headers on connect.

    Example::

        adapter = WebSocketAdapter(config=AdapterConfig(
            connection_params={
                "url": "ws://localhost:8765",
                "message_format": "json",
                "response_timeout": 10.0,
            }
        ))
        async with adapter:
            req = adapter.translate_request({"query": "hello"}, spec)
            resp = await adapter.send(req)
    """

    def __init__(self, config: AdapterConfig | None = None) -> None:
        _require_websockets()
        super().__init__(config)
        conn = self._config.connection_params
        self._url: str = conn.get("url", "")
        self._message_format: str = conn.get("message_format", "json")
        self._response_timeout: float = conn.get("response_timeout", 30.0)
        self._extra_headers: dict | None = conn.get("extra_headers")
        self._ws = None
        self._connected = False

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def connect(self) -> None:
        if not self._url:
            raise ToolConfigError("WebSocketAdapter requires 'url' in connection_params")
        try:
            kwargs: dict[str, Any] = {}
            if self._extra_headers:
                kwargs["additional_headers"] = self._extra_headers
            self._ws = await _ws_client.connect(self._url, **kwargs)
            self._connected = True
        except Exception as exc:
            raise ToolConnectionError(
                f"Failed to connect to WebSocket '{self._url}'",
                details={"url": self._url},
                previous=exc,
            ) from exc

    async def disconnect(self) -> None:
        if self._ws is not None:
            await self._ws.close()
            self._ws = None
        self._connected = False

    # ── Request / Response ───────────────────────────────────────────────

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        if self._message_format == "json":
            payload = json.dumps(params)
        else:
            payload = params  # text or bytes passed through
        return AdapterRequest(
            method="WS",
            params={"payload": payload, "format": self._message_format},
        )

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        if not self._connected or self._ws is None:
            raise ToolConnectionError("WebSocketAdapter is not connected")
        import asyncio
        payload = request.params.get("payload", "")
        try:
            await self._ws.send(payload)
            raw = await asyncio.wait_for(
                self._ws.recv(), timeout=self._response_timeout
            )
        except asyncio.TimeoutError:
            raise ToolTimeoutError(
                f"WebSocket response timed out after {self._response_timeout}s",
                details={"url": self._url, "timeout": self._response_timeout},
            )
        except Exception as exc:
            raise ToolExecutionError(
                f"WebSocket communication error: {exc}",
                details={"url": self._url},
                previous=exc,
            ) from exc

        if self._message_format == "json":
            try:
                body = json.loads(raw) if isinstance(raw, (str, bytes)) else raw
            except (json.JSONDecodeError, TypeError):
                body = {"raw": raw}
        else:
            body = {"data": raw}

        return AdapterResponse(status_code=200, body=body)

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        if not response.ok:
            raise ToolExecutionError(
                f"WebSocket error (status {response.status_code})",
                details=response.metadata,
            )
        return response.body

    async def health_check(self) -> HealthStatus:
        if not self._connected or self._ws is None:
            return HealthStatus.UNHEALTHY
        try:
            await self._ws.ping()
            return HealthStatus.HEALTHY
        except Exception:
            return HealthStatus.DEGRADED

    def __repr__(self) -> str:
        return (
            f"<WebSocketAdapter url={self._url!r} "
            f"format={self._message_format!r} connected={self._connected}>"
        )


class WebSocketTool(AbstractTool):
    """Convenience: a tool backed by a WebSocket endpoint.

    Example::

        tool = WebSocketTool(
            spec=ToolSpec(name="chat.send", description="Send a chat message"),
            url="ws://localhost:8765",
            message_format="json",
        )
        result = await tool.execute({"text": "Hello"})
    """

    def __init__(
        self,
        spec: ToolSpec,
        *,
        url: str = "",
        message_format: str = "json",
        response_timeout: float = 30.0,
        extra_headers: dict | None = None,
    ) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = WebSocketAdapter(
            config=AdapterConfig(
                adapter_type="websocket",
                connection_params={
                    "url": url,
                    "message_format": message_format,
                    "response_timeout": response_timeout,
                    "extra_headers": extra_headers,
                },
            )
        )

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        if not self._adapter._connected:
            await self._adapter.connect()
        request = self._adapter.translate_request(dict(params), self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        return await self._adapter.health_check()
