"""Adapter for ML model inference.

Wraps any object that follows the ``predict`` / ``__call__`` convention
(scikit-learn estimators, PyTorch modules, HuggingFace pipelines, custom
models) behind the unified adapter interface.
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable, Protocol, runtime_checkable

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolConfigError, ToolExecutionError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus


@runtime_checkable
class PredictableModel(Protocol):
    """Structural protocol for model-like objects."""

    def predict(self, *args: Any, **kwargs: Any) -> Any: ...


class MLModelAdapter(AbstractAdapter):
    """Adapter that wraps ML model inference.

    Supports models with any of these interfaces (checked in order):
    1. ``async predict(...)`` — async-native model
    2. ``predict(...)`` — sklearn-style
    3. ``__call__(...)`` — HuggingFace pipeline / PyTorch module style

    Args:
        model: The model object to wrap.
        predict_fn: Optional explicit predict callable (overrides model method detection).
        preprocessor: Optional callable to transform input before model call.
        postprocessor: Optional callable to transform model output.
        config: Optional adapter configuration.

    Config ``connection_params`` keys:
        model_name (str): Human-readable model identifier.
        batch_size (int): Max batch size hint.
        device (str): Device hint (``"cpu"``, ``"cuda:0"``, etc.).
    """

    def __init__(
        self,
        model: Any,
        *,
        predict_fn: Callable[..., Any] | None = None,
        preprocessor: Callable[[dict[str, Any]], Any] | None = None,
        postprocessor: Callable[[Any], Any] | None = None,
        config: AdapterConfig | None = None,
    ) -> None:
        super().__init__(config)
        self._model = model
        self._preprocessor = preprocessor
        self._postprocessor = postprocessor

        # Resolve the predict function
        if predict_fn is not None:
            self._predict_fn = predict_fn
        elif hasattr(model, "predict"):
            self._predict_fn = model.predict
        elif callable(model):
            self._predict_fn = model
        else:
            raise ToolConfigError(
                "Model must have a 'predict' method, be callable, or provide predict_fn",
                details={"model_type": type(model).__name__},
            )
        self._is_async = asyncio.iscoroutinefunction(self._predict_fn)
        self._connected = True

    # ── Lifecycle ───────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    # ── Request / Response ──────────────────────────────────────────────

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        model_input = request.params.get("input")
        try:
            if self._is_async:
                raw_output = await self._predict_fn(model_input)
            else:
                loop = asyncio.get_running_loop()
                raw_output = await loop.run_in_executor(
                    None, lambda: self._predict_fn(model_input)
                )
            return AdapterResponse(status_code=200, body=raw_output)
        except Exception as exc:
            return AdapterResponse(
                status_code=500,
                body=None,
                metadata={"error": str(exc), "exception_type": type(exc).__name__},
            )

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        model_input = params
        if self._preprocessor is not None:
            model_input = self._preprocessor(params)
        return AdapterRequest(
            method="PREDICT",
            params={"input": model_input},
        )

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        if not response.ok:
            error_msg = response.metadata.get("error", "Model inference failed")
            raise ToolExecutionError(error_msg, details=response.metadata)
        output = response.body
        if self._postprocessor is not None:
            output = self._postprocessor(output)
        return output

    @property
    def model(self) -> Any:
        """The wrapped model object."""
        return self._model

    @property
    def model_name(self) -> str:
        conn = self._config.connection_params
        if "model_name" in conn:
            return conn["model_name"]
        return type(self._model).__name__

    def __repr__(self) -> str:
        return f"<MLModelAdapter model={self.model_name} async={self._is_async}>"


class MLModelTool(AbstractTool):
    """Convenience: a tool backed by an ML model.

    Example::

        from sklearn.linear_model import LinearRegression
        model = LinearRegression()
        model.fit(X_train, y_train)

        tool = MLModelTool(
            spec=ToolSpec(name="ml.predict_price", description="Predict house price"),
            model=model,
            preprocessor=lambda p: [[p["sqft"], p["bedrooms"]]],
            postprocessor=lambda pred: {"price": float(pred[0])},
        )
        result = await tool.execute({"sqft": 1500, "bedrooms": 3})
    """

    def __init__(
        self,
        spec: ToolSpec,
        model: Any,
        *,
        predict_fn: Callable[..., Any] | None = None,
        preprocessor: Callable[[dict[str, Any]], Any] | None = None,
        postprocessor: Callable[[Any], Any] | None = None,
    ) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = MLModelAdapter(
            model,
            predict_fn=predict_fn,
            preprocessor=preprocessor,
            postprocessor=postprocessor,
        )

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        request = self._adapter.translate_request(params, self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        return HealthStatus.HEALTHY if self._adapter.is_connected else HealthStatus.UNHEALTHY
