"""HTTP/REST API adapter.

When ``api_client_base`` is installed, this adapter delegates to
:class:`AsyncAPIClient` for full-featured HTTP transport (auth, retry,
rate-limiting, circuit breaker).  When the package is absent, a
lightweight fallback using :mod:`urllib.request` is provided so the
core package remains dependency-free.
"""

from __future__ import annotations

import json as _json
import urllib.error
import urllib.request
from typing import Any

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolConnectionError, ToolExecutionError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus

try:
    from api_client_base import APIClientConfig, AsyncAPIClient
    _HAS_API_CLIENT = True
except ImportError:  # pragma: no cover
    _HAS_API_CLIENT = False


class HttpAdapterConfig(AdapterConfig):
    """Extended config for HTTP adapters.

    Attributes on ``connection_params``:
        base_url (str): Base URL for the API (e.g. ``"https://api.example.com/v1"``).
        default_headers (dict): Headers sent with every request.

    Attributes on ``auth_params``:
        type (str): ``"api_key"`` | ``"bearer"``
        api_key / token (str): Credential value.
        header_name (str): Header to place the credential in (default ``"Authorization"``).
    """
    pass


class HttpApiAdapter(AbstractAdapter):
    """REST API adapter with optional ``api_client_base`` integration.

    Usage with ``api_client_base`` (recommended)::

        config = AdapterConfig(
            adapter_type="http",
            connection_params={"base_url": "https://api.example.com"},
            auth_params={"type": "bearer", "token": "sk-..."},
        )
        adapter = HttpApiAdapter(config=config)
        async with adapter:
            ...

    Falls back to :mod:`urllib.request` when ``api_client_base`` is not
    installed (no auth, retry, or rate-limiting in fallback mode).
    """

    def __init__(self, config: AdapterConfig | None = None) -> None:
        super().__init__(config)
        self._client: Any | None = None  # AsyncAPIClient or None
        self._base_url: str = self._config.connection_params.get("base_url", "")

    # ── Lifecycle ───────────────────────────────────────────────────────

    async def connect(self) -> None:
        if _HAS_API_CLIENT:
            api_config = self._build_api_client_config()
            self._client = AsyncAPIClient(api_config)
            await self._client.__aenter__()
        self._connected = True

    async def disconnect(self) -> None:
        if self._client is not None:
            await self._client.__aexit__(None, None, None)
            self._client = None
        self._connected = False

    # ── Request / Response ──────────────────────────────────────────────

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        if _HAS_API_CLIENT and self._client is not None:
            return await self._send_via_api_client(request)
        return await self._send_via_urllib(request)

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        conn = self._config.connection_params
        method = conn.get("method", "GET").upper()
        endpoint = conn.get("endpoint", "")
        default_headers = dict(conn.get("default_headers", {}))

        # Map tool params to query params or JSON body based on method
        param_mapping = conn.get("param_mapping", {})
        mapped: dict[str, Any] = {}
        for tool_key, api_key in param_mapping.items():
            if tool_key in params:
                mapped[api_key] = params[tool_key]
        # Pass through unmapped params
        for k, v in params.items():
            if k not in param_mapping:
                mapped[k] = v

        if method in ("GET", "DELETE", "HEAD"):
            return AdapterRequest(
                method=method,
                url=endpoint,
                headers=default_headers,
                params=mapped,
            )
        else:
            default_headers.setdefault("Content-Type", "application/json")
            return AdapterRequest(
                method=method,
                url=endpoint,
                headers=default_headers,
                body=mapped,
            )

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        if not response.ok:
            raise ToolExecutionError(
                f"HTTP {response.status_code}",
                details={"status_code": response.status_code, "body": response.body},
            )
        return response.body

    # ── Private helpers ─────────────────────────────────────────────────

    def _build_api_client_config(self) -> Any:
        """Build an ``APIClientConfig`` from our adapter config."""
        conn = self._config.connection_params
        auth_params = self._config.auth_params

        kwargs: dict[str, Any] = {
            "base_url": self._base_url,
            "timeout": self._config.timeout,
        }

        # Build auth strategy if credentials are provided
        if auth_params:
            auth_type = auth_params.get("type", "")
            if auth_type == "api_key":
                from api_client_base import APIKeyAuth
                kwargs["auth_strategy"] = APIKeyAuth(
                    api_key=auth_params["api_key"],
                    header_name=auth_params.get("header_name", "Authorization"),
                    prefix=auth_params.get("prefix", "Bearer"),
                )
            elif auth_type == "bearer":
                from api_client_base import BearerTokenAuth
                kwargs["auth_strategy"] = BearerTokenAuth(
                    token=auth_params["token"],
                )

        return APIClientConfig(**kwargs)

    async def _send_via_api_client(self, request: AdapterRequest) -> AdapterResponse:
        """Send using ``api_client_base.AsyncAPIClient``."""
        method = request.method.lower()
        call = getattr(self._client, method, None)
        if call is None:
            call = self._client.request
            kwargs: dict[str, Any] = {"method": request.method, "path": request.url}
        else:
            kwargs = {"path": request.url}

        if request.params:
            kwargs["params"] = request.params
        if request.body is not None:
            kwargs["json"] = request.body
        if request.headers:
            kwargs["headers"] = request.headers

        resp = await call(**kwargs)
        return AdapterResponse(
            status_code=resp.status_code,
            headers=dict(getattr(resp, "headers", {})),
            body=resp.body,
            raw=resp,
        )

    async def _send_via_urllib(self, request: AdapterRequest) -> AdapterResponse:
        """Lightweight fallback when ``api_client_base`` is not installed."""
        import asyncio

        url = self._base_url.rstrip("/") + "/" + request.url.lstrip("/")

        # Append query params for GET
        if request.params:
            from urllib.parse import urlencode
            url += ("&" if "?" in url else "?") + urlencode(request.params)

        headers = dict(request.headers)
        # Apply simple auth from config
        auth_params = self._config.auth_params
        if auth_params:
            auth_type = auth_params.get("type", "")
            header_name = auth_params.get("header_name", "Authorization")
            if auth_type == "bearer" and "token" in auth_params:
                headers[header_name] = f"Bearer {auth_params['token']}"
            elif auth_type == "api_key" and "api_key" in auth_params:
                prefix = auth_params.get("prefix", "Bearer")
                val = f"{prefix} {auth_params['api_key']}" if prefix else auth_params["api_key"]
                headers[header_name] = val

        data = None
        if request.body is not None:
            data = _json.dumps(request.body).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")

        req = urllib.request.Request(url, data=data, headers=headers, method=request.method)

        loop = asyncio.get_running_loop()
        try:
            resp = await loop.run_in_executor(None, lambda: urllib.request.urlopen(req, timeout=self._config.timeout))
            body_bytes = resp.read()
            try:
                body = _json.loads(body_bytes)
            except (ValueError, _json.JSONDecodeError):
                body = body_bytes.decode("utf-8", errors="replace")
            return AdapterResponse(
                status_code=resp.status,
                headers=dict(resp.headers),
                body=body,
                raw=resp,
            )
        except urllib.error.HTTPError as exc:
            body_bytes = exc.read()
            try:
                body = _json.loads(body_bytes)
            except Exception:
                body = body_bytes.decode("utf-8", errors="replace")
            return AdapterResponse(status_code=exc.code, body=body, raw=exc)
        except urllib.error.URLError as exc:
            raise ToolConnectionError(
                f"Connection failed: {exc.reason}",
                previous=exc,
            )

    def __repr__(self) -> str:
        backend = "api_client_base" if _HAS_API_CLIENT else "urllib"
        return f"<HttpApiAdapter base_url={self._base_url!r} backend={backend} connected={self._connected}>"


class HttpTool(AbstractTool):
    """Convenience: a tool backed by an HTTP API endpoint.

    Example::

        tool = HttpTool(
            spec=ToolSpec(name="weather.current", description="Get weather"),
            config=AdapterConfig(
                adapter_type="http",
                connection_params={
                    "base_url": "https://api.weather.com",
                    "endpoint": "/current",
                    "method": "GET",
                    "param_mapping": {"city": "q"},
                },
                auth_params={"type": "api_key", "api_key": "sk-..."},
            ),
        )
    """

    def __init__(self, spec: ToolSpec, config: AdapterConfig) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = HttpApiAdapter(config=config)

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        if not self._adapter.is_connected:
            await self._adapter.connect()
        request = self._adapter.translate_request(params, self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        if not self._adapter.is_connected:
            return HealthStatus.UNHEALTHY
        return HealthStatus.HEALTHY
