"""Adapter that wraps CLI tools and shell commands."""

from __future__ import annotations

import asyncio
import shlex
from typing import Any

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolExecutionError, ToolTimeoutError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus


class SubprocessAdapter(AbstractAdapter):
    """Adapter that executes shell commands / CLI tools as subprocesses.

    The adapter translates tool parameters into command-line arguments and
    captures stdout, stderr, and the return code.

    Config ``connection_params`` keys:
        command (str | list[str]): Base command (e.g. ``"curl"`` or ``["python", "-m", "mymod"]``).
        shell (bool): If ``True``, run through the shell.  Default ``False``.
        cwd (str | None): Working directory.  Default ``None`` (inherit).
        env (dict | None): Extra environment variables merged with the current env.
        timeout (float | None): Per-execution timeout in seconds.  Overrides adapter-level timeout.

    Tool parameters are appended as positional args by default.  To customise,
    provide an ``arg_builder`` key in ``connection_params`` — a dotted path
    to a callable that receives ``(params, spec)`` and returns ``list[str]``.
    """

    def __init__(self, config: AdapterConfig | None = None) -> None:
        super().__init__(config)
        conn = self._config.connection_params
        base = conn.get("command", [])
        self._base_command: list[str] = shlex.split(base) if isinstance(base, str) else list(base)
        self._shell: bool = conn.get("shell", False)
        self._cwd: str | None = conn.get("cwd")
        self._extra_env: dict[str, str] | None = conn.get("env")
        self._timeout: float | None = conn.get("timeout", self._config.timeout)
        self._connected = True  # subprocesses are always "available"

    # ── Lifecycle ───────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    # ── Request / Response ──────────────────────────────────────────────

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        cmd = request.params.get("cmd", [])
        env = request.params.get("env")
        stdin_data = request.params.get("stdin")
        timeout = request.params.get("timeout", self._timeout)

        try:
            if self._shell:
                cmd_str = " ".join(cmd) if isinstance(cmd, list) else cmd
                proc = await asyncio.create_subprocess_shell(
                    cmd_str,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=self._cwd,
                    env=env,
                )
            else:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=self._cwd,
                    env=env,
                )

            stdin_bytes = stdin_data.encode() if isinstance(stdin_data, str) else stdin_data
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=stdin_bytes),
                timeout=timeout,
            )

            return AdapterResponse(
                status_code=200 if proc.returncode == 0 else 500,
                body={
                    "stdout": stdout.decode("utf-8", errors="replace") if stdout else "",
                    "stderr": stderr.decode("utf-8", errors="replace") if stderr else "",
                    "returncode": proc.returncode,
                },
                metadata={"returncode": proc.returncode},
            )

        except asyncio.TimeoutError:
            proc.kill()
            raise ToolTimeoutError(
                f"Subprocess timed out after {timeout}s",
                details={"command": cmd, "timeout": timeout},
            )

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        """Build command-line args from tool params.

        Default strategy: append ``--key value`` flags for each param.
        Booleans become ``--flag`` (when True) or are omitted (when False).
        A special ``_args`` key provides positional arguments.
        A special ``_stdin`` key provides stdin data.
        """
        cmd = list(self._base_command)
        stdin_data = params.pop("_stdin", None) if isinstance(params, dict) else None
        positional = params.pop("_args", []) if isinstance(params, dict) else []

        for key, value in params.items():
            if key.startswith("_"):
                continue
            flag = f"--{key.replace('_', '-')}"
            if isinstance(value, bool):
                if value:
                    cmd.append(flag)
            elif isinstance(value, list):
                for item in value:
                    cmd.extend([flag, str(item)])
            else:
                cmd.extend([flag, str(value)])

        cmd.extend(str(a) for a in positional)

        env = None
        if self._extra_env:
            import os
            env = {**os.environ, **self._extra_env}

        return AdapterRequest(
            method="EXEC",
            params={"cmd": cmd, "env": env, "stdin": stdin_data, "timeout": self._timeout},
        )

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        body = response.body
        if not response.ok:
            raise ToolExecutionError(
                f"Command failed with return code {body.get('returncode', -1)}",
                details=body,
            )
        return body

    def __repr__(self) -> str:
        cmd_str = " ".join(self._base_command) if self._base_command else "(no command)"
        return f"<SubprocessAdapter cmd={cmd_str!r} shell={self._shell}>"


class SubprocessTool(AbstractTool):
    """Convenience: a tool backed by a CLI command.

    Example::

        tool = SubprocessTool(
            spec=ToolSpec(name="sys.disk_usage", description="Check disk usage"),
            command="df -h",
        )
        result = await tool.execute({"_args": ["/home"]})
    """

    def __init__(
        self,
        spec: ToolSpec,
        command: str | list[str],
        *,
        shell: bool = False,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = SubprocessAdapter(
            config=AdapterConfig(
                adapter_type="subprocess",
                connection_params={
                    "command": command,
                    "shell": shell,
                    "cwd": cwd,
                    "env": env,
                    "timeout": timeout,
                },
            )
        )

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        request = self._adapter.translate_request(dict(params), self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        return HealthStatus.HEALTHY
