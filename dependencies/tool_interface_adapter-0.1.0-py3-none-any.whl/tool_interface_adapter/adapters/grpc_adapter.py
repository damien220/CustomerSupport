"""Adapter for gRPC services.

Requires the ``grpcio`` extra::

    pip install tool-interface-adapter[grpc]

When ``grpcio`` is not installed the adapter raises :class:`ToolConfigError`
at construction time with a clear install hint.
"""

from __future__ import annotations

from typing import Any, Callable

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolConfigError, ToolConnectionError, ToolExecutionError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus

try:
    import grpc as _grpc  # type: ignore[import]
    _has_grpc = True
except ImportError:
    _has_grpc = False


def _require_grpc() -> None:
    if not _has_grpc:
        raise ToolConfigError(
            "grpcio is not installed. Install it with: pip install grpcio>=1.60",
            details={"hint": "pip install tool-interface-adapter[grpc]"},
        )


class GrpcAdapter(AbstractAdapter):
    """Adapter that calls methods on a gRPC service stub.

    Config ``connection_params`` keys:
        service_url (str): gRPC server address, e.g. ``"localhost:50051"``.
        stub_factory (callable): Accepts a :class:`grpc.Channel` and returns a
            gRPC stub instance.  E.g. ``MyServiceStub``.
        method (str): Name of the RPC method to call on the stub.
        use_ssl (bool): Whether to use a secure channel.  Default ``False``.
        request_factory (callable | None): ``(params) -> proto_message``.
            When ``None`` the params dict is passed directly (works for
            dynamic stubs and test doubles).
        response_parser (callable | None): ``(response) -> dict``.
            When ``None``, ``response.__dict__`` is used.

    Example::

        adapter = GrpcAdapter(config=AdapterConfig(
            connection_params={
                "service_url": "localhost:50051",
                "stub_factory": GreeterStub,
                "method": "SayHello",
                "request_factory": lambda p: HelloRequest(name=p["name"]),
                "response_parser": lambda r: {"message": r.message},
            }
        ))
        await adapter.connect()
        req = adapter.translate_request({"name": "Alice"}, spec)
        resp = await adapter.send(req)
    """

    def __init__(self, config: AdapterConfig | None = None) -> None:
        _require_grpc()
        super().__init__(config)
        conn = self._config.connection_params
        self._service_url: str = conn.get("service_url", "localhost:50051")
        self._stub_factory: Callable | None = conn.get("stub_factory")
        self._method: str = conn.get("method", "")
        self._use_ssl: bool = conn.get("use_ssl", False)
        self._request_factory: Callable | None = conn.get("request_factory")
        self._response_parser: Callable | None = conn.get("response_parser")
        self._channel = None
        self._stub = None
        self._connected = False

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def connect(self) -> None:
        try:
            if self._use_ssl:
                credentials = _grpc.ssl_channel_credentials()
                self._channel = _grpc.aio.secure_channel(self._service_url, credentials)
            else:
                self._channel = _grpc.aio.insecure_channel(self._service_url)

            if self._stub_factory is not None:
                self._stub = self._stub_factory(self._channel)

            self._connected = True
        except Exception as exc:
            raise ToolConnectionError(
                f"Failed to create gRPC channel to '{self._service_url}'",
                details={"service_url": self._service_url},
                previous=exc,
            ) from exc

    async def disconnect(self) -> None:
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._stub = None
        self._connected = False

    # ── Request / Response ───────────────────────────────────────────────

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        if self._request_factory is not None:
            proto_msg = self._request_factory(params)
        else:
            proto_msg = params  # pass-through for test doubles
        return AdapterRequest(
            method="GRPC",
            params={"proto_message": proto_msg, "grpc_method": self._method},
        )

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        if not self._connected or self._stub is None:
            raise ToolConnectionError("GrpcAdapter is not connected")
        proto_msg = request.params.get("proto_message")
        method_name = request.params.get("grpc_method", self._method)
        try:
            rpc = getattr(self._stub, method_name)
            response = await rpc(proto_msg)
            return AdapterResponse(status_code=200, body=response)
        except Exception as exc:
            raise ToolExecutionError(
                f"gRPC call '{method_name}' failed: {exc}",
                details={"method": method_name},
                previous=exc,
            ) from exc

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        if not response.ok:
            raise ToolExecutionError(
                f"gRPC error (status {response.status_code})",
                details=response.metadata,
            )
        raw = response.body
        if self._response_parser is not None:
            return self._response_parser(raw)
        if hasattr(raw, "__dict__"):
            return {k: v for k, v in raw.__dict__.items() if not k.startswith("_")}
        return raw

    async def health_check(self) -> HealthStatus:
        return HealthStatus.HEALTHY if self._connected else HealthStatus.UNHEALTHY

    def __repr__(self) -> str:
        return (
            f"<GrpcAdapter url={self._service_url!r} "
            f"method={self._method!r} connected={self._connected}>"
        )


class GrpcTool(AbstractTool):
    """Convenience: a tool backed by a gRPC service method.

    Example::

        tool = GrpcTool(
            spec=ToolSpec(name="greeter.say_hello", description="Say hello via gRPC"),
            service_url="localhost:50051",
            stub_factory=GreeterStub,
            method="SayHello",
            request_factory=lambda p: HelloRequest(name=p["name"]),
            response_parser=lambda r: {"message": r.message},
        )
    """

    def __init__(
        self,
        spec: ToolSpec,
        *,
        service_url: str = "localhost:50051",
        stub_factory: Callable | None = None,
        method: str = "",
        use_ssl: bool = False,
        request_factory: Callable | None = None,
        response_parser: Callable | None = None,
    ) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = GrpcAdapter(
            config=AdapterConfig(
                adapter_type="grpc",
                connection_params={
                    "service_url": service_url,
                    "stub_factory": stub_factory,
                    "method": method,
                    "use_ssl": use_ssl,
                    "request_factory": request_factory,
                    "response_parser": response_parser,
                },
            )
        )

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        if not self._adapter._connected:
            await self._adapter.connect()
        request = self._adapter.translate_request(dict(params), self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        return await self._adapter.health_check()
