"""Adapter that wraps any Python callable (sync or async) as a tool."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable

from ..core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_spec import ToolSpec
from ..exceptions import ToolExecutionError
from ..types.configs import AdapterConfig
from ..types.enums import HealthStatus


class FunctionAdapter(AbstractAdapter):
    """Adapter that delegates to a plain Python callable.

    Wraps both synchronous and asynchronous functions.  Sync functions
    are executed in a thread-pool to avoid blocking the event loop.

    Args:
        fn: The callable to wrap.
        config: Optional adapter configuration.
    """

    def __init__(
        self,
        fn: Callable[..., Any],
        config: AdapterConfig | None = None,
    ) -> None:
        super().__init__(config)
        if not callable(fn):
            raise TypeError(f"Expected a callable, got {type(fn).__name__}")
        self._fn = fn
        self._is_async = asyncio.iscoroutinefunction(fn)
        # Functions are always "connected"
        self._connected = True

    # ── Lifecycle (no-ops for functions) ────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    # ── Request / Response ──────────────────────────────────────────────

    async def send(self, request: AdapterRequest) -> AdapterResponse:
        args = request.params.get("args", ())
        kwargs = request.params.get("kwargs", {})
        try:
            if self._is_async:
                result = await self._fn(*args, **kwargs)
            else:
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, lambda: self._fn(*args, **kwargs))
            return AdapterResponse(status_code=200, body=result)
        except Exception as exc:
            return AdapterResponse(
                status_code=500,
                body=None,
                metadata={"error": str(exc), "exception_type": type(exc).__name__},
            )

    def translate_request(self, params: dict[str, Any], spec: ToolSpec) -> AdapterRequest:
        return AdapterRequest(
            method="CALL",
            params={"args": (), "kwargs": params},
        )

    def translate_response(self, response: AdapterResponse, spec: ToolSpec) -> Any:
        if not response.ok:
            error_msg = response.metadata.get("error", "Function call failed")
            raise ToolExecutionError(
                error_msg,
                details=response.metadata,
            )
        return response.body

    @property
    def fn(self) -> Callable[..., Any]:
        """The wrapped callable."""
        return self._fn

    def __repr__(self) -> str:
        name = getattr(self._fn, "__name__", repr(self._fn))
        return f"<FunctionAdapter fn={name} async={self._is_async}>"


class FunctionTool(AbstractTool):
    """Convenience class: a tool backed by a single function.

    This is the simplest way to turn a callable into a full tool::

        def word_count(text: str) -> dict:
            return {"count": len(text.split())}

        tool = FunctionTool(
            spec=ToolSpec(name="text.word_count", description="Count words"),
            fn=word_count,
        )
        result = await tool.execute({"text": "hello world"})
    """

    def __init__(self, spec: ToolSpec, fn: Callable[..., Any]) -> None:
        super().__init__()
        self._spec = spec
        self._adapter = FunctionAdapter(fn)

    @property
    def spec(self) -> ToolSpec:
        return self._spec

    async def _execute(self, params: dict[str, Any], context: ToolContext) -> Any:
        request = self._adapter.translate_request(params, self._spec)
        response = await self._adapter.send(request)
        return self._adapter.translate_response(response, self._spec)

    async def health_check(self) -> HealthStatus:
        return HealthStatus.HEALTHY
