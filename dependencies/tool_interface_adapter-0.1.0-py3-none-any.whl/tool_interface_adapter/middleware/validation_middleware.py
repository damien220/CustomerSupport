"""Explicit input/output validation middleware."""

from __future__ import annotations

from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..core.validation import SchemaValidator
from .abstract_middleware import AbstractToolMiddleware, ToolLike


class ValidationMiddleware(AbstractToolMiddleware):
    """Applies additional JSON-schema validation at the middleware layer.

    Useful when you want to enforce extra constraints on top of the tool's
    built-in validation (or when the underlying tool skips it).

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        extra_input_schema: Additional JSON schema for input params.
        extra_output_schema: Additional JSON schema for result data.
        validate_output: Whether to validate the result data.  Default ``False``
            (output validation is already handled inside ``AbstractTool``).
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        extra_input_schema: dict[str, Any] | None = None,
        extra_output_schema: dict[str, Any] | None = None,
        validate_output: bool = False,
    ) -> None:
        super().__init__(wrapped)
        self._extra_input_schema = extra_input_schema
        self._extra_output_schema = extra_output_schema
        self._validate_output = validate_output
        self._validator = SchemaValidator()

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        if self._extra_input_schema:
            check = self._validator.validate(params, self._extra_input_schema)
            if not check.valid:
                return ToolResult.fail(
                    "TOOL_VALIDATION_ERROR",
                    f"Extra input validation failed for '{self.name}'",
                    details={"errors": check.errors},
                )

        result = await self._call_next(params, context)

        if self._validate_output and result.success and self._extra_output_schema:
            check = self._validator.validate(result.data, self._extra_output_schema)
            if not check.valid:
                return ToolResult.fail(
                    "TOOL_VALIDATION_ERROR",
                    f"Extra output validation failed for '{self.name}'",
                    details={"errors": check.errors},
                )

        return result

    def _wrap(self, tool: ToolLike) -> ValidationMiddleware:
        return ValidationMiddleware(
            tool,
            extra_input_schema=self._extra_input_schema,
            extra_output_schema=self._extra_output_schema,
            validate_output=self._validate_output,
        )
