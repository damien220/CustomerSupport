"""Execution metrics tracking middleware."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .abstract_middleware import AbstractToolMiddleware, ToolLike


@dataclass
class ToolMetrics:
    """Accumulated execution metrics for a single tool."""

    total_calls: int = 0
    success_count: int = 0
    error_count: int = 0
    total_duration_ms: float = 0.0
    min_duration_ms: float = float("inf")
    max_duration_ms: float = 0.0

    @property
    def avg_duration_ms(self) -> float:
        return self.total_duration_ms / self.total_calls if self.total_calls else 0.0

    @property
    def error_rate(self) -> float:
        return self.error_count / self.total_calls if self.total_calls else 0.0

    def record(self, success: bool, duration_ms: float) -> None:
        """Update counters with a single execution result."""
        self.total_calls += 1
        if success:
            self.success_count += 1
        else:
            self.error_count += 1
        self.total_duration_ms += duration_ms
        self.min_duration_ms = min(self.min_duration_ms, duration_ms)
        self.max_duration_ms = max(self.max_duration_ms, duration_ms)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_calls": self.total_calls,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "error_rate": self.error_rate,
            "total_duration_ms": round(self.total_duration_ms, 3),
            "avg_duration_ms": round(self.avg_duration_ms, 3),
            "min_duration_ms": (
                round(self.min_duration_ms, 3)
                if self.min_duration_ms != float("inf")
                else None
            ),
            "max_duration_ms": round(self.max_duration_ms, 3),
        }


class MetricsMiddleware(AbstractToolMiddleware):
    """Tracks call count, latency, and error rate for every execution.

    Access accumulated data via :attr:`metrics`.

    Example::

        mw = MetricsMiddleware()(tool)
        await mw.execute(params)
        print(mw.metrics.to_dict())
    """

    def __init__(self, wrapped: ToolLike | None = None) -> None:
        super().__init__(wrapped)
        self._metrics = ToolMetrics()

    @property
    def metrics(self) -> ToolMetrics:
        """Accumulated execution metrics."""
        return self._metrics

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        start = time.monotonic()
        result = await self._call_next(params, context)
        duration_ms = (time.monotonic() - start) * 1000
        self._metrics.record(result.success, duration_ms)
        return result

    def _wrap(self, tool: ToolLike) -> MetricsMiddleware:
        return MetricsMiddleware(tool)
