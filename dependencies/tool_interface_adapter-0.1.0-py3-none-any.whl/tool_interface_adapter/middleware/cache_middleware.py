"""Transparent caching middleware."""

from __future__ import annotations

import hashlib
import json
import time
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..types.enums import CachePolicy
from .abstract_middleware import AbstractToolMiddleware, ToolLike

# Optional integration with cache_manager sibling package
try:
    from cache_manager import CacheManager as _CacheManager  # type: ignore[import]
    _has_cache_manager = True
except ImportError:
    _has_cache_manager = False


class CacheMiddleware(AbstractToolMiddleware):
    """Caches successful tool results keyed by parameter hash.

    Skips caching when the context's :attr:`~ToolContext.cache_policy` is
    ``NEVER``.  Forces a cache refresh when the policy is ``REFRESH``.

    Uses an in-process dict by default; pass an external ``cache`` object
    (e.g. from the ``cache_manager`` package) to use a shared/distributed
    cache.

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        ttl: Cache entry lifetime in seconds.  ``None`` means entries never expire.
        cache: Optional external cache object with ``get(key)`` / ``set(key, value, ttl)``
            methods (e.g. from the ``cache_manager`` sibling package).
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        ttl: float | None = 300.0,
        cache: Any | None = None,
    ) -> None:
        super().__init__(wrapped)
        self._ttl = ttl
        self._external_cache = cache
        # Fallback in-process store: key → (ToolResult, expires_at | None)
        self._local: dict[str, tuple[ToolResult, float | None]] = {}

    # ── Cache helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _make_key(tool_name: str, params: dict[str, Any]) -> str:
        payload = json.dumps(
            {"tool": tool_name, "params": params}, sort_keys=True, default=str
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    def _local_get(self, key: str) -> ToolResult | None:
        entry = self._local.get(key)
        if entry is None:
            return None
        result, expires_at = entry
        if expires_at is not None and time.monotonic() > expires_at:
            del self._local[key]
            return None
        return result

    def _local_set(self, key: str, result: ToolResult) -> None:
        expires_at = (time.monotonic() + self._ttl) if self._ttl is not None else None
        self._local[key] = (result, expires_at)

    def _cache_get(self, key: str) -> ToolResult | None:
        if self._external_cache is not None:
            try:
                return self._external_cache.get(key)
            except Exception:
                pass
        return self._local_get(key)

    def _cache_set(self, key: str, result: ToolResult) -> None:
        if self._external_cache is not None:
            try:
                self._external_cache.set(key, result, self._ttl)
                return
            except Exception:
                pass
        self._local_set(key, result)

    # ── Intercept ─────────────────────────────────────────────────────────

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        policy = context.cache_policy

        if policy == CachePolicy.NEVER:
            return await self._call_next(params, context)

        key = self._make_key(self.name, params)

        if policy != CachePolicy.REFRESH:
            cached = self._cache_get(key)
            if cached is not None:
                return ToolResult(
                    success=cached.success,
                    data=cached.data,
                    error=cached.error,
                    duration_ms=cached.duration_ms,
                    metadata={**cached.metadata, "cache_hit": True},
                    cached=True,
                )

        result = await self._call_next(params, context)
        if result.success:
            self._cache_set(key, result)
        return result

    def _wrap(self, tool: ToolLike) -> CacheMiddleware:
        return CacheMiddleware(tool, ttl=self._ttl, cache=self._external_cache)
