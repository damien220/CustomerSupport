"""Ordered middleware pipeline around a base tool."""

from __future__ import annotations

from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..core.tool_spec import ToolSpec
from ..types.enums import HealthStatus, ToolState
from .abstract_middleware import AbstractToolMiddleware, ToolLike


class MiddlewarePipeline:
    """Composes an ordered list of middleware layers around a base tool.

    Middleware is applied in the order added: the first-added middleware
    becomes the outermost layer (first to intercept each request).

    Example::

        pipeline = MiddlewarePipeline(tool)
        pipeline.add(LoggingMiddleware())
        pipeline.add(CacheMiddleware(ttl=300))
        pipeline.add(RetryMiddleware(max_retries=3))
        result = await pipeline.execute(params)

    The execution chain above is:
        Logging → Cache → Retry → tool
    """

    def __init__(self, tool: ToolLike) -> None:
        self._base_tool = tool
        self._middlewares: list[AbstractToolMiddleware] = []
        self._composed: ToolLike = tool

    # ── Composition ────────────────────────────────────────────────────────

    def add(self, middleware: AbstractToolMiddleware) -> MiddlewarePipeline:
        """Append *middleware* as the new outermost layer.

        Returns *self* for fluent chaining::

            pipeline.add(LoggingMiddleware()).add(RetryMiddleware(max_retries=2))
        """
        self._middlewares.append(middleware)
        self._composed = middleware(self._composed)
        return self

    # ── Tool-like interface ────────────────────────────────────────────────

    @property
    def spec(self) -> ToolSpec:
        return self._base_tool.spec

    @property
    def name(self) -> str:
        return self._base_tool.spec.name

    @property
    def state(self) -> ToolState:
        if hasattr(self._base_tool, "state"):
            return self._base_tool.state  # type: ignore[union-attr]
        return ToolState.READY

    async def execute(
        self, params: dict[str, Any], context: ToolContext | None = None
    ) -> ToolResult:
        ctx = context or ToolContext()
        return await self._composed.execute(params, ctx)

    async def health_check(self) -> HealthStatus:
        return await self._base_tool.health_check()

    def __repr__(self) -> str:
        layers = " → ".join(type(m).__name__ for m in self._middlewares)
        return f"<MiddlewarePipeline [{layers} → {self._base_tool.spec.name}]>"
