"""Structured logging middleware."""

from __future__ import annotations

import logging
import time
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .abstract_middleware import AbstractToolMiddleware, ToolLike

# Optional integration with logger_pkg sibling package
try:
    from logger_pkg import get_logger as _pkg_get_logger  # type: ignore[import]
    _has_logger_pkg = True
except ImportError:
    _has_logger_pkg = False


def _make_logger(name: str) -> logging.Logger:
    if _has_logger_pkg:
        return _pkg_get_logger(name)  # type: ignore[return-value]
    return logging.getLogger(name)


class LoggingMiddleware(AbstractToolMiddleware):
    """Logs tool execution start, success, and failure.

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        logger: Optional pre-configured logger.  Defaults to one named
            ``tool.<tool_name>``.
        log_params: Whether to include params in log output.  Default ``False``
            (params may contain sensitive data).
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        logger: logging.Logger | None = None,
        log_params: bool = False,
    ) -> None:
        super().__init__(wrapped)
        self._logger = logger
        self._log_params = log_params

    def _get_logger(self) -> logging.Logger:
        if self._logger is not None:
            return self._logger
        return _make_logger(f"tool.{self.name}")

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        log = self._get_logger()
        extra: dict[str, Any] = {
            "tool": self.name,
            "correlation_id": context.correlation_id,
        }
        if self._log_params:
            extra["params"] = params

        log.info("Executing tool '%s'", self.name, extra=extra)
        start = time.monotonic()
        result = await self._call_next(params, context)
        duration_ms = (time.monotonic() - start) * 1000

        if result.success:
            log.info(
                "Tool '%s' succeeded in %.1fms",
                self.name,
                duration_ms,
                extra={**extra, "duration_ms": duration_ms},
            )
        else:
            error_code = result.error.code if result.error else "UNKNOWN"
            log.warning(
                "Tool '%s' failed (%s) in %.1fms",
                self.name,
                error_code,
                duration_ms,
                extra={**extra, "error_code": error_code, "duration_ms": duration_ms},
            )
        return result

    def _wrap(self, tool: ToolLike) -> LoggingMiddleware:
        return LoggingMiddleware(tool, logger=self._logger, log_params=self._log_params)
