"""Lifecycle event emission middleware."""

from __future__ import annotations

import time
from typing import Any, Callable

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .abstract_middleware import AbstractToolMiddleware, ToolLike

# Optional integration with event_dispatcher sibling package
try:
    from event_dispatcher import EventDispatcher as _EventDispatcher  # type: ignore[import]
    _has_event_dispatcher = True
except ImportError:
    _has_event_dispatcher = False

# Simple synchronous event handler callable
EventHandler = Callable[[str, dict[str, Any]], None]


class EventMiddleware(AbstractToolMiddleware):
    """Emits lifecycle events before and after tool execution.

    Events emitted:
        ``tool.executing`` — fired before execution begins.
        ``tool.succeeded`` — fired after a successful result.
        ``tool.failed``    — fired after a failed result.

    Payloads include ``tool`` (name) and ``correlation_id``.  Success/failure
    payloads additionally include ``duration_ms`` and ``data`` / ``error``.

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        dispatcher: Optional dispatcher object with an ``emit(event, payload)``
            method (e.g. from the ``event_dispatcher`` sibling package).
        handlers: Dict of ``{event_name: handler_callable}`` for in-process
            subscriptions.  Use :pymeth:`on` to add handlers after construction.
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        dispatcher: Any | None = None,
        handlers: dict[str, EventHandler] | None = None,
    ) -> None:
        super().__init__(wrapped)
        self._dispatcher = dispatcher
        # Internal handler registry: event → list of callables
        self._handlers: dict[str, list[EventHandler]] = {}
        if handlers:
            for event, handler in handlers.items():
                self._handlers.setdefault(event, []).append(handler)

    def on(self, event: str, handler: EventHandler) -> None:
        """Register a local handler for *event*."""
        self._handlers.setdefault(event, []).append(handler)

    def _emit(self, event: str, payload: dict[str, Any]) -> None:
        if self._dispatcher is not None and hasattr(self._dispatcher, "emit"):
            try:
                self._dispatcher.emit(event, payload)
            except Exception:
                pass
        for handler in self._handlers.get(event, []):
            try:
                handler(event, payload)
            except Exception:
                pass

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        base = {"tool": self.name, "correlation_id": context.correlation_id}

        self._emit("tool.executing", {**base})

        start = time.monotonic()
        result = await self._call_next(params, context)
        duration_ms = (time.monotonic() - start) * 1000

        if result.success:
            self._emit("tool.succeeded", {
                **base,
                "duration_ms": duration_ms,
                "data": result.data,
            })
        else:
            self._emit("tool.failed", {
                **base,
                "duration_ms": duration_ms,
                "error": result.error.code if result.error else "UNKNOWN",
            })

        return result

    def _wrap(self, tool: ToolLike) -> EventMiddleware:
        new_mw = EventMiddleware(tool, dispatcher=self._dispatcher)
        # Copy all registered handlers to the new instance
        for event, handlers in self._handlers.items():
            for handler in handlers:
                new_mw.on(event, handler)
        return new_mw
