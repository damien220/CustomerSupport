"""Retry middleware with configurable exponential back-off."""

from __future__ import annotations

import asyncio
from typing import Any, Sequence

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .abstract_middleware import AbstractToolMiddleware, ToolLike


class RetryMiddleware(AbstractToolMiddleware):
    """Retries failed tool executions with exponential back-off.

    Args:
        wrapped: The tool or middleware to wrap (can be supplied later via ``__call__``).
        max_retries: Maximum number of additional attempts after the first failure.
        backoff: Base delay in seconds between retries (doubles each attempt).
        retryable_errors: Sequence of error codes that trigger a retry.  When
            ``None`` (the default) every failure is retried.
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        max_retries: int = 3,
        backoff: float = 0.5,
        retryable_errors: Sequence[str] | None = None,
    ) -> None:
        super().__init__(wrapped)
        self._max_retries = max_retries
        self._backoff = backoff
        self._retryable_errors: frozenset[str] | None = (
            frozenset(retryable_errors) if retryable_errors is not None else None
        )

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        last_result: ToolResult | None = None
        for attempt in range(self._max_retries + 1):
            result = await self._call_next(params, context)
            if result.success:
                return result
            # Check if this error code is eligible for retry
            if self._retryable_errors is not None:
                error_code = result.error.code if result.error else ""
                if error_code not in self._retryable_errors:
                    return result
            last_result = result
            if attempt < self._max_retries:
                delay = self._backoff * (2 ** attempt)
                await asyncio.sleep(delay)
        return last_result  # type: ignore[return-value]

    def _wrap(self, tool: ToolLike) -> RetryMiddleware:
        return RetryMiddleware(
            tool,
            max_retries=self._max_retries,
            backoff=self._backoff,
            retryable_errors=list(self._retryable_errors) if self._retryable_errors is not None else None,
        )
