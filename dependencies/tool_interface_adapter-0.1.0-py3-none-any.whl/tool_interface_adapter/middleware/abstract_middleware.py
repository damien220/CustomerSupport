"""Abstract base class for all middleware layers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Union

from ..core.abstract_tool import AbstractTool
from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from ..core.tool_spec import ToolSpec
from ..types.enums import HealthStatus, ToolState

# Anything that satisfies the tool interface (AbstractTool or another middleware)
ToolLike = Union[AbstractTool, "AbstractToolMiddleware"]


class AbstractToolMiddleware(ABC):
    """Wraps a tool or another middleware, adding cross-cutting concerns.

    Subclasses override :pymeth:`_intercept` to add behaviour before/after
    the inner call.  Call :pymeth:`_call_next` to proceed to the wrapped layer.

    Usage::

        tool = RetryMiddleware(max_retries=3)(tool)
        tool = CacheMiddleware(ttl=300)(tool)
        tool = LoggingMiddleware()(tool)
    """

    def __init__(self, wrapped: ToolLike | None = None) -> None:
        self._wrapped = wrapped

    # ── Tool-like interface ────────────────────────────────────────────────

    @property
    def spec(self) -> ToolSpec:
        assert self._wrapped is not None, "Middleware has no wrapped tool"
        return self._wrapped.spec

    @property
    def name(self) -> str:
        return self.spec.name

    @property
    def state(self) -> ToolState:
        if self._wrapped is not None and hasattr(self._wrapped, "state"):
            return self._wrapped.state  # type: ignore[union-attr]
        return ToolState.READY

    async def execute(
        self, params: dict[str, Any], context: ToolContext | None = None
    ) -> ToolResult:
        """Entry point — delegates to :pymeth:`_intercept`."""
        ctx = context or ToolContext()
        return await self._intercept(params, ctx)

    async def health_check(self) -> HealthStatus:
        """Delegate health check to the wrapped tool."""
        if self._wrapped is not None:
            return await self._wrapped.health_check()
        return HealthStatus.UNKNOWN

    # ── Abstract contract ─────────────────────────────────────────────────

    @abstractmethod
    async def _intercept(
        self, params: dict[str, Any], context: ToolContext
    ) -> ToolResult:
        """Add cross-cutting logic; call :pymeth:`_call_next` to proceed."""
        ...

    @abstractmethod
    def _wrap(self, tool: ToolLike) -> AbstractToolMiddleware:
        """Create a new instance of this middleware configured for *tool*."""
        ...

    # ── Plumbing ──────────────────────────────────────────────────────────

    async def _call_next(
        self, params: dict[str, Any], context: ToolContext
    ) -> ToolResult:
        """Invoke the next layer (wrapped tool or middleware)."""
        assert self._wrapped is not None, "Middleware has no wrapped tool"
        return await self._wrapped.execute(params, context)

    def __call__(self, tool: ToolLike) -> AbstractToolMiddleware:
        """Return a new instance of this middleware wrapping *tool*.

        Allows the pattern ``RetryMiddleware(max_retries=3)(tool)``.
        """
        return self._wrap(tool)

    def __repr__(self) -> str:
        inner = repr(self._wrapped) if self._wrapped else "unwrapped"
        return f"<{type(self).__name__} wrapping {inner}>"
