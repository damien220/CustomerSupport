"""Timeout enforcement middleware."""

from __future__ import annotations

import asyncio
from typing import Any

from ..core.tool_context import ToolContext
from ..core.tool_result import ToolResult
from .abstract_middleware import AbstractToolMiddleware, ToolLike


class TimeoutMiddleware(AbstractToolMiddleware):
    """Enforces a maximum execution time per tool call.

    The effective timeout is resolved in priority order:
    1. ``context.timeout_override``
    2. ``timeout`` passed to this middleware
    3. ``tool.spec.timeout`` (if set on the spec)

    On expiry the call is cancelled and a ``ToolResult.fail`` with code
    ``TOOL_TIMEOUT_ERROR`` is returned (no exception propagated).

    Args:
        wrapped: The tool to wrap (can be supplied later via ``__call__``).
        timeout: Default timeout in seconds.  ``None`` falls through to the spec.
    """

    def __init__(
        self,
        wrapped: ToolLike | None = None,
        *,
        timeout: float | None = None,
    ) -> None:
        super().__init__(wrapped)
        self._timeout = timeout

    def _effective_timeout(self, context: ToolContext) -> float | None:
        if context.timeout_override is not None:
            return context.timeout_override
        if self._timeout is not None:
            return self._timeout
        return getattr(self.spec, "timeout", None)

    async def _intercept(self, params: dict[str, Any], context: ToolContext) -> ToolResult:
        effective = self._effective_timeout(context)
        if effective is None:
            return await self._call_next(params, context)

        try:
            return await asyncio.wait_for(
                self._call_next(params, context),
                timeout=effective,
            )
        except asyncio.TimeoutError:
            return ToolResult.fail(
                "TOOL_TIMEOUT_ERROR",
                f"Tool '{self.name}' timed out after {effective}s",
                details={"tool": self.name, "timeout_s": effective},
            )

    def _wrap(self, tool: ToolLike) -> TimeoutMiddleware:
        return TimeoutMiddleware(tool, timeout=self._timeout)
