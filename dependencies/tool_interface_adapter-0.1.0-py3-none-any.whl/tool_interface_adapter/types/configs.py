"""Configuration dataclasses for tool interface adapter."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class RateLimitSpec:
    """Rate limit constraints for a tool."""

    max_calls: int
    period_seconds: float
    burst: int | None = None


@dataclass
class ToolConfig:
    """Runtime configuration for a tool instance."""

    timeout: float = 30.0
    retries: int = 0
    retry_delay: float = 1.0
    cache_ttl: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AdapterConfig:
    """Configuration for instantiating an adapter."""

    adapter_type: str = "custom"
    connection_params: dict[str, Any] = field(default_factory=dict)
    auth_params: dict[str, Any] = field(default_factory=dict)
    timeout: float = 30.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MiddlewareConfig:
    """Configuration for a middleware layer."""

    enabled: bool = True
    order: int = 0
    params: dict[str, Any] = field(default_factory=dict)
