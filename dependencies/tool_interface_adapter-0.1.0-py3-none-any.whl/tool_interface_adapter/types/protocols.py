"""Duck-typed protocols for tool interface adapter."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from .enums import HealthStatus


@runtime_checkable
class ToolLike(Protocol):
    """Structural protocol for anything that behaves like a tool.

    Use this when you want to accept both AbstractTool subclasses and
    third-party objects that happen to have the right shape.
    """

    @property
    def name(self) -> str: ...

    async def execute(
        self, params: dict[str, Any], context: Any | None = None
    ) -> Any: ...

    async def health_check(self) -> HealthStatus: ...
