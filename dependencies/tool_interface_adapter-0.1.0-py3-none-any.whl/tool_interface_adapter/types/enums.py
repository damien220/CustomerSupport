"""Enumerations for the tool interface adapter package."""

from __future__ import annotations

from enum import Enum, auto


class AdapterType(str, Enum):
    """Identifies the kind of adapter backing a tool."""

    HTTP = "http"
    FUNCTION = "function"
    SUBPROCESS = "subprocess"
    ML_MODEL = "ml_model"
    GRPC = "grpc"
    WEBSOCKET = "websocket"
    CUSTOM = "custom"


class ToolState(str, Enum):
    """Lifecycle state of a tool instance."""

    UNINITIALIZED = "uninitialized"
    READY = "ready"
    EXECUTING = "executing"
    ERROR = "error"
    DISABLED = "disabled"


class CachePolicy(str, Enum):
    """Controls caching behaviour for a tool execution."""

    DEFAULT = "default"
    ALWAYS = "always"
    NEVER = "never"
    REFRESH = "refresh"


class HealthStatus(str, Enum):
    """Result of a tool health check."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"
