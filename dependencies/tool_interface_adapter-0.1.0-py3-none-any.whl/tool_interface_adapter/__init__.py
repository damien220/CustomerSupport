"""Tool Interface / Adapter — abstract adapter for external tools and APIs."""

from ._version import __version__

# ── Core abstractions ───────────────────────────────────────────────────
from .core.abstract_adapter import AbstractAdapter, AdapterRequest, AdapterResponse
from .core.abstract_tool import AbstractTool
from .core.tool_context import ToolContext
from .core.tool_result import ToolError, ToolResult
from .core.tool_spec import ToolSpec
from .core.validation import SchemaValidator, ValidationResult

# ── Types & Enums ───────────────────────────────────────────────────────
from .types.enums import AdapterType, CachePolicy, HealthStatus, ToolState
from .types.configs import AdapterConfig, MiddlewareConfig, RateLimitSpec, ToolConfig
from .types.protocols import ToolLike

# ── Registry ────────────────────────────────────────────────────────────
from .registry.tool_registry import ToolRegistry
from .registry.decorators import get_default_registry, register_tool, set_default_registry
from .registry.discovery import (
    discover_tools_from_directory,
    discover_tools_from_entry_points,
    discover_tools_from_module,
    discover_tools_from_package,
    has_plugin_loader,
)

# ── Factory ───────────────────���─────────────────────────────────────────
from .factory.tool_factory import (
    AdapterBackedTool,
    create_adapter,
    create_tool,
    get_adapter_type,
    list_adapter_types,
    register_adapter_type,
)

# ── Built-in Adapters ───────────────────────────────────────────────────
from .adapters.function_adapter import FunctionAdapter, FunctionTool
from .adapters.http_adapter import HttpApiAdapter, HttpTool
from .adapters.subprocess_adapter import SubprocessAdapter, SubprocessTool
from .adapters.ml_model_adapter import MLModelAdapter, MLModelTool

# ── Integrations ────────────────────────────────────────────────────────
from .integrations import AuditMiddleware, NotificationMiddleware, ToolJobManager

# ── Composition ─────────────────────────────────────────────────────────
from .composition import (
    ChainResult,
    ChainStep,
    GroupResult,
    Pipeline,
    PipelineBranch,
    PipelineResult,
    PipelineStep,
    ToolChain,
    ToolGroup,
)

# ── Middleware ──────────────────────────────────────────────────────────
from .middleware import (
    AbstractToolMiddleware,
    CacheMiddleware,
    EventMiddleware,
    LoggingMiddleware,
    MetricsMiddleware,
    MiddlewarePipeline,
    RetryMiddleware,
    TimeoutMiddleware,
    ToolMetrics,
    ValidationMiddleware,
)

# ── Exceptions ──────────────────────────────────────────────────────────
from .exceptions import (
    ToolAdapterError,
    ToolAuthenticationError,
    ToolConfigError,
    ToolConnectionError,
    ToolExecutionError,
    ToolNotFoundError,
    ToolSchemaError,
    ToolTimeoutError,
    ToolValidationError,
)

__all__ = [
    "__version__",
    # Core ABCs
    "AbstractAdapter",
    "AbstractTool",
    # Core data models
    "AdapterRequest",
    "AdapterResponse",
    "ToolContext",
    "ToolError",
    "ToolResult",
    "ToolSpec",
    # Validation
    "SchemaValidator",
    "ValidationResult",
    # Enums
    "AdapterType",
    "CachePolicy",
    "HealthStatus",
    "ToolState",
    # Configs
    "AdapterConfig",
    "MiddlewareConfig",
    "RateLimitSpec",
    "ToolConfig",
    # Protocols
    "ToolLike",
    # Registry
    "ToolRegistry",
    "get_default_registry",
    "register_tool",
    "set_default_registry",
    # Discovery
    "discover_tools_from_directory",
    "discover_tools_from_entry_points",
    "discover_tools_from_module",
    "discover_tools_from_package",
    "has_plugin_loader",
    # Factory
    "AdapterBackedTool",
    "create_adapter",
    "create_tool",
    "get_adapter_type",
    "list_adapter_types",
    "register_adapter_type",
    # Built-in Adapters
    "FunctionAdapter",
    "FunctionTool",
    "HttpApiAdapter",
    "HttpTool",
    "SubprocessAdapter",
    "SubprocessTool",
    "MLModelAdapter",
    "MLModelTool",
    # Integrations
    "AuditMiddleware",
    "NotificationMiddleware",
    "ToolJobManager",
    # Composition
    "ChainResult",
    "ChainStep",
    "GroupResult",
    "Pipeline",
    "PipelineBranch",
    "PipelineResult",
    "PipelineStep",
    "ToolChain",
    "ToolGroup",
    # Middleware
    "AbstractToolMiddleware",
    "CacheMiddleware",
    "EventMiddleware",
    "LoggingMiddleware",
    "MetricsMiddleware",
    "MiddlewarePipeline",
    "RetryMiddleware",
    "TimeoutMiddleware",
    "ToolMetrics",
    "ValidationMiddleware",
    # Exceptions
    "ToolAdapterError",
    "ToolAuthenticationError",
    "ToolConfigError",
    "ToolConnectionError",
    "ToolExecutionError",
    "ToolNotFoundError",
    "ToolSchemaError",
    "ToolTimeoutError",
    "ToolValidationError",
]
