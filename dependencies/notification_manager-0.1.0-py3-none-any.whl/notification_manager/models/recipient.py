"""Recipient and recipient-group models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ChannelPreferences:
    """Per-recipient channel delivery preferences.

    Attributes
    ----------
    preferred_channels
        Ordered list of channel_ids the recipient prefers. The router
        tries these before falling back to the system default.
    disabled_channels
        Channels the recipient has opted out of. The router skips these.
    quiet_hours_start
        Local time (HH:MM, 24-hour) at which quiet hours begin.
        Notifications with priority < HIGH are deferred until quiet_hours_end.
    quiet_hours_end
        Local time (HH:MM, 24-hour) at which quiet hours end.
    """

    preferred_channels: list[str] = field(default_factory=list)
    disabled_channels: list[str] = field(default_factory=list)
    quiet_hours_start: Optional[str] = None  # e.g. "22:00"
    quiet_hours_end: Optional[str] = None    # e.g. "08:00"


@dataclass
class Recipient:
    """A single notification target.

    Attributes
    ----------
    id
        Stable, application-defined identifier (e.g. user ID).
    channels
        Channel_ids this recipient can be reached on, in preference order.
        If empty, the NotificationManager falls back to default_channel.
    preferences
        Fine-grained delivery preferences (opt-outs, quiet hours).
    timezone
        IANA timezone string (e.g. "America/New_York"). Used by the
        scheduler for quiet-hours calculations.
    locale
        BCP-47 locale tag (e.g. "en-US"). May be used by the template
        engine to select locale-specific templates.
    metadata
        Arbitrary key/value pairs for use by routing rules or plugins.
    """

    id: str
    channels: list[str] = field(default_factory=list)
    preferences: ChannelPreferences = field(default_factory=ChannelPreferences)
    timezone: str = "UTC"
    locale: str = "en"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RecipientGroup:
    """A named collection of recipients for broadcast notifications.

    Attributes
    ----------
    id
        Stable identifier for this group.
    name
        Human-readable label.
    members
        Individual recipients in the group.
    metadata
        Arbitrary key/value pairs (e.g. department, team).
    """

    id: str
    name: str
    members: list[Recipient] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def add(self, recipient: Recipient) -> None:
        """Add a recipient to the group (no-op if already present by id)."""
        if not any(m.id == recipient.id for m in self.members):
            self.members.append(recipient)

    def remove(self, recipient_id: str) -> None:
        """Remove a recipient by id."""
        self.members = [m for m in self.members if m.id != recipient_id]

    def __len__(self) -> int:
        return len(self.members)
