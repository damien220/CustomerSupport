"""Public surface of the models sub-package."""

from notification_manager.models.delivery import (
    DeliveryAttempt,
    DeliveryReceipt,
    DeliveryStatus,
)
from notification_manager.models.message import (
    Attachment,
    Conversation,
    Message,
    ReadReceipt,
    Thread,
)
from notification_manager.models.notification import (
    Notification,
    NotificationStatus,
    Priority,
)
from notification_manager.models.recipient import (
    ChannelPreferences,
    Recipient,
    RecipientGroup,
)
from notification_manager.models.template import (
    NotificationTemplate,
    RenderedContent,
    TemplateVariable,
)

__all__ = [
    # Notification
    "Notification",
    "NotificationStatus",
    "Priority",
    # Recipient
    "Recipient",
    "RecipientGroup",
    "ChannelPreferences",
    # Delivery
    "DeliveryReceipt",
    "DeliveryAttempt",
    "DeliveryStatus",
    # Message
    "Message",
    "Thread",
    "Conversation",
    "ReadReceipt",
    "Attachment",
    # Template
    "NotificationTemplate",
    "TemplateVariable",
    "RenderedContent",
]
