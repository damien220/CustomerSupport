"""Delivery receipt and attempt models.

These objects track the full lifecycle of a single notification's delivery:
which channel was used, how many times it was attempted, and the final outcome.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class DeliveryStatus(Enum):
    """Terminal and intermediate states of a notification delivery."""

    PENDING = "pending"       # Not yet dispatched
    RETRYING = "retrying"     # Previous attempt failed; waiting to retry
    DELIVERED = "delivered"   # Successfully acknowledged by the platform
    FAILED = "failed"         # All retry attempts exhausted without success
    SKIPPED = "skipped"       # Deliberately not sent (rate-limited, opted-out, etc.)


@dataclass
class DeliveryAttempt:
    """Record of a single delivery attempt to a channel.

    Attributes
    ----------
    attempt_number
        1-based counter. First attempt is 1.
    channel_id
        The channel this attempt targeted.
    status
        Outcome of this specific attempt.
    timestamp
        When the attempt was made (UTC).
    error
        Human-readable error description if the attempt failed.
        Must not contain secret values (API keys, tokens).
    duration_ms
        Round-trip time in milliseconds, if measurable.
    metadata
        Additional platform-specific data (e.g. platform message_id on success).
    """

    attempt_number: int
    channel_id: str
    status: DeliveryStatus
    timestamp: datetime = field(default_factory=datetime.utcnow)
    error: Optional[str] = None
    duration_ms: Optional[float] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeliveryReceipt:
    """Tracks the full delivery lifecycle of one notification.

    Returned immediately by NotificationManager.send() with status=PENDING.
    The engine updates it asynchronously as delivery progresses.

    Attributes
    ----------
    notification_id
        Matches Notification.id.
    channel_id
        The channel ultimately used for delivery.
    status
        Current overall delivery status.
    attempts
        Ordered list of all delivery attempts (most recent last).
    delivered_at
        Set to UTC timestamp when status transitions to DELIVERED.
    error
        Final error description if status is FAILED.
        Must not contain secret values.
    metadata
        Additional information (e.g. platform-assigned message IDs).
    """

    notification_id: str
    channel_id: str
    status: DeliveryStatus = DeliveryStatus.PENDING
    attempts: list[DeliveryAttempt] = field(default_factory=list)
    delivered_at: Optional[datetime] = None
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def attempt_count(self) -> int:
        """Number of delivery attempts made so far."""
        return len(self.attempts)

    @property
    def is_terminal(self) -> bool:
        """True when the delivery has reached a final state (no further retries)."""
        return self.status in (
            DeliveryStatus.DELIVERED,
            DeliveryStatus.FAILED,
            DeliveryStatus.SKIPPED,
        )

    def record_attempt(self, attempt: DeliveryAttempt) -> None:
        """Append an attempt and update status and delivered_at accordingly."""
        self.attempts.append(attempt)
        self.status = attempt.status
        if attempt.status == DeliveryStatus.DELIVERED:
            self.delivered_at = attempt.timestamp
        if attempt.status == DeliveryStatus.FAILED:
            self.error = attempt.error
