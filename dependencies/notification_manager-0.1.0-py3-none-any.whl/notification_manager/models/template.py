"""Notification template models.

Templates decouple content authoring from delivery. A NotificationTemplate
defines a reusable skeleton with named placeholders; the template engine
(Phase 6) fills in the placeholders at render time.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class TemplateVariable:
    """Declaration of a single variable used within a NotificationTemplate.

    Attributes
    ----------
    name
        The placeholder name referenced in title_template / body_template
        (e.g. "username", "amount").
    description
        Human-readable explanation of what this variable represents.
    required
        When True, the template engine raises TemplateRenderError if this
        variable is missing from the supplied bindings.
    default
        Value used when the variable is absent and required=False.
    """

    name: str
    description: str = ""
    required: bool = True
    default: Optional[Any] = None


@dataclass
class RenderedContent:
    """The final output of a TemplateEngine.render() call.

    Attributes
    ----------
    title
        Rendered subject line (all placeholders resolved).
    body
        Rendered message body (all placeholders resolved).
    channel_id
        When not None, this content was rendered for a specific channel
        override (e.g. a Slack-specific format).
    metadata
        Any additional data the template engine attaches (e.g. HTML body
        variant, attachment list derived from variables).
    """

    title: str
    body: str
    channel_id: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class NotificationTemplate:
    """A reusable notification skeleton with named placeholders.

    Attributes
    ----------
    name
        Unique, human-readable identifier (e.g. "welcome_email").
    title_template
        Template string for the notification title.
        Uses Jinja2 syntax by default (e.g. "Hello, {{ username }}!").
    body_template
        Template string for the notification body.
    id
        Auto-generated UUID; used as a stable reference key.
    description
        Human-readable explanation of when to use this template.
    variables
        Declares all placeholders, their types, and whether they are required.
    channel_overrides
        Channel-specific templates that override the defaults.
        Structure: {"slack": {"title_template": "...", "body_template": "..."}}
        Useful when a channel has different formatting requirements.
    metadata
        Arbitrary additional data (e.g. version tag, author).
    """

    name: str
    title_template: str
    body_template: str

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    description: str = ""
    variables: list[TemplateVariable] = field(default_factory=list)
    channel_overrides: dict[str, dict[str, str]] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def get_required_variable_names(self) -> list[str]:
        """Return names of all variables that must be supplied at render time."""
        return [v.name for v in self.variables if v.required]

    def get_defaults(self) -> dict[str, Any]:
        """Return a dict of {name: default} for variables that have defaults."""
        return {v.name: v.default for v in self.variables if v.default is not None}

    def has_channel_override(self, channel_id: str) -> bool:
        """True if a channel-specific template exists for the given channel."""
        return channel_id in self.channel_overrides

    def get_channel_title_template(self, channel_id: str) -> str:
        """Return the channel-specific title template, falling back to the default."""
        return self.channel_overrides.get(channel_id, {}).get(
            "title_template", self.title_template
        )

    def get_channel_body_template(self, channel_id: str) -> str:
        """Return the channel-specific body template, falling back to the default."""
        return self.channel_overrides.get(channel_id, {}).get(
            "body_template", self.body_template
        )
