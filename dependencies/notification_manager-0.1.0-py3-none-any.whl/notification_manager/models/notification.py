"""Notification model — the primary unit of work for this package."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from notification_manager.models.recipient import Recipient


class Priority(Enum):
    """Delivery priority levels, ordered lowest → highest."""

    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


class NotificationStatus(Enum):
    """Lifecycle status of a Notification object."""

    PENDING = "pending"         # Created, not yet queued
    QUEUED = "queued"           # Accepted into the priority queue
    DELIVERING = "delivering"   # Actively being sent by a plugin
    DELIVERED = "delivered"     # Successfully delivered
    FAILED = "failed"           # All attempts exhausted
    CANCELLED = "cancelled"     # Explicitly cancelled before delivery
    SCHEDULED = "scheduled"     # Deferred — waiting for scheduled_at


@dataclass
class Notification:
    """A single notification to be delivered to a recipient.

    Attributes
    ----------
    title
        Short subject line (plain text).
    body
        Main content (plain text; plugins may format as needed).
    recipient
        The target of this notification.
    id
        Auto-generated UUID identifying this notification.
    channel_hint
        Preferred channel_id. When set, the router tries this channel first.
        When None, routing falls back to Recipient.preferences and then to
        NotificationManagerConfig.default_channel.
    priority
        Controls ordering in the priority queue. CRITICAL notifications
        are dispatched before LOW regardless of arrival order.
    metadata
        Arbitrary key/value pairs forwarded to the plugin (e.g. deep-link
        URL, icon name, sound preference).
    template_id
        If set, the template engine renders the final title/body from the
        named template + `variables`. The `title` and `body` fields are
        then treated as fallbacks for channels without template support.
    variables
        Variable bindings used when rendering `template_id`.
    scheduled_at
        When set (UTC), the scheduler defers dispatch until this time.
        Notifications with scheduled_at in the past are dispatched immediately.
    idempotency_key
        Used by the engine to de-duplicate re-submissions. Two Notification
        objects with the same idempotency_key will not both be delivered
        within the idempotency TTL window. Defaults to `id`.
    status
        Current lifecycle status. Managed by the engine; do not set manually.
    created_at
        UTC timestamp at object construction.
    """

    title: str
    body: str
    recipient: "Recipient"

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    channel_hint: Optional[str] = None
    priority: Priority = Priority.NORMAL
    metadata: dict[str, Any] = field(default_factory=dict)
    template_id: Optional[str] = None
    variables: dict[str, Any] = field(default_factory=dict)
    scheduled_at: Optional[datetime] = None
    idempotency_key: Optional[str] = None
    status: NotificationStatus = NotificationStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)

    def __post_init__(self) -> None:
        if self.idempotency_key is None:
            self.idempotency_key = self.id

    # -------------------------------------------------------------------------
    # Priority-queue ordering support
    # -------------------------------------------------------------------------

    def __lt__(self, other: "Notification") -> bool:
        """Higher Priority enum value = higher urgency = sort first in the queue."""
        return self.priority.value > other.priority.value

    def __le__(self, other: "Notification") -> bool:
        return self.priority.value >= other.priority.value

    def __gt__(self, other: "Notification") -> bool:
        return self.priority.value < other.priority.value

    def __ge__(self, other: "Notification") -> bool:
        return self.priority.value <= other.priority.value

    # -------------------------------------------------------------------------
    # Convenience helpers
    # -------------------------------------------------------------------------

    @property
    def is_scheduled(self) -> bool:
        """True when delivery should be deferred to a future time."""
        return self.scheduled_at is not None

    @property
    def uses_template(self) -> bool:
        """True when this notification should be rendered from a template."""
        return self.template_id is not None
