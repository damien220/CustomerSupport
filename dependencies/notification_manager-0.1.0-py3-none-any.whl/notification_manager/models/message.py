"""Message, Thread, Conversation, and ReadReceipt models.

These models represent the stateful messaging layer on top of the channel
abstraction — threads, replies, and read receipts. They are used by
MessageManager (Phase 5) and are defined here in Phase 1 so that plugin
contracts and type hints can reference them from the start.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass
class Attachment:
    """A file or media item attached to a message.

    Attributes
    ----------
    url
        Publicly accessible (or pre-signed) URL to the attachment.
        The URL must not embed authentication tokens inline; use headers instead.
    filename
        Original filename with extension.
    content_type
        MIME type (e.g. "image/png", "application/pdf").
    size_bytes
        File size in bytes, if known.
    metadata
        Platform-specific data (e.g. thumbnail URL, alt text).
    """

    url: str
    filename: str
    content_type: str
    size_bytes: Optional[int] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ReadReceipt:
    """Records that a specific user has read a specific message.

    Attributes
    ----------
    message_id
        The id of the Message that was read.
    reader_id
        The id of the Recipient who read the message.
    read_at
        UTC timestamp when the message was marked as read.
    """

    message_id: str
    reader_id: str
    read_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Message:
    """A single message exchanged between two parties on a platform.

    Attributes
    ----------
    sender_id
        Application-level identifier of the sender.
    recipient_id
        Application-level identifier of the recipient.
    content
        Plain-text message body. Plugins may format this for their platform.
    platform
        The channel_id of the platform this message lives on (e.g. "slack").
    id
        Auto-generated UUID.
    thread_id
        If this message belongs to a Thread, the Thread's id.
    conversation_id
        The parent Conversation's id, if applicable.
    reply_to
        The id of the Message this is a reply to, if any.
    attachments
        Files or media included with this message.
    read_at
        UTC timestamp set when the recipient marks this message as read.
    metadata
        Platform-specific data (e.g. platform-assigned message ID, reaction counts).
    created_at
        UTC timestamp at object construction.
    """

    sender_id: str
    recipient_id: str
    content: str
    platform: str

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    thread_id: Optional[str] = None
    conversation_id: Optional[str] = None
    reply_to: Optional[str] = None
    attachments: list[Attachment] = field(default_factory=list)
    read_at: Optional[datetime] = None
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def is_read(self) -> bool:
        """True when the recipient has acknowledged reading this message."""
        return self.read_at is not None

    @property
    def is_reply(self) -> bool:
        """True when this message is a reply to another message."""
        return self.reply_to is not None


@dataclass
class Thread:
    """An ordered sequence of messages in a single channel.

    A Thread belongs to a Conversation and groups messages by topic or
    context. Platforms that support native threading (e.g. Slack) map
    directly to their thread primitives; others simulate it via
    conversation context.

    Attributes
    ----------
    channel
        The channel_id (e.g. "slack") this thread lives on.
    id
        Auto-generated UUID.
    participants
        Application-level user IDs of everyone in this thread.
    messages
        Ordered list of messages, oldest first.
    metadata
        Platform-specific data (e.g. native thread_ts for Slack).
    created_at / updated_at
        UTC timestamps; updated_at advances on each new message.
    """

    channel: str

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    participants: list[str] = field(default_factory=list)
    messages: list[Message] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def add_message(self, message: Message) -> None:
        """Append a message and advance updated_at."""
        self.messages.append(message)
        self.updated_at = datetime.utcnow()

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def latest_message(self) -> Optional[Message]:
        """The most recently added message, or None if the thread is empty."""
        return self.messages[-1] if self.messages else None


@dataclass
class Conversation:
    """A collection of Threads on a single platform.

    Represents an ongoing exchange between participants that may span
    multiple threads (e.g. different topics within the same channel).

    Attributes
    ----------
    platform
        The channel_id this conversation belongs to.
    id
        Auto-generated UUID.
    threads
        All threads within this conversation.
    metadata
        Platform-specific or application-specific data.
    created_at / updated_at
        UTC timestamps; updated_at advances when threads are added/modified.
    """

    platform: str

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    threads: list[Thread] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def add_thread(self, thread: Thread) -> None:
        """Attach a thread to this conversation."""
        self.threads.append(thread)
        self.updated_at = datetime.utcnow()

    @property
    def thread_count(self) -> int:
        return len(self.threads)
