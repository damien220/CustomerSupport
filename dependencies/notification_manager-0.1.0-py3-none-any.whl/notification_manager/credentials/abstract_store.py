"""CredentialStore — abstract contract for all credential backends.

Every store implementation resolves a (channel_id, key) pair to a secret
string and produces scoped PluginCredentials objects. Secrets are never
exposed in bulk; only individual key lookups are supported.

Naming convention for all stores
---------------------------------
Environment variable names follow the pattern::

    NM_<CHANNEL_ID_UPPER>_<KEY_UPPER>

Examples::

    NM_SLACK_BOT_TOKEN
    NM_SENDGRID_API_KEY
    NM_TWILIO_ACCOUNT_SID

This convention is enforced by PluginCredentials and CredentialNotFoundError
so that all stores produce consistent error messages.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from notification_manager.credentials.plugin_credentials import PluginCredentials


class CredentialStore(ABC):
    """Abstract source of secrets for platform plugins.

    Concrete implementations include:
    - ``EnvCredentialStore`` — reads from ``.env`` file and environment variables.
    - ``CacheCredentialStore`` — reads from Cache_Manager with an optional fallback.

    Stores are used only by the plugin system during plugin registration.
    After construction, plugins interact exclusively with their scoped
    ``PluginCredentials`` object and never touch the store directly.
    """

    @abstractmethod
    def get(self, channel_id: str, key: str) -> Optional[str]:
        """Return the secret value for a given channel and key, or None.

        This is the internal resolution method called by ``PluginCredentials``.
        Application code should use ``get_plugin_credentials()`` instead.

        Parameters
        ----------
        channel_id
            The plugin's channel identifier (e.g. ``"slack"``).
        key
            The credential key within that channel (e.g. ``"bot_token"``).

        Returns
        -------
        str or None
            The secret value, or ``None`` if not present in this store.
            Never raises — the caller (PluginCredentials) decides whether
            absence is an error.
        """

    @abstractmethod
    def get_plugin_credentials(self, channel_id: str) -> "PluginCredentials":
        """Return a scoped, read-only credential view for one plugin.

        Parameters
        ----------
        channel_id
            The channel_id the plugin is registered under.

        Returns
        -------
        PluginCredentials
            A view that only exposes keys belonging to ``channel_id``.
            The plugin never receives a reference to this store.
        """

    @abstractmethod
    def rotate(self, channel_id: str, key: str, new_value: str) -> None:
        """Update a credential value in the store without restarting.

        Used for OAuth token rotation, API key cycling, etc.
        The store must make the new value visible to subsequent ``get()``
        calls immediately, without requiring a process restart.

        Parameters
        ----------
        channel_id
            Target channel.
        key
            Credential key to update.
        new_value
            The replacement secret. Must not be logged or stored in
            exception details.

        Raises
        ------
        NotImplementedError
            If this store does not support in-process rotation (e.g. read-only
            stores backed by a secret manager that doesn't allow writes).
        """
