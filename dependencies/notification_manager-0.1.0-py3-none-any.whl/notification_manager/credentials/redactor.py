"""Redactor — masks secrets in log output and error messages.

All secret values and API tokens registered with a Redactor instance are
replaced with ``***REDACTED***`` before they can reach log files, error
responses, or any other output surface.

Integration with Logger_Package
--------------------------------
The ``Redactor`` works alongside the ``PIIFilter`` from ``Logger_Package``.
Use ``build_pii_filter()`` to obtain a ``PIIFilter`` pre-loaded with all
registered patterns. Attach it to handlers that write to external targets::

    from logger_pkg.filters import PIIFilter
    from notification_manager.credentials import Redactor

    redactor = Redactor()
    redactor.register_secret(bot_token)
    redactor.register_pattern(r"xoxb-\\S+")   # Slack bot token format

    pii_filter = redactor.build_pii_filter()
    handler.addFilter(pii_filter)

Stand-alone usage
-----------------
``Redactor.scrub(text)`` can be called directly before writing to any
output that may contain secret values::

    safe_msg = redactor.scrub(f"Connecting with token={token}")

Design notes
------------
- Exact-value matching uses ``str.replace()`` — fast and reliable.
- Pattern matching uses compiled ``re`` patterns — applied after exact matches.
- Patterns are applied in registration order.
- The placeholder is ``***REDACTED***`` (not ``[REDACTED]``) to be visually
  distinct from PIIFilter's ``[TOKEN]`` / ``[REDACTED]`` markers.
- Thread-safe reads (no mutable shared state during ``scrub()``); the
  internal sets/lists are only modified via ``register_*`` methods.
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Optional, Sequence

if TYPE_CHECKING:
    try:
        from logger_pkg.filters.pii_filter import PIIFilter as _PIIFilter
    except ImportError:
        pass

logger = logging.getLogger(__name__)

PLACEHOLDER = "***REDACTED***"


class Redactor:
    """Masks registered secrets and patterns in arbitrary text.

    Typical lifecycle
    -----------------
    1. Construct once per ``NotificationManager`` instance.
    2. Call ``register_secret(value)`` for each credential value retrieved
       from ``PluginCredentials`` at plugin registration.
    3. Call ``register_pattern(regex)`` for known token formats
       (e.g. Slack's ``xoxb-`` prefix).
    4. Pass the instance to ``integrations/logger.py`` which attaches it
       to all log handlers via ``build_pii_filter()``.
    5. Call ``scrub(text)`` before writing to ``DeliveryReceipt.error`` or
       ``ErrorFormatter`` output.
    """

    PLACEHOLDER: str = PLACEHOLDER

    def __init__(self) -> None:
        self._exact: list[str] = []
        self._patterns: list[re.Pattern[str]] = []

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_secret(self, value: str) -> None:
        """Register an exact secret value to be masked.

        Parameters
        ----------
        value
            The raw secret string (e.g. an API token). Empty strings are
            silently ignored — they would match everywhere.
        """
        if not value:
            return
        if value not in self._exact:
            self._exact.append(value)
            logger.debug("Redactor: registered exact secret (len=%d)", len(value))

    def register_secrets(self, values: Sequence[str]) -> None:
        """Bulk-register multiple exact secret values."""
        for v in values:
            self.register_secret(v)

    def register_pattern(self, pattern: str) -> None:
        """Register a regex pattern whose matches will be masked.

        Parameters
        ----------
        pattern
            A regular-expression string. The pattern is compiled immediately;
            a ``re.error`` is raised if it is invalid.

        Examples
        --------
        ::

            redactor.register_pattern(r"xoxb-\\S+")        # Slack bot token
            redactor.register_pattern(r"SG\\.\\S{60,}")    # SendGrid API key
            redactor.register_pattern(r"sk-[A-Za-z0-9]+") # OpenAI-style key
        """
        compiled = re.compile(pattern)
        if not any(p.pattern == pattern for p in self._patterns):
            self._patterns.append(compiled)
            logger.debug("Redactor: registered pattern %r", pattern)

    # ------------------------------------------------------------------
    # Scrubbing
    # ------------------------------------------------------------------

    def scrub(self, text: str) -> str:
        """Return *text* with all registered secrets and patterns masked.

        Exact matches are replaced first (fastest path for known tokens),
        then regex patterns are applied in registration order.

        Parameters
        ----------
        text
            Any string that may contain secret values.

        Returns
        -------
        str
            The sanitised string safe for logging or error output.
        """
        for secret in self._exact:
            if secret in text:
                text = text.replace(secret, PLACEHOLDER)

        for pattern in self._patterns:
            text = pattern.sub(PLACEHOLDER, text)

        return text

    def scrub_dict(self, data: dict[str, str]) -> dict[str, str]:
        """Scrub all values in a string dictionary.

        Returns a new dict with sanitised values; keys are unchanged.
        """
        return {k: self.scrub(v) for k, v in data.items()}

    # ------------------------------------------------------------------
    # Logger_Package integration
    # ------------------------------------------------------------------

    def as_pii_filter_patterns(self) -> list[tuple[str, str]]:
        """Return registered patterns as (pattern_str, replacement) tuples.

        Compatible with ``PIIFilter(extra_patterns=...)`` from Logger_Package.
        Exact-value secrets are not included here (they are best handled via
        exact string replacement in ``scrub()``, not regex).
        """
        return [(p.pattern, PLACEHOLDER) for p in self._patterns]

    def build_pii_filter(
        self,
        name: str = "",
        disable_builtins: bool = False,
    ) -> "logging.Filter":
        """Build a ``PIIFilter`` loaded with all registered patterns.

        Tries to import ``PIIFilter`` from ``Logger_Package``. Falls back to
        a minimal ``logging.Filter`` subclass that calls ``self.scrub()``
        directly when the package is not installed.

        Parameters
        ----------
        name
            Optional filter name (passed to ``logging.Filter``).
        disable_builtins
            If ``True``, suppress PIIFilter's built-in patterns (email,
            credit card, etc.) and use only the patterns registered here.

        Returns
        -------
        logging.Filter
            A filter ready to be attached to any logging handler.
        """
        extra_patterns = self.as_pii_filter_patterns()

        try:
            from logger_pkg.filters.pii_filter import PIIFilter  # type: ignore[import-untyped]

            return PIIFilter(
                name=name,
                extra_patterns=extra_patterns or None,
                disable_builtins=disable_builtins,
            )
        except ImportError:
            logger.debug(
                "Logger_Package not installed; using fallback scrub filter."
            )
            return _FallbackScrubFilter(redactor=self, name=name)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def exact_count(self) -> int:
        """Number of exact-match secrets registered."""
        return len(self._exact)

    @property
    def pattern_count(self) -> int:
        """Number of regex patterns registered."""
        return len(self._patterns)

    def clear(self) -> None:
        """Remove all registered secrets and patterns.

        Use with care — intended for testing teardown only.
        """
        self._exact.clear()
        self._patterns.clear()

    def __repr__(self) -> str:
        return (
            f"Redactor(exact_count={self.exact_count}, "
            f"pattern_count={self.pattern_count})"
        )


# ---------------------------------------------------------------------------
# Fallback filter (used when Logger_Package is not installed)
# ---------------------------------------------------------------------------


class _FallbackScrubFilter(logging.Filter):
    """Minimal scrub filter that delegates to Redactor.scrub().

    Used automatically when ``logger_pkg`` is not installed.
    """

    def __init__(self, redactor: Redactor, name: str = "") -> None:
        super().__init__(name)
        self._redactor = redactor

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._redactor.scrub(str(record.msg))
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: self._redactor.scrub(str(v)) for k, v in record.args.items()
                }
            elif isinstance(record.args, tuple):
                record.args = tuple(
                    self._redactor.scrub(str(a)) for a in record.args
                )
        return True
