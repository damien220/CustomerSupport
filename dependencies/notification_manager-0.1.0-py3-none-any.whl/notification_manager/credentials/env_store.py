"""EnvCredentialStore — resolves secrets from environment variables and .env files.

This is the **primary** credential store. It follows a two-tier resolution:

1. **Live environment variable** (highest priority) — set in the process
   environment via ``export NM_SLACK_BOT_TOKEN=...`` or from the shell.
2. **.env file value** — loaded once at construction time from the given
   path using ``python-dotenv`` (if installed) or a built-in parser.

``python-dotenv`` is optional. If it is not installed, the store falls back
to a minimal parser that handles ``KEY=VALUE`` and ``KEY="VALUE"`` lines
(no multiline values, no variable interpolation).

Env-var naming convention::

    NM_<CHANNEL_ID_UPPER>_<KEY_UPPER>

    NM_SLACK_BOT_TOKEN        → channel_id="slack",  key="bot_token"
    NM_SENDGRID_API_KEY       → channel_id="sendgrid", key="api_key"
    NM_TWILIO_ACCOUNT_SID     → channel_id="twilio", key="account_sid"

The ``.env`` file must never be committed to version control.
Commit ``.env.example`` with placeholder values instead.

Rotation
--------
``rotate(channel_id, key, new_value)`` updates the in-memory copy of the
``.env`` values for the duration of the process. It does **not** write back
to the ``.env`` file. For persistent rotation (e.g. OAuth token refresh),
use ``CacheCredentialStore`` layered on top of this store.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Optional

from notification_manager.credentials.abstract_store import CredentialStore
from notification_manager.credentials.plugin_credentials import PluginCredentials

logger = logging.getLogger(__name__)

# Regex for the fallback .env parser — matches:
#   KEY=value
#   KEY="value"
#   KEY='value'
#   export KEY=value
_ENV_LINE_RE = re.compile(
    r"^\s*(?:export\s+)?"          # optional "export "
    r"([A-Za-z_][A-Za-z0-9_]*)"   # key
    r"\s*=\s*"                     # =
    r"""(?:"([^"]*)"|'([^']*)'|([^#\n]*))"""  # quoted or bare value
    r"\s*(?:#.*)?$"                # optional trailing comment
)


def _parse_env_file(path: str) -> dict[str, str]:
    """Minimal .env parser used when python-dotenv is not installed."""
    result: dict[str, str] = {}
    p = Path(path)
    if not p.exists():
        return result
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = _ENV_LINE_RE.match(line)
            if m:
                key = m.group(1)
                # Groups 2, 3, 4 correspond to double-quoted, single-quoted, bare
                value = m.group(2) if m.group(2) is not None else (
                    m.group(3) if m.group(3) is not None else (m.group(4) or "").strip()
                )
                result[key] = value
    except OSError as exc:
        logger.warning("Could not read .env file %r: %s", path, exc)
    return result


def _load_dotenv(path: str) -> dict[str, str]:
    """Load .env values, preferring python-dotenv if available."""
    try:
        from dotenv import dotenv_values  # type: ignore[import-untyped]
        result = dict(dotenv_values(path))
        # dotenv_values returns None for empty values; normalise to empty string
        return {k: (v or "") for k, v in result.items()}
    except ImportError:
        logger.debug(
            "python-dotenv not installed; using built-in .env parser. "
            "Install with: pip install python-dotenv"
        )
        return _parse_env_file(path)


class EnvCredentialStore(CredentialStore):
    """Resolves credentials from environment variables and an optional .env file.

    Parameters
    ----------
    env_file
        Path to the ``.env`` file. Defaults to ``".env"`` in the current
        working directory. Silently ignored if the file does not exist.

    Examples
    --------
    Given a ``.env`` file containing::

        NM_SLACK_BOT_TOKEN=xoxb-123
        NM_SENDGRID_API_KEY=SG.abc

    And usage::

        store = EnvCredentialStore(env_file=".env")
        creds = store.get_plugin_credentials("slack")
        token = creds.get("bot_token")   # → "xoxb-123"
    """

    def __init__(self, env_file: str = ".env") -> None:
        self._env_file = env_file
        # Loaded once at construction; live os.environ always takes precedence.
        self._dotenv_values: dict[str, str] = _load_dotenv(env_file)
        logger.debug(
            "EnvCredentialStore initialised (env_file=%r, keys_loaded=%d)",
            env_file,
            len(self._dotenv_values),
        )

    # ------------------------------------------------------------------
    # CredentialStore interface
    # ------------------------------------------------------------------

    def get(self, channel_id: str, key: str) -> Optional[str]:
        """Resolve NM_<CHANNEL>_<KEY> from env → .env → None."""
        env_var = self._env_var_name(channel_id, key)

        # 1. Live environment variable (highest priority)
        value = os.getenv(env_var)
        if value is not None:
            return value

        # 2. .env file value
        value = self._dotenv_values.get(env_var)
        return value if value else None

    def get_plugin_credentials(self, channel_id: str) -> PluginCredentials:
        """Return a scoped credential view for *channel_id*."""
        return PluginCredentials(channel_id=channel_id, store=self)

    def rotate(self, channel_id: str, key: str, new_value: str) -> None:
        """Update the in-memory value for *key* in this process.

        The change is visible immediately to subsequent ``get()`` calls
        but is **not** written back to the ``.env`` file. For persistent
        rotation across restarts, use ``CacheCredentialStore``.
        """
        env_var = self._env_var_name(channel_id, key)
        self._dotenv_values[env_var] = new_value
        logger.debug(
            "EnvCredentialStore: in-memory rotation applied for %s (channel=%r, key=%r)",
            env_var,
            channel_id,
            key,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _env_var_name(channel_id: str, key: str) -> str:
        """Build the canonical environment variable name."""
        return f"NM_{channel_id.upper()}_{key.upper()}"

    def reload(self) -> None:
        """Re-read the .env file from disk, updating in-memory values.

        Useful if the .env file has been updated and you want to pick up
        changes without a full process restart. Live ``os.environ`` entries
        are always read fresh and are unaffected by this call.
        """
        self._dotenv_values = _load_dotenv(self._env_file)
        logger.debug(
            "EnvCredentialStore reloaded %r (%d keys)",
            self._env_file,
            len(self._dotenv_values),
        )

    def __repr__(self) -> str:
        return f"EnvCredentialStore(env_file={self._env_file!r})"
