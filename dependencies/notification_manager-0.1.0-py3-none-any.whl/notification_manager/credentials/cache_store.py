"""CacheCredentialStore — Cache_Manager-backed credential store with fallback.

Wraps any ``AbstractCache`` instance (from the Cache_Manager package) and
optionally chains to a fallback ``CredentialStore`` (typically
``EnvCredentialStore``) when a key is absent from the cache.

Primary use-cases
-----------------
1. **OAuth / short-lived token rotation without restart**

   A background job calls ``rotate()`` to push a fresh access token into
   the cache. All subsequent ``get()`` calls pick up the new token
   immediately — no process restart required.

2. **Distributed deployments**

   Multiple app instances share the same Redis-backed cache, so a single
   token refresh propagates to all instances atomically.

3. **Layered resolution (cache → env → None)**

   If a key has not yet been written to the cache (first startup), the
   store transparently falls back to the ``EnvCredentialStore``.

Cache key format::

    nm:credentials:<CHANNEL_ID_UPPER>:<KEY_UPPER>

TTL
---
Defaults to 3600 seconds (1 hour). Set ``ttl=None`` to disable expiry.
Short TTLs are recommended for OAuth tokens that must be rotated regularly.

Example
-------
::

    from cache_manager import get_cache
    from notification_manager.credentials import EnvCredentialStore, CacheCredentialStore

    env_store  = EnvCredentialStore(env_file=".env")
    cache      = get_cache("redis", host="localhost", port=6379)
    cred_store = CacheCredentialStore(cache=cache, fallback=env_store, ttl=3600)

    # Register a token rotation (e.g. called by an OAuth refresh job):
    cred_store.rotate("slack", "access_token", new_oauth_token)

    # Plugin looks up the token — gets the rotated value from Redis:
    creds = cred_store.get_plugin_credentials("slack")
    token = creds.get("access_token")
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from notification_manager.credentials.abstract_store import CredentialStore
from notification_manager.credentials.plugin_credentials import PluginCredentials

if TYPE_CHECKING:
    # AbstractCache lives in the Cache_Manager package.
    # Imported inside TYPE_CHECKING to keep this module importable even if
    # cache_manager is not installed (e.g. when using EnvCredentialStore only).
    try:
        from cache_manager import AbstractCache
    except ImportError:
        from typing import Any as AbstractCache  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_NAMESPACE = "nm:credentials"


class CacheCredentialStore(CredentialStore):
    """Cache_Manager-backed credential store with an optional fallback chain.

    Parameters
    ----------
    cache
        Any ``AbstractCache`` instance (MemoryCache, RedisCache, etc.).
        The instance must already be connected (``cache.connect()`` called).
    fallback
        Secondary store consulted when a key is absent from the cache.
        Typically an ``EnvCredentialStore``. Set to ``None`` to disable
        the fallback (the store returns ``None`` for missing keys).
    ttl
        Time-to-live in seconds for values written via ``rotate()``.
        ``None`` means no expiry. Default: 3600.
    """

    def __init__(
        self,
        cache: "AbstractCache",
        fallback: Optional[CredentialStore] = None,
        ttl: Optional[int] = 3600,
    ) -> None:
        self._cache = cache
        self._fallback = fallback
        self._ttl = ttl
        logger.debug(
            "CacheCredentialStore initialised (backend=%r, fallback=%r, ttl=%r)",
            type(cache).__name__,
            type(fallback).__name__ if fallback else None,
            ttl,
        )

    # ------------------------------------------------------------------
    # CredentialStore interface
    # ------------------------------------------------------------------

    def get(self, channel_id: str, key: str) -> Optional[str]:
        """Resolve from cache → fallback → None.

        Resolution order:
        1. Cache hit — return immediately.
        2. Cache miss + fallback present — delegate to fallback.
        3. Cache miss + no fallback — return None.
        """
        cache_key = self._cache_key(channel_id, key)
        value = self._cache.get(cache_key)
        if value is not None:
            return str(value)

        if self._fallback is not None:
            return self._fallback.get(channel_id, key)

        return None

    def get_plugin_credentials(self, channel_id: str) -> PluginCredentials:
        """Return a scoped credential view for *channel_id*."""
        return PluginCredentials(channel_id=channel_id, store=self)

    def rotate(self, channel_id: str, key: str, new_value: str) -> None:
        """Write a new secret value into the cache.

        The new value is visible to all instances sharing this cache backend
        immediately after this call returns. The fallback store is **not**
        updated — it remains the last-resort source for keys not yet cached.

        Parameters
        ----------
        channel_id
            Target channel.
        key
            Credential key to update.
        new_value
            The replacement secret. Stored in the cache with the configured TTL.
        """
        cache_key = self._cache_key(channel_id, key)
        self._cache.set(cache_key, new_value, ttl=self._ttl)
        logger.debug(
            "CacheCredentialStore: rotated credential (channel=%r, key=%r, ttl=%r)",
            channel_id,
            key,
            self._ttl,
        )

    # ------------------------------------------------------------------
    # Additional cache-specific operations
    # ------------------------------------------------------------------

    def invalidate(self, channel_id: str, key: str) -> bool:
        """Remove a credential from the cache, forcing fallback resolution.

        Returns True if the key existed and was removed.
        Useful when a token has been revoked and the fallback should provide
        a fresh value on the next access.
        """
        cache_key = self._cache_key(channel_id, key)
        removed = self._cache.delete(cache_key)
        logger.debug(
            "CacheCredentialStore: invalidated %r (existed=%r)", cache_key, removed
        )
        return removed

    def is_cached(self, channel_id: str, key: str) -> bool:
        """Return True if the given credential is currently in the cache."""
        return self._cache.exists(self._cache_key(channel_id, key))

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _cache_key(channel_id: str, key: str) -> str:
        """Build the namespaced cache key."""
        return f"{_NAMESPACE}:{channel_id.upper()}:{key.upper()}"

    def __repr__(self) -> str:
        return (
            f"CacheCredentialStore("
            f"backend={type(self._cache).__name__!r}, "
            f"fallback={type(self._fallback).__name__ if self._fallback else None!r}, "
            f"ttl={self._ttl!r})"
        )
