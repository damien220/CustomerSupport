"""PluginCredentials — a scoped, read-only view of secrets for a single plugin.

Passed to every ChannelPlugin at construction time. Plugins call
``get()`` / ``get_optional()`` to retrieve their own secrets by key.

Design constraints
------------------
- A plugin can only access credentials belonging to its own ``channel_id``.
- The underlying ``CredentialStore`` is held as a private attribute;
  there is no public property exposing it — plugins cannot reach secrets
  belonging to other channels.
- ``get()`` raises ``CredentialNotFoundError`` immediately when the key
  is absent, so misconfiguration is caught at plugin registration time
  (not at first delivery).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from notification_manager.exceptions import CredentialNotFoundError

if TYPE_CHECKING:
    from notification_manager.credentials.abstract_store import CredentialStore


class PluginCredentials:
    """Scoped, read-only access to secrets for one plugin channel.

    Constructed by ``CredentialStore.get_plugin_credentials(channel_id)``
    and passed directly to the plugin constructor::

        class MySlackPlugin(ChannelPlugin):
            channel_id = "slack"

            def __init__(self, credentials: PluginCredentials) -> None:
                self._token = credentials.get("bot_token")

    Attributes
    ----------
    channel_id : str
        Read-only. The channel this credentials object is scoped to.
    """

    __slots__ = ("_channel_id", "_store")

    def __init__(self, channel_id: str, store: "CredentialStore") -> None:
        # Private storage — no public accessors for `_store`.
        object.__setattr__(self, "_channel_id", channel_id)
        object.__setattr__(self, "_store", store)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    @property
    def channel_id(self) -> str:
        """The channel_id this credentials object is scoped to."""
        return object.__getattribute__(self, "_channel_id")

    def get(self, key: str) -> str:
        """Return the secret value for *key*.

        Parameters
        ----------
        key
            Credential key within this channel (e.g. ``"bot_token"``).
            Case-insensitive — resolved to ``NM_<CHANNEL>_<KEY_UPPER>``.

        Returns
        -------
        str
            The secret value.

        Raises
        ------
        CredentialNotFoundError
            If the key is absent from the store. Raised immediately so
            the plugin registration fails fast with a clear message.
        """
        store: CredentialStore = object.__getattribute__(self, "_store")
        channel_id: str = object.__getattribute__(self, "_channel_id")
        value = store.get(channel_id, key)
        if value is None:
            raise CredentialNotFoundError(channel_id=channel_id, key=key)
        return value

    def get_optional(self, key: str, default: str = "") -> str:
        """Return the secret value for *key*, or *default* if absent.

        Never raises. Use this for optional credentials (e.g. a proxy URL
        or an optional webhook signing secret).

        Parameters
        ----------
        key
            Credential key within this channel.
        default
            Returned when the key is not found in the store.

        Returns
        -------
        str
            The secret value, or *default*.
        """
        store: CredentialStore = object.__getattribute__(self, "_store")
        channel_id: str = object.__getattribute__(self, "_channel_id")
        value = store.get(channel_id, key)
        return value if value is not None else default

    # ------------------------------------------------------------------
    # Protect against accidental secret exposure
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        channel_id: str = object.__getattribute__(self, "_channel_id")
        return f"PluginCredentials(channel_id={channel_id!r})"

    def __str__(self) -> str:
        return repr(self)

    # Prevent attribute assignment — this object is immutable after construction.
    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("PluginCredentials is immutable.")
