"""ChannelPlugin — the base class plugin authors should subclass.

This module provides the concrete abstract base that extends the core ABC
(``core/abstract_channel.py``) with standard ``__init__`` wiring for
credentials and config injection.

Relationship to the core ABC
-----------------------------
``core.abstract_channel.ChannelPlugin`` defines the pure interface (four
abstract methods, rate_limit defaults). This class adds the operational
layer:

- ``self._credentials`` — the plugin's scoped secret store.
- ``self._config`` — operational settings (timeout, retries, extras).
- Config-driven overrides of ``max_retries`` and ``rate_limit`` (instance
  attributes shadow the class defaults when config values are provided).
- A validation step ensuring ``config.channel_id`` matches the plugin's
  declared ``channel_id``.

Plugin authors should import from here::

    from notification_manager.plugins import ChannelPlugin

not from ``notification_manager.core``, unless they need the raw ABC.

Minimal plugin example
-----------------------
::

    from notification_manager.plugins import ChannelPlugin
    from notification_manager.models import Notification, DeliveryReceipt, DeliveryStatus
    from notification_manager.models.delivery import DeliveryAttempt

    class MyEmailPlugin(ChannelPlugin):
        channel_id = "email"

        async def connect(self) -> None:
            api_key = self._credentials.get("api_key")
            self._client = EmailClient(api_key=api_key)

        async def disconnect(self) -> None:
            await self._client.close()

        async def send(self, notification: Notification) -> DeliveryReceipt:
            ...

        async def health_check(self) -> bool:
            return await self._client.ping()
"""

from __future__ import annotations

import logging
from typing import Optional

from notification_manager.core.abstract_channel import ChannelPlugin as _CoreChannelPlugin
from notification_manager.exceptions import PluginConfigError
from notification_manager.plugins.config import PluginConfig

# Imported at runtime only — avoids circular imports during early loading.
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from notification_manager.credentials.plugin_credentials import PluginCredentials

logger = logging.getLogger(__name__)


class ChannelPlugin(_CoreChannelPlugin):
    """Concrete abstract base for all platform channel plugins.

    Extends ``core.ChannelPlugin`` with:

    - Standard ``__init__`` that accepts ``credentials`` and ``config``.
    - ``self._credentials`` — ``PluginCredentials`` scoped to this channel.
    - ``self._config`` — ``PluginConfig`` with operational settings.
    - Instance-level overrides of ``max_retries`` and ``rate_limit`` from
      config (shadow class defaults without affecting other instances).

    This class is still abstract — plugin authors must implement the four
    abstract methods: ``connect``, ``disconnect``, ``send``, ``health_check``.

    Parameters
    ----------
    credentials
        Scoped credential view for this plugin. Obtain via
        ``credential_store.get_plugin_credentials(channel_id)``.
        May be ``None`` for plugins that require no secrets (e.g. console).
    config
        Operational configuration. When ``None``, a default ``PluginConfig``
        is constructed using the plugin class's ``channel_id``.

    Raises
    ------
    PluginConfigError
        If ``config.channel_id`` does not match the plugin's ``channel_id``
        class attribute (catches copy-paste mistakes at registration time).
    """

    def __init__(
        self,
        credentials: Optional["PluginCredentials"] = None,
        config: Optional[PluginConfig] = None,
    ) -> None:
        # Build a default config if none provided.
        effective_config = config or PluginConfig(channel_id=type(self).channel_id)

        # Validate channel_id consistency.
        if effective_config.channel_id != type(self).channel_id:
            raise PluginConfigError(
                channel_id=effective_config.channel_id,
                reason=(
                    f"PluginConfig.channel_id={effective_config.channel_id!r} does not "
                    f"match {type(self).__name__}.channel_id={type(self).channel_id!r}. "
                    "Ensure you are passing the correct PluginConfig to this plugin."
                ),
            )

        self._credentials: Optional["PluginCredentials"] = credentials
        self._config: PluginConfig = effective_config

        # Apply config-level overrides as instance attributes (shadow class defaults).
        if effective_config.max_retries is not None:
            self.max_retries = effective_config.max_retries

        if effective_config.rate_limit is not None:
            self.rate_limit = effective_config.rate_limit

        logger.debug(
            "Plugin %r initialised (channel_id=%r, max_retries=%d, timeout=%.1fs)",
            type(self).__name__,
            type(self).channel_id,
            self.max_retries,
            effective_config.timeout_seconds,
        )
