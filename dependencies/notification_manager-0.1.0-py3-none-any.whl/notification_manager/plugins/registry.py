"""PluginRegistry — maps channel_id → ChannelPlugin instance at runtime.

The registry is the single source of truth for which platform plugins are
active. The NotificationManager holds one registry and consults it on every
send operation to resolve the correct plugin for a given channel_id.

Lifecycle
---------
1. Host app instantiates plugins and calls ``registry.register()``.
2. ``NotificationManager`` calls ``await registry.connect_all()`` on startup.
3. During operation the engine calls ``registry.get(channel_id)`` per send.
4. On shutdown ``NotificationManager`` calls ``await registry.disconnect_all()``.
5. Health checks run via ``await registry.available()`` (periodically or
   on-demand).

Thread / async safety
---------------------
``register()`` and ``unregister()`` are synchronous and must be called before
the asyncio event loop starts (i.e. during application bootstrap). The async
methods (``connect_all``, ``disconnect_all``, ``available``) are safe to call
concurrently from within the event loop.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from notification_manager.core.abstract_channel import ChannelPlugin as _CoreChannelPlugin
from notification_manager.exceptions import PluginConfigError, PluginNotFoundError

if TYPE_CHECKING:
    from notification_manager.plugins.base import ChannelPlugin

logger = logging.getLogger(__name__)


class PluginRegistry:
    """Central registry mapping channel_id strings to ChannelPlugin instances.

    Examples
    --------
    ::

        registry = PluginRegistry()
        registry.register("slack", MySlackPlugin(credentials=creds.get("slack")))
        registry.register("email", MyEmailPlugin(credentials=creds.get("email")))

        await registry.connect_all()

        plugin = registry.get("slack")
        receipt = await plugin.send(notification)
    """

    def __init__(self) -> None:
        self._plugins: dict[str, _CoreChannelPlugin] = {}

    # ------------------------------------------------------------------
    # Registration (synchronous — call during bootstrap)
    # ------------------------------------------------------------------

    def register(self, channel_id: str, plugin: _CoreChannelPlugin) -> None:
        """Register a plugin instance under a channel_id.

        Parameters
        ----------
        channel_id
            The key used to look up this plugin. Conventionally matches
            ``plugin.channel_id``, but may differ if you need to register
            the same plugin class under multiple names.
        plugin
            A fully constructed (but not yet connected) plugin instance.

        Raises
        ------
        PluginConfigError
            If ``plugin`` is not a ``ChannelPlugin`` subclass instance.

        Notes
        -----
        If a plugin is already registered under ``channel_id``, the previous
        registration is overwritten with a warning. Connect the new plugin
        manually if ``connect_all()`` has already been called.
        """
        if not isinstance(plugin, _CoreChannelPlugin):
            raise PluginConfigError(
                channel_id=channel_id,
                reason=(
                    f"Expected a ChannelPlugin instance, got "
                    f"{type(plugin).__name__!r}."
                ),
            )

        if channel_id in self._plugins:
            logger.warning(
                "PluginRegistry: overwriting existing plugin for channel %r "
                "(%s → %s). If connect_all() was already called, connect the "
                "new plugin manually.",
                channel_id,
                type(self._plugins[channel_id]).__name__,
                type(plugin).__name__,
            )

        self._plugins[channel_id] = plugin
        logger.debug(
            "PluginRegistry: registered %r for channel %r",
            type(plugin).__name__,
            channel_id,
        )

    def unregister(self, channel_id: str) -> None:
        """Remove a plugin from the registry.

        Parameters
        ----------
        channel_id
            Channel to deregister.

        Raises
        ------
        PluginNotFoundError
            If ``channel_id`` is not currently registered.

        Notes
        -----
        Does not call ``disconnect()`` on the plugin — the caller is
        responsible for graceful teardown before unregistering.
        """
        if channel_id not in self._plugins:
            raise PluginNotFoundError(channel_id)

        removed = self._plugins.pop(channel_id)
        logger.debug(
            "PluginRegistry: unregistered %r (channel %r)",
            type(removed).__name__,
            channel_id,
        )

    # ------------------------------------------------------------------
    # Lookup (synchronous — called per send operation)
    # ------------------------------------------------------------------

    def get(self, channel_id: str) -> _CoreChannelPlugin:
        """Return the plugin registered under ``channel_id``.

        Raises
        ------
        PluginNotFoundError
            If no plugin is registered for this channel_id.
        """
        try:
            return self._plugins[channel_id]
        except KeyError:
            raise PluginNotFoundError(channel_id)

    def list_channels(self) -> list[str]:
        """Return all currently registered channel_ids."""
        return list(self._plugins.keys())

    def get_all(self) -> dict[str, _CoreChannelPlugin]:
        """Return a shallow copy of the channel_id → plugin mapping."""
        return dict(self._plugins)

    # ------------------------------------------------------------------
    # Lifecycle (async — called by NotificationManager)
    # ------------------------------------------------------------------

    async def connect_all(self) -> None:
        """Call ``connect()`` on every registered plugin sequentially.

        Raises
        ------
        PluginConfigError
            If any plugin's ``connect()`` raises. The error is re-raised
            immediately; plugins registered after the failing one are not
            connected.
        """
        for channel_id, plugin in self._plugins.items():
            logger.debug(
                "PluginRegistry: connecting %r (channel %r)",
                type(plugin).__name__,
                channel_id,
            )
            try:
                await plugin.connect()
            except Exception as exc:
                raise PluginConfigError(
                    channel_id=channel_id,
                    reason=f"connect() failed: {exc}",
                    previous=exc,
                ) from exc
            logger.info("PluginRegistry: channel %r connected.", channel_id)

    async def disconnect_all(self) -> None:
        """Call ``disconnect()`` on every registered plugin.

        Errors are logged and swallowed — shutdown must always complete.
        All plugins are disconnected regardless of individual failures.
        """
        for channel_id, plugin in self._plugins.items():
            try:
                await plugin.disconnect()
                logger.debug(
                    "PluginRegistry: channel %r disconnected.", channel_id
                )
            except Exception as exc:
                logger.warning(
                    "PluginRegistry: disconnect() failed for channel %r: %s",
                    channel_id,
                    exc,
                )

    # ------------------------------------------------------------------
    # Health checks (async — may be called periodically)
    # ------------------------------------------------------------------

    async def available(self) -> dict[str, bool]:
        """Run ``health_check()`` on all plugins concurrently.

        Returns
        -------
        dict[str, bool]
            Mapping of channel_id → True (healthy) / False (unavailable).
            Never raises — unhealthy plugins are recorded as False.
        """
        if not self._plugins:
            return {}

        async def _check(channel_id: str, plugin: _CoreChannelPlugin) -> tuple[str, bool]:
            try:
                healthy = await plugin.health_check()
                return channel_id, bool(healthy)
            except Exception as exc:
                logger.warning(
                    "PluginRegistry: health_check() failed for channel %r: %s",
                    channel_id,
                    exc,
                )
                return channel_id, False

        results = await asyncio.gather(
            *(_check(cid, p) for cid, p in self._plugins.items())
        )
        return dict(results)

    async def check(self, channel_id: str) -> bool:
        """Run ``health_check()`` for a single channel.

        Returns False (and logs a warning) if the check raises.

        Raises
        ------
        PluginNotFoundError
            If ``channel_id`` is not registered.
        """
        plugin = self.get(channel_id)
        try:
            return bool(await plugin.health_check())
        except Exception as exc:
            logger.warning(
                "PluginRegistry: health_check() failed for channel %r: %s",
                channel_id,
                exc,
            )
            return False

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        """Number of registered plugins."""
        return len(self._plugins)

    def __contains__(self, channel_id: object) -> bool:
        """Support ``"slack" in registry`` checks."""
        return channel_id in self._plugins

    def __repr__(self) -> str:
        channels = list(self._plugins.keys())
        return f"PluginRegistry(channels={channels!r})"
