"""PluginConfig — per-plugin configuration (no secrets).

Secrets are handled exclusively through PluginCredentials (credentials sub-package).
PluginConfig carries only non-sensitive operational parameters such as timeouts,
retry caps, and plugin-specific settings that are safe to log or store in a
config file.

Typical usage
-------------
::

    config = PluginConfig(
        channel_id="slack",
        timeout_seconds=10.0,
        max_retries=5,
        extra={"default_channel": "#alerts"},
    )

Config-driven plugins (via PluginLoader.load_from_config) receive a PluginConfig
constructed from the ``plugins`` list in NotificationManagerConfig.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from notification_manager.core.abstract_channel import RateLimit


@dataclass
class PluginConfig:
    """Operational configuration for a single channel plugin.

    Attributes
    ----------
    channel_id
        Matches the plugin class's ``channel_id`` class attribute.
        Used to associate this config with the correct plugin class during
        config-driven loading.
    timeout_seconds
        Per-request timeout for platform API calls. The plugin is responsible
        for applying this value (e.g. as an ``aiohttp`` or ``httpx`` timeout).
        Default: 30 s.
    max_retries
        Maximum delivery attempts. When set, overrides the plugin class's
        ``max_retries`` class attribute for this instance. When ``None``,
        the class default is used.
    rate_limit
        Per-channel throughput limit. When set, overrides the plugin class's
        ``rate_limit`` class attribute. When ``None``, the class default is used.
    extra
        Arbitrary non-sensitive plugin-specific options (e.g. a default Slack
        channel name, a SendGrid sender address, an FCM project ID). These are
        passed through to the plugin and must never contain credential values.
    """

    channel_id: str
    timeout_seconds: float = 30.0
    max_retries: Optional[int] = None
    rate_limit: Optional["RateLimit"] = None
    extra: dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any = None) -> Any:
        """Convenience accessor for ``extra`` dict values."""
        return self.extra.get(key, default)
