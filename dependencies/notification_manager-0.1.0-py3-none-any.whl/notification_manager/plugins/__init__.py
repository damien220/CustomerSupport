"""Public surface of the plugins sub-package."""

from notification_manager.plugins.base import ChannelPlugin
from notification_manager.plugins.config import PluginConfig
from notification_manager.plugins.loader import PluginLoader
from notification_manager.plugins.registry import PluginRegistry

__all__ = [
    "ChannelPlugin",
    "PluginConfig",
    "PluginRegistry",
    "PluginLoader",
]
