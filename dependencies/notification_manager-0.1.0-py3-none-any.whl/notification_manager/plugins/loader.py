"""PluginLoader — discovers and instantiates ChannelPlugin classes.

Three loading strategies are supported, in increasing order of automation:

1. **Direct** (default)
   The host app instantiates plugins manually and passes them to
   ``PluginRegistry.register()``. The loader is not involved.

2. **Config-driven**
   ``load_from_config(plugin_configs, credential_store)`` reads a list of
   plugin config dicts (from ``NotificationManagerConfig.plugins``), imports
   each plugin class by its dotted Python path, and instantiates it with
   ``PluginCredentials`` from the given store.

3. **Entry-point driven**
   ``load_from_entry_points(credential_store)`` discovers and loads all
   plugins advertised under the ``notification_manager.plugins`` setuptools
   entry point group. Useful for third-party plugin packages that register
   themselves at install time.

   Plugin packages add to their ``pyproject.toml``::

       [project.entry-points."notification_manager.plugins"]
       my_slack = "my_slack_pkg:SlackPlugin"

Entry-point loading requires the plugin package to be installed in the same
Python environment.

Config-driven loading
---------------------
Each dict in ``NotificationManagerConfig.plugins`` may contain:

.. code-block:: python

    {
        "channel_id": "slack",
        "class": "my_slack_pkg.SlackPlugin",   # dotted path — required
        "timeout_seconds": 10.0,               # optional PluginConfig fields
        "max_retries": 5,
        # any extra keys go into PluginConfig.extra
        "default_channel": "#alerts",
    }

Keys ``channel_id``, ``class``, ``timeout_seconds``, ``max_retries``, and
``rate_limit`` are consumed by the loader. All remaining keys are forwarded
into ``PluginConfig.extra``.
"""

from __future__ import annotations

import importlib
import logging
from typing import TYPE_CHECKING, Any

from notification_manager.core.abstract_channel import ChannelPlugin as _CoreChannelPlugin
from notification_manager.exceptions import PluginConfigError
from notification_manager.plugins.config import PluginConfig

if TYPE_CHECKING:
    from notification_manager.credentials.abstract_store import CredentialStore
    from notification_manager.plugins.base import ChannelPlugin

logger = logging.getLogger(__name__)

#: Setuptools entry point group name used by third-party plugin packages.
ENTRY_POINT_GROUP = "notification_manager.plugins"

#: Keys consumed by the loader; all others are forwarded to PluginConfig.extra.
_LOADER_KEYS = frozenset({"channel_id", "class", "timeout_seconds", "max_retries", "rate_limit"})


class PluginLoader:
    """Discovers and instantiates ChannelPlugin classes from various sources.

    Example — config-driven loading::

        loader = PluginLoader()
        registry = PluginRegistry()
        credential_store = EnvCredentialStore()

        pairs = loader.load_from_config(
            plugin_configs=nm_config.plugins,
            credential_store=credential_store,
        )
        for channel_id, plugin in pairs:
            registry.register(channel_id, plugin)

    Example — entry-point loading::

        for channel_id, plugin in loader.load_from_entry_points(credential_store):
            registry.register(channel_id, plugin)
    """

    # ------------------------------------------------------------------
    # Class loading helpers
    # ------------------------------------------------------------------

    def load_class(self, dotted_path: str) -> type[_CoreChannelPlugin]:
        """Import and return a ChannelPlugin class by its dotted module path.

        Parameters
        ----------
        dotted_path
            Fully-qualified Python path, e.g. ``"my_pkg.plugins.SlackPlugin"``.

        Returns
        -------
        type[ChannelPlugin]
            The resolved class.

        Raises
        ------
        PluginConfigError
            If the module cannot be imported, the class is not found, or the
            resolved object is not a ChannelPlugin subclass.
        """
        if "." not in dotted_path:
            raise PluginConfigError(
                channel_id="?",
                reason=(
                    f"Invalid dotted path {dotted_path!r}. "
                    "Expected 'module.ClassName' format."
                ),
            )

        module_path, class_name = dotted_path.rsplit(".", 1)

        try:
            module = importlib.import_module(module_path)
        except ImportError as exc:
            raise PluginConfigError(
                channel_id="?",
                reason=f"Cannot import module {module_path!r}: {exc}",
                previous=exc,
            ) from exc

        cls = getattr(module, class_name, None)
        if cls is None:
            raise PluginConfigError(
                channel_id="?",
                reason=(
                    f"Class {class_name!r} not found in module {module_path!r}. "
                    f"Available names: {[n for n in dir(module) if not n.startswith('_')]}"
                ),
            )

        if not (isinstance(cls, type) and issubclass(cls, _CoreChannelPlugin)):
            raise PluginConfigError(
                channel_id="?",
                reason=(
                    f"{dotted_path!r} resolved to {cls!r}, which is not a "
                    "ChannelPlugin subclass."
                ),
            )

        return cls

    # ------------------------------------------------------------------
    # Config-driven loading
    # ------------------------------------------------------------------

    def load_from_config(
        self,
        plugin_configs: list[dict[str, Any]],
        credential_store: "CredentialStore",
    ) -> list[tuple[str, _CoreChannelPlugin]]:
        """Instantiate plugins from a list of config dicts.

        Each dict must have a ``channel_id`` key and a ``class`` key pointing
        to the plugin's dotted module path. Dicts without a ``class`` key are
        skipped (they may be stubs for manually-registered plugins).

        Parameters
        ----------
        plugin_configs
            List of plugin config dicts, typically from
            ``NotificationManagerConfig.plugins``.
        credential_store
            Used to produce ``PluginCredentials`` for each plugin.

        Returns
        -------
        list[tuple[str, ChannelPlugin]]
            ``(channel_id, plugin_instance)`` pairs ready to be passed to
            ``PluginRegistry.register()``.
        """
        results: list[tuple[str, _CoreChannelPlugin]] = []

        for cfg_dict in plugin_configs:
            channel_id: str = cfg_dict.get("channel_id", "")
            dotted_class: str | None = cfg_dict.get("class")

            if not channel_id:
                logger.warning(
                    "PluginLoader: skipping entry with missing 'channel_id': %r",
                    cfg_dict,
                )
                continue

            if not dotted_class:
                logger.debug(
                    "PluginLoader: no 'class' key for channel %r — "
                    "plugin must be registered manually.",
                    channel_id,
                )
                continue

            config = self._build_config(channel_id, cfg_dict)
            credentials = credential_store.get_plugin_credentials(channel_id)

            try:
                cls = self.load_class(dotted_class)
                plugin: _CoreChannelPlugin = cls(
                    credentials=credentials,
                    config=config,
                )
                results.append((channel_id, plugin))
                logger.info(
                    "PluginLoader: loaded %r for channel %r",
                    cls.__name__,
                    channel_id,
                )
            except PluginConfigError:
                raise
            except Exception as exc:
                raise PluginConfigError(
                    channel_id=channel_id,
                    reason=f"Failed to instantiate plugin {dotted_class!r}: {exc}",
                    previous=exc,
                ) from exc

        return results

    # ------------------------------------------------------------------
    # Entry-point loading
    # ------------------------------------------------------------------

    def load_from_entry_points(
        self,
        credential_store: "CredentialStore",
    ) -> list[tuple[str, _CoreChannelPlugin]]:
        """Discover and load plugins via setuptools entry points.

        Scans the ``notification_manager.plugins`` entry point group.
        Each entry point's value must be a ChannelPlugin subclass with a
        ``channel_id`` class attribute.

        Parameters
        ----------
        credential_store
            Used to produce ``PluginCredentials`` for each discovered plugin.

        Returns
        -------
        list[tuple[str, ChannelPlugin]]
            Loaded ``(channel_id, plugin_instance)`` pairs. Plugins that fail
            to load are skipped with a warning (never raises).
        """
        results: list[tuple[str, _CoreChannelPlugin]] = []

        try:
            from importlib.metadata import entry_points
        except ImportError:
            logger.debug(
                "PluginLoader: importlib.metadata unavailable — "
                "entry-point loading skipped."
            )
            return results

        try:
            eps = entry_points(group=ENTRY_POINT_GROUP)
        except Exception as exc:
            logger.warning(
                "PluginLoader: failed to read entry points for group %r: %s",
                ENTRY_POINT_GROUP,
                exc,
            )
            return results

        for ep in eps:
            try:
                cls = ep.load()

                if not (isinstance(cls, type) and issubclass(cls, _CoreChannelPlugin)):
                    logger.warning(
                        "PluginLoader: entry point %r loaded %r which is not a "
                        "ChannelPlugin subclass — skipped.",
                        ep.name,
                        cls,
                    )
                    continue

                channel_id: str = getattr(cls, "channel_id", ep.name)
                credentials = credential_store.get_plugin_credentials(channel_id)
                plugin: _CoreChannelPlugin = cls(credentials=credentials)
                results.append((channel_id, plugin))
                logger.info(
                    "PluginLoader: loaded entry-point plugin %r for channel %r",
                    cls.__name__,
                    channel_id,
                )

            except Exception as exc:
                logger.warning(
                    "PluginLoader: failed to load entry point %r: %s — skipped.",
                    ep.name,
                    exc,
                )

        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_config(channel_id: str, cfg_dict: dict[str, Any]) -> PluginConfig:
        """Build a PluginConfig from a raw config dict."""
        extra = {k: v for k, v in cfg_dict.items() if k not in _LOADER_KEYS}
        return PluginConfig(
            channel_id=channel_id,
            timeout_seconds=float(cfg_dict.get("timeout_seconds", 30.0)),
            max_retries=cfg_dict.get("max_retries"),  # None → use class default
            rate_limit=cfg_dict.get("rate_limit"),     # None → use class default
            extra=extra,
        )
