"""Top-level configuration dataclasses for the Notification Manager.

NotificationManagerConfig follows the same layered construction approach as
Logger_Package: defaults → environment variables → config file → explicit kwargs.
The layered builder will be implemented in the engine phase; this module only
defines the schema.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class RetryPolicyConfig:
    """Parameters controlling the exponential-backoff retry policy.

    Applied globally by default; individual plugins may override via
    PluginConfig.retry_policy.
    """

    max_attempts: int = 3
    initial_delay_seconds: float = 1.0
    backoff_multiplier: float = 2.0
    max_delay_seconds: float = 60.0
    jitter: bool = True


@dataclass
class NotificationManagerConfig:
    """Central configuration for a NotificationManager instance.

    Fields
    ------
    plugins
        List of raw plugin config dicts (channel_id, timeout_seconds, …).
        Secrets are never stored here — use the credential_store instead.
    credential_store
        Which CredentialStore implementation to use: "env" or "cache".
    env_file
        Path to the .env file loaded by EnvCredentialStore.
        Defaults to ".env" in the current working directory.
    default_channel
        Fallback channel_id used by DefaultRoutingStrategy when the
        Notification carries no channel_hint and the Recipient has no
        channel preferences.
    cache_backend
        Backend name passed to the Cache_Manager factory.
        "memory" (default) works in a single process; use "redis" for
        distributed deployments.
    cache_config
        Keyword arguments forwarded to the Cache_Manager factory.
    log_level
        Logging level used when setting up the Logger_Package integration.
    enable_scheduler
        When True, the engine activates the delayed-dispatch scheduler.
    enable_rate_limiting
        When True, the engine enforces per-channel and per-recipient limits.
    max_global_rps
        Global maximum notifications per second across all channels.
    retry_policy
        Default retry policy applied to all delivery attempts.
    """

    # Plugin registration (no secrets — secrets live in the credential store)
    plugins: list[dict[str, Any]] = field(default_factory=list)

    # Credentials
    credential_store: str = "env"
    env_file: str = ".env"

    # Routing
    default_channel: Optional[str] = None

    # Cache (rate limiting, idempotency, scheduling, optional credential caching)
    cache_backend: str = "memory"
    cache_config: dict[str, Any] = field(default_factory=dict)

    # Logging
    log_level: str = "INFO"

    # Feature flags
    enable_scheduler: bool = False
    enable_rate_limiting: bool = True
    max_global_rps: int = 100

    # Retry
    retry_policy: RetryPolicyConfig = field(default_factory=RetryPolicyConfig)

    @classmethod
    def from_env(cls) -> "NotificationManagerConfig":
        """Construct a config instance populated from environment variables.

        Recognised variables (all optional):
            NM_DEFAULT_CHANNEL
            NM_CACHE_BACKEND
            NM_LOG_LEVEL
            NM_ENABLE_SCHEDULER       (1 / true / yes)
            NM_ENABLE_RATE_LIMITING   (1 / true / yes)
            NM_MAX_GLOBAL_RPS
            NM_ENV_FILE
            NM_CREDENTIAL_STORE
            NM_RETRY_MAX_ATTEMPTS
            NM_RETRY_INITIAL_DELAY
            NM_RETRY_BACKOFF_MULTIPLIER
            NM_RETRY_MAX_DELAY
            NM_RETRY_JITTER           (1 / true / yes)
        """

        def _bool(key: str, default: bool) -> bool:
            val = os.getenv(key, "").strip().lower()
            if not val:
                return default
            return val in ("1", "true", "yes")

        retry = RetryPolicyConfig(
            max_attempts=int(os.getenv("NM_RETRY_MAX_ATTEMPTS", "3")),
            initial_delay_seconds=float(os.getenv("NM_RETRY_INITIAL_DELAY", "1.0")),
            backoff_multiplier=float(os.getenv("NM_RETRY_BACKOFF_MULTIPLIER", "2.0")),
            max_delay_seconds=float(os.getenv("NM_RETRY_MAX_DELAY", "60.0")),
            jitter=_bool("NM_RETRY_JITTER", True),
        )

        return cls(
            credential_store=os.getenv("NM_CREDENTIAL_STORE", "env"),
            env_file=os.getenv("NM_ENV_FILE", ".env"),
            default_channel=os.getenv("NM_DEFAULT_CHANNEL") or None,
            cache_backend=os.getenv("NM_CACHE_BACKEND", "memory"),
            log_level=os.getenv("NM_LOG_LEVEL", "INFO"),
            enable_scheduler=_bool("NM_ENABLE_SCHEDULER", False),
            enable_rate_limiting=_bool("NM_ENABLE_RATE_LIMITING", True),
            max_global_rps=int(os.getenv("NM_MAX_GLOBAL_RPS", "100")),
            retry_policy=retry,
        )
