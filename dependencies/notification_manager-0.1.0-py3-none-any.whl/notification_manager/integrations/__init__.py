"""Integration layer — adapters for Logger_Package, Error-Exception_Handler, Cache_Manager."""

from notification_manager.integrations.cache import (
    get_notification_cache,
    is_backend_available,
    list_available_backends,
)
from notification_manager.integrations.error_handler import (
    create_error_handler,
    handle_delivery_error,
    normalize_exception,
)
from notification_manager.integrations.logger import (
    attach_redactor,
    bind_context,
    bound_context,
    clear_context,
    get_context,
    get_logger,
    new_correlation_id,
    reset_context,
    setup_logging,
)

__all__ = [
    # Cache
    "get_notification_cache",
    "is_backend_available",
    "list_available_backends",
    # Error handler
    "create_error_handler",
    "handle_delivery_error",
    "normalize_exception",
    # Logger
    "setup_logging",
    "get_logger",
    "attach_redactor",
    "bind_context",
    "reset_context",
    "bound_context",
    "get_context",
    "clear_context",
    "new_correlation_id",
]
