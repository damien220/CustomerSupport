"""Cache integration — factory wrapper around ``Cache_Manager``.

Provides a single ``get_notification_cache()`` entry point that:

1. Tries to create a ``cache_manager.AbstractCache`` via
   ``cache_manager.get_cache(backend, **config)``.
2. Returns ``None`` on ``ImportError`` so the rest of the package can
   fall back to its in-process dicts.

The ``NotificationManager``, ``MessageManager``, ``NotificationScheduler``,
``RateLimiter``, and credential stores all accept an optional ``cache``
parameter.  Obtain the cache once at startup and pass the same instance to
each component so they share a single backend connection.

Typical usage
-------------
::

    from notification_manager.integrations.cache import get_notification_cache

    # Redis-backed (requires cache_manager[redis])
    cache = get_notification_cache("redis", host="localhost", port=6379, db=0)

    # In-process memory (default; no external dependency)
    cache = get_notification_cache("memory")

    manager = NotificationManager(registry=registry, cache=cache)

Available backends
------------------
The list depends on which extras are installed; call
``list_available_backends()`` to inspect at runtime.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Cache_Manager — import with graceful fallback
# ---------------------------------------------------------------------------
try:
    from cache_manager import (  # type: ignore[import-untyped]
        AbstractCache as _AbstractCache,
        get_cache as _get_cache,
        is_backend_available as _is_backend_available,
        list_available_backends as _list_available_backends,
    )
    _CACHE_MANAGER_AVAILABLE = True
except ImportError:
    _CACHE_MANAGER_AVAILABLE = False
    _AbstractCache = None  # type: ignore[assignment,misc]
    _get_cache = None  # type: ignore[assignment]
    _is_backend_available = None  # type: ignore[assignment]
    _list_available_backends = None  # type: ignore[assignment]
    logger.debug(
        "cache_manager not installed — get_notification_cache() will return None; "
        "notification_manager will use in-process dicts."
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_notification_cache(
    backend: str = "memory",
    **config: Any,
) -> Optional[Any]:
    """Create and return an ``AbstractCache`` instance.

    Parameters
    ----------
    backend
        Cache backend identifier (e.g. ``"memory"``, ``"redis"``,
        ``"memcached"``).  See ``list_available_backends()`` for what is
        installed.
    **config
        Backend-specific keyword arguments (e.g. ``host``, ``port``, ``db``
        for Redis; ``max_size`` for the memory backend).

    Returns
    -------
    AbstractCache or None
        A ready-to-use cache instance, or ``None`` if ``cache_manager`` is not
        installed.  All notification_manager components accept ``None`` and fall
        back to in-process storage.

    Raises
    ------
    cache_manager.CacheBackendError
        If the requested backend is installed but cannot connect (e.g. Redis
        is unreachable).  Let this propagate to the caller so they can decide
        whether to abort startup or continue with ``None``.
    """
    if not _CACHE_MANAGER_AVAILABLE or _get_cache is None:
        logger.debug(
            "get_notification_cache(%r): cache_manager not available — returning None.",
            backend,
        )
        return None

    try:
        cache = _get_cache(backend, **config)
        logger.info(
            "get_notification_cache: created %r cache backend.", backend
        )
        return cache
    except Exception as exc:
        logger.warning(
            "get_notification_cache: failed to create %r backend (%s) — returning None.",
            backend,
            exc,
        )
        return None


def is_backend_available(backend: str) -> bool:
    """Return ``True`` if *backend* can be instantiated.

    Delegates to ``cache_manager.is_backend_available()`` when available.
    Always returns ``False`` when ``cache_manager`` is not installed.
    """
    if not _CACHE_MANAGER_AVAILABLE or _is_backend_available is None:
        return False
    try:
        return _is_backend_available(backend)
    except Exception:
        return False


def list_available_backends() -> list[str]:
    """Return the list of cache backends that are currently usable.

    Delegates to ``cache_manager.list_available_backends()`` when available.
    Returns an empty list when ``cache_manager`` is not installed.
    """
    if not _CACHE_MANAGER_AVAILABLE or _list_available_backends is None:
        return []
    try:
        return list(_list_available_backends())
    except Exception:
        return []
