"""Error-handler integration — bridges notification_manager exceptions with
``error_handler`` (the ``Error-Exception_Handler`` package).

Responsibilities
----------------
- **normalize_exception** — convert any ``NotificationManagerError`` into an
  ``ErrorResponse`` (from ``error_handler``) with a sanitised message.
- **handle_delivery_error** — specialised handler that formats a delivery
  failure into a structured response and optionally delegates to an
  ``ErrorHandler`` instance.
- **create_error_handler** — factory that returns a configured
  ``ErrorHandler`` ready to process ``NotificationManagerError`` subclasses.

All functions degrade gracefully when ``error_handler`` is not installed.

Typical usage
-------------
::

    from notification_manager.integrations.error_handler import (
        normalize_exception,
        handle_delivery_error,
    )
    from notification_manager.exceptions import DeliveryFailedError

    try:
        receipt = await manager.send(notification)
    except DeliveryFailedError as exc:
        response = handle_delivery_error(exc, notification)
        # response.status_code, response.error, response.detail …
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

from notification_manager.exceptions import (
    DeliveryFailedError,
    NotificationManagerError,
)

if TYPE_CHECKING:
    from notification_manager.models.notification import Notification

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# error_handler package — import with graceful fallback
# ---------------------------------------------------------------------------
try:
    from error_handler import (  # type: ignore[import-untyped]
        ErrorFormatter as _ErrorFormatter,
        ErrorHandler as _ErrorHandler,
        ErrorResponse as _ErrorResponse,
        InternalException as _InternalException,
    )
    _ERROR_HANDLER_AVAILABLE = True
except ImportError:
    _ERROR_HANDLER_AVAILABLE = False
    _ErrorFormatter = None  # type: ignore[assignment,misc]
    _ErrorHandler = None  # type: ignore[assignment,misc]
    _ErrorResponse = None  # type: ignore[assignment,misc]
    _InternalException = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Simple fallback response for when error_handler is not installed
# ---------------------------------------------------------------------------

class _FallbackErrorResponse:
    """Minimal error response used when ``error_handler`` is not available."""

    def __init__(self, error: str, detail: str, status_code: int = 500) -> None:
        self.error = error
        self.detail = detail
        self.status_code = status_code

    def __repr__(self) -> str:
        return (
            f"ErrorResponse(status_code={self.status_code}, "
            f"error={self.error!r}, detail={self.detail!r})"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_error_handler(**kwargs: Any) -> Any:
    """Return a configured ``ErrorHandler`` from the ``error_handler`` package.

    Parameters
    ----------
    **kwargs
        Forwarded to ``ErrorHandler.__init__()`` (e.g. ``logger``, custom
        formatters).

    Returns
    -------
    ErrorHandler or None
        A ready-to-use ``ErrorHandler`` instance, or ``None`` if the
        ``error_handler`` package is not installed.
    """
    if not _ERROR_HANDLER_AVAILABLE or _ErrorHandler is None:
        logger.debug(
            "error_handler package not installed — create_error_handler() returns None."
        )
        return None
    return _ErrorHandler(**kwargs)


def normalize_exception(
    exc: Exception,
    redactor: Optional[Any] = None,
) -> Any:
    """Convert *exc* into a structured error response.

    Parameters
    ----------
    exc
        Any exception, typically a ``NotificationManagerError`` subclass.
    redactor
        Optional ``Redactor`` instance.  When provided, the exception message
        is scrubbed before it is included in the response.

    Returns
    -------
    ErrorResponse (or _FallbackErrorResponse)
        A structured response with ``error``, ``detail``, and ``status_code``
        fields.
    """
    message = str(exc)
    if redactor is not None:
        message = redactor.scrub(message)

    # Map NotificationManagerError subclasses to HTTP-style status codes.
    status_code = _status_for(exc)

    if _ERROR_HANDLER_AVAILABLE and _ErrorFormatter is not None:
        try:
            formatted = _ErrorFormatter.format(exc)
            return _FallbackErrorResponse(
                error=type(exc).__name__,
                detail=message,
                status_code=status_code,
            ) if formatted is None else formatted
        except Exception as fmt_exc:
            logger.debug("ErrorFormatter.format() failed: %s", fmt_exc)

    return _FallbackErrorResponse(
        error=type(exc).__name__,
        detail=message,
        status_code=status_code,
    )


def handle_delivery_error(
    exc: Exception,
    notification: Optional["Notification"] = None,
    handler: Optional[Any] = None,
    redactor: Optional[Any] = None,
) -> Any:
    """Handle a delivery failure.

    Logs the error, scrubs secrets from the message, and returns a
    structured response.  Optionally delegates to a provided
    ``ErrorHandler`` instance.

    Parameters
    ----------
    exc
        The exception raised during delivery (typically ``DeliveryFailedError``).
    notification
        The notification whose delivery failed (used for context logging).
    handler
        An ``ErrorHandler`` instance (from ``create_error_handler()``).
        When provided, ``handler.handle(exc)`` is called.
    redactor
        ``Redactor`` used to scrub the error message.

    Returns
    -------
    ErrorResponse (or _FallbackErrorResponse)
        Structured representation of the failure.
    """
    message = str(exc)
    if redactor is not None:
        message = redactor.scrub(message)

    log_context: dict[str, Any] = {"error": message}
    if notification is not None:
        log_context["notification_id"] = getattr(notification, "id", "?")
        log_context["channel"] = getattr(notification, "channel_hint", "?")

    logger.error("Delivery error: %s | context=%s", message, log_context)

    # Delegate to ErrorHandler if provided.
    if handler is not None:
        try:
            result = handler.handle(exc)
            if result is not None:
                return result
        except Exception as handler_exc:
            logger.debug("ErrorHandler.handle() raised: %s", handler_exc)

    return normalize_exception(exc, redactor=redactor)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _status_for(exc: Exception) -> int:
    """Map a notification_manager exception type to an HTTP-style status code."""
    from notification_manager.exceptions import (
        CredentialNotFoundError,
        PluginConfigError,
        PluginNotFoundError,
        RateLimitExceededError,
        TemplateRenderError,
    )

    mapping: dict[type, int] = {
        PluginNotFoundError: 404,
        PluginConfigError: 422,
        CredentialNotFoundError: 401,
        RateLimitExceededError: 429,
        TemplateRenderError: 422,
        DeliveryFailedError: 502,
        NotificationManagerError: 500,
    }
    for exc_type, code in mapping.items():
        if isinstance(exc, exc_type):
            return code
    return 500
