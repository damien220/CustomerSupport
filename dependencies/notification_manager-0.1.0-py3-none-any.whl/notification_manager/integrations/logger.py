"""Logger integration — wires ``notification_manager`` into ``Logger_Package``.

This module provides a thin adapter between the notification manager and the
``logger_pkg`` package already present in this repository.  All functions
degrade gracefully when ``logger_pkg`` is not installed, falling back to the
standard-library ``logging`` module.

Key responsibilities
--------------------
- **setup_logging** — configure the logging pipeline (format, level, file,
  JSON) for the ``notification_manager`` namespace via ``logger_pkg``.
- **get_logger** — return a logger for a given name, using ``logger_pkg``'s
  context-enriched logger when available.
- **bind_context / reset_context / bound_context** — forward context helpers
  so callers do not need a direct ``logger_pkg`` import.
- **attach_redactor** — attach a ``Redactor``-backed ``PIIFilter`` to every
  handler on the ``notification_manager`` root logger so secrets can never
  leak into log files.

Typical setup (application startup)
------------------------------------
::

    from notification_manager.integrations.logger import setup_logging, attach_redactor
    from notification_manager.credentials import Redactor

    redactor = Redactor()
    redactor.register_pattern(r"xoxb-\\S+")   # Slack tokens

    listener = setup_logging(level="INFO", fmt="json")
    attach_redactor(redactor)
    # … after registering plugins, also call redactor.register_secret(token_value)
"""

from __future__ import annotations

import logging
import logging.handlers
from contextlib import contextmanager
from typing import Any, Generator, Optional

# ---------------------------------------------------------------------------
# Logger_Package — import with graceful fallback
# ---------------------------------------------------------------------------
try:
    from logger_pkg import (  # type: ignore[import-untyped]
        bind_context as _bind_context,
        bound_context as _bound_context,
        clear_context as _clear_context,
        get_context as _get_context,
        get_logger as _get_logger,
        new_correlation_id as _new_correlation_id,
        reset_context as _reset_context,
        setup_logging as _setup_logging,
    )
    _LOGGER_PKG_AVAILABLE = True
except ImportError:
    _LOGGER_PKG_AVAILABLE = False
    _bind_context = None  # type: ignore[assignment]
    _bound_context = None  # type: ignore[assignment]
    _clear_context = None  # type: ignore[assignment]
    _get_context = None  # type: ignore[assignment]
    _get_logger = None  # type: ignore[assignment]
    _new_correlation_id = None  # type: ignore[assignment]
    _reset_context = None  # type: ignore[assignment]
    _setup_logging = None  # type: ignore[assignment]

_NM_LOGGER_NAME = "notification_manager"
_std_logger = logging.getLogger(_NM_LOGGER_NAME)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def setup_logging(
    level: str = "INFO",
    fmt: str = "human",
    file_path: Optional[str] = None,
    async_queue: bool = False,
    **kwargs: Any,
) -> Optional[Any]:
    """Configure the logging pipeline for ``notification_manager``.

    Delegates to ``logger_pkg.setup_logging()`` when available; otherwise
    applies a basic ``logging.basicConfig()`` fallback.

    Parameters
    ----------
    level
        Log level string: ``"DEBUG"``, ``"INFO"``, ``"WARNING"``, etc.
    fmt
        Output format: ``"human"`` (default) or ``"json"``.  Ignored in
        fallback mode.
    file_path
        When provided, also write logs to this file path.
    async_queue
        Enable asynchronous log queue (``logger_pkg`` feature).
    **kwargs
        Additional keyword arguments forwarded to ``logger_pkg.setup_logging``
        or ``logger_pkg.build_config``.

    Returns
    -------
    Any or None
        The ``QueueListener`` returned by ``logger_pkg`` (call ``.stop()`` at
        shutdown), or ``None`` in fallback mode.
    """
    if _LOGGER_PKG_AVAILABLE:
        try:
            from logger_pkg.config import build_config  # type: ignore[import-untyped]

            cfg = build_config(
                level=level,
                format=fmt,
                file_enabled=file_path is not None,
                file_path=file_path or "notification_manager.log",
                async_queue_enabled=async_queue,
                pii_filter_enabled=True,
                **kwargs,
            )
            return _setup_logging(config=cfg)
        except Exception as exc:
            _std_logger.warning(
                "notification_manager: logger_pkg setup failed (%s); "
                "falling back to basicConfig.",
                exc,
            )

    # Fallback: standard library
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    if file_path:
        fh = logging.FileHandler(file_path)
        fh.setLevel(getattr(logging, level.upper(), logging.INFO))
        logging.getLogger().addHandler(fh)
    return None


def get_logger(name: str) -> logging.Logger:
    """Return a logger for *name*.

    Uses ``logger_pkg.get_logger()`` when available (adds context enrichment),
    otherwise returns ``logging.getLogger(name)``.

    Parameters
    ----------
    name
        Logger name — use ``__name__`` for module-scoped loggers.
    """
    if _LOGGER_PKG_AVAILABLE and _get_logger is not None:
        try:
            return _get_logger(name)  # type: ignore[return-value]
        except Exception:
            pass
    return logging.getLogger(name)


def bind_context(**fields: Any) -> Any:
    """Attach context fields to the current thread / asyncio task.

    Delegates to ``logger_pkg.bind_context()`` when available.  Returns the
    token produced by the context var; pass it to ``reset_context()`` to undo.

    Parameters
    ----------
    **fields
        Arbitrary key/value pairs to include in every log record until
        ``reset_context()`` or ``clear_context()`` is called.
    """
    if _LOGGER_PKG_AVAILABLE and _bind_context is not None:
        try:
            return _bind_context(**fields)
        except Exception:
            pass
    return None


def reset_context(token: Any) -> None:
    """Remove context fields via the token returned by ``bind_context()``.

    No-op when ``logger_pkg`` is not installed.
    """
    if _LOGGER_PKG_AVAILABLE and _reset_context is not None and token is not None:
        try:
            _reset_context(token)
        except Exception:
            pass


def clear_context() -> None:
    """Remove all context fields for the current thread / asyncio task."""
    if _LOGGER_PKG_AVAILABLE and _clear_context is not None:
        try:
            _clear_context()
        except Exception:
            pass


def get_context() -> dict[str, Any]:
    """Return the current context dict.  Empty dict in fallback mode."""
    if _LOGGER_PKG_AVAILABLE and _get_context is not None:
        try:
            return _get_context()
        except Exception:
            pass
    return {}


@contextmanager
def bound_context(**fields: Any) -> Generator[None, None, None]:
    """Context manager: bind context fields and automatically reset on exit.

    Delegates to ``logger_pkg.bound_context()`` when available; otherwise
    yields immediately (fields are ignored in fallback mode).

    Usage
    -----
    ::

        async with bound_context(notification_id="abc", channel="slack"):
            await manager.send(notification)
    """
    if _LOGGER_PKG_AVAILABLE and _bound_context is not None:
        try:
            with _bound_context(**fields):
                yield
            return
        except Exception:
            pass
    yield  # fallback: no-op


def new_correlation_id() -> str:
    """Generate a random UUID4 string suitable as a correlation id.

    Delegates to ``logger_pkg.new_correlation_id()`` when available.
    """
    if _LOGGER_PKG_AVAILABLE and _new_correlation_id is not None:
        try:
            return _new_correlation_id()
        except Exception:
            pass
    import uuid
    return str(uuid.uuid4())


def attach_redactor(
    redactor: Any,
    logger_name: str = _NM_LOGGER_NAME,
) -> None:
    """Attach a ``Redactor``-backed ``PIIFilter`` to all handlers on *logger_name*.

    Call this after registering plugins so that all secret values are
    already registered in the ``Redactor`` before the filter is attached.

    Parameters
    ----------
    redactor
        A ``notification_manager.credentials.Redactor`` instance.
    logger_name
        The root logger to protect.  Defaults to ``"notification_manager"``.
    """
    pii_filter = redactor.build_pii_filter(name="nm_pii_filter")
    target_logger = logging.getLogger(logger_name)

    # Attach to all existing handlers.
    for handler in target_logger.handlers:
        if not any(type(f).__name__ == "PIIFilter" for f in handler.filters):
            handler.addFilter(pii_filter)

    # If no handlers on this logger, attach to the root logger's handlers.
    if not target_logger.handlers:
        for handler in logging.getLogger().handlers:
            if not any(
                getattr(f, "name", None) == "nm_pii_filter" for f in handler.filters
            ):
                handler.addFilter(pii_filter)

    _std_logger.debug("attach_redactor: PIIFilter attached to logger %r.", logger_name)
