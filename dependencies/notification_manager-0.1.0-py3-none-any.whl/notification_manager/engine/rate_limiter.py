"""Token-bucket rate limiter backed by Cache_Manager.

Three independent scopes are checked in order for every send:

1. **Global** — total notifications/second across all channels.
2. **Per-channel** — throughput limit declared by the plugin's ``RateLimit``.
3. **Per-recipient** — applied only when ``RateLimit.per_recipient`` is True.

If any scope is exhausted ``RateLimitExceededError`` is raised immediately.
The caller (``NotificationManager``) catches it and marks the notification
as SKIPPED, or propagates it to the application if preferred.

Token-bucket algorithm
----------------------
Each scope maintains a state dict cached under a namespaced key::

    {"tokens": float, "last_refill": float}   # last_refill is time.monotonic()

On each request:

1. Compute elapsed seconds since ``last_refill``.
2. Refill: ``new_tokens = min(burst_size, tokens + elapsed * rps)``.
3. If ``new_tokens >= 1.0``: consume one token, allow the request.
4. Else: compute ``retry_after = (1.0 - new_tokens) / rps`` and raise
   ``RateLimitExceededError``.

Cache TTL is set to ``burst_size / rps * 2`` so that idle buckets expire
and the cache does not grow unbounded.

Thread / async safety
---------------------
The token-bucket update is not atomic when backed by a remote cache (Redis).
For high-throughput single-instance deployments this is acceptable; for
strict enforcement across multiple processes, add a distributed lock.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Optional

from notification_manager.exceptions import RateLimitExceededError

if TYPE_CHECKING:
    from notification_manager.config import NotificationManagerConfig
    from notification_manager.core.abstract_channel import ChannelPlugin
    from notification_manager.models.notification import Notification

logger = logging.getLogger(__name__)

_NS = "nm:rl"

# Fallback in-memory dict when Cache_Manager is unavailable.
_fallback_store: dict[str, dict[str, float]] = {}


class RateLimiter:
    """Token-bucket rate limiter with global, per-channel, and per-recipient scopes.

    Parameters
    ----------
    cache
        Any ``AbstractCache`` instance (synchronous). When ``None``, an
        in-process dict is used (single-process only, not persistent).
    config
        ``NotificationManagerConfig`` — supplies ``max_global_rps``.
    """

    def __init__(
        self,
        cache: Any,   # AbstractCache | None
        config: "NotificationManagerConfig",
    ) -> None:
        self._cache = cache
        self._global_rps = float(config.max_global_rps)
        self._global_burst = max(1, config.max_global_rps)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(
        self,
        notification: "Notification",
        channel_id: str,
        plugin: "ChannelPlugin",
    ) -> None:
        """Check all applicable rate-limit scopes for this send operation.

        Raises
        ------
        RateLimitExceededError
            On the first scope whose bucket is exhausted. The caller may
            catch this to skip delivery or propagate it to the application.
        """
        # 1. Global scope
        self._consume(
            scope=f"{_NS}:global",
            rps=self._global_rps,
            burst=self._global_burst,
        )

        # 2. Per-channel scope (from plugin's RateLimit declaration)
        rate_limit = getattr(plugin, "rate_limit", None)
        if rate_limit is not None:
            self._consume(
                scope=f"{_NS}:channel:{channel_id}",
                rps=rate_limit.requests_per_second,
                burst=rate_limit.burst_size,
            )

            # 3. Per-recipient scope (opt-in via rate_limit.per_recipient)
            if rate_limit.per_recipient:
                self._consume(
                    scope=f"{_NS}:recipient:{notification.recipient.id}:{channel_id}",
                    rps=rate_limit.requests_per_second,
                    burst=rate_limit.burst_size,
                )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _consume(self, scope: str, rps: float, burst: int) -> None:
        """Consume one token from the bucket at *scope*, or raise on exhaustion."""
        if rps <= 0:
            return  # rate limiting disabled for this scope

        now = time.monotonic()
        state = self._get(scope)

        if state is None:
            # First request for this scope — initialise a full bucket.
            state = {"tokens": float(burst) - 1.0, "last_refill": now}
            self._set(scope, state, rps, burst)
            return

        # Refill tokens based on elapsed time.
        elapsed: float = now - state["last_refill"]
        new_tokens: float = min(float(burst), state["tokens"] + elapsed * rps)

        if new_tokens >= 1.0:
            state["tokens"] = new_tokens - 1.0
            state["last_refill"] = now
            self._set(scope, state, rps, burst)
        else:
            retry_after: float = (1.0 - new_tokens) / rps
            logger.debug(
                "RateLimiter: bucket exhausted for scope %r "
                "(tokens=%.3f, retry_after=%.2fs)",
                scope,
                new_tokens,
                retry_after,
            )
            raise RateLimitExceededError(
                scope=scope,
                retry_after_seconds=round(retry_after, 2),
            )

    def _get(self, scope: str) -> Optional[dict[str, float]]:
        if self._cache is not None:
            return self._cache.get(scope)
        return _fallback_store.get(scope)

    def _set(
        self,
        scope: str,
        state: dict[str, float],
        rps: float,
        burst: int,
    ) -> None:
        ttl = int(burst / rps * 2) + 1
        if self._cache is not None:
            self._cache.set(scope, state, ttl=ttl)
        else:
            _fallback_store[scope] = state
