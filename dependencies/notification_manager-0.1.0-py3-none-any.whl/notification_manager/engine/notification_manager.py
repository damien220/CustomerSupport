"""NotificationManager — the main delivery orchestrator.

Wires together the plugin registry, router, retry policy, rate limiter,
idempotency check, and redactor into a single ``send()`` entry point.

Typical setup
-------------
::

    from notification_manager import (
        NotificationManager, PluginRegistry, EnvCredentialStore,
        NotificationManagerConfig,
    )

    store    = EnvCredentialStore()
    registry = PluginRegistry()
    registry.register("slack", MySlackPlugin(credentials=store.get_plugin_credentials("slack")))

    manager = NotificationManager(registry=registry)
    await manager.start()

    receipt = await manager.send(notification)
    await manager.stop()

Delivery flow for ``send()``
-----------------------------
1. **Idempotency** — if ``notification.idempotency_key`` has already been
   delivered (cached), the existing receipt is returned immediately.
2. **Routing** — ``RoutingStrategy.resolve()`` produces an ordered list of
   channel_ids to try.
3. **Per-channel attempt loop** — for each channel in the resolved list:
   a. Rate-limit check (raises ``RateLimitExceededError`` if exhausted).
   b. Retry loop — calls ``plugin.send()`` up to ``max_retries`` times.
      Delays between attempts follow the ``RetryPolicy``.
   c. On success, the receipt is finalised and the loop exits.
4. **Receipt caching** — the final ``DeliveryReceipt`` is stored in the
   cache for later retrieval via ``get_status()``.
5. Return the receipt.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any, Optional

from notification_manager.config import NotificationManagerConfig
from notification_manager.credentials.redactor import Redactor
from notification_manager.engine.rate_limiter import RateLimiter
from notification_manager.engine.retry import ExponentialBackoffPolicy, RetryPolicy
from notification_manager.engine.router import DefaultRoutingStrategy
from notification_manager.exceptions import (
    DeliveryFailedError,
    PluginNotFoundError,
    RateLimitExceededError,
)
from notification_manager.models.delivery import DeliveryAttempt, DeliveryReceipt, DeliveryStatus
from notification_manager.models.notification import Notification, NotificationStatus
from notification_manager.plugins.registry import PluginRegistry

logger = logging.getLogger(__name__)


def _make_cache(backend: str, config: dict[str, Any]) -> Any:
    """Attempt to create a Cache_Manager instance; return None on ImportError."""
    try:
        from cache_manager import get_cache  # type: ignore[import-untyped]
        return get_cache(backend, **config)
    except ImportError:
        logger.debug(
            "cache_manager not installed — idempotency and rate-limit state "
            "will be held in-process (not shared across workers)."
        )
        return None


class NotificationManager:
    """Async orchestrator for notification delivery.

    Parameters
    ----------
    registry
        Active ``PluginRegistry`` with at least one registered plugin.
    config
        Global configuration. Defaults to ``NotificationManagerConfig()``
        (memory cache, 3 retries, rate limiting enabled).
    router
        Routing strategy. Defaults to ``DefaultRoutingStrategy``.
    retry_policy
        Retry strategy. Defaults to ``ExponentialBackoffPolicy`` built
        from ``config.retry_policy``.
    cache
        ``AbstractCache`` for idempotency, receipt storage, and rate
        limiting. When ``None``, the manager tries to build one from
        ``config.cache_backend``; falls back to a plain dict on failure.
    redactor
        ``Redactor`` used to scrub secrets from error messages and logs.
        Defaults to a fresh instance (no patterns registered).
    """

    def __init__(
        self,
        registry: PluginRegistry,
        config: Optional[NotificationManagerConfig] = None,
        router: Optional[object] = None,
        retry_policy: Optional[RetryPolicy] = None,
        cache: Optional[Any] = None,
        redactor: Optional[Redactor] = None,
    ) -> None:
        self._registry = registry
        self._config = config or NotificationManagerConfig()
        self._redactor = redactor or Redactor()

        # Cache (idempotency, receipts, rate-limit state)
        self._cache = cache or _make_cache(
            self._config.cache_backend,
            self._config.cache_config,
        )

        # Fallback in-process receipt store when cache is unavailable.
        self._receipt_store: dict[str, DeliveryReceipt] = {}

        # Router
        self._router = router or DefaultRoutingStrategy(
            registry=self._registry,
            default_channel=self._config.default_channel,
        )

        # Retry policy
        self._retry_policy: RetryPolicy = retry_policy or ExponentialBackoffPolicy.from_config(
            self._config.retry_policy
        )

        # Rate limiter (only when enabled in config)
        self._rate_limiter: Optional[RateLimiter] = (
            RateLimiter(cache=self._cache, config=self._config)
            if self._config.enable_rate_limiting
            else None
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Connect all registered plugins.

        Call this once before the first ``send()``. Raises ``PluginConfigError``
        if any plugin's ``connect()`` fails.
        """
        logger.info("NotificationManager: starting — connecting %d plugin(s).", len(self._registry))
        await self._registry.connect_all()
        logger.info("NotificationManager: all plugins connected.")

    async def stop(self) -> None:
        """Disconnect all registered plugins.

        Safe to call even if ``start()`` was never called or failed partway.
        """
        logger.info("NotificationManager: stopping.")
        await self._registry.disconnect_all()
        logger.info("NotificationManager: stopped.")

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    async def send(self, notification: Notification) -> DeliveryReceipt:
        """Deliver a single notification.

        Parameters
        ----------
        notification
            The notification to deliver. Must have a populated ``recipient``.

        Returns
        -------
        DeliveryReceipt
            Reflects the final delivery outcome. Status is one of:
            ``DELIVERED``, ``FAILED``, or ``SKIPPED``.

        Raises
        ------
        RateLimitExceededError
            Re-raised when the rate limit is exceeded and the notification
            cannot be queued for retry. (Catch this at the call site if you
            want to handle it rather than fail.)
        """
        # 1. Idempotency check — return existing receipt if already delivered.
        cached = self._get_receipt(notification.idempotency_key)
        if cached is not None and cached.is_terminal:
            logger.debug(
                "NotificationManager: idempotency hit for key %r — "
                "returning cached receipt (status=%s).",
                notification.idempotency_key,
                cached.status.value,
            )
            return cached

        # 2. Resolve channel list.
        channels = self._router.resolve(notification, notification.recipient)  # type: ignore[attr-defined]

        if not channels:
            receipt = DeliveryReceipt(
                notification_id=notification.id,
                channel_id="",
                status=DeliveryStatus.SKIPPED,
                error="No eligible channel found for this recipient.",
            )
            self._store_receipt(notification.idempotency_key, receipt)
            notification.status = NotificationStatus.FAILED
            return receipt

        # 3. Attempt delivery on each channel (first success stops the loop).
        receipt = DeliveryReceipt(
            notification_id=notification.id,
            channel_id=channels[0],
        )
        notification.status = NotificationStatus.DELIVERING

        for channel_id in channels:
            receipt.channel_id = channel_id

            # 3a. Rate limit check.
            if self._rate_limiter is not None:
                try:
                    plugin = self._registry.get(channel_id)
                    self._rate_limiter.check(notification, channel_id, plugin)
                except RateLimitExceededError:
                    logger.warning(
                        "NotificationManager: rate limit exceeded for channel %r "
                        "(notification=%r).",
                        channel_id,
                        notification.id,
                    )
                    raise
                except PluginNotFoundError:
                    continue  # channel disappeared from registry — try next
            else:
                try:
                    plugin = self._registry.get(channel_id)
                except PluginNotFoundError:
                    continue

            # 3b. Retry loop.
            delivered = await self._deliver_with_retry(
                notification=notification,
                plugin=plugin,
                receipt=receipt,
            )
            if delivered:
                break  # Success — don't try fallback channels.

        # 4. Final status assignment and caching.
        if receipt.status == DeliveryStatus.DELIVERED:
            notification.status = NotificationStatus.DELIVERED
        else:
            notification.status = NotificationStatus.FAILED

        self._store_receipt(notification.idempotency_key, receipt)
        logger.info(
            "NotificationManager: notification %r → %s (channel=%r, attempts=%d).",
            notification.id,
            receipt.status.value,
            receipt.channel_id,
            receipt.attempt_count,
        )
        return receipt

    async def broadcast(self, notifications: list[Notification]) -> list[DeliveryReceipt]:
        """Deliver multiple notifications, grouped by channel for batch efficiency.

        Notifications sharing the same resolved primary channel are grouped
        and delivered via ``plugin.send_batch()`` in a single call. Notifications
        whose primary channel differs are sent to their own group.

        Routing is performed individually per notification so that different
        recipients may use different channels within the same broadcast.

        Parameters
        ----------
        notifications
            List of notifications to deliver. May be empty (returns ``[]``).

        Returns
        -------
        list[DeliveryReceipt]
            One receipt per notification, in the same order as the input list.
        """
        if not notifications:
            return []

        # Group by resolved primary channel (first result from router).
        groups: dict[str, list[tuple[int, Notification]]] = {}
        unrouted: list[tuple[int, Notification]] = []

        for idx, notif in enumerate(notifications):
            channels = self._router.resolve(notif, notif.recipient)  # type: ignore[attr-defined]
            if not channels:
                unrouted.append((idx, notif))
            else:
                groups.setdefault(channels[0], []).append((idx, notif))

        receipts: list[Optional[DeliveryReceipt]] = [None] * len(notifications)

        # Deliver each group via send_batch().
        for channel_id, indexed_notifs in groups.items():
            try:
                plugin = self._registry.get(channel_id)
            except PluginNotFoundError:
                for idx, notif in indexed_notifs:
                    receipts[idx] = DeliveryReceipt(
                        notification_id=notif.id,
                        channel_id=channel_id,
                        status=DeliveryStatus.FAILED,
                        error=f"Plugin for channel {channel_id!r} not found.",
                    )
                continue

            batch = [n for _, n in indexed_notifs]
            batch_receipts = await plugin.send_batch(batch)

            for (idx, notif), receipt in zip(indexed_notifs, batch_receipts):
                self._store_receipt(notif.idempotency_key, receipt)
                receipts[idx] = receipt

        # Mark unrouted notifications as SKIPPED.
        for idx, notif in unrouted:
            receipt = DeliveryReceipt(
                notification_id=notif.id,
                channel_id="",
                status=DeliveryStatus.SKIPPED,
                error="No eligible channel found.",
            )
            self._store_receipt(notif.idempotency_key, receipt)
            receipts[idx] = receipt

        logger.info(
            "NotificationManager: broadcast complete — %d delivered, %d skipped.",
            sum(1 for r in receipts if r and r.status == DeliveryStatus.DELIVERED),
            len(unrouted),
        )
        return receipts  # type: ignore[return-value]

    async def get_status(self, notification_id: str) -> Optional[DeliveryReceipt]:
        """Look up the cached delivery receipt for a notification.

        Parameters
        ----------
        notification_id
            The ``Notification.id`` (or ``idempotency_key``) to look up.

        Returns
        -------
        DeliveryReceipt or None
            The receipt, or None if no record exists (delivery not attempted
            or cache expired).
        """
        return self._get_receipt(notification_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _deliver_with_retry(
        self,
        notification: Notification,
        plugin: Any,
        receipt: DeliveryReceipt,
    ) -> bool:
        """Attempt delivery with retry logic.

        Returns True on successful delivery, False when all attempts fail.
        Updates ``receipt`` in place after each attempt.
        """
        channel_id: str = type(plugin).channel_id
        max_attempts: int = plugin.max_retries
        timeout: float = (
            plugin._config.timeout_seconds
            if hasattr(plugin, "_config")
            else 30.0
        )
        last_exc: Optional[Exception] = None

        for attempt in range(1, max_attempts + 1):
            try:
                sub_receipt = await asyncio.wait_for(
                    plugin.send(notification),
                    timeout=timeout,
                )
                attempt_obj = DeliveryAttempt(
                    attempt_number=attempt,
                    channel_id=channel_id,
                    status=sub_receipt.status,
                    metadata=sub_receipt.metadata,
                )
                receipt.record_attempt(attempt_obj)

                if receipt.status == DeliveryStatus.DELIVERED:
                    return True
                if receipt.is_terminal:
                    # Plugin returned FAILED or SKIPPED directly.
                    return False

            except asyncio.TimeoutError as exc:
                last_exc = exc
                error_msg = f"Delivery timed out after {timeout:.0f}s."
                receipt.record_attempt(
                    DeliveryAttempt(
                        attempt_number=attempt,
                        channel_id=channel_id,
                        status=DeliveryStatus.FAILED,
                        error=error_msg,
                    )
                )

            except Exception as exc:
                last_exc = exc
                error_msg = self._redactor.scrub(str(exc))
                receipt.record_attempt(
                    DeliveryAttempt(
                        attempt_number=attempt,
                        channel_id=channel_id,
                        status=DeliveryStatus.FAILED,
                        error=error_msg,
                    )
                )

            # Decide whether to retry.
            if (
                attempt < max_attempts
                and self._retry_policy.should_retry(attempt, max_attempts, last_exc or Exception())
            ):
                delay = self._retry_policy.delay(attempt)
                logger.debug(
                    "NotificationManager: retry %d/%d for notification %r "
                    "on channel %r in %.2fs.",
                    attempt,
                    max_attempts,
                    notification.id,
                    channel_id,
                    delay,
                )
                receipt.status = DeliveryStatus.RETRYING
                await asyncio.sleep(delay)
            else:
                break

        receipt.status = DeliveryStatus.FAILED
        if last_exc:
            receipt.error = self._redactor.scrub(str(last_exc))
        return False

    # ------------------------------------------------------------------
    # Receipt persistence (cache or in-process fallback)
    # ------------------------------------------------------------------

    _RECEIPT_NS = "nm:receipt"
    _RECEIPT_TTL = 3600  # 1 hour

    def _receipt_key(self, key: str) -> str:
        return f"{self._RECEIPT_NS}:{key}"

    def _store_receipt(self, key: str, receipt: DeliveryReceipt) -> None:
        ckey = self._receipt_key(key)
        if self._cache is not None:
            try:
                self._cache.set(ckey, receipt, ttl=self._RECEIPT_TTL)
                return
            except Exception as exc:
                logger.debug("NotificationManager: cache write failed (%s); using fallback.", exc)
        self._receipt_store[ckey] = receipt

    def _get_receipt(self, key: str) -> Optional[DeliveryReceipt]:
        ckey = self._receipt_key(key)
        if self._cache is not None:
            try:
                value = self._cache.get(ckey)
                if value is not None:
                    return value
            except Exception as exc:
                logger.debug("NotificationManager: cache read failed (%s); using fallback.", exc)
        return self._receipt_store.get(ckey)
