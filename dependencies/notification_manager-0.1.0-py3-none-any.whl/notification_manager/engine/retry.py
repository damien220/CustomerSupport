"""Retry policy — controls whether and how delivery is re-attempted after failure.

Two components:
- ``RetryPolicy`` ABC — the contract.
- ``ExponentialBackoffPolicy`` — the default implementation (exponential delay
  with optional jitter and a configurable ceiling).

The ``NotificationManager`` consults the policy after each failed delivery
attempt. If ``should_retry()`` returns True it waits ``delay()`` seconds before
the next attempt.

Per-plugin override
-------------------
``PluginConfig.max_retries`` sets the ceiling on attempts for a specific channel.
The policy's ``should_retry()`` receives the current attempt number so it can
respect that ceiling::

    class MyPolicy(RetryPolicy):
        def should_retry(self, attempt: int, max_attempts: int, error: Exception) -> bool:
            return attempt < max_attempts and not isinstance(error, PermanentError)
"""

from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod

from notification_manager.config import RetryPolicyConfig


class RetryPolicy(ABC):
    """Contract for retry-decision and delay-calculation logic.

    The ``NotificationManager`` calls these two methods after each failed
    delivery attempt.
    """

    @abstractmethod
    def should_retry(self, attempt: int, max_attempts: int, error: Exception) -> bool:
        """Return True if delivery should be re-attempted.

        Parameters
        ----------
        attempt
            The 1-based number of the attempt that just failed.
        max_attempts
            The maximum number of attempts allowed (from plugin config or
            global config). When ``attempt >= max_attempts`` the caller
            will not retry regardless of this method's return value.
        error
            The exception raised by the last delivery attempt.

        Returns
        -------
        bool
            True → schedule another attempt after ``delay(attempt)`` seconds.
            False → mark delivery as permanently FAILED.
        """

    @abstractmethod
    def delay(self, attempt: int) -> float:
        """Return the number of seconds to wait before attempt ``attempt + 1``.

        Parameters
        ----------
        attempt
            The 1-based number of the attempt that just completed (and failed).

        Returns
        -------
        float
            Seconds to sleep. Must be >= 0.
        """


class ExponentialBackoffPolicy(RetryPolicy):
    """Exponential backoff with optional jitter.

    Delay formula (before jitter)::

        delay = min(initial_delay * multiplier^(attempt - 1), max_delay)

    With jitter enabled the delay is multiplied by a uniform random factor
    in ``[0.5, 1.5]``, reducing thundering-herd effects when many
    notifications fail simultaneously.

    Parameters
    ----------
    max_attempts
        Maximum total delivery attempts (including the first). Default: 3.
    initial_delay
        Delay in seconds before the second attempt. Default: 1.0.
    backoff_multiplier
        Growth factor applied on each successive failure. Default: 2.0.
    max_delay
        Upper bound on the computed delay (seconds). Default: 60.0.
    jitter
        When True, multiply the base delay by a uniform factor in [0.5, 1.5].
        Default: True.
    """

    def __init__(
        self,
        max_attempts: int = 3,
        initial_delay: float = 1.0,
        backoff_multiplier: float = 2.0,
        max_delay: float = 60.0,
        jitter: bool = True,
    ) -> None:
        self.max_attempts = max_attempts
        self.initial_delay = initial_delay
        self.backoff_multiplier = backoff_multiplier
        self.max_delay = max_delay
        self.jitter = jitter

    def should_retry(self, attempt: int, max_attempts: int, error: Exception) -> bool:
        """Retry unless the attempt ceiling has been reached."""
        return attempt < max_attempts

    def delay(self, attempt: int) -> float:
        """Return exponentially increasing delay for the given attempt number."""
        base = self.initial_delay * math.pow(self.backoff_multiplier, attempt - 1)
        base = min(base, self.max_delay)
        if self.jitter:
            base *= random.uniform(0.5, 1.5)
        return max(0.0, base)

    @classmethod
    def from_config(cls, config: RetryPolicyConfig) -> "ExponentialBackoffPolicy":
        """Construct from a ``RetryPolicyConfig`` dataclass."""
        return cls(
            max_attempts=config.max_attempts,
            initial_delay=config.initial_delay_seconds,
            backoff_multiplier=config.backoff_multiplier,
            max_delay=config.max_delay_seconds,
            jitter=config.jitter,
        )
