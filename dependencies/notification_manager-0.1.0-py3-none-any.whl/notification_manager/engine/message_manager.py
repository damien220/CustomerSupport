"""MessageManager — stateful messaging layer over the channel/plugin abstraction.

Manages threads, conversations, and read receipts. Delivery is delegated to
channel plugins; state is persisted in Cache_Manager (when available) or in
an in-process dict.

Typical usage
-------------
::

    from notification_manager import PluginRegistry
    from notification_manager.engine.message_manager import MessageManager
    from notification_manager.models import Message

    registry = PluginRegistry()
    # ... register plugins ...

    mm = MessageManager(registry=registry)

    message = Message(
        sender_id="user-1",
        recipient_id="user-2",
        content="Hello!",
        platform="slack",
    )
    sent = await mm.send_message(message)
    thread = mm.get_thread(sent.thread_id)

Cache key schema
----------------
- ``nm:msg:thread:<thread_id>``        — pickled Thread object
- ``nm:msg:conv:<conv_id>``            — pickled Conversation object
- ``nm:msg:message:<message_id>``      — pickled Message object
- ``nm:msg:receipt:<message_id>:<rid>``— pickled ReadReceipt object
"""

from __future__ import annotations

import logging
import pickle
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from notification_manager.exceptions import PluginNotFoundError
from notification_manager.models.message import Conversation, Message, ReadReceipt, Thread

if TYPE_CHECKING:
    from notification_manager.plugins.registry import PluginRegistry

logger = logging.getLogger(__name__)

_NS_THREAD = "nm:msg:thread"
_NS_CONV = "nm:msg:conv"
_NS_MSG = "nm:msg:message"
_NS_RECEIPT = "nm:msg:receipt"
_TTL = 86_400  # 24 hours


class MessageManager:
    """Stateful messaging layer: threads, conversations, and read receipts.

    Parameters
    ----------
    registry
        Active ``PluginRegistry`` whose plugins handle actual delivery.
    cache
        Optional ``AbstractCache`` from Cache_Manager for state persistence.
        When ``None``, an in-process dict is used (single-process, ephemeral).
    """

    def __init__(
        self,
        registry: "PluginRegistry",
        cache: Optional[Any] = None,
    ) -> None:
        self._registry = registry
        self._cache = cache
        # In-process fallback stores
        self._threads: dict[str, Thread] = {}
        self._conversations: dict[str, Conversation] = {}
        self._messages: dict[str, Message] = {}
        self._receipts: dict[str, ReadReceipt] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def send_message(
        self,
        message: Message,
        thread_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> Message:
        """Send a message and record it in the thread/conversation.

        Delivery is attempted by calling ``plugin.send_message(message)`` if
        the plugin exposes that method.  Plugins that do not implement
        ``send_message`` are skipped for delivery but the message is still
        tracked in local state so the conversation history remains consistent.

        Parameters
        ----------
        message
            The message to send.  ``message.platform`` must match a registered
            channel_id.
        thread_id
            ID of an existing Thread to attach the message to.  When ``None``
            (and ``conversation_id`` is also None) a new Thread is created.
        conversation_id
            ID of an existing Conversation to link the Thread to.  When
            ``None`` a new Conversation is created.

        Returns
        -------
        Message
            The message with ``thread_id`` and ``conversation_id`` populated.

        Raises
        ------
        PluginNotFoundError
            If ``message.platform`` is not registered in the registry.
        """
        # Resolve plugin (raises PluginNotFoundError if missing).
        try:
            plugin = self._registry.get(message.platform)
        except PluginNotFoundError:
            logger.warning(
                "MessageManager: plugin not found for platform %r — "
                "message will be stored locally without network delivery.",
                message.platform,
            )
            plugin = None

        # Retrieve or create Thread.
        if thread_id is not None:
            thread = self._get_thread(thread_id)
            if thread is None:
                logger.debug(
                    "MessageManager: thread %r not found — creating new thread.",
                    thread_id,
                )
                thread = Thread(channel=message.platform, id=thread_id)
        else:
            thread = Thread(channel=message.platform)
            logger.debug("MessageManager: created new thread %r.", thread.id)

        # Retrieve or create Conversation.
        if conversation_id is not None:
            conv = self._get_conversation(conversation_id)
            if conv is None:
                logger.debug(
                    "MessageManager: conversation %r not found — creating new conversation.",
                    conversation_id,
                )
                conv = Conversation(platform=message.platform, id=conversation_id)
        else:
            conv = self._get_conversation_for_thread(thread.id)
            if conv is None:
                conv = Conversation(platform=message.platform)
                conv.add_thread(thread)
                logger.debug(
                    "MessageManager: created new conversation %r with thread %r.",
                    conv.id,
                    thread.id,
                )

        # Link identifiers.
        message.thread_id = thread.id
        message.conversation_id = conv.id
        thread.add_message(message)

        # Add thread to conversation if not already present.
        thread_ids = {t.id for t in conv.threads}
        if thread.id not in thread_ids:
            conv.add_thread(thread)

        # Deliver via plugin if supported.
        if plugin is not None and hasattr(plugin, "send_message"):
            try:
                await plugin.send_message(message)  # type: ignore[attr-defined]
                logger.info(
                    "MessageManager: message %r delivered via plugin %r.",
                    message.id,
                    message.platform,
                )
            except Exception as exc:
                logger.error(
                    "MessageManager: delivery failed for message %r via plugin %r: %s",
                    message.id,
                    message.platform,
                    exc,
                )
        elif plugin is not None:
            logger.debug(
                "MessageManager: plugin %r does not implement send_message — "
                "message stored locally only.",
                message.platform,
            )

        # Persist state.
        self._store_message(message)
        self._store_thread(thread)
        self._store_conversation(conv)

        return message

    def get_thread(self, thread_id: str) -> Optional[Thread]:
        """Return the Thread with the given id, or None if not found.

        Checks the cache first, then the in-process store.
        """
        return self._get_thread(thread_id)

    def get_conversation(self, conversation_id: str) -> Optional[Conversation]:
        """Return the Conversation with the given id, or None if not found.

        Checks the cache first, then the in-process store.
        """
        return self._get_conversation(conversation_id)

    def get_message(self, message_id: str) -> Optional[Message]:
        """Return the Message with the given id, or None if not found."""
        return self._get_message(message_id)

    def mark_read(self, message_id: str, reader_id: str) -> ReadReceipt:
        """Mark a message as read by the given reader.

        Parameters
        ----------
        message_id
            The id of the Message to mark as read.
        reader_id
            The application-level id of the reader (typically a Recipient id).

        Returns
        -------
        ReadReceipt
            The read receipt that was created.
        """
        receipt = ReadReceipt(
            message_id=message_id,
            reader_id=reader_id,
            read_at=datetime.utcnow(),
        )

        # Update the Message object itself if it's in state.
        message = self._get_message(message_id)
        if message is not None:
            message.read_at = receipt.read_at
            self._store_message(message)

        # Persist the receipt.
        rkey = f"{_NS_RECEIPT}:{message_id}:{reader_id}"
        self._write(rkey, receipt, ttl=_TTL)
        self._receipts[rkey] = receipt

        logger.debug(
            "MessageManager: message %r marked as read by %r.",
            message_id,
            reader_id,
        )
        return receipt

    def get_read_receipt(self, message_id: str, reader_id: str) -> Optional[ReadReceipt]:
        """Return the ReadReceipt for a (message_id, reader_id) pair, or None."""
        rkey = f"{_NS_RECEIPT}:{message_id}:{reader_id}"
        return self._read(rkey, self._receipts)

    # ------------------------------------------------------------------
    # Internal state helpers
    # ------------------------------------------------------------------

    def _get_thread(self, thread_id: str) -> Optional[Thread]:
        return self._read(f"{_NS_THREAD}:{thread_id}", self._threads)

    def _get_conversation(self, conv_id: str) -> Optional[Conversation]:
        return self._read(f"{_NS_CONV}:{conv_id}", self._conversations)

    def _get_message(self, message_id: str) -> Optional[Message]:
        return self._read(f"{_NS_MSG}:{message_id}", self._messages)

    def _get_conversation_for_thread(self, thread_id: str) -> Optional[Conversation]:
        """Scan conversations to find one that contains *thread_id*."""
        # Check in-process store first.
        for conv in self._conversations.values():
            for t in conv.threads:
                if t.id == thread_id:
                    return conv
        return None

    def _store_thread(self, thread: Thread) -> None:
        key = f"{_NS_THREAD}:{thread.id}"
        self._write(key, thread, ttl=_TTL)
        self._threads[key] = thread

    def _store_conversation(self, conv: Conversation) -> None:
        key = f"{_NS_CONV}:{conv.id}"
        self._write(key, conv, ttl=_TTL)
        self._conversations[key] = conv

    def _store_message(self, message: Message) -> None:
        key = f"{_NS_MSG}:{message.id}"
        self._write(key, message, ttl=_TTL)
        self._messages[key] = message

    # ------------------------------------------------------------------
    # Cache read/write with pickle serialisation and in-process fallback
    # ------------------------------------------------------------------

    def _write(self, key: str, obj: Any, ttl: int = _TTL) -> None:
        if self._cache is not None:
            try:
                self._cache.set(key, pickle.dumps(obj), ttl=ttl)
                return
            except Exception as exc:
                logger.debug("MessageManager: cache write failed (%s); using fallback.", exc)

    def _read(self, key: str, fallback: dict) -> Optional[Any]:
        if self._cache is not None:
            try:
                raw = self._cache.get(key)
                if raw is not None:
                    return pickle.loads(raw)  # noqa: S301  # trusted internal data
            except Exception as exc:
                logger.debug("MessageManager: cache read failed (%s); using fallback.", exc)
        return fallback.get(key)
