"""DefaultRoutingStrategy — resolves which channel(s) to try for a notification.

Resolution order (first match wins for each step; disabled channels always excluded):

1. ``notification.channel_hint``        — explicit per-notification override.
2. ``recipient.preferences.preferred_channels`` — recipient's ordered preference list.
3. ``recipient.channels``               — all channels the recipient can receive on.
4. ``default_channel`` (from config)    — global system fallback.

At each step, only channels that are currently registered in the ``PluginRegistry``
are included. Channels listed in ``recipient.preferences.disabled_channels``
are excluded at every step.

An empty result means no channel could be found — the caller (NotificationManager)
will mark the notification as SKIPPED.

Custom routing
--------------
Inject a different ``RoutingStrategy`` into ``NotificationManager`` to
implement custom rules (e.g. route CRITICAL priority to SMS regardless of
preference, or A/B test two channels).
"""

from __future__ import annotations

import logging
from typing import Optional

from notification_manager.core.abstract_router import RoutingStrategy
from notification_manager.models.notification import Notification
from notification_manager.models.recipient import Recipient

logger = logging.getLogger(__name__)


class DefaultRoutingStrategy(RoutingStrategy):
    """Four-step routing: hint → preferences → recipient channels → global default.

    Parameters
    ----------
    registry
        The active ``PluginRegistry``. Only channels registered here are
        ever returned; unknown channel_ids are silently skipped.
    default_channel
        Global fallback channel_id (from ``NotificationManagerConfig``).
        Used when no channel can be resolved from the notification or recipient.
    """

    def __init__(
        self,
        registry: object,   # PluginRegistry — typed as object to avoid circular import
        default_channel: Optional[str] = None,
    ) -> None:
        self._registry = registry
        self._default_channel = default_channel

    def resolve(self, notification: Notification, recipient: Recipient) -> list[str]:
        """Return an ordered list of channel_ids to attempt for delivery.

        Returns an empty list if no suitable registered channel is found.
        """
        disabled: set[str] = set(recipient.preferences.disabled_channels)
        registered: set[str] = set(self._registry.list_channels())  # type: ignore[attr-defined]

        def _eligible(channel_id: str) -> bool:
            return channel_id in registered and channel_id not in disabled

        candidates: list[str] = []

        # Step 1 — explicit channel_hint on the notification
        if notification.channel_hint and _eligible(notification.channel_hint):
            candidates.append(notification.channel_hint)

        # Step 2 — recipient's preferred channels (ordered)
        for ch in recipient.preferences.preferred_channels:
            if _eligible(ch) and ch not in candidates:
                candidates.append(ch)

        # Step 3 — recipient's general channel list
        for ch in recipient.channels:
            if _eligible(ch) and ch not in candidates:
                candidates.append(ch)

        # Step 4 — global default
        if (
            self._default_channel
            and _eligible(self._default_channel)
            and self._default_channel not in candidates
        ):
            candidates.append(self._default_channel)

        if not candidates:
            logger.warning(
                "DefaultRoutingStrategy: no eligible channel found for "
                "notification %r (recipient=%r). "
                "registered=%r, disabled=%r, hint=%r",
                notification.id,
                recipient.id,
                sorted(registered),
                sorted(disabled),
                notification.channel_hint,
            )

        return candidates
