"""NotificationScheduler — deferred/delayed dispatch of Notifications.

Notifications with ``scheduled_at`` set are stored and dispatched once their
scheduled time arrives.  Delivery is delegated to ``NotificationManager.send()``.

Storage strategy
----------------
Pending notifications are kept in an in-process dict (``_pending``) that
doubles as a fast lookup structure.  When Cache_Manager is available, each
scheduled notification is *also* persisted under ``nm:sched:<notification_id>``
so that the schedule survives process restarts.  On ``start()`` the scheduler
loads any persisted entries from the cache back into the in-process dict.

Polling
-------
A background ``asyncio.Task`` wakes every ``poll_interval`` seconds, scans
``_pending`` for notifications whose ``scheduled_at <= utcnow()``, and
dispatches them via the attached ``NotificationManager``.

Typical usage
-------------
::

    scheduler = NotificationScheduler(manager=nm, poll_interval=10.0)
    await scheduler.start()

    notif = Notification(
        title="Reminder",
        body="Don't forget your meeting!",
        recipient=recipient,
        scheduled_at=datetime.utcnow() + timedelta(minutes=30),
    )
    await scheduler.schedule(notif)

    # … later …
    await scheduler.stop()

Cache key schema
----------------
- ``nm:sched:<notification_id>``  — pickled ``Notification``
- ``nm:sched:index``              — pickled list of ``(notification_id, scheduled_at_iso)``
  stored as a convenience index so the scheduler can reload its state on start.
"""

from __future__ import annotations

import asyncio
import logging
import pickle
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from notification_manager.models.notification import Notification, NotificationStatus

if TYPE_CHECKING:
    from notification_manager.engine.notification_manager import NotificationManager

logger = logging.getLogger(__name__)

_NS = "nm:sched"
_INDEX_KEY = f"{_NS}:index"
_TTL = 7 * 86_400  # 7 days — long enough for distant scheduled notifications


class NotificationScheduler:
    """Deferred notification dispatch backed by Cache_Manager.

    Parameters
    ----------
    manager
        ``NotificationManager`` instance used to dispatch due notifications.
    cache
        Optional ``AbstractCache`` for persistence.  When ``None``, an
        in-process dict is used (ephemeral — schedule is lost on restart).
    poll_interval
        Seconds between polls for due notifications.  Defaults to 10 s.
    """

    def __init__(
        self,
        manager: "NotificationManager",
        cache: Optional[Any] = None,
        poll_interval: float = 10.0,
    ) -> None:
        self._manager = manager
        self._cache = cache
        self._poll_interval = poll_interval

        # In-process store: notification_id → Notification
        self._pending: dict[str, Notification] = {}
        self._task: Optional[asyncio.Task] = None  # type: ignore[type-arg]
        self._running = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Load persisted schedule from cache and start the polling loop."""
        if self._running:
            return
        self._load_from_cache()
        self._running = True
        self._task = asyncio.create_task(self._poll_loop())
        logger.info(
            "NotificationScheduler: started — %d pending, poll_interval=%.1fs.",
            len(self._pending),
            self._poll_interval,
        )

    async def stop(self) -> None:
        """Stop the polling loop gracefully."""
        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("NotificationScheduler: stopped.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def schedule(self, notification: Notification) -> str:
        """Store a notification for deferred delivery.

        Parameters
        ----------
        notification
            A ``Notification`` with ``scheduled_at`` set to a future UTC
            datetime.  If ``scheduled_at`` is ``None`` or in the past, the
            notification is dispatched immediately.

        Returns
        -------
        str
            The ``notification.id`` (use this to cancel if needed).
        """
        if notification.scheduled_at is None or notification.scheduled_at <= datetime.utcnow():
            logger.debug(
                "NotificationScheduler: notification %r has no future scheduled_at — "
                "dispatching immediately.",
                notification.id,
            )
            await self._manager.send(notification)
            return notification.id

        notification.status = NotificationStatus.SCHEDULED
        self._pending[notification.id] = notification
        self._persist(notification)
        self._update_index_add(notification.id, notification.scheduled_at)

        logger.info(
            "NotificationScheduler: notification %r scheduled for %s.",
            notification.id,
            notification.scheduled_at.isoformat(),
        )
        return notification.id

    async def cancel(self, notification_id: str) -> bool:
        """Cancel a pending scheduled notification.

        Parameters
        ----------
        notification_id
            The ``Notification.id`` returned by ``schedule()``.

        Returns
        -------
        bool
            ``True`` if the notification was found and removed, ``False``
            if it was not in the pending queue (already dispatched or unknown).
        """
        notif = self._pending.pop(notification_id, None)
        if notif is None:
            return False
        notif.status = NotificationStatus.CANCELLED
        self._remove_persisted(notification_id)
        self._update_index_remove(notification_id)
        logger.info("NotificationScheduler: notification %r cancelled.", notification_id)
        return True

    def list_pending(self) -> list[Notification]:
        """Return a snapshot of all currently pending notifications."""
        return list(self._pending.values())

    def pending_count(self) -> int:
        """Return the number of notifications waiting to be dispatched."""
        return len(self._pending)

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        while self._running:
            try:
                await asyncio.sleep(self._poll_interval)
                await self._dispatch_due()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.error("NotificationScheduler: unexpected error in poll loop: %s", exc)

    async def _dispatch_due(self) -> None:
        """Dispatch all notifications whose scheduled_at has arrived."""
        now = datetime.utcnow()
        due_ids = [
            nid
            for nid, notif in list(self._pending.items())
            if notif.scheduled_at is not None and notif.scheduled_at <= now
        ]

        for nid in due_ids:
            notif = self._pending.pop(nid, None)
            if notif is None:
                continue
            self._remove_persisted(nid)
            self._update_index_remove(nid)
            try:
                logger.info(
                    "NotificationScheduler: dispatching notification %r (was scheduled for %s).",
                    nid,
                    notif.scheduled_at.isoformat() if notif.scheduled_at else "now",
                )
                await self._manager.send(notif)
            except Exception as exc:
                logger.error(
                    "NotificationScheduler: dispatch failed for notification %r: %s",
                    nid,
                    exc,
                )

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _persist(self, notification: Notification) -> None:
        if self._cache is None:
            return
        try:
            key = f"{_NS}:{notification.id}"
            self._cache.set(key, pickle.dumps(notification), ttl=_TTL)
        except Exception as exc:
            logger.debug("NotificationScheduler: cache write failed (%s).", exc)

    def _remove_persisted(self, notification_id: str) -> None:
        if self._cache is None:
            return
        try:
            key = f"{_NS}:{notification_id}"
            # Cache_Manager delete — try common method names.
            for method in ("delete", "remove", "evict"):
                if hasattr(self._cache, method):
                    getattr(self._cache, method)(key)
                    break
        except Exception as exc:
            logger.debug("NotificationScheduler: cache delete failed (%s).", exc)

    def _update_index_add(self, notification_id: str, scheduled_at: datetime) -> None:
        if self._cache is None:
            return
        try:
            raw = self._cache.get(_INDEX_KEY)
            index: list[tuple[str, str]] = pickle.loads(raw) if raw else []  # noqa: S301
            # Remove stale entry for same id if re-scheduling.
            index = [(nid, ts) for nid, ts in index if nid != notification_id]
            index.append((notification_id, scheduled_at.isoformat()))
            self._cache.set(_INDEX_KEY, pickle.dumps(index), ttl=_TTL)
        except Exception as exc:
            logger.debug("NotificationScheduler: index update failed (%s).", exc)

    def _update_index_remove(self, notification_id: str) -> None:
        if self._cache is None:
            return
        try:
            raw = self._cache.get(_INDEX_KEY)
            if raw is None:
                return
            index: list[tuple[str, str]] = pickle.loads(raw)  # noqa: S301
            index = [(nid, ts) for nid, ts in index if nid != notification_id]
            self._cache.set(_INDEX_KEY, pickle.dumps(index), ttl=_TTL)
        except Exception as exc:
            logger.debug("NotificationScheduler: index removal failed (%s).", exc)

    def _load_from_cache(self) -> None:
        """Reload persisted scheduled notifications from cache on start."""
        if self._cache is None:
            return
        try:
            raw = self._cache.get(_INDEX_KEY)
            if raw is None:
                return
            index: list[tuple[str, str]] = pickle.loads(raw)  # noqa: S301
        except Exception as exc:
            logger.debug("NotificationScheduler: failed to read index from cache (%s).", exc)
            return

        loaded = 0
        now = datetime.utcnow()
        for notification_id, scheduled_at_iso in index:
            try:
                scheduled_at = datetime.fromisoformat(scheduled_at_iso)
            except ValueError:
                continue

            # Skip already-past notifications — they'll be dispatched immediately.
            if scheduled_at <= now:
                self._pending[notification_id] = _placeholder_notification(
                    notification_id, scheduled_at
                )
            else:
                key = f"{_NS}:{notification_id}"
                try:
                    raw_notif = self._cache.get(key)
                    if raw_notif is not None:
                        notif: Notification = pickle.loads(raw_notif)  # noqa: S301
                        self._pending[notification_id] = notif
                        loaded += 1
                except Exception as exc:
                    logger.debug(
                        "NotificationScheduler: failed to load notification %r (%s).",
                        notification_id,
                        exc,
                    )

        logger.info("NotificationScheduler: loaded %d persisted notification(s) from cache.", loaded)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _placeholder_notification(notification_id: str, scheduled_at: datetime) -> Notification:
    """Create a minimal Notification shell for index entries whose cache entry expired."""
    from notification_manager.models.notification import Priority
    from notification_manager.models.recipient import Recipient

    placeholder_recipient = Recipient(id="__unknown__", channels={})
    notif = Notification(
        title="",
        body="",
        recipient=placeholder_recipient,
        id=notification_id,
        priority=Priority.NORMAL,
        scheduled_at=scheduled_at,
    )
    notif.status = NotificationStatus.SCHEDULED
    return notif
