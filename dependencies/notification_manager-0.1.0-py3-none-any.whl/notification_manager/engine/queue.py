"""InProcessQueue — asyncio-native priority queue for notification dispatch.

Implements the ``NotificationQueue`` ABC using ``asyncio.PriorityQueue`` as
the backing store. Notifications are ordered by Priority (CRITICAL first,
LOW last); within the same priority, FIFO order is preserved via a
monotonically increasing counter (stable sort).

Priority mapping
----------------
The underlying heap is a min-heap, so lower numbers surface first.
We negate ``Priority.value`` so that CRITICAL (3) → -3 (smallest) and
LOW (0) → 0 (largest).

    Priority.CRITICAL → position -3  (dequeued first)
    Priority.HIGH     → position -2
    Priority.NORMAL   → position -1
    Priority.LOW      → position  0  (dequeued last)

Swapping the queue backend
--------------------------
For distributed or multi-process deployments, replace this with a
``MessageBroker``-backed queue that survives process restarts. The
``NotificationQueue`` ABC is the contract; any conforming implementation
can be injected into ``NotificationManager``.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from notification_manager.core.abstract_queue import NotificationQueue
from notification_manager.models.notification import Notification, NotificationStatus

logger = logging.getLogger(__name__)


class InProcessQueue(NotificationQueue):
    """In-process, asyncio-based priority queue.

    Parameters
    ----------
    maxsize
        Maximum number of notifications the queue may hold simultaneously.
        ``0`` (default) means unbounded.
    """

    def __init__(self, maxsize: int = 0) -> None:
        self._queue: asyncio.PriorityQueue[
            tuple[int, int, Notification]
        ] = asyncio.PriorityQueue(maxsize=maxsize)
        self._counter: int = 0

    # ------------------------------------------------------------------
    # NotificationQueue interface
    # ------------------------------------------------------------------

    async def enqueue(self, notification: Notification) -> None:
        """Add a notification, ordered by priority then insertion order."""
        # Negate value → min-heap serves highest-priority first.
        heap_key = -notification.priority.value
        self._counter += 1
        await self._queue.put((heap_key, self._counter, notification))
        notification.status = NotificationStatus.QUEUED
        logger.debug(
            "Queue: enqueued %r (priority=%s, queue_size=%d)",
            notification.id,
            notification.priority.name,
            self._queue.qsize(),
        )

    async def dequeue(self) -> Notification:
        """Block until a notification is available and return it."""
        _, _, notification = await self._queue.get()
        return notification

    async def peek(self) -> Optional[Notification]:
        """Return the highest-priority notification without removing it.

        Uses the underlying heap's root element. This accesses an asyncio
        implementation detail (``_queue._queue``); returns ``None`` safely
        if the internal structure is unavailable.
        """
        if self._queue.empty():
            return None
        try:
            # asyncio.PriorityQueue stores items in a list used as a heap.
            root = self._queue._queue[0]  # type: ignore[attr-defined]
            return root[2]
        except (IndexError, AttributeError):
            return None

    async def size(self) -> int:
        return self._queue.qsize()

    async def clear(self) -> None:
        count = self._queue.qsize()
        try:
            # Clear the underlying heap and reset the unfinished task counter.
            self._queue._queue.clear()  # type: ignore[attr-defined]
            self._queue._unfinished_tasks = 0  # type: ignore[attr-defined]
        except AttributeError:
            # Fallback: drain item by item.
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
        if count:
            logger.warning("InProcessQueue: cleared %d pending notification(s).", count)

    @property
    def is_empty(self) -> bool:
        return self._queue.empty()
