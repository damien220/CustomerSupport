"""Reference ConsolePlugin implementation."""

from notification_manager.example_plugin.console_plugin import ConsolePlugin

__all__ = ["ConsolePlugin"]
