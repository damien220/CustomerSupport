"""ConsolePlugin — a fully annotated reference plugin implementation.

This plugin delivers notifications by printing them to stdout (or any
writable stream).  It requires no external dependencies or credentials,
making it ideal for local development, CI pipelines, and integration tests.

Reading guide
-------------
Every section below is annotated to explain *why* the pattern is used, not
just *what* it does.  Use this file as a template when writing your own
channel plugin:

1.  Declare ``channel_id`` as a **class attribute** (required by the framework).
2.  Call ``super().__init__(credentials, config)`` — this wires in
    ``self._credentials`` and ``self._config`` and validates config consistency.
3.  Implement the four abstract methods: ``connect``, ``disconnect``,
    ``send``, ``health_check``.
4.  Optionally override ``send_batch()`` and ``supports_threading()`` for
    richer capabilities.

Credentials pattern (for plugins that need API keys)
------------------------------------------------------
::

    class MySlackPlugin(ChannelPlugin):
        channel_id = "slack"

        async def connect(self) -> None:
            # Fetch the API key at connect-time (not at import time) so that
            # CredentialNotFoundError surfaces early, before the first send().
            api_key = self._credentials.get("api_key")
            self._client = SlackClient(token=api_key)

The ConsolePlugin intentionally passes ``credentials=None`` to show that
credentials are optional for plugins that do not need them.
"""

from __future__ import annotations

import asyncio
import sys
from datetime import datetime
from typing import Any, Optional

from notification_manager.models.delivery import DeliveryAttempt, DeliveryReceipt, DeliveryStatus
from notification_manager.models.notification import Notification
from notification_manager.plugins import ChannelPlugin, PluginConfig


class ConsolePlugin(ChannelPlugin):
    """Delivers notifications to a console (stdout or any writable stream).

    Parameters
    ----------
    stream
        Output stream.  Defaults to ``sys.stdout``.  Use ``io.StringIO`` in
        tests to capture output without printing.
    credentials
        Not required for this plugin — pass ``None`` (the default).
    config
        Optional ``PluginConfig``.  A default config is created automatically
        if omitted.  You may use ``config.extra`` to pass ``{"prefix": "📢"}``
        or similar formatting hints.

    Class attributes
    ----------------
    channel_id : str
        ``"console"`` — the unique identifier for this channel.
    max_retries : int
        ``1`` — console delivery never fails transiently so one attempt is
        always enough.
    """

    # 1. Declare the channel identifier.  Must be a plain string class attribute.
    channel_id = "console"

    # Override the class-level default to 1 retry — console writes don't fail.
    max_retries: int = 1

    def __init__(
        self,
        stream: Any = None,
        credentials: Optional[Any] = None,
        config: Optional[PluginConfig] = None,
    ) -> None:
        # 2. Always call super().__init__() with credentials and config.
        #    This sets self._credentials and self._config, and validates that
        #    config.channel_id matches this class's channel_id.
        super().__init__(credentials=credentials, config=config)
        self._stream = stream or sys.stdout
        self._connected: bool = False

    # ------------------------------------------------------------------
    # 3. Required abstract methods
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Establish the connection to the delivery target.

        For a real plugin this would authenticate with an external API.
        Console delivery needs no network connection — we just set a flag.

        If credentials are needed, fetch them here::

            api_key = self._credentials.get("api_key")
            self._client = ExternalClient(token=api_key)

        Raise ``PluginConfigError`` if the connection cannot be established.
        """
        self._connected = True

    async def disconnect(self) -> None:
        """Release resources.  Called during ``NotificationManager.stop()``.

        For a real plugin this would close the HTTP session / WebSocket.
        Must not raise — ``disconnect_all()`` swallows errors but still calls
        every plugin.
        """
        self._connected = False

    async def send(self, notification: Notification) -> DeliveryReceipt:
        """Deliver a single notification.

        Parameters
        ----------
        notification
            The notification to deliver.  Access title, body, recipient,
            priority, and metadata from this object.

        Returns
        -------
        DeliveryReceipt
            Set ``status`` to ``DELIVERED`` on success.  The engine reads
            this receipt and records it; you do not need to cache it yourself.

        Implementation notes
        --------------------
        - Create one ``DeliveryAttempt`` per actual network call.
        - Call ``receipt.record_attempt(attempt)`` to append it.
        - Return the receipt with the final status set.
        """
        started = datetime.utcnow()

        # Format the notification for console output.
        prefix = self._config.get("prefix", "📩") if self._config else "📩"
        lines = [
            f"{prefix} [{notification.priority.name}] {notification.title}",
            f"   To: {notification.recipient.id}",
            f"   {notification.body}",
        ]
        if notification.metadata:
            lines.append(f"   metadata={notification.metadata}")

        # Simulate async I/O (real plugins await HTTP calls here).
        await asyncio.sleep(0)
        print("\n".join(lines), file=self._stream, flush=True)

        duration_ms = int((datetime.utcnow() - started).total_seconds() * 1000)
        receipt = DeliveryReceipt(
            notification_id=notification.id,
            channel_id=self.channel_id,
            status=DeliveryStatus.DELIVERED,
        )
        receipt.record_attempt(
            DeliveryAttempt(
                attempt_number=1,
                channel_id=self.channel_id,
                status=DeliveryStatus.DELIVERED,
                duration_ms=duration_ms,
            )
        )
        return receipt

    async def health_check(self) -> bool:
        """Return True when the plugin is ready to accept sends.

        For a real plugin this would ping the external API.
        Console is always healthy when connected.
        """
        return self._connected

    # ------------------------------------------------------------------
    # 4. Optional overrides
    # ------------------------------------------------------------------

    async def send_batch(self, notifications: list[Notification]) -> list[DeliveryReceipt]:
        """Deliver multiple notifications in a single batch.

        The default implementation (in ``core.ChannelPlugin``) calls
        ``send()`` sequentially.  Override this when the target API supports
        a native batch endpoint — doing so reduces round-trips and rate-limit
        consumption.

        For the ConsolePlugin, we print all notifications together separated
        by a divider, demonstrating the batching contract.

        The returned list **must be the same length as** ``notifications``
        and in the **same order**.
        """
        divider = "─" * 40
        print(divider, file=self._stream)
        receipts = []
        for notif in notifications:
            receipt = await self.send(notif)
            receipts.append(receipt)
        print(divider, file=self._stream, flush=True)
        return receipts

    def supports_threading(self) -> bool:
        """Return True if the channel supports message threading.

        Console output does not have a threading concept, so we return False.
        A Slack plugin, for example, would return True and use thread_ts.
        """
        return False
