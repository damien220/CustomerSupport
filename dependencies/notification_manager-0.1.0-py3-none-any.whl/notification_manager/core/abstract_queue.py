"""NotificationQueue — abstract priority queue for dispatch ordering.

The default implementation (engine/queue.py, Phase 4) wraps an in-process
asyncio.PriorityQueue with four priority lanes (CRITICAL → LOW).

Replace with a MessageBroker-backed implementation for multi-process or
distributed deployments where the queue must survive process restarts.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from notification_manager.models.notification import Notification


class NotificationQueue(ABC):
    """Async priority queue that orders notifications for delivery.

    The engine calls enqueue() when a new notification is accepted and
    dequeue() in its dispatch loop. All methods are async so that
    implementations can use network-backed queues without blocking.
    """

    @abstractmethod
    async def enqueue(self, notification: "Notification") -> None:
        """Add a notification to the queue, respecting its Priority.

        CRITICAL notifications must be retrievable before NORMAL or LOW
        ones regardless of insertion order.

        Parameters
        ----------
        notification
            The notification to enqueue. Its status should be updated to
            NotificationStatus.QUEUED by the caller before this call.
        """

    @abstractmethod
    async def dequeue(self) -> "Notification":
        """Remove and return the highest-priority notification.

        Blocks (awaits) until a notification is available. Must not return
        None; use peek() for a non-blocking existence check.
        """

    @abstractmethod
    async def peek(self) -> Optional["Notification"]:
        """Return the highest-priority notification without removing it.

        Returns None if the queue is currently empty. Non-blocking.
        """

    @abstractmethod
    async def size(self) -> int:
        """Return the current number of notifications in the queue.

        For external queue backends, this may involve a network call.
        """

    @abstractmethod
    async def clear(self) -> None:
        """Remove all pending notifications from the queue.

        Used during shutdown or when flushing stale state. Implementations
        should log the number of dropped notifications at WARNING level.
        """

    @property
    @abstractmethod
    def is_empty(self) -> bool:
        """True when the queue has no pending notifications.

        For in-process queues this is a local check (no await needed).
        External queue implementations may cache the last known size.
        """
