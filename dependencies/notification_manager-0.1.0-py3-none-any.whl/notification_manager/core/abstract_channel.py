"""ChannelPlugin — the contract every platform plugin must implement.

A plugin author creates a subclass of ChannelPlugin, sets `channel_id` as a
class attribute, and implements the four abstract methods. Everything else
(retry, rate limiting, batching defaults) is handled by the engine.

Example skeleton
----------------
    from notification_manager.core import ChannelPlugin
    from notification_manager.models import Notification, DeliveryReceipt

    class MySlackPlugin(ChannelPlugin):
        channel_id = "slack"
        max_retries = 5

        async def connect(self) -> None:
            self._client = SlackClient(token=self._token)

        async def disconnect(self) -> None:
            await self._client.close()

        async def send(self, notification: Notification) -> DeliveryReceipt:
            ...

        async def health_check(self) -> bool:
            return await self._client.ping()
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from notification_manager.models.delivery import DeliveryReceipt
    from notification_manager.models.notification import Notification


@dataclass
class RateLimit:
    """Rate-limit declaration attached to a ChannelPlugin.

    The engine reads these values when constructing the per-channel
    token-bucket rate limiter (Phase 4). Override as a class attribute
    on your plugin if the platform imposes specific limits.

    Attributes
    ----------
    requests_per_second
        Maximum sustained throughput for this channel.
    burst_size
        Maximum number of requests allowed in a single burst before
        the limiter kicks in.
    per_recipient
        When True, the limit is applied per recipient rather than globally
        across the channel.
    """

    requests_per_second: float = 10.0
    burst_size: int = 20
    per_recipient: bool = False


# The four methods every concrete plugin must implement.
_REQUIRED_METHODS: frozenset[str] = frozenset(
    {"connect", "disconnect", "send", "health_check"}
)


class ChannelPlugin(ABC):
    """Abstract base class for all platform delivery plugins.

    Class attributes
    ----------------
    channel_id : str
        **Required.** Unique identifier registered with the PluginRegistry
        (e.g. ``"slack"``, ``"email"``, ``"fcm"``). Must be set on each
        concrete subclass — a TypeError is raised at class definition time
        if it is missing.
    max_retries : int
        Maximum delivery attempts before the engine marks the notification
        as FAILED. Default: 3. Overrides NotificationManagerConfig.retry_policy
        for this channel only.
    rate_limit : RateLimit
        Throughput limit declared by this plugin. Default: 10 RPS, burst 20.
    """

    channel_id: str  # must be overridden on every concrete subclass
    max_retries: int = 3

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)

        # Provide a default RateLimit on every subclass that doesn't declare one.
        if "rate_limit" not in cls.__dict__:
            cls.rate_limit = RateLimit()

        # Validate channel_id only when a class defines ALL four required methods
        # in its own __dict__ (i.e. it is a fully concrete plugin, not an
        # intermediate abstract base).
        #
        # We cannot rely on cls.__abstractmethods__ here because __init_subclass__
        # is called by type.__new__() *before* ABCMeta sets __abstractmethods__.
        # The method-presence check is a reliable, timing-safe alternative.
        if all(name in cls.__dict__ for name in _REQUIRED_METHODS):
            if not isinstance(getattr(cls, "channel_id", None), str):
                raise TypeError(
                    f"{cls.__name__} must define a `channel_id: str` class attribute "
                    f"(e.g. channel_id = 'my_channel')."
                )

    # -------------------------------------------------------------------------
    # Abstract interface — must be implemented by every plugin
    # -------------------------------------------------------------------------

    @abstractmethod
    async def connect(self) -> None:
        """Initialize the connection or API client to the platform.

        Called once when the plugin is activated by NotificationManager.
        Raise PluginConfigError if the connection cannot be established
        (e.g. invalid API key, network unreachable).
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Gracefully tear down the connection or client.

        Called on NotificationManager shutdown. Must not raise exceptions;
        swallow errors and log warnings instead.
        """

    @abstractmethod
    async def send(self, notification: "Notification") -> "DeliveryReceipt":
        """Deliver a single notification via this channel.

        Returns a DeliveryReceipt reflecting the outcome. On transient
        failure, raise DeliveryFailedError so the engine can apply the
        retry policy. On permanent failure (e.g. invalid recipient),
        set DeliveryStatus.FAILED directly in the receipt.

        The implementation must never log or include raw credential values
        in error messages or metadata.
        """

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the channel is reachable and operational.

        Called periodically by the registry to update channel availability.
        Should complete quickly (< 5 s) and must not raise.
        """

    # -------------------------------------------------------------------------
    # Methods with default implementations — override as needed
    # -------------------------------------------------------------------------

    async def send_batch(
        self, notifications: list["Notification"]
    ) -> list["DeliveryReceipt"]:
        """Deliver multiple notifications to this channel.

        Default implementation sends sequentially (one call to send() per
        notification). Override for platforms that offer native batch APIs
        (e.g. sending multiple FCM messages in a single HTTP call).

        Returns receipts in the same order as the input list.
        """
        receipts = []
        for notification in notifications:
            receipt = await self.send(notification)
            receipts.append(receipt)
        return receipts

    def supports_threading(self) -> bool:
        """Return True if this platform supports message threads or replies.

        Default: False. Override and return True in plugins for platforms
        that natively support threading (e.g. Slack, Discord).
        The MessageManager uses this flag to decide whether to maintain
        Thread state for conversations on this channel.
        """
        return False
