"""RoutingStrategy — decides which channel(s) to try for a given notification.

The engine calls resolve() once per send operation. The returned list is
tried in order; the first successful delivery wins (unless the engine is
configured to deliver to all channels).

The DefaultRoutingStrategy (engine/router.py, Phase 4) implements:
    1. channel_hint on the Notification (explicit override)
    2. Recipient.preferences.preferred_channels
    3. NotificationManagerConfig.default_channel
    4. First registered channel (last resort)

Implement this ABC to replace the default logic with custom rules
(e.g. route high-priority notifications to SMS regardless of preference,
or A/B test two channels).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from notification_manager.models.notification import Notification
    from notification_manager.models.recipient import Recipient


class RoutingStrategy(ABC):
    """Determines the ordered list of channel_ids to attempt for delivery.

    The engine respects the order: the first channel_id is the primary
    target; subsequent entries are fallbacks tried only if the primary
    fails (or if the engine is in broadcast mode).
    """

    @abstractmethod
    def resolve(
        self,
        notification: "Notification",
        recipient: "Recipient",
    ) -> list[str]:
        """Return an ordered list of channel_ids to attempt.

        Parameters
        ----------
        notification
            The notification to be delivered. Inspect notification.channel_hint,
            notification.priority, and notification.metadata for routing signals.
        recipient
            The target recipient. Inspect recipient.channels,
            recipient.preferences.preferred_channels, and
            recipient.preferences.disabled_channels.

        Returns
        -------
        list[str]
            Ordered channel_ids. Return an empty list to skip delivery
            entirely (e.g. recipient has opted out of all channels).

        Notes
        -----
        - The returned list must only contain channel_ids that are
          registered in the PluginRegistry; the engine validates this.
        - Disabled channels (recipient.preferences.disabled_channels)
          should be excluded from the result.
        - This method is called synchronously; keep it fast.
        """
