"""Public surface of the core abstractions sub-package."""

from notification_manager.core.abstract_broker import MessageBroker
from notification_manager.core.abstract_channel import ChannelPlugin, RateLimit
from notification_manager.core.abstract_queue import NotificationQueue
from notification_manager.core.abstract_router import RoutingStrategy
from notification_manager.core.abstract_template_engine import TemplateEngine

__all__ = [
    "ChannelPlugin",
    "RateLimit",
    "MessageBroker",
    "RoutingStrategy",
    "TemplateEngine",
    "NotificationQueue",
]
