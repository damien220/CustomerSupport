"""TemplateEngine — renders a NotificationTemplate into final deliverable content.

The engine calls render() after routing and before handing the notification to
a plugin. Rendered title and body replace the raw notification fields so that
plugins always receive the final, personalised content.

The DefaultTemplateEngine (template/engine.py, Phase 6) uses Jinja2.
Implement this ABC to use a different rendering library (Mako, Mustache,
simple str.format(), etc.) or to add custom filters and globals.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from notification_manager.models.template import NotificationTemplate, RenderedContent


class TemplateEngine(ABC):
    """Renders a NotificationTemplate with variable bindings into final content.

    Two-step usage
    --------------
    1. validate() — check that all required variables are present without
       performing the full render (cheap, used for early validation).
    2. render() — produce the final RenderedContent.
    """

    @abstractmethod
    def render(
        self,
        template: "NotificationTemplate",
        variables: dict[str, Any],
        channel_id: str | None = None,
    ) -> "RenderedContent":
        """Render template with the given variable bindings.

        Parameters
        ----------
        template
            The NotificationTemplate to render.
        variables
            Mapping of variable name → value. Template defaults are applied
            for variables present in template.variables but absent from this dict.
        channel_id
            When provided, use the channel-specific override template if one
            exists (template.channel_overrides[channel_id]); otherwise fall
            back to the default title/body templates.

        Returns
        -------
        RenderedContent
            Fully rendered title and body with all placeholders resolved.

        Raises
        ------
        TemplateRenderError
            If a required variable is missing, the template syntax is
            invalid, or rendering produces an empty title or body.
        """

    @abstractmethod
    def validate(
        self,
        template: "NotificationTemplate",
        variables: dict[str, Any],
    ) -> list[str]:
        """Check that all required variables are supplied.

        Parameters
        ----------
        template
            The template whose variable declarations to check against.
        variables
            The variable bindings to validate.

        Returns
        -------
        list[str]
            Names of required variables that are missing from `variables`.
            Returns an empty list if all required variables are present.

        Notes
        -----
        This method must not render the template. It is called during
        notification construction to catch misconfiguration early.
        """
