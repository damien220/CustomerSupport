"""MessageBroker — abstract transport layer between the engine and the queue backend.

The default engine uses the in-process NotificationQueue directly. Swap in a
MessageBroker implementation to route notifications through an external queue
(Redis Streams, RabbitMQ, Kafka, etc.) for distributed or multi-process setups.

The broker decouples *publishing* a notification from *consuming* and
delivering it, enabling separate producer and consumer processes.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncIterator

if TYPE_CHECKING:
    from notification_manager.models.notification import Notification


class MessageBroker(ABC):
    """Abstract transport that publishes and consumes Notification objects.

    Implementations must be async-native. The engine calls connect() on
    startup and disconnect() on shutdown.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Establish the connection to the broker backend.

        Raise NotificationManagerError (or a subclass) if the connection
        cannot be established. Called once on engine startup.
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Gracefully close the broker connection.

        Must not raise. Called on engine shutdown.
        """

    @abstractmethod
    async def publish(self, notification: "Notification") -> None:
        """Enqueue a notification for delivery.

        The broker is responsible for durability — once this coroutine
        returns, the notification must be guaranteed to survive a
        consumer restart (for durable backends like Redis or RabbitMQ).

        Raise NotificationManagerError on publish failure.
        """

    @abstractmethod
    async def consume(self) -> AsyncIterator["Notification"]:
        """Yield notifications ready for delivery, indefinitely.

        This must be an async generator. Implementations should block
        (using await) until a notification becomes available rather than
        busy-polling.

        Example::

            async def consume(self):
                while True:
                    item = await self._queue.get()
                    yield item
        """

    @abstractmethod
    async def ack(self, notification_id: str) -> None:
        """Acknowledge that a notification was delivered successfully.

        After ack(), the broker must not re-deliver this notification_id.
        For at-least-once brokers (e.g. RabbitMQ), this removes the
        message from the queue permanently.
        """

    @abstractmethod
    async def nack(self, notification_id: str, reason: str = "") -> None:
        """Reject a notification and optionally re-queue it for retry.

        Parameters
        ----------
        notification_id
            The Notification.id that failed.
        reason
            Human-readable failure description (must not contain secrets).
        """
