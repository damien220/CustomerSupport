"""Notification and Messaging Manager — public API.

Phase 1: models, core abstractions, exceptions, config.
Phase 2: credentials (CredentialStore, EnvCredentialStore,
          CacheCredentialStore, PluginCredentials, Redactor).
Phase 3: plugin system (ChannelPlugin, PluginConfig, PluginRegistry,
          PluginLoader).
Phase 4: delivery engine (NotificationManager, RetryPolicy,
          ExponentialBackoffPolicy, DefaultRoutingStrategy,
          InProcessQueue, RateLimiter).
Phase 5: messaging system (MessageManager, NotificationScheduler).
Phase 6: template engine (DefaultTemplateEngine, TemplateRenderer).
Phase 7: integration layer (setup_logging, get_notification_cache,
          normalize_exception, attach_redactor, …).
Phase 8: reference plugin (ConsolePlugin) + PLUGIN_GUIDE.md.

Quick import reference
----------------------
    from notification_manager import NotificationManager, PluginRegistry
    from notification_manager.models import Notification, Recipient, Priority
    from notification_manager.plugins import ChannelPlugin
    from notification_manager.credentials import EnvCredentialStore
    from notification_manager.config import NotificationManagerConfig
    from notification_manager.template import DefaultTemplateEngine, TemplateRenderer
    from notification_manager.integrations import setup_logging, get_notification_cache
    from notification_manager.example_plugin import ConsolePlugin
"""

# Models
from notification_manager.models import (
    Attachment,
    ChannelPreferences,
    Conversation,
    DeliveryAttempt,
    DeliveryReceipt,
    DeliveryStatus,
    Message,
    Notification,
    NotificationStatus,
    NotificationTemplate,
    Priority,
    ReadReceipt,
    Recipient,
    RecipientGroup,
    RenderedContent,
    TemplateVariable,
    Thread,
)

# Core abstractions (raw ABCs — advanced use only)
from notification_manager.core import (
    MessageBroker,
    NotificationQueue,
    RateLimit,
    RoutingStrategy,
    TemplateEngine,
)

# Exceptions
from notification_manager.exceptions import (
    CredentialNotFoundError,
    DeliveryFailedError,
    NotificationManagerError,
    PluginConfigError,
    PluginNotFoundError,
    RateLimitExceededError,
    TemplateRenderError,
)

# Config
from notification_manager.config import NotificationManagerConfig, RetryPolicyConfig

# Credentials
from notification_manager.credentials import (
    CacheCredentialStore,
    CredentialStore,
    EnvCredentialStore,
    PluginCredentials,
    Redactor,
)

# Plugin system — ChannelPlugin exported from plugins (richer base with
# credentials + config injection), not from core (raw ABC).
from notification_manager.plugins import (
    ChannelPlugin,
    PluginConfig,
    PluginLoader,
    PluginRegistry,
)

# Delivery engine
from notification_manager.engine import (
    DefaultRoutingStrategy,
    ExponentialBackoffPolicy,
    InProcessQueue,
    MessageManager,
    NotificationManager,
    NotificationScheduler,
    RateLimiter,
    RetryPolicy,
)

__all__ = [
    # Models — notification
    "Notification",
    "NotificationStatus",
    "Priority",
    # Models — recipient
    "Recipient",
    "RecipientGroup",
    "ChannelPreferences",
    # Models — delivery
    "DeliveryReceipt",
    "DeliveryAttempt",
    "DeliveryStatus",
    # Models — message
    "Message",
    "Thread",
    "Conversation",
    "ReadReceipt",
    "Attachment",
    # Models — template
    "NotificationTemplate",
    "TemplateVariable",
    "RenderedContent",
    # Core abstractions (raw ABCs)
    "RateLimit",
    "MessageBroker",
    "RoutingStrategy",
    "TemplateEngine",
    "NotificationQueue",
    # Exceptions
    "NotificationManagerError",
    "PluginNotFoundError",
    "PluginConfigError",
    "CredentialNotFoundError",
    "DeliveryFailedError",
    "RateLimitExceededError",
    "TemplateRenderError",
    # Config
    "NotificationManagerConfig",
    "RetryPolicyConfig",
    # Credentials
    "CredentialStore",
    "EnvCredentialStore",
    "CacheCredentialStore",
    "PluginCredentials",
    "Redactor",
    # Plugin system
    "ChannelPlugin",
    "PluginConfig",
    "PluginRegistry",
    "PluginLoader",
    # Delivery engine
    "NotificationManager",
    "RetryPolicy",
    "ExponentialBackoffPolicy",
    "DefaultRoutingStrategy",
    "InProcessQueue",
    "RateLimiter",
    # Messaging system
    "MessageManager",
    "NotificationScheduler",
    # Template engine (import from notification_manager.template)
    # Integration layer (import from notification_manager.integrations)
    # Example plugin (import from notification_manager.example_plugin)
]
