"""TemplateRenderer — registry + render pipeline for NotificationTemplates.

The renderer keeps a named registry of ``NotificationTemplate`` objects and
exposes a single ``render()`` entry point that resolves a template by name or
id and delegates rendering to a ``TemplateEngine``.

It also provides ``render_notification()``, a convenience that reads a
``Notification``'s ``template_id`` + ``variables`` fields, resolves and
renders the template, and writes the result back into the notification's
``title`` and ``body`` fields.

Typical usage
-------------
::

    from notification_manager.template.renderer import TemplateRenderer
    from notification_manager.template.engine import DefaultTemplateEngine
    from notification_manager.models.template import NotificationTemplate, TemplateVariable

    engine = DefaultTemplateEngine()
    renderer = TemplateRenderer(engine=engine)

    template = NotificationTemplate(
        name="order_shipped",
        title_template="Your order #{{ order_id }} has shipped!",
        body_template="Hi {{ username }}, your order is on its way.",
        variables=[
            TemplateVariable(name="order_id", required=True),
            TemplateVariable(name="username", required=True),
        ],
    )
    renderer.register(template)

    # At delivery time:
    content = renderer.render(
        template_id="order_shipped",
        variables={"order_id": "12345", "username": "Alice"},
        channel_id="email",
    )
    print(content.title)  # "Your order #12345 has shipped!"
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

from notification_manager.exceptions import PluginNotFoundError, TemplateRenderError
from notification_manager.models.template import NotificationTemplate, RenderedContent

if TYPE_CHECKING:
    from notification_manager.core.abstract_template_engine import TemplateEngine
    from notification_manager.models.notification import Notification

logger = logging.getLogger(__name__)


class TemplateRenderer:
    """Registry + render pipeline for ``NotificationTemplate`` objects.

    Parameters
    ----------
    engine
        A ``TemplateEngine`` implementation.  Defaults to
        ``DefaultTemplateEngine`` when ``None``.
    """

    def __init__(self, engine: Optional["TemplateEngine"] = None) -> None:
        if engine is None:
            from notification_manager.template.engine import DefaultTemplateEngine
            engine = DefaultTemplateEngine()
        self._engine: "TemplateEngine" = engine
        # Registry: template name → template, and template id → template
        self._by_name: dict[str, NotificationTemplate] = {}
        self._by_id: dict[str, NotificationTemplate] = {}

    # ------------------------------------------------------------------
    # Template registry
    # ------------------------------------------------------------------

    def register(self, template: NotificationTemplate) -> None:
        """Add a template to the registry.

        Parameters
        ----------
        template
            The template to register.  Both ``template.name`` and
            ``template.id`` are indexed; either can be used to look up or
            render.

        Raises
        ------
        ValueError
            If a template with the same name or id is already registered
            (use ``unregister()`` first to replace it).
        """
        if template.name in self._by_name:
            raise ValueError(
                f"A template named {template.name!r} is already registered. "
                "Call unregister() first if you want to replace it."
            )
        self._by_name[template.name] = template
        self._by_id[template.id] = template
        logger.debug(
            "TemplateRenderer: registered template %r (id=%r).",
            template.name,
            template.id,
        )

    def unregister(self, template_id: str) -> bool:
        """Remove a template by name or id.

        Parameters
        ----------
        template_id
            The ``template.name`` or ``template.id`` to remove.

        Returns
        -------
        bool
            ``True`` if found and removed, ``False`` otherwise.
        """
        tmpl = self._by_name.pop(template_id, None) or self._by_id.pop(template_id, None)
        if tmpl is None:
            return False
        # Clean up both indices.
        self._by_name.pop(tmpl.name, None)
        self._by_id.pop(tmpl.id, None)
        logger.debug("TemplateRenderer: unregistered template %r.", template_id)
        return True

    def get(self, template_id: str) -> Optional[NotificationTemplate]:
        """Return a template by name or id, or ``None`` if not registered."""
        return self._by_name.get(template_id) or self._by_id.get(template_id)

    def list_templates(self) -> list[NotificationTemplate]:
        """Return all registered templates (de-duplicated)."""
        return list(self._by_id.values())

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render(
        self,
        template_id: str,
        variables: dict[str, Any],
        channel_id: Optional[str] = None,
    ) -> RenderedContent:
        """Render a registered template.

        Parameters
        ----------
        template_id
            The ``template.name`` or ``template.id`` to render.
        variables
            Variable bindings to substitute into the template.
        channel_id
            When provided, the channel-specific override is used if one
            exists on the template.

        Returns
        -------
        RenderedContent
            Fully rendered title and body.

        Raises
        ------
        TemplateRenderError
            If the template is not found or rendering fails.
        """
        template = self.get(template_id)
        if template is None:
            raise TemplateRenderError(
                template_id=template_id,
                reason=f"No template registered with name or id {template_id!r}.",
            )
        return self._engine.render(template, variables, channel_id=channel_id)

    def render_notification(self, notification: "Notification") -> None:
        """Resolve and render a notification's template in-place.

        Reads ``notification.template_id`` and ``notification.variables``,
        renders the resolved template for the notification's ``channel_hint``
        (if set), and writes the result back into ``notification.title`` and
        ``notification.body``.

        This is a no-op when ``notification.template_id`` is ``None``.

        Parameters
        ----------
        notification
            The notification to render in-place.

        Raises
        ------
        TemplateRenderError
            If the template is not registered or rendering fails.
        """
        if not notification.template_id:
            return

        content = self.render(
            template_id=notification.template_id,
            variables=notification.variables,
            channel_id=notification.channel_hint,
        )
        notification.title = content.title
        notification.body = content.body
        logger.debug(
            "TemplateRenderer: rendered notification %r from template %r.",
            notification.id,
            notification.template_id,
        )

    def validate(
        self,
        template_id: str,
        variables: dict[str, Any],
    ) -> list[str]:
        """Return names of missing required variables without rendering.

        Parameters
        ----------
        template_id
            The ``template.name`` or ``template.id`` to validate against.
        variables
            Variable bindings to check.

        Returns
        -------
        list[str]
            Missing required variable names; empty when all are present.

        Raises
        ------
        TemplateRenderError
            If the template is not registered.
        """
        template = self.get(template_id)
        if template is None:
            raise TemplateRenderError(
                template_id=template_id,
                reason=f"No template registered with name or id {template_id!r}.",
            )
        return self._engine.validate(template, variables)
