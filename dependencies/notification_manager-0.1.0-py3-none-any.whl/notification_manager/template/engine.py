"""DefaultTemplateEngine — Jinja2-based notification template renderer.

Falls back to a lightweight ``{{ variable }}`` substitution engine when
Jinja2 is not installed, so the package can be used without that
dependency for simple use-cases.

Jinja2 features available (when installed)
-------------------------------------------
- Variable interpolation: ``{{ username }}``
- Filters: ``{{ amount | round(2) }}``, ``{{ name | upper }}``
- Conditionals: ``{% if is_vip %} VIP {% endif %}``
- Loops: ``{% for item in items %} … {% endfor %}``
- Auto-escaping is disabled — notifications are plain text, not HTML.

Fallback mode (no Jinja2)
--------------------------
Only basic ``{{ variable_name }}`` substitution is supported.  Variables
are matched by name; whitespace around the name is ignored.  Filters,
control flow, and other Jinja2 constructs are not handled and will appear
as literal text.

Usage
-----
::

    from notification_manager.template.engine import DefaultTemplateEngine
    from notification_manager.models.template import NotificationTemplate, TemplateVariable

    engine = DefaultTemplateEngine()

    template = NotificationTemplate(
        name="welcome",
        title_template="Welcome, {{ username }}!",
        body_template="Hi {{ username }}, your account is ready.",
        variables=[TemplateVariable(name="username", required=True)],
    )

    content = engine.render(template, {"username": "Alice"})
    print(content.title)   # "Welcome, Alice!"
"""

from __future__ import annotations

import re
import logging
from typing import Any, Optional

from notification_manager.core.abstract_template_engine import TemplateEngine
from notification_manager.exceptions import TemplateRenderError
from notification_manager.models.template import NotificationTemplate, RenderedContent

logger = logging.getLogger(__name__)

# Detect Jinja2 availability once at import time.
try:
    import jinja2 as _jinja2  # type: ignore[import-untyped]
    _JINJA2_AVAILABLE = True
except ImportError:
    _jinja2 = None  # type: ignore[assignment]
    _JINJA2_AVAILABLE = False
    logger.debug(
        "Jinja2 not installed — DefaultTemplateEngine will use the built-in "
        "fallback renderer ({{ variable }} substitution only)."
    )

# Fallback: matches {{ var_name }} with optional surrounding whitespace.
_FALLBACK_RE = re.compile(r"\{\{\s*(\w+)\s*\}\}")


class DefaultTemplateEngine(TemplateEngine):
    """Template engine backed by Jinja2 (with plain-substitution fallback).

    Parameters
    ----------
    jinja_env
        An existing ``jinja2.Environment`` to use.  When ``None``, a default
        environment is created with ``undefined=StrictUndefined`` so that
        missing variables raise errors rather than silently expanding to
        empty strings.  Ignored when Jinja2 is not installed.
    """

    def __init__(self, jinja_env: Optional[Any] = None) -> None:
        self._jinja_env: Optional[Any] = None

        if _JINJA2_AVAILABLE:
            if jinja_env is not None:
                self._jinja_env = jinja_env
            else:
                self._jinja_env = _jinja2.Environment(
                    undefined=_jinja2.StrictUndefined,
                    autoescape=False,
                    keep_trailing_newline=True,
                )

    # ------------------------------------------------------------------
    # TemplateEngine ABC
    # ------------------------------------------------------------------

    def render(
        self,
        template: NotificationTemplate,
        variables: dict[str, Any],
        channel_id: Optional[str] = None,
    ) -> RenderedContent:
        """Render *template* with *variables*, optionally for *channel_id*.

        Parameters
        ----------
        template
            The ``NotificationTemplate`` to render.
        variables
            Caller-supplied variable bindings.  Template defaults are merged
            in for variables that are absent from this dict.
        channel_id
            When provided, the channel-specific override templates are used
            if they exist on *template*.

        Returns
        -------
        RenderedContent
            Fully rendered title and body.

        Raises
        ------
        TemplateRenderError
            If a required variable is missing or Jinja2 reports a syntax /
            undefined variable error.
        """
        # Merge defaults for optional variables.
        merged = {**template.get_defaults(), **variables}

        # Validate required variables before rendering.
        missing = self.validate(template, merged)
        if missing:
            raise TemplateRenderError(
                template_id=template.id,
                reason=f"Missing required variable(s): {', '.join(missing)}",
            )

        # Resolve title/body template strings (may use channel override).
        if channel_id is not None:
            title_src = template.get_channel_title_template(channel_id)
            body_src = template.get_channel_body_template(channel_id)
        else:
            title_src = template.title_template
            body_src = template.body_template

        title = self._render_string(title_src, merged, template.id, "title")
        body = self._render_string(body_src, merged, template.id, "body")

        logger.debug(
            "DefaultTemplateEngine: rendered template %r for channel %r.",
            template.name,
            channel_id,
        )
        return RenderedContent(title=title, body=body, channel_id=channel_id)

    def validate(
        self,
        template: NotificationTemplate,
        variables: dict[str, Any],
    ) -> list[str]:
        """Return names of required variables absent from *variables*.

        Parameters
        ----------
        template
            Template whose variable declarations to check.
        variables
            Caller-supplied bindings (defaults already merged in is fine too).

        Returns
        -------
        list[str]
            Missing required variable names; empty when all are present.
        """
        return [
            v.name
            for v in template.variables
            if v.required and v.name not in variables
        ]

    # ------------------------------------------------------------------
    # Internal rendering
    # ------------------------------------------------------------------

    def _render_string(
        self,
        source: str,
        variables: dict[str, Any],
        template_id: str,
        field_name: str,
    ) -> str:
        """Render a single template string with the given variables."""
        if _JINJA2_AVAILABLE and self._jinja_env is not None:
            return self._render_jinja(source, variables, template_id, field_name)
        return self._render_fallback(source, variables, template_id, field_name)

    def _render_jinja(
        self,
        source: str,
        variables: dict[str, Any],
        template_id: str,
        field_name: str,
    ) -> str:
        try:
            jinja_template = self._jinja_env.from_string(source)
            return jinja_template.render(**variables)
        except _jinja2.UndefinedError as exc:
            raise TemplateRenderError(
                template_id=template_id,
                reason=f"Undefined variable in {field_name!r}: {exc}",
            ) from exc
        except _jinja2.TemplateSyntaxError as exc:
            raise TemplateRenderError(
                template_id=template_id,
                reason=f"Syntax error in {field_name!r}: {exc}",
            ) from exc
        except Exception as exc:
            raise TemplateRenderError(
                template_id=template_id,
                reason=f"Rendering failed for {field_name!r}: {exc}",
            ) from exc

    def _render_fallback(
        self,
        source: str,
        variables: dict[str, Any],
        template_id: str,
        field_name: str,
    ) -> str:
        """Regex-based fallback for ``{{ variable }}`` patterns."""
        missing_in_source: list[str] = []

        def _replace(match: re.Match) -> str:  # type: ignore[type-arg]
            name = match.group(1)
            if name not in variables:
                missing_in_source.append(name)
                return match.group(0)  # leave placeholder intact
            return str(variables[name])

        result = _FALLBACK_RE.sub(_replace, source)
        if missing_in_source:
            logger.warning(
                "DefaultTemplateEngine (fallback): unresolved variables in %r "
                "for template %r: %s",
                field_name,
                template_id,
                missing_in_source,
            )
        return result
