"""Package-level exception hierarchy for the Notification Manager.

All exceptions extend BaseAppException from the Error-Exception_Handler package.
If that package is not installed, a compatible fallback is used so this module
remains importable in isolation (e.g., during testing without full dependencies).

Install the real package with:
    pip install -e /path/to/Error-Exception_Handler
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:
    # Lightweight fallback — mirrors BaseAppException's public contract exactly.
    class BaseAppException(Exception):  # type: ignore[no-redef]
        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.message = message
            self.code = code
            self.status_code = status_code
            self.details = details
            self.previous = previous
            if previous is not None:
                self.__cause__ = previous

        def to_dict(self) -> dict[str, Any]:
            return {
                "success": False,
                "error": {
                    "code": self.code,
                    "message": self.message,
                    "details": self.details,
                    "status_code": self.status_code,
                },
            }


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class NotificationManagerError(BaseAppException):
    """Root exception for all Notification Manager errors."""

    def __init__(
        self,
        message: str = "Notification Manager error",
        *,
        code: str = "NOTIFICATION_MANAGER_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            details=details,
            previous=previous,
        )


# ---------------------------------------------------------------------------
# Plugin errors
# ---------------------------------------------------------------------------


class PluginNotFoundError(NotificationManagerError):
    """Raised when a requested channel_id is not registered in the PluginRegistry."""

    def __init__(
        self,
        channel_id: str,
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            f"No plugin registered for channel '{channel_id}'.",
            code="PLUGIN_NOT_FOUND",
            status_code=404,
            details=details or {"channel_id": channel_id},
            previous=previous,
        )
        self.channel_id = channel_id


class PluginConfigError(NotificationManagerError):
    """Raised when a plugin is misconfigured.

    Detected at registration time so that misconfiguration surfaces on startup,
    not silently at the first delivery attempt.
    """

    def __init__(
        self,
        channel_id: str,
        reason: str = "",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            f"Plugin configuration error for channel '{channel_id}'"
            + (f": {reason}" if reason else "."),
            code="PLUGIN_CONFIG_ERROR",
            status_code=400,
            details=details or {"channel_id": channel_id},
            previous=previous,
        )
        self.channel_id = channel_id


# ---------------------------------------------------------------------------
# Credential errors
# ---------------------------------------------------------------------------


class CredentialNotFoundError(PluginConfigError):
    """Raised when a required credential key is absent from the CredentialStore.

    Naming convention for environment variables:
        NM_<CHANNEL_ID_UPPER>_<KEY_UPPER>
    Example:
        NM_SLACK_BOT_TOKEN
    """

    def __init__(
        self,
        channel_id: str,
        key: str,
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        env_var = f"NM_{channel_id.upper()}_{key.upper()}"
        super().__init__(
            channel_id,
            reason=f"Required credential key '{key}' not found. Set {env_var}.",
            details=details or {"channel_id": channel_id, "key": key, "env_var": env_var},
            previous=previous,
        )
        self.key = key
        self.env_var = env_var


# ---------------------------------------------------------------------------
# Delivery errors
# ---------------------------------------------------------------------------


class DeliveryFailedError(NotificationManagerError):
    """Raised when a notification cannot be delivered after all retry attempts."""

    def __init__(
        self,
        notification_id: str,
        channel_id: str,
        reason: str = "",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            f"Delivery failed for notification '{notification_id}' on channel '{channel_id}'"
            + (f": {reason}" if reason else "."),
            code="DELIVERY_FAILED",
            status_code=500,
            details=details or {"notification_id": notification_id, "channel_id": channel_id},
            previous=previous,
        )
        self.notification_id = notification_id
        self.channel_id = channel_id


class RateLimitExceededError(NotificationManagerError):
    """Raised when the rate limit for a channel or recipient is exceeded."""

    def __init__(
        self,
        scope: str,
        *,
        retry_after_seconds: Optional[float] = None,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            f"Rate limit exceeded for scope '{scope}'.",
            code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            details=details or {"scope": scope, "retry_after_seconds": retry_after_seconds},
            previous=previous,
        )
        self.scope = scope
        self.retry_after_seconds = retry_after_seconds


# ---------------------------------------------------------------------------
# Template errors
# ---------------------------------------------------------------------------


class TemplateRenderError(NotificationManagerError):
    """Raised when a notification template cannot be rendered."""

    def __init__(
        self,
        template_id: str,
        reason: str = "",
        *,
        missing_variables: Optional[list[str]] = None,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            f"Failed to render template '{template_id}'" + (f": {reason}" if reason else "."),
            code="TEMPLATE_RENDER_ERROR",
            status_code=400,
            details=details
            or {
                "template_id": template_id,
                "missing_variables": missing_variables or [],
            },
            previous=previous,
        )
        self.template_id = template_id
        self.missing_variables = missing_variables or []
