"""Plugin manager configuration."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PluginManagerConfig:
    """Configuration for :class:`PluginManager`.

    All fields have sensible defaults so a bare ``PluginManagerConfig()``
    creates a usable configuration with no discovery sources.
    """

    # ── Discovery ────────────────────────────────────────────────
    plugin_dirs: list[str] = field(default_factory=list)
    entry_point_group: str = ""
    scan_packages: list[str] = field(default_factory=list)

    # ── Validation ───────────────────────────────────────────────
    required_base_class: str | None = None
    required_methods: list[str] = field(default_factory=list)
    strict_validation: bool = True

    # ── Lifecycle ────────────────────────────────────────────────
    auto_initialize: bool = True
    auto_start: bool = False
    error_policy: str = "suppress"
    initialization_timeout_seconds: float = 30.0

    # ── Registry ─────────────────────────────────────────────────
    allow_override: bool = False
    max_plugins: int | None = None

    # ── Cache (when cache_manager is available) ──────────────────
    cache_discovery: bool = False
    cache_ttl_seconds: int = 300

    # ── Logging ──────────────────────────────────────────────────
    log_level: str = "DEBUG"
    log_lifecycle: bool = True
