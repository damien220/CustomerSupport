"""PluginSandbox — error isolation for plugin lifecycle operations."""

from __future__ import annotations

import time
from contextlib import asynccontextmanager, contextmanager
from typing import TYPE_CHECKING, AsyncGenerator, Generator

from plugin_loader.exceptions import PluginLoaderError
from plugin_loader.types import ErrorPolicy, PluginOperationResult, PluginState

if TYPE_CHECKING:
    from plugin_loader.types import PluginRecord


class PluginSandbox:
    """Wraps plugin operations in error-safe context managers.

    A *sandbox* is bound to one :class:`PluginRecord` and one
    :class:`ErrorPolicy`.  It catches any exception that escapes from the
    wrapped block, updates the record state, and then either suppresses,
    re-raises, or disables the plugin depending on the policy.

    Usage (sync)::

        sandbox = PluginSandbox(ErrorPolicy.SUPPRESS, record)
        with sandbox.safe_execute("initialize") as guard:
            if guard.ok:
                plugin.do_something()
        result = sandbox.last_result

    Usage (async)::

        async with sandbox.safe_execute_async("start") as guard:
            if guard.ok:
                await plugin.start()

    The context manager exposes a *guard* object whose ``ok`` attribute
    is ``True`` before the block runs and becomes ``False`` if an
    exception is caught.  This lets callers opt-in to skipping the body
    when a previous step already failed.
    """

    def __init__(self, error_policy: ErrorPolicy, record: "PluginRecord") -> None:
        self.error_policy = error_policy
        self.record = record
        self.last_result: PluginOperationResult | None = None

    # ── Sync context manager ─────────────────────────────────────

    @contextmanager
    def safe_execute(self, operation_name: str) -> Generator["_Guard", None, None]:
        """Sync context manager for safe plugin execution.

        Yields a :class:`_Guard` whose ``ok`` attribute is ``True`` if
        the operation may proceed.  On exception the guard's ``ok`` flag
        is flipped to ``False``.
        """
        guard = _Guard()
        start = time.monotonic()
        try:
            yield guard
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - start) * 1000
            self._handle_error(exc, operation_name, elapsed)
        else:
            elapsed = (time.monotonic() - start) * 1000
            if guard.ok:
                self.last_result = PluginOperationResult(
                    plugin_name=self.record.plugin_name,
                    success=True,
                    state=self.record.state,
                    elapsed_ms=elapsed,
                )

    # ── Async context manager ────────────────────────────────────

    @asynccontextmanager
    async def safe_execute_async(
        self, operation_name: str
    ) -> AsyncGenerator["_Guard", None]:
        """Async context manager for safe plugin execution."""
        guard = _Guard()
        start = time.monotonic()
        try:
            yield guard
        except Exception as exc:  # noqa: BLE001
            elapsed = (time.monotonic() - start) * 1000
            self._handle_error(exc, operation_name, elapsed)
        else:
            elapsed = (time.monotonic() - start) * 1000
            if guard.ok:
                self.last_result = PluginOperationResult(
                    plugin_name=self.record.plugin_name,
                    success=True,
                    state=self.record.state,
                    elapsed_ms=elapsed,
                )

    # ── Error handling ───────────────────────────────────────────

    def _handle_error(
        self, exc: Exception, operation_name: str, elapsed_ms: float
    ) -> None:
        """Apply error policy and update the plugin record."""
        self.record.error = exc
        self.record.state = PluginState.ERROR

        self.last_result = PluginOperationResult(
            plugin_name=self.record.plugin_name,
            success=False,
            state=PluginState.ERROR,
            error=exc,
            elapsed_ms=elapsed_ms,
        )

        if self.error_policy == ErrorPolicy.PROPAGATE:
            if isinstance(exc, PluginLoaderError):
                raise
            raise PluginLoaderError(
                f"Plugin '{self.record.plugin_name}' failed during '{operation_name}': {exc}",
                previous=exc,
            ) from exc

        if self.error_policy == ErrorPolicy.DISABLE_PLUGIN:
            self.record.state = PluginState.DISABLED
            self.last_result = PluginOperationResult(
                plugin_name=self.record.plugin_name,
                success=False,
                state=PluginState.DISABLED,
                error=exc,
                elapsed_ms=elapsed_ms,
            )
            # Suppress — do not re-raise

        # SUPPRESS: just swallow — record already updated


# ── Guard helper ─────────────────────────────────────────────────


class _Guard:
    """Small sentinel yielded by :class:`PluginSandbox` context managers.

    The ``ok`` attribute is always ``True`` before the context body runs.
    It is set to ``False`` in ``_handle_error`` path so that callers can
    check it after the context if needed.
    """

    __slots__ = ("ok",)

    def __init__(self) -> None:
        self.ok: bool = True
