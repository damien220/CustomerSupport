"""DirectoryStrategy — discover plugins by scanning filesystem directories."""

from __future__ import annotations

import importlib.util
import inspect
import sys
import time
from pathlib import Path

from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy
from plugin_loader.types import DiscoveryMethod, DiscoveryResult, PluginMetadata


class DirectoryStrategy(AbstractDiscoveryStrategy):
    """Scan one or more directories for Python files that contain plugins.

    For each ``.py`` file found the strategy:

    1. Imports the module via :func:`importlib.util.spec_from_file_location`.
    2. Inspects every class defined in the module.
    3. Keeps classes that match the configured *filter criteria*.

    Parameters
    ----------
    plugin_dirs:
        One or more directory paths to scan.
    recursive:
        When ``True`` subdirectories are also scanned.
    file_pattern:
        Glob pattern used to select files (default ``"*.py"``).
    base_class:
        When provided, only classes that are a subclass of *base_class*
        **and** are not *base_class* itself are kept.
    exclude_abstract:
        Skip classes that still have abstract methods (default ``True``).
    """

    def __init__(
        self,
        plugin_dirs: list[str] | str,
        *,
        recursive: bool = False,
        file_pattern: str = "*.py",
        base_class: type | None = None,
        exclude_abstract: bool = True,
    ) -> None:
        if isinstance(plugin_dirs, str):
            plugin_dirs = [plugin_dirs]
        self.plugin_dirs: list[Path] = [Path(d) for d in plugin_dirs]
        self.recursive = recursive
        self.file_pattern = file_pattern
        self.base_class = base_class
        self.exclude_abstract = exclude_abstract

    # ── Discovery ────────────────────────────────────────────────

    def discover(self) -> DiscoveryResult:
        start = time.monotonic()
        result = DiscoveryResult()
        seen_names: set[str] = set()

        for directory in self.plugin_dirs:
            self._scan_directory(directory, result, seen_names)

        result.elapsed_ms = (time.monotonic() - start) * 1000
        return result

    # ── Internal ─────────────────────────────────────────────────

    def _scan_directory(
        self, directory: Path, result: DiscoveryResult, seen_names: set[str]
    ) -> None:
        if not directory.exists():
            result.errors.append(
                (str(directory), FileNotFoundError(f"Directory not found: {directory}"))
            )
            return

        if not directory.is_dir():
            result.errors.append(
                (str(directory), NotADirectoryError(f"Not a directory: {directory}"))
            )
            return

        if self.recursive:
            py_files = list(directory.rglob(self.file_pattern))
        else:
            py_files = list(directory.glob(self.file_pattern))

        for py_file in sorted(py_files):
            self._load_file(py_file, result, seen_names)

    def _load_file(
        self, path: Path, result: DiscoveryResult, seen_names: set[str]
    ) -> None:
        module_name = f"_plugin_loader_discovery.{path.stem}_{id(path)}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, path)
            if spec is None or spec.loader is None:
                return
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception as exc:  # noqa: BLE001
            result.errors.append((str(path), exc))
            return

        for _, obj in inspect.getmembers(module, inspect.isclass):
            if not self._is_plugin_candidate(obj, module):
                continue
            name = getattr(obj, "plugin_name", obj.__name__)
            if name in seen_names:
                continue
            seen_names.add(name)
            # Annotate source info on metadata if it doesn't exist yet
            result.plugin_classes.append((name, obj))

    def _is_plugin_candidate(self, cls: type, module: object) -> bool:
        # Only classes defined in this module (not imported ones)
        if cls.__module__ != getattr(module, "__name__", None):
            return False

        # Apply base class filter
        if self.base_class is not None:
            if not (issubclass(cls, self.base_class) and cls is not self.base_class):
                return False

        # Skip abstract classes
        if self.exclude_abstract:
            has_abstracts = any(
                getattr(getattr(cls, name, None), "__isabstractmethod__", False)
                for name in dir(cls)
            )
            if has_abstracts:
                return False

        return True

    def __repr__(self) -> str:
        dirs = ", ".join(str(d) for d in self.plugin_dirs)
        return f"<DirectoryStrategy dirs=[{dirs}] recursive={self.recursive}>"
