"""AbstractDiscoveryStrategy — base class for all discovery strategies."""

from __future__ import annotations

from abc import ABC, abstractmethod

from plugin_loader.types import DiscoveryResult


class AbstractDiscoveryStrategy(ABC):
    """Base class for all plugin discovery strategies.

    Each strategy implements :meth:`discover` which scans some source
    (a directory, an entry-point group, a package) and returns a
    :class:`DiscoveryResult` containing the discovered plugin classes and
    any errors that occurred during scanning.

    The async variant :meth:`discover_async` defaults to delegating to
    the sync variant.  Override it when the underlying source is I/O-bound
    and can benefit from true async scanning.
    """

    @abstractmethod
    def discover(self) -> DiscoveryResult:
        """Scan the source and return discovered plugin classes (sync)."""

    async def discover_async(self) -> DiscoveryResult:
        """Async scan — defaults to delegating to :meth:`discover`."""
        return self.discover()

    def __repr__(self) -> str:
        return f"<{type(self).__name__}>"
