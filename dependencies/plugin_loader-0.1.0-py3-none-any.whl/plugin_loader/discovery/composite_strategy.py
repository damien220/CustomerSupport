"""CompositeStrategy — chains multiple discovery strategies."""

from __future__ import annotations

import time

from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy
from plugin_loader.types import DiscoveryResult


class CompositeStrategy(AbstractDiscoveryStrategy):
    """Runs multiple discovery strategies in sequence and merges results.

    Plugins with duplicate ``plugin_name`` values are deduplicated: the
    first occurrence (in strategy order) wins.

    Parameters
    ----------
    strategies:
        Ordered list of :class:`AbstractDiscoveryStrategy` instances.
    """

    def __init__(self, strategies: list[AbstractDiscoveryStrategy]) -> None:
        self.strategies = list(strategies)

    # ── Discovery ────────────────────────────────────────────────

    def discover(self) -> DiscoveryResult:
        start = time.monotonic()
        merged = DiscoveryResult()
        seen_names: set[str] = set()

        for strategy in self.strategies:
            partial = strategy.discover()
            self._merge(partial, merged, seen_names)

        merged.elapsed_ms = (time.monotonic() - start) * 1000
        return merged

    async def discover_async(self) -> DiscoveryResult:
        start = time.monotonic()
        merged = DiscoveryResult()
        seen_names: set[str] = set()

        for strategy in self.strategies:
            partial = await strategy.discover_async()
            self._merge(partial, merged, seen_names)

        merged.elapsed_ms = (time.monotonic() - start) * 1000
        return merged

    # ── Internal ─────────────────────────────────────────────────

    @staticmethod
    def _merge(
        source: DiscoveryResult,
        target: DiscoveryResult,
        seen_names: set[str],
    ) -> None:
        for name, cls in source.plugin_classes:
            if name not in seen_names:
                seen_names.add(name)
                target.plugin_classes.append((name, cls))
        target.errors.extend(source.errors)

    # ── Composition helpers ──────────────────────────────────────

    def add_strategy(self, strategy: AbstractDiscoveryStrategy) -> None:
        """Append a strategy to the end of the chain."""
        self.strategies.append(strategy)

    def __len__(self) -> int:
        return len(self.strategies)

    def __repr__(self) -> str:
        inner = ", ".join(repr(s) for s in self.strategies)
        return f"<CompositeStrategy [{inner}]>"
