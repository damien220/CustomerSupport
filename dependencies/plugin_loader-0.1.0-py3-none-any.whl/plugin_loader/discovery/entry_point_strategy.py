"""EntryPointStrategy — discover plugins via setuptools entry points."""

from __future__ import annotations

import importlib
import inspect
import time

from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy
from plugin_loader.types import DiscoveryResult


class EntryPointStrategy(AbstractDiscoveryStrategy):
    """Discover plugins registered via ``importlib.metadata`` entry points.

    Third-party packages advertise plugins by adding entries to their
    ``pyproject.toml``::

        [project.entry-points."myapp.plugins"]
        my_plugin = "my_package.module:MyPluginClass"

    This strategy calls
    ``importlib.metadata.entry_points(group=entry_point_group)`` and
    imports each advertised class.

    Parameters
    ----------
    entry_point_group:
        The entry-point group name to scan (e.g. ``"myapp.plugins"``).
    base_class:
        When provided, only classes that are a subclass of *base_class*
        are kept.
    exclude_abstract:
        Skip classes that still have abstract methods (default ``True``).
    """

    def __init__(
        self,
        entry_point_group: str,
        *,
        base_class: type | None = None,
        exclude_abstract: bool = True,
    ) -> None:
        self.entry_point_group = entry_point_group
        self.base_class = base_class
        self.exclude_abstract = exclude_abstract

    # ── Discovery ────────────────────────────────────────────────

    def discover(self) -> DiscoveryResult:
        from importlib.metadata import entry_points

        start = time.monotonic()
        result = DiscoveryResult()
        seen_names: set[str] = set()

        try:
            eps = entry_points(group=self.entry_point_group)
        except Exception as exc:  # noqa: BLE001
            result.errors.append((self.entry_point_group, exc))
            result.elapsed_ms = (time.monotonic() - start) * 1000
            return result

        for ep in eps:
            try:
                obj = ep.load()
            except Exception as exc:  # noqa: BLE001
                result.errors.append((ep.value, exc))
                continue

            candidates = self._collect_candidates(obj)
            for cls in candidates:
                name = getattr(cls, "plugin_name", cls.__name__)
                if name in seen_names:
                    continue
                seen_names.add(name)
                result.plugin_classes.append((name, cls))

        result.elapsed_ms = (time.monotonic() - start) * 1000
        return result

    # ── Internal ─────────────────────────────────────────────────

    def _collect_candidates(self, obj: object) -> list[type]:
        """Return plugin classes from the loaded entry-point value.

        The entry point may point to:
        - A single class: ``"module:MyClass"``
        - A module: ``"module"`` (all classes in it are inspected)
        """
        if inspect.isclass(obj) and self._is_plugin_candidate(obj):
            return [obj]

        if inspect.ismodule(obj):
            return [
                cls
                for _, cls in inspect.getmembers(obj, inspect.isclass)
                if self._is_plugin_candidate(cls)
            ]

        return []

    def _is_plugin_candidate(self, cls: type) -> bool:
        if self.base_class is not None:
            if not (issubclass(cls, self.base_class) and cls is not self.base_class):
                return False

        if self.exclude_abstract:
            has_abstracts = any(
                getattr(getattr(cls, name, None), "__isabstractmethod__", False)
                for name in dir(cls)
            )
            if has_abstracts:
                return False

        return True

    def __repr__(self) -> str:
        return f"<EntryPointStrategy group={self.entry_point_group!r}>"
