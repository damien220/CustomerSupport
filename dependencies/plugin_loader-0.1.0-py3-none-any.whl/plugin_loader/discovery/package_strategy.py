"""PackageStrategy — discover plugins by walking installed Python packages."""

from __future__ import annotations

import importlib
import inspect
import pkgutil
import time

from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy
from plugin_loader.types import DiscoveryResult


class PackageStrategy(AbstractDiscoveryStrategy):
    """Discover plugins by walking installed Python packages.

    Uses :func:`pkgutil.walk_packages` to iterate over all modules inside
    each configured package, importing them and inspecting their classes.

    Parameters
    ----------
    scan_packages:
        One or more dotted package names to scan (e.g.
        ``["myapp.plugins", "myapp.extensions"]``).
    base_class:
        When provided, only classes that are a subclass of *base_class*
        are kept.
    exclude_abstract:
        Skip classes that still have abstract methods (default ``True``).
    recursive:
        When ``True`` sub-packages are also walked (default ``True``).
    """

    def __init__(
        self,
        scan_packages: list[str] | str,
        *,
        base_class: type | None = None,
        exclude_abstract: bool = True,
        recursive: bool = True,
    ) -> None:
        if isinstance(scan_packages, str):
            scan_packages = [scan_packages]
        self.scan_packages = scan_packages
        self.base_class = base_class
        self.exclude_abstract = exclude_abstract
        self.recursive = recursive

    # ── Discovery ────────────────────────────────────────────────

    def discover(self) -> DiscoveryResult:
        start = time.monotonic()
        result = DiscoveryResult()
        seen_names: set[str] = set()

        for pkg_name in self.scan_packages:
            self._scan_package(pkg_name, result, seen_names)

        result.elapsed_ms = (time.monotonic() - start) * 1000
        return result

    # ── Internal ─────────────────────────────────────────────────

    def _scan_package(
        self, pkg_name: str, result: DiscoveryResult, seen_names: set[str]
    ) -> None:
        try:
            root_pkg = importlib.import_module(pkg_name)
        except ImportError as exc:
            result.errors.append((pkg_name, exc))
            return

        # Inspect the root package itself
        self._inspect_module(root_pkg, result, seen_names)

        # Walk sub-modules
        pkg_path = getattr(root_pkg, "__path__", None)
        if pkg_path is None:
            return  # Not a package, just a module

        prefix = pkg_name + "."
        walker = pkgutil.walk_packages(pkg_path, prefix=prefix) if self.recursive else \
                 pkgutil.iter_modules(pkg_path, prefix=prefix)

        for module_info in walker:
            try:
                mod = importlib.import_module(module_info.name)
            except Exception as exc:  # noqa: BLE001
                result.errors.append((module_info.name, exc))
                continue
            self._inspect_module(mod, result, seen_names)

    def _inspect_module(
        self, module: object, result: DiscoveryResult, seen_names: set[str]
    ) -> None:
        for _, cls in inspect.getmembers(module, inspect.isclass):
            if not self._is_plugin_candidate(cls, module):
                continue
            name = getattr(cls, "plugin_name", cls.__name__)
            if name in seen_names:
                continue
            seen_names.add(name)
            result.plugin_classes.append((name, cls))

    def _is_plugin_candidate(self, cls: type, module: object) -> bool:
        # Only classes defined in this module
        if cls.__module__ != getattr(module, "__name__", None):
            return False

        if self.base_class is not None:
            if not (issubclass(cls, self.base_class) and cls is not self.base_class):
                return False

        if self.exclude_abstract:
            has_abstracts = any(
                getattr(getattr(cls, name, None), "__isabstractmethod__", False)
                for name in dir(cls)
            )
            if has_abstracts:
                return False

        return True

    def __repr__(self) -> str:
        pkgs = ", ".join(self.scan_packages)
        return f"<PackageStrategy packages=[{pkgs}]>"
