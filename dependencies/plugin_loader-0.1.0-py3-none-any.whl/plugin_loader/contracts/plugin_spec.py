"""PluginSpec protocol and @plugin_hook decorator."""

from __future__ import annotations

from typing import Any, Callable, Protocol, runtime_checkable


@runtime_checkable
class PluginSpec(Protocol):
    """Duck-typed protocol for plugin conformance checking.

    Any class exposing these members is considered a valid plugin,
    regardless of whether it inherits from :class:`AbstractPlugin`.
    """

    plugin_name: str

    async def initialize(self, config: dict[str, Any] | None = None) -> None: ...

    async def start(self) -> None: ...

    async def stop(self) -> None: ...


def plugin_hook(
    name: str,
    *,
    tags: tuple[str, ...] = (),
    capabilities: tuple[str, ...] = (),
) -> Callable[..., Any]:
    """Decorator that turns a plain function into a lightweight plugin.

    The decorated callable is annotated with plugin metadata so the
    :class:`PluginManager` can register and manage it.

    Usage::

        @plugin_hook("my_tool", tags=("search",))
        async def my_tool_handler(query: str) -> dict:
            return {"results": [...]}
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        fn._plugin_hook = True  # type: ignore[attr-defined]
        fn._plugin_name = name  # type: ignore[attr-defined]
        fn._plugin_tags = tags  # type: ignore[attr-defined]
        fn._plugin_capabilities = capabilities  # type: ignore[attr-defined]
        return fn

    return decorator
