"""AbstractPlugin — the universal base class for all plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from plugin_loader.types import DiscoveryMethod, PluginMetadata


class AbstractPlugin(ABC):
    """Universal base class for all plugins.

    Concrete subclasses **must** define a ``plugin_name`` class attribute
    (enforced at class-creation time via ``__init_subclass__``).

    Lifecycle methods are async to accommodate I/O-bound initialisation
    (connecting to APIs, loading resources, etc.).
    """

    plugin_name: str
    plugin_version: str = "0.0.0"
    plugin_description: str = ""
    plugin_tags: tuple[str, ...] = ()
    plugin_capabilities: tuple[str, ...] = ()
    plugin_dependencies: tuple[str, ...] = ()

    # ── Subclass validation ──────────────────────────────────────

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Only enforce on concrete (non-abstract) subclasses.
        # NOTE: __abstractmethods__ is not yet set when __init_subclass__
        # runs, so we inspect methods directly.
        has_abstracts = any(
            getattr(getattr(cls, name, None), "__isabstractmethod__", False)
            for name in dir(cls)
        )
        if not has_abstracts:
            if not isinstance(getattr(cls, "plugin_name", None), str):
                raise TypeError(
                    f"{cls.__name__} must define a `plugin_name: str` class attribute."
                )

    # ── Lifecycle ────────────────────────────────────────────────

    @abstractmethod
    async def initialize(self, config: dict[str, Any] | None = None) -> None:
        """One-time setup.  Receive config, acquire resources."""

    @abstractmethod
    async def start(self) -> None:
        """Begin active operation."""

    @abstractmethod
    async def stop(self) -> None:
        """Graceful shutdown.  Release resources."""

    async def health_check(self) -> bool:
        """Return ``True`` if healthy.  Override for custom checks."""
        return True

    # ── Metadata ─────────────────────────────────────────────────

    def get_metadata(self) -> PluginMetadata:
        """Build a :class:`PluginMetadata` from class attributes."""
        return PluginMetadata(
            plugin_name=self.plugin_name,
            plugin_version=self.plugin_version,
            description=self.plugin_description,
            tags=self.plugin_tags,
            capabilities=self.plugin_capabilities,
            plugin_dependencies=self.plugin_dependencies,
            discovery_method=DiscoveryMethod.EXPLICIT,
        )

    # ── Repr ─────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"<{type(self).__name__} name={self.plugin_name!r} v{self.plugin_version}>"
