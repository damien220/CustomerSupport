"""Plugin contracts — ABCs, protocols, and decorators."""

from plugin_loader.contracts.base_plugin import AbstractPlugin
from plugin_loader.contracts.plugin_spec import PluginSpec, plugin_hook

__all__ = [
    "AbstractPlugin",
    "PluginSpec",
    "plugin_hook",
]
