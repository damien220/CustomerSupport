"""plugin_loader — Abstract, reusable plugin loading and lifecycle management.

Public API
----------
Core contracts::

    AbstractPlugin, PluginSpec, plugin_hook

Configuration & types::

    PluginManagerConfig, PluginState, ErrorPolicy, DiscoveryMethod,
    PluginMetadata, PluginRecord, PluginOperationResult, DiscoveryResult

Exceptions::

    PluginLoaderError, PluginNotFoundError, PluginValidationError,
    PluginDependencyError, PluginInitializationError, PluginLoadError,
    PluginDiscoveryError, PluginSandboxError, PluginConfigError

Validation & sandboxing::

    PluginValidator, PluginSandbox

Discovery strategies::

    DirectoryStrategy, EntryPointStrategy, PackageStrategy,
    CompositeStrategy, AbstractDiscoveryStrategy

Registry & manager::

    PluginRegistry, PluginManager

Factory::

    create_plugin_manager, register_discovery_strategy,
    list_discovery_strategies, get_discovery_strategy

Integrations (optional sibling packages)::

    has_logger_pkg, has_error_handler, has_event_dispatcher,
    has_cache_manager, has_config_manager,
    get_plugin_logger, plugin_logging_context,
    plugin_error_to_structured, handle_plugin_exception, classify_plugin_error,
    PluginEventBridge, CachedDiscovery, load_plugin_manager_config
"""

__version__ = "0.1.0"

# ── Types & Config ───────────────────────────────────────────────
from plugin_loader.types import (
    DiscoveryMethod,
    DiscoveryResult,
    ErrorPolicy,
    PluginMetadata,
    PluginOperationResult,
    PluginRecord,
    PluginState,
)
from plugin_loader.config import PluginManagerConfig

# ── Exceptions ───────────────────────────────────────────────────
from plugin_loader.exceptions import (
    PluginConfigError,
    PluginDependencyError,
    PluginDiscoveryError,
    PluginInitializationError,
    PluginLoadError,
    PluginLoaderError,
    PluginNotFoundError,
    PluginSandboxError,
    PluginValidationError,
)

# ── Contracts ────────────────────────────────────────────────────
from plugin_loader.contracts import AbstractPlugin, PluginSpec, plugin_hook

# ── Validation & Sandbox ─────────────────────────────────────────
from plugin_loader.validation import PluginValidator
from plugin_loader.sandbox import PluginSandbox

# ── Discovery ────────────────────────────────────────────────────
from plugin_loader.discovery import (
    AbstractDiscoveryStrategy,
    CompositeStrategy,
    DirectoryStrategy,
    EntryPointStrategy,
    PackageStrategy,
)

# ── Registry ─────────────────────────────────────────────────────
from plugin_loader.registry import PluginRegistry

# ── Manager & Factory ────────────────────────────────────────────
from plugin_loader.manager import PluginManager
from plugin_loader.factory import (
    create_plugin_manager,
    register_discovery_strategy,
    list_discovery_strategies,
    get_discovery_strategy,
)

# ── Integrations ─────────────────────────────────────────────────
from plugin_loader.integrations import (
    # Availability guards
    has_error_handler,
    has_logger_pkg,
    has_event_dispatcher,
    has_cache_manager,
    has_config_manager,
    # Error integration
    plugin_error_to_structured,
    handle_plugin_exception,
    classify_plugin_error,
    # Logger integration
    get_plugin_logger,
    plugin_logging_context,
    log_plugin_loaded,
    log_plugin_initialized,
    log_plugin_started,
    log_plugin_stopped,
    log_plugin_error,
    # Event integration
    PluginEventBridge,
    # Cache integration
    CachedDiscovery,
    # Config integration
    load_plugin_manager_config,
)

__all__ = [
    # Types & enums
    "DiscoveryMethod",
    "DiscoveryResult",
    "ErrorPolicy",
    "PluginMetadata",
    "PluginOperationResult",
    "PluginRecord",
    "PluginState",
    # Config
    "PluginManagerConfig",
    # Exceptions
    "PluginConfigError",
    "PluginDependencyError",
    "PluginDiscoveryError",
    "PluginInitializationError",
    "PluginLoadError",
    "PluginLoaderError",
    "PluginNotFoundError",
    "PluginSandboxError",
    "PluginValidationError",
    # Contracts
    "AbstractPlugin",
    "PluginSpec",
    "plugin_hook",
    # Validation & Sandbox
    "PluginValidator",
    "PluginSandbox",
    # Discovery
    "AbstractDiscoveryStrategy",
    "CompositeStrategy",
    "DirectoryStrategy",
    "EntryPointStrategy",
    "PackageStrategy",
    # Registry
    "PluginRegistry",
    # Manager & Factory
    "PluginManager",
    "create_plugin_manager",
    "register_discovery_strategy",
    "list_discovery_strategies",
    "get_discovery_strategy",
    # Integrations — availability guards
    "has_error_handler",
    "has_logger_pkg",
    "has_event_dispatcher",
    "has_cache_manager",
    "has_config_manager",
    # Integrations — error
    "plugin_error_to_structured",
    "handle_plugin_exception",
    "classify_plugin_error",
    # Integrations — logger
    "get_plugin_logger",
    "plugin_logging_context",
    "log_plugin_loaded",
    "log_plugin_initialized",
    "log_plugin_started",
    "log_plugin_stopped",
    "log_plugin_error",
    # Integrations — event
    "PluginEventBridge",
    # Integrations — cache
    "CachedDiscovery",
    # Integrations — config
    "load_plugin_manager_config",
]
