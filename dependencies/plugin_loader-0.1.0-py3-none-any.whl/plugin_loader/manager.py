"""PluginManager — the primary orchestrator for plugin loading and lifecycle.

Wires together:
- Discovery strategies  (Phase 3)
- PluginValidator       (Phase 2)
- PluginRegistry        (Phase 4)
- PluginSandbox         (Phase 2)

Usage::

    async with PluginManager(config) as pm:
        pm.register(MyPlugin)
        await pm.discover_async()   # optional
        await pm.initialize_all()
        await pm.start_all()
        plugin = pm.get_plugin("my_plugin")
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from plugin_loader.config import PluginManagerConfig
from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy
from plugin_loader.discovery.composite_strategy import CompositeStrategy
from plugin_loader.discovery.directory_strategy import DirectoryStrategy
from plugin_loader.discovery.entry_point_strategy import EntryPointStrategy
from plugin_loader.discovery.package_strategy import PackageStrategy
from plugin_loader.exceptions import (
    PluginConfigError,
    PluginInitializationError,
    PluginNotFoundError,
)
from plugin_loader.registry import PluginRegistry
from plugin_loader.sandbox import PluginSandbox
from plugin_loader.types import (
    DiscoveryResult,
    ErrorPolicy,
    PluginOperationResult,
    PluginRecord,
    PluginState,
)
from plugin_loader.validation import PluginValidator

logger = logging.getLogger(__name__)


class PluginManager:
    """Orchestrates plugin discovery, validation, registration, and lifecycle.

    Parameters
    ----------
    config:
        Manager configuration.  Defaults to :class:`PluginManagerConfig`
        with all defaults (no discovery sources, suppress errors).
    """

    def __init__(self, config: PluginManagerConfig | None = None) -> None:
        self.config = config or PluginManagerConfig()
        self._registry = PluginRegistry(
            allow_override=self.config.allow_override,
            max_plugins=self.config.max_plugins,
        )
        self._validator = self._build_validator()
        self._strategies: list[AbstractDiscoveryStrategy] = self._build_strategies()
        self._error_policy = self._resolve_error_policy()

    # ── Discovery ────────────────────────────────────────────────

    def add_discovery_strategy(self, strategy: AbstractDiscoveryStrategy) -> None:
        """Append a discovery strategy to the manager."""
        self._strategies.append(strategy)

    def discover(self) -> DiscoveryResult:
        """Run all configured discovery strategies (sync) and register findings.

        Returns the merged :class:`DiscoveryResult`.  Any classes that
        pass validation are registered automatically.
        """
        result = self._run_discovery_sync()
        self._register_discovered(result)
        return result

    async def discover_async(self) -> DiscoveryResult:
        """Run all configured discovery strategies (async) and register findings."""
        result = await self._run_discovery_async()
        self._register_discovered(result)
        return result

    # ── Registration ─────────────────────────────────────────────

    def register(
        self,
        plugin_class: type,
        *,
        config: dict[str, Any] | None = None,
    ) -> PluginRecord:
        """Manually register a plugin class.

        The class is validated before registration when
        ``config.strict_validation`` is ``True``.

        Returns
        -------
        PluginRecord
        """
        name = getattr(plugin_class, "plugin_name", None) or plugin_class.__name__

        if self.config.strict_validation:
            ok, errors = self._validator.validate(plugin_class)
            if not ok:
                raise PluginConfigError(
                    f"Plugin '{name}' failed validation: "
                    + "; ".join(errors),
                    details={"plugin_name": name, "errors": errors},
                )

        record = self._registry.register(name, plugin_class, config=config)
        if self.config.log_lifecycle:
            logger.debug("Registered plugin '%s'", name)
        return record

    def register_instance(self, instance: Any) -> PluginRecord:
        """Register a pre-built plugin instance.

        The instance must have a ``plugin_name`` attribute.
        The record is placed directly in the ``INITIALIZED`` state so
        ``start_all()`` can be called without ``initialize_all()``.
        """
        name = getattr(instance, "plugin_name", None)
        if not name:
            raise PluginConfigError(
                "Cannot register instance without 'plugin_name' attribute.",
            )
        record = self._registry.register(name, type(instance))
        record.instance = instance
        record.state = PluginState.INITIALIZED
        if self.config.log_lifecycle:
            logger.debug("Registered plugin instance '%s'", name)
        return record

    def unregister(self, plugin_name: str) -> None:
        """Unregister a plugin by name."""
        self._registry.unregister(plugin_name)
        if self.config.log_lifecycle:
            logger.debug("Unregistered plugin '%s'", plugin_name)

    # ── Lifecycle — single plugin ────────────────────────────────

    async def initialize_plugin(
        self,
        plugin_name: str,
        config: dict[str, Any] | None = None,
    ) -> PluginOperationResult:
        """Instantiate and initialize a single plugin."""
        record = self._get_or_raise(plugin_name)

        if record.state in (PluginState.INITIALIZED, PluginState.ACTIVE):
            return PluginOperationResult(
                plugin_name=plugin_name,
                success=True,
                state=record.state,
            )

        sandbox = PluginSandbox(self._error_policy, record)
        cfg = config or record.config

        async with sandbox.safe_execute_async("initialize"):
            instance = record.plugin_class()
            await instance.initialize(cfg or None)
            record.instance = instance
            record.state = PluginState.INITIALIZED

        if self.config.log_lifecycle and sandbox.last_result:
            if sandbox.last_result.success:
                logger.debug(
                    "Initialized plugin '%s' in %.1fms",
                    plugin_name, sandbox.last_result.elapsed_ms,
                )
            else:
                logger.warning(
                    "Plugin '%s' failed to initialize: %s",
                    plugin_name, sandbox.last_result.error,
                )

        return sandbox.last_result or PluginOperationResult(
            plugin_name=plugin_name, success=False, state=record.state,
        )

    async def start_plugin(self, plugin_name: str) -> PluginOperationResult:
        """Start a single initialized plugin."""
        record = self._get_or_raise(plugin_name)

        if record.state == PluginState.ACTIVE:
            return PluginOperationResult(
                plugin_name=plugin_name, success=True, state=PluginState.ACTIVE,
            )

        if record.instance is None:
            raise PluginConfigError(
                f"Plugin '{plugin_name}' must be initialized before starting.",
                details={"plugin_name": plugin_name, "state": record.state.value},
            )

        sandbox = PluginSandbox(self._error_policy, record)
        async with sandbox.safe_execute_async("start"):
            await record.instance.start()
            record.state = PluginState.ACTIVE

        if self.config.log_lifecycle and sandbox.last_result:
            if sandbox.last_result.success:
                logger.debug("Started plugin '%s'", plugin_name)
            else:
                logger.warning("Plugin '%s' failed to start: %s", plugin_name, sandbox.last_result.error)

        return sandbox.last_result or PluginOperationResult(
            plugin_name=plugin_name, success=False, state=record.state,
        )

    async def stop_plugin(self, plugin_name: str) -> PluginOperationResult:
        """Stop a single active plugin."""
        record = self._get_or_raise(plugin_name)

        if record.instance is None or record.state not in (
            PluginState.ACTIVE, PluginState.INITIALIZED
        ):
            return PluginOperationResult(
                plugin_name=plugin_name, success=True, state=record.state,
            )

        sandbox = PluginSandbox(ErrorPolicy.SUPPRESS, record)  # always suppress on stop
        async with sandbox.safe_execute_async("stop"):
            await record.instance.stop()
            record.state = PluginState.UNLOADED

        if self.config.log_lifecycle and sandbox.last_result:
            logger.debug("Stopped plugin '%s'", plugin_name)

        return sandbox.last_result or PluginOperationResult(
            plugin_name=plugin_name, success=True, state=record.state,
        )

    # ── Lifecycle — bulk ────────────────────────────────────────

    async def initialize_all(
        self, config: dict[str, Any] | None = None,
    ) -> list[PluginOperationResult]:
        """Initialize all registered plugins in dependency order."""
        order = self._registry.resolve_dependencies()
        results = []
        for name in order:
            result = await self.initialize_plugin(name, config)
            results.append(result)
        return results

    async def start_all(self) -> list[PluginOperationResult]:
        """Start all initialized plugins in dependency order."""
        order = self._registry.resolve_dependencies()
        results = []
        for name in order:
            record = self._registry.get(name)
            if record.state == PluginState.INITIALIZED:
                result = await self.start_plugin(name)
                results.append(result)
        return results

    async def stop_all(self) -> list[PluginOperationResult]:
        """Stop all active plugins in reverse dependency order."""
        order = list(reversed(self._registry.resolve_dependencies()))
        results = []
        for name in order:
            record = self._registry.get(name)
            if record.state in (PluginState.ACTIVE, PluginState.INITIALIZED):
                result = await self.stop_plugin(name)
                results.append(result)
        return results

    # ── Dependency resolution (delegates to registry) ────────────

    def resolve_dependencies(self) -> list[str]:
        """Return plugin names in dependency-safe initialization order."""
        return self._registry.resolve_dependencies()

    # ── Query ────────────────────────────────────────────────────

    def get_plugin(self, plugin_name: str) -> Any:
        """Return the live instance for *plugin_name*.

        Raises
        ------
        PluginNotFoundError
            If not registered.
        PluginConfigError
            If registered but not yet initialized.
        """
        return self._registry.get_instance(plugin_name)

    def get_record(self, plugin_name: str) -> PluginRecord:
        """Return the :class:`PluginRecord` for *plugin_name*."""
        return self._registry.get(plugin_name)

    def list_plugins(
        self,
        *,
        state: PluginState | None = None,
        tag: str | None = None,
        capability: str | None = None,
    ) -> list[PluginRecord]:
        """Return records matching the given filters."""
        return self._registry.list_plugins(state=state, tag=tag, capability=capability)

    def has_plugin(self, plugin_name: str) -> bool:
        """Return ``True`` if *plugin_name* is registered."""
        return self._registry.has(plugin_name)

    # ── Health checks ─────────────────────────────────────────────

    async def health_check(self, plugin_name: str) -> bool:
        """Return the health status of a single plugin."""
        record = self._get_or_raise(plugin_name)
        if record.instance is None:
            return False
        try:
            return await record.instance.health_check()
        except Exception:  # noqa: BLE001
            return False

    async def health_check_all(self) -> dict[str, bool]:
        """Return health status for all registered plugins."""
        results: dict[str, bool] = {}
        for name in self._registry:
            results[name] = await self.health_check(name)
        return results

    # ── Context managers ──────────────────────────────────────────

    async def __aenter__(self) -> "PluginManager":
        """Async context manager — discover and initialize on entry."""
        if self._strategies:
            await self.discover_async()
        if self.config.auto_initialize:
            await self.initialize_all()
        if self.config.auto_start:
            await self.start_all()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager — stop all plugins on exit."""
        await self.stop_all()

    def __enter__(self) -> "PluginManager":
        """Sync context manager — runs async setup in a new event loop."""
        asyncio.get_event_loop().run_until_complete(self.__aenter__())
        return self

    def __exit__(self, *args: Any) -> None:
        asyncio.get_event_loop().run_until_complete(self.__aexit__(*args))

    def __repr__(self) -> str:
        return (
            f"<PluginManager plugins={len(self._registry)} "
            f"error_policy={self.config.error_policy!r}>"
        )

    # ── Internal helpers ──────────────────────────────────────────

    def _build_validator(self) -> PluginValidator:
        base_cls: type | None = None
        if self.config.required_base_class:
            import importlib
            parts = self.config.required_base_class.rsplit(".", 1)
            if len(parts) == 2:
                mod = importlib.import_module(parts[0])
                base_cls = getattr(mod, parts[1])
        return PluginValidator(
            required_base_class=base_cls,
            required_methods=list(self.config.required_methods),
        )

    def _build_strategies(self) -> list[AbstractDiscoveryStrategy]:
        strategies: list[AbstractDiscoveryStrategy] = []
        if self.config.plugin_dirs:
            strategies.append(DirectoryStrategy(self.config.plugin_dirs))
        if self.config.entry_point_group:
            strategies.append(EntryPointStrategy(self.config.entry_point_group))
        if self.config.scan_packages:
            strategies.append(PackageStrategy(self.config.scan_packages))
        return strategies

    def _resolve_error_policy(self) -> ErrorPolicy:
        mapping = {
            "propagate": ErrorPolicy.PROPAGATE,
            "suppress": ErrorPolicy.SUPPRESS,
            "disable": ErrorPolicy.DISABLE_PLUGIN,
        }
        policy = mapping.get(self.config.error_policy.lower())
        if policy is None:
            raise PluginConfigError(
                f"Unknown error_policy '{self.config.error_policy}'. "
                f"Valid values: {list(mapping)}",
            )
        return policy

    def _run_discovery_sync(self) -> DiscoveryResult:
        if not self._strategies:
            return DiscoveryResult()
        composite = CompositeStrategy(self._strategies)
        return composite.discover()

    async def _run_discovery_async(self) -> DiscoveryResult:
        if not self._strategies:
            return DiscoveryResult()
        composite = CompositeStrategy(self._strategies)
        return await composite.discover_async()

    def _register_discovered(self, result: DiscoveryResult) -> None:
        for name, cls in result.plugin_classes:
            if self._registry.has(name) and not self.config.allow_override:
                continue
            ok, errors = self._validator.validate(cls)
            if not ok:
                if self.config.strict_validation:
                    logger.warning(
                        "Skipping '%s' — validation failed: %s", name, errors
                    )
                    continue
            try:
                self._registry.register(name, cls)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not register discovered plugin '%s': %s", name, exc)

    def _get_or_raise(self, plugin_name: str) -> PluginRecord:
        return self._registry.get(plugin_name)
