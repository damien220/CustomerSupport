"""PluginRegistry — central store for discovered and loaded plugins.

Responsibilities
----------------
- CRUD for :class:`PluginRecord` entries.
- Query by state, tag, and capability.
- Enforcement of ``allow_override`` and ``max_plugins`` constraints.
- Topological dependency resolution via Kahn's algorithm (stdlib-only).
"""

from __future__ import annotations

from collections import deque
from typing import Any, Iterator

from plugin_loader.exceptions import (
    PluginConfigError,
    PluginDependencyError,
    PluginNotFoundError,
)
from plugin_loader.types import PluginMetadata, PluginRecord, PluginState


class PluginRegistry:
    """Holds all registered plugins and their lifecycle state.

    Parameters
    ----------
    allow_override:
        When ``True``, registering a plugin whose name is already present
        silently replaces the existing record.  When ``False`` (default)
        a :class:`PluginConfigError` is raised.
    max_plugins:
        Upper bound on the number of simultaneously registered plugins.
        ``None`` means unlimited.
    """

    def __init__(
        self,
        *,
        allow_override: bool = False,
        max_plugins: int | None = None,
    ) -> None:
        self._records: dict[str, PluginRecord] = {}
        self.allow_override = allow_override
        self.max_plugins = max_plugins
        self._load_counter: int = 0

    # ── Registration ─────────────────────────────────────────────

    def register(
        self,
        plugin_name: str,
        plugin_class: type,
        *,
        metadata: PluginMetadata | None = None,
        config: dict[str, Any] | None = None,
    ) -> PluginRecord:
        """Register a plugin class.

        Parameters
        ----------
        plugin_name:
            Unique identifier for the plugin.
        plugin_class:
            The class (not an instance) to register.
        metadata:
            Optional pre-built metadata.  When omitted, a minimal
            :class:`PluginMetadata` is created from *plugin_name*.
        config:
            Initial configuration dict stored on the record.

        Returns
        -------
        PluginRecord
            The newly created registry entry.

        Raises
        ------
        PluginConfigError
            If the name already exists and ``allow_override`` is ``False``,
            or if ``max_plugins`` would be exceeded.
        """
        if plugin_name in self._records and not self.allow_override:
            raise PluginConfigError(
                f"Plugin '{plugin_name}' is already registered. "
                "Set allow_override=True to replace it.",
                details={"plugin_name": plugin_name},
            )

        if (
            self.max_plugins is not None
            and plugin_name not in self._records
            and len(self._records) >= self.max_plugins
        ):
            raise PluginConfigError(
                f"Cannot register '{plugin_name}': "
                f"registry is full (max_plugins={self.max_plugins}).",
                details={"plugin_name": plugin_name, "max_plugins": self.max_plugins},
            )

        if metadata is None:
            # Try to read class-level metadata attributes
            metadata = PluginMetadata(
                plugin_name=plugin_name,
                plugin_version=getattr(plugin_class, "plugin_version", "0.0.0"),
                description=getattr(plugin_class, "plugin_description", ""),
                author=getattr(plugin_class, "author", ""),
                tags=tuple(getattr(plugin_class, "plugin_tags", ())),
                capabilities=tuple(getattr(plugin_class, "plugin_capabilities", ())),
                plugin_dependencies=tuple(
                    getattr(plugin_class, "plugin_dependencies", ())
                ),
            )

        self._load_counter += 1
        record = PluginRecord(
            plugin_name=plugin_name,
            plugin_class=plugin_class,
            metadata=metadata,
            state=PluginState.LOADED,
            config=dict(config or {}),
            load_order=self._load_counter,
        )
        self._records[plugin_name] = record
        return record

    def unregister(self, plugin_name: str) -> PluginRecord:
        """Remove and return the record for *plugin_name*.

        Raises
        ------
        PluginNotFoundError
        """
        record = self._get_or_raise(plugin_name)
        del self._records[plugin_name]
        return record

    # ── Retrieval ────────────────────────────────────────────────

    def get(self, plugin_name: str) -> PluginRecord:
        """Return the record for *plugin_name*.

        Raises
        ------
        PluginNotFoundError
        """
        return self._get_or_raise(plugin_name)

    def get_instance(self, plugin_name: str) -> Any:
        """Return the live instance stored on the record.

        Raises
        ------
        PluginNotFoundError
            If the plugin is not registered.
        PluginConfigError
            If the plugin has been registered but not yet instantiated.
        """
        record = self._get_or_raise(plugin_name)
        if record.instance is None:
            raise PluginConfigError(
                f"Plugin '{plugin_name}' has not been instantiated yet.",
                details={"plugin_name": plugin_name, "state": record.state.value},
            )
        return record.instance

    def has(self, plugin_name: str) -> bool:
        """Return ``True`` if *plugin_name* is registered."""
        return plugin_name in self._records

    def get_all(self) -> dict[str, PluginRecord]:
        """Return a shallow copy of all records keyed by plugin name."""
        return dict(self._records)

    def list_plugins(
        self,
        *,
        state: PluginState | None = None,
        tag: str | None = None,
        capability: str | None = None,
    ) -> list[PluginRecord]:
        """Return records matching the given filters.

        All provided filters are applied with logical AND.
        """
        records = list(self._records.values())

        if state is not None:
            records = [r for r in records if r.state == state]

        if tag is not None:
            records = [r for r in records if tag in r.metadata.tags]

        if capability is not None:
            records = [r for r in records if capability in r.metadata.capabilities]

        return sorted(records, key=lambda r: r.load_order)

    # ── Dependency resolution ─────────────────────────────────────

    def resolve_dependencies(self) -> list[str]:
        """Return plugin names in dependency-safe initialization order.

        Uses **Kahn's algorithm** (BFS topological sort).

        Raises
        ------
        PluginDependencyError
            If a dependency is missing from the registry, or if a circular
            dependency is detected.
        """
        # Validate all declared dependencies are present
        for name, record in self._records.items():
            for dep in record.metadata.plugin_dependencies:
                if dep not in self._records:
                    raise PluginDependencyError(
                        f"Plugin '{name}' requires '{dep}', "
                        "which is not registered.",
                        details={"plugin": name, "missing_dependency": dep},
                    )

        # Build in-degree map and adjacency list
        # Edge: dep → plugin  (dep must come before plugin)
        in_degree: dict[str, int] = {name: 0 for name in self._records}
        dependents: dict[str, list[str]] = {name: [] for name in self._records}

        for name, record in self._records.items():
            for dep in record.metadata.plugin_dependencies:
                dependents[dep].append(name)
                in_degree[name] += 1

        # Kahn's BFS
        queue: deque[str] = deque(
            sorted(name for name, deg in in_degree.items() if deg == 0)
        )
        order: list[str] = []

        while queue:
            node = queue.popleft()
            order.append(node)
            for dependent in sorted(dependents[node]):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        if len(order) != len(self._records):
            # Find which plugins are in the cycle
            cycled = sorted(
                name for name, deg in in_degree.items() if deg > 0
            )
            raise PluginDependencyError(
                f"Circular dependency detected among plugins: "
                f"{', '.join(cycled)}",
                details={"cycled_plugins": cycled},
            )

        return order

    # ── Dunder helpers ────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self._records)

    def __contains__(self, plugin_name: object) -> bool:
        return plugin_name in self._records

    def __iter__(self) -> Iterator[str]:
        return iter(self._records)

    def __repr__(self) -> str:
        return (
            f"<PluginRegistry plugins={len(self._records)} "
            f"allow_override={self.allow_override}>"
        )

    # ── Private ───────────────────────────────────────────────────

    def _get_or_raise(self, plugin_name: str) -> PluginRecord:
        record = self._records.get(plugin_name)
        if record is None:
            raise PluginNotFoundError(
                f"Plugin '{plugin_name}' is not registered.",
                details={"plugin_name": plugin_name},
            )
        return record
