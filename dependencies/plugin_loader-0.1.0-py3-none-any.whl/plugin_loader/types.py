"""Core types, enums, and dataclasses for the plugin_loader package."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ── Enums ────────────────────────────────────────────────────────


class PluginState(str, Enum):
    """Lifecycle state of a plugin."""

    DISCOVERED = "discovered"
    LOADED = "loaded"
    VALIDATED = "validated"
    INITIALIZED = "initialized"
    ACTIVE = "active"
    DISABLED = "disabled"
    ERROR = "error"
    UNLOADED = "unloaded"


class ErrorPolicy(str, Enum):
    """How the manager handles plugin errors."""

    PROPAGATE = "propagate"
    SUPPRESS = "suppress"
    DISABLE_PLUGIN = "disable"


class DiscoveryMethod(str, Enum):
    """How a plugin was discovered."""

    DIRECTORY = "directory"
    ENTRY_POINT = "entry_point"
    PACKAGE = "package"
    EXPLICIT = "explicit"


# ── Dataclasses ──────────────────────────────────────────────────


@dataclass(frozen=True)
class PluginMetadata:
    """Immutable metadata describing a discovered plugin."""

    plugin_name: str
    plugin_version: str = "0.0.0"
    description: str = ""
    author: str = ""
    tags: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()
    plugin_dependencies: tuple[str, ...] = ()
    source: str = ""
    discovery_method: DiscoveryMethod = DiscoveryMethod.EXPLICIT


@dataclass
class PluginRecord:
    """Mutable record in the registry for a loaded plugin."""

    plugin_name: str
    plugin_class: type
    metadata: PluginMetadata
    state: PluginState = PluginState.DISCOVERED
    instance: Any = None
    config: dict[str, Any] = field(default_factory=dict)
    error: Exception | None = None
    load_order: int = 0


@dataclass(frozen=True)
class PluginOperationResult:
    """Outcome of a plugin lifecycle operation."""

    plugin_name: str
    success: bool
    state: PluginState
    error: Exception | None = None
    elapsed_ms: float = 0.0


@dataclass
class DiscoveryResult:
    """Result of a discovery scan."""

    plugin_classes: list[tuple[str, type]] = field(default_factory=list)
    errors: list[tuple[str, Exception]] = field(default_factory=list)
    elapsed_ms: float = 0.0
