"""Factory for creating PluginManager instances."""

from __future__ import annotations

from typing import Any

from plugin_loader.config import PluginManagerConfig
from plugin_loader.discovery.base_strategy import AbstractDiscoveryStrategy

# Registry of named discovery strategies (extend via register_discovery_strategy)
_STRATEGY_REGISTRY: dict[str, type[AbstractDiscoveryStrategy]] = {}


def _populate_defaults() -> None:
    """Lazily populate the default strategy registry to avoid circular imports."""
    if _STRATEGY_REGISTRY:
        return
    from plugin_loader.discovery.directory_strategy import DirectoryStrategy
    from plugin_loader.discovery.entry_point_strategy import EntryPointStrategy
    from plugin_loader.discovery.package_strategy import PackageStrategy
    from plugin_loader.discovery.composite_strategy import CompositeStrategy

    _STRATEGY_REGISTRY.update({
        "directory": DirectoryStrategy,
        "entry_point": EntryPointStrategy,
        "package": PackageStrategy,
        "composite": CompositeStrategy,
    })


def create_plugin_manager(
    config: PluginManagerConfig | None = None,
    **kwargs: Any,
) -> "PluginManager":  # type: ignore[name-defined]  # noqa: F821
    """Create and return a :class:`PluginManager`.

    Parameters
    ----------
    config:
        Pre-built configuration object.  When omitted, one is created
        from *kwargs* passed to :class:`PluginManagerConfig`.
    **kwargs:
        Forwarded to :class:`PluginManagerConfig` when *config* is
        ``None``.  Ignored when *config* is provided.

    Returns
    -------
    PluginManager
    """
    from plugin_loader.manager import PluginManager

    if config is None and kwargs:
        config = PluginManagerConfig(**kwargs)

    return PluginManager(config)


def register_discovery_strategy(
    name: str,
    cls: type[AbstractDiscoveryStrategy],
) -> None:
    """Register a custom discovery strategy under *name*.

    After registration, the strategy can be referenced by name when
    building discovery pipelines programmatically.

    Parameters
    ----------
    name:
        Short identifier (e.g. ``"git"`` or ``"database"``).
    cls:
        A concrete subclass of :class:`AbstractDiscoveryStrategy`.
    """
    _populate_defaults()
    _STRATEGY_REGISTRY[name] = cls


def list_discovery_strategies() -> list[str]:
    """Return the names of all registered discovery strategies."""
    _populate_defaults()
    return sorted(_STRATEGY_REGISTRY)


def get_discovery_strategy(name: str) -> type[AbstractDiscoveryStrategy]:
    """Return the strategy class registered under *name*.

    Raises
    ------
    KeyError
        If no strategy is registered with that name.
    """
    _populate_defaults()
    if name not in _STRATEGY_REGISTRY:
        raise KeyError(
            f"Unknown discovery strategy '{name}'. "
            f"Available: {list_discovery_strategies()}"
        )
    return _STRATEGY_REGISTRY[name]
