"""Exception hierarchy for the plugin_loader package.

Attempts to use :class:`BaseAppException` from the ``error_handler``
package.  Falls back to a lightweight shim with the same public contract
when ``error_handler`` is not installed.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:  # pragma: no cover

    class BaseAppException(Exception):  # type: ignore[no-redef]
        """Lightweight fallback — mirrors BaseAppException's public contract."""

        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.message = message
            self.code = code
            self.status_code = status_code
            self.details = details
            self.previous = previous

            if previous is not None:
                self.__cause__ = previous

        def to_dict(self) -> dict[str, Any]:
            return {
                "success": False,
                "error": {
                    "code": self.code,
                    "message": self.message,
                    "details": self.details,
                    "status_code": self.status_code,
                },
            }


# ── Plugin Loader exceptions ────────────────────────────────────


class PluginLoaderError(BaseAppException):
    """Root exception for all plugin_loader errors."""

    def __init__(self, message: str = "A plugin loader error occurred", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_LOADER_ERROR")
        kwargs.setdefault("status_code", 500)
        super().__init__(message, **kwargs)


class PluginDiscoveryError(PluginLoaderError):
    """Discovery scan failed."""

    def __init__(self, message: str = "Plugin discovery failed", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_DISCOVERY_ERROR")
        super().__init__(message, **kwargs)


class PluginValidationError(PluginLoaderError):
    """Plugin class does not meet the required contract."""

    def __init__(self, message: str = "Plugin validation failed", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_VALIDATION_ERROR")
        kwargs.setdefault("status_code", 400)
        super().__init__(message, **kwargs)


class PluginLoadError(PluginLoaderError):
    """Module import failed."""

    def __init__(self, message: str = "Plugin module could not be loaded", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_LOAD_ERROR")
        super().__init__(message, **kwargs)


class PluginInitializationError(PluginLoaderError):
    """Plugin ``initialize()`` raised."""

    def __init__(self, message: str = "Plugin initialization failed", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_INIT_ERROR")
        super().__init__(message, **kwargs)


class PluginNotFoundError(PluginLoaderError):
    """Plugin name not found in the registry."""

    def __init__(self, message: str = "Plugin not found", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_NOT_FOUND")
        kwargs.setdefault("status_code", 404)
        super().__init__(message, **kwargs)


class PluginDependencyError(PluginLoaderError):
    """Missing or circular plugin dependency."""

    def __init__(self, message: str = "Plugin dependency error", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_DEPENDENCY_ERROR")
        kwargs.setdefault("status_code", 400)
        super().__init__(message, **kwargs)


class PluginSandboxError(PluginLoaderError):
    """Sandbox caught an unrecoverable error."""

    def __init__(self, message: str = "Plugin sandbox error", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_SANDBOX_ERROR")
        super().__init__(message, **kwargs)


class PluginConfigError(PluginLoaderError):
    """Invalid plugin configuration."""

    def __init__(self, message: str = "Invalid plugin configuration", **kwargs: Any) -> None:
        kwargs.setdefault("code", "PLUGIN_CONFIG_ERROR")
        kwargs.setdefault("status_code", 400)
        super().__init__(message, **kwargs)
