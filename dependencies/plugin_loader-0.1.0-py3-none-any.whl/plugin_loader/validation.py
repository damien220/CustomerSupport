"""PluginValidator — validates plugin classes against required contracts."""

from __future__ import annotations

import inspect
from typing import Any, Callable


class PluginValidator:
    """Validates plugin classes before they are registered.

    Checks are cumulative — all failures are collected and returned
    together rather than stopping at the first error.

    Parameters
    ----------
    required_base_class:
        When provided, the plugin class must be a subclass of this type.
    required_methods:
        Names of methods the plugin class (or its instances) must expose.
    required_attributes:
        Names of class-level attributes that must be present and
        non-``None``.
    custom_validators:
        Callables of the form ``(cls) -> bool``.  A return value of
        ``False`` (or any falsy value) is treated as a validation failure.
        Use ``details`` alongside each callable by passing a
        ``(callable, description)`` tuple instead of a bare callable.
    """

    def __init__(
        self,
        required_base_class: type | None = None,
        required_methods: list[str] | None = None,
        required_attributes: list[str] | None = None,
        custom_validators: list[Callable[[type], bool] | tuple[Callable[[type], bool], str]] | None = None,
    ) -> None:
        self.required_base_class = required_base_class
        self.required_methods: list[str] = required_methods or []
        self.required_attributes: list[str] = required_attributes or []
        self._custom_validators: list[tuple[Callable[[type], bool], str]] = []

        for entry in custom_validators or []:
            if isinstance(entry, tuple):
                fn, desc = entry
                self._custom_validators.append((fn, desc))
            else:
                self._custom_validators.append((entry, entry.__name__ or "custom_validator"))

    # ── Public API ────────────────────────────────────────────────

    def validate(self, plugin_cls: type) -> tuple[bool, list[str]]:
        """Validate a plugin *class* (not an instance).

        Returns
        -------
        (is_valid, errors):
            ``is_valid`` is ``True`` when ``errors`` is empty.
        """
        errors: list[str] = []

        errors.extend(self._check_base_class(plugin_cls))
        errors.extend(self._check_methods(plugin_cls))
        errors.extend(self._check_attributes(plugin_cls))
        errors.extend(self._run_custom_validators(plugin_cls))

        return (len(errors) == 0), errors

    def validate_instance(self, instance: Any) -> tuple[bool, list[str]]:
        """Validate a *live plugin instance* (protocol conformance).

        Runs the same checks as :meth:`validate` but against
        ``type(instance)``, then also verifies that the instance exposes
        all required methods/attributes at runtime (handles ``__slots__``
        and dynamic attributes).

        Returns
        -------
        (is_valid, errors):
            ``is_valid`` is ``True`` when ``errors`` is empty.
        """
        errors: list[str] = []
        plugin_cls = type(instance)

        errors.extend(self._check_base_class(plugin_cls))
        errors.extend(self._check_instance_methods(instance))
        errors.extend(self._check_instance_attributes(instance))
        errors.extend(self._run_custom_validators(plugin_cls))

        return (len(errors) == 0), errors

    # ── Internal checks ──────────────────────────────────────────

    def _check_base_class(self, plugin_cls: type) -> list[str]:
        if self.required_base_class is None:
            return []
        if not issubclass(plugin_cls, self.required_base_class):
            return [
                f"{plugin_cls.__name__} must be a subclass of "
                f"{self.required_base_class.__name__}."
            ]
        return []

    def _check_methods(self, plugin_cls: type) -> list[str]:
        errors: list[str] = []
        for method_name in self.required_methods:
            attr = getattr(plugin_cls, method_name, None)
            if attr is None:
                errors.append(
                    f"{plugin_cls.__name__} is missing required method '{method_name}'."
                )
            elif not callable(attr):
                errors.append(
                    f"{plugin_cls.__name__}.{method_name} exists but is not callable."
                )
        return errors

    def _check_attributes(self, plugin_cls: type) -> list[str]:
        errors: list[str] = []
        for attr_name in self.required_attributes:
            val = getattr(plugin_cls, attr_name, None)
            if val is None:
                errors.append(
                    f"{plugin_cls.__name__} is missing required class attribute "
                    f"'{attr_name}'."
                )
        return errors

    def _check_instance_methods(self, instance: Any) -> list[str]:
        errors: list[str] = []
        for method_name in self.required_methods:
            attr = getattr(instance, method_name, None)
            if attr is None:
                errors.append(
                    f"Plugin instance is missing required method '{method_name}'."
                )
            elif not callable(attr):
                errors.append(
                    f"Plugin instance attribute '{method_name}' is not callable."
                )
        return errors

    def _check_instance_attributes(self, instance: Any) -> list[str]:
        errors: list[str] = []
        for attr_name in self.required_attributes:
            if not hasattr(instance, attr_name) or getattr(instance, attr_name) is None:
                errors.append(
                    f"Plugin instance is missing required attribute '{attr_name}'."
                )
        return errors

    def _run_custom_validators(self, plugin_cls: type) -> list[str]:
        errors: list[str] = []
        for fn, description in self._custom_validators:
            try:
                result = fn(plugin_cls)
            except Exception as exc:  # noqa: BLE001
                errors.append(
                    f"Custom validator '{description}' raised an exception: {exc}"
                )
            else:
                if not result:
                    errors.append(
                        f"Custom validator '{description}' failed for "
                        f"{plugin_cls.__name__}."
                    )
        return errors

    # ── Helpers ──────────────────────────────────────────────────

    @staticmethod
    def has_method(cls: type, method_name: str) -> bool:
        """Return ``True`` if *cls* exposes a callable named *method_name*."""
        attr = getattr(cls, method_name, None)
        return attr is not None and callable(attr)

    @staticmethod
    def is_async_method(cls: type, method_name: str) -> bool:
        """Return ``True`` if the method is a coroutine function."""
        attr = getattr(cls, method_name, None)
        return attr is not None and inspect.iscoroutinefunction(attr)
