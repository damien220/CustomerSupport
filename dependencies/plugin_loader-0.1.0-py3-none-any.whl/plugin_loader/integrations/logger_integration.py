"""Logger_Package integration for plugin_loader.

When ``logger_pkg`` is installed, plugin lifecycle operations are logged
with structured context (plugin_name, state, operation).  Falls back
transparently to Python's stdlib ``logging`` when the package is absent.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Generator

if TYPE_CHECKING:
    from plugin_loader.types import PluginOperationResult, PluginRecord

# ── Availability check ────────────────────────────────────────────

_LOGGER_PKG_AVAILABLE: bool | None = None


def has_logger_pkg() -> bool:
    """Return ``True`` if ``logger_pkg`` is installed."""
    global _LOGGER_PKG_AVAILABLE
    if _LOGGER_PKG_AVAILABLE is None:
        try:
            import logger_pkg  # noqa: F401
            _LOGGER_PKG_AVAILABLE = True
        except ImportError:
            _LOGGER_PKG_AVAILABLE = False
    return _LOGGER_PKG_AVAILABLE


# ── Logger factory ────────────────────────────────────────────────


def get_plugin_logger(name: str = "plugin_loader") -> logging.Logger:
    """Return a structured logger for *name*.

    Uses ``logger_pkg.get_logger()`` when available, otherwise falls back
    to ``logging.getLogger()``.
    """
    if has_logger_pkg():
        from logger_pkg import get_logger
        return get_logger(name)
    return logging.getLogger(name)


# ── Context binding ───────────────────────────────────────────────


@contextmanager
def plugin_logging_context(**fields: Any) -> Generator[None, None, None]:
    """Context manager that binds *fields* to the structured log context.

    When ``logger_pkg`` is installed, uses ``logger_pkg.bound_context``
    for async-safe context propagation.  When absent, yields immediately
    (no-op — stdlib logging carries no structured context).

    Usage::

        with plugin_logging_context(plugin_name="alpha", operation="initialize"):
            logger.debug("Initializing plugin")
    """
    if has_logger_pkg():
        from logger_pkg import bound_context
        with bound_context(**fields):
            yield
    else:
        yield


# ── Lifecycle log helpers ─────────────────────────────────────────


def log_plugin_loaded(
    logger: logging.Logger,
    record: "PluginRecord",
) -> None:
    """Log that a plugin class was registered."""
    with plugin_logging_context(
        plugin_name=record.plugin_name,
        plugin_version=record.metadata.plugin_version,
        operation="register",
    ):
        logger.debug(
            "Plugin registered: '%s' v%s",
            record.plugin_name,
            record.metadata.plugin_version,
        )


def log_plugin_initialized(
    logger: logging.Logger,
    result: "PluginOperationResult",
) -> None:
    """Log the outcome of a plugin initialization."""
    with plugin_logging_context(
        plugin_name=result.plugin_name,
        operation="initialize",
        success=result.success,
        elapsed_ms=round(result.elapsed_ms, 2),
    ):
        if result.success:
            logger.debug(
                "Plugin initialized: '%s' in %.1fms",
                result.plugin_name,
                result.elapsed_ms,
            )
        else:
            logger.warning(
                "Plugin initialization failed: '%s' — %s",
                result.plugin_name,
                result.error,
            )


def log_plugin_started(
    logger: logging.Logger,
    result: "PluginOperationResult",
) -> None:
    """Log the outcome of a plugin start."""
    with plugin_logging_context(
        plugin_name=result.plugin_name,
        operation="start",
        success=result.success,
    ):
        if result.success:
            logger.debug("Plugin started: '%s'", result.plugin_name)
        else:
            logger.warning(
                "Plugin start failed: '%s' — %s",
                result.plugin_name,
                result.error,
            )


def log_plugin_stopped(
    logger: logging.Logger,
    result: "PluginOperationResult",
) -> None:
    """Log that a plugin was stopped."""
    with plugin_logging_context(
        plugin_name=result.plugin_name,
        operation="stop",
    ):
        logger.debug("Plugin stopped: '%s'", result.plugin_name)


def log_plugin_error(
    logger: logging.Logger,
    plugin_name: str,
    error: Exception,
    operation: str = "unknown",
) -> None:
    """Log a plugin error with structured context."""
    with plugin_logging_context(
        plugin_name=plugin_name,
        operation=operation,
        error_type=type(error).__name__,
    ):
        logger.error(
            "Plugin error in '%s' during '%s': %s",
            plugin_name,
            operation,
            error,
            exc_info=True,
        )
