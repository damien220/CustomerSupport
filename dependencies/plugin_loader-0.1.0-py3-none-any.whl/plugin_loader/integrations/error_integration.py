"""Error-Exception-Handler integration for plugin_loader.

Converts :class:`PluginOperationResult` failures and raw exceptions into
the standard structured error format produced by ``error_handler``.
Falls back to a plain dict representation when the package is absent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from plugin_loader.types import PluginOperationResult

# ── Availability check ────────────────────────────────────────────

_ERROR_HANDLER_AVAILABLE: bool | None = None


def has_error_handler() -> bool:
    """Return ``True`` if ``error_handler`` is installed."""
    global _ERROR_HANDLER_AVAILABLE
    if _ERROR_HANDLER_AVAILABLE is None:
        try:
            import error_handler  # noqa: F401
            _ERROR_HANDLER_AVAILABLE = True
        except ImportError:
            _ERROR_HANDLER_AVAILABLE = False
    return _ERROR_HANDLER_AVAILABLE


# ── Structured error conversion ────────────────────────────────────


def plugin_error_to_structured(result: "PluginOperationResult") -> dict[str, Any]:
    """Convert a failed :class:`PluginOperationResult` to a structured error dict.

    When ``error_handler`` is available and the stored exception is a
    ``BaseAppException``, delegates to ``ErrorFormatter.format()`` for
    a fully normalised response.

    Otherwise builds the same ``{success, error: {code, message, …}}``
    structure manually so callers never need to branch.

    Returns
    -------
    dict
        ``{"success": False, "error": {"code": …, "message": …, …}}``
    """
    exc = result.error

    if exc is None:
        return {
            "success": result.success,
            "error": None,
        }

    if has_error_handler():
        from error_handler import ErrorFormatter
        try:
            return ErrorFormatter.format(exc)
        except Exception:  # noqa: BLE001
            pass  # Fall through to manual construction

    # Manual fallback — same shape as error_handler's output
    return {
        "success": False,
        "error": {
            "code": getattr(exc, "code", type(exc).__name__.upper()),
            "message": str(exc),
            "details": getattr(exc, "details", None),
            "status_code": getattr(exc, "status_code", 500),
        },
    }


def handle_plugin_exception(exc: Exception) -> dict[str, Any]:
    """Normalise *any* exception into a structured response dict.

    When ``error_handler`` is installed, uses ``ErrorHandler.handle()``
    which returns ``{"status_code": int, "body": ErrorResponse}``.
    Falls back to a plain envelope otherwise.

    Returns
    -------
    dict
        ``{"status_code": int, "body": {"success": False, "error": {…}}}``
    """
    if has_error_handler():
        from error_handler import ErrorHandler
        try:
            return ErrorHandler.handle(exc)
        except Exception:  # noqa: BLE001
            pass

    return {
        "status_code": getattr(exc, "status_code", 500),
        "body": {
            "success": False,
            "error": {
                "code": getattr(exc, "code", type(exc).__name__.upper()),
                "message": str(exc),
                "details": getattr(exc, "details", None),
                "status_code": getattr(exc, "status_code", 500),
            },
        },
    }


def classify_plugin_error(exc: Exception) -> str:
    """Return the error code string for *exc*.

    Reads ``exc.code`` when present (i.e. all ``PluginLoaderError``
    subclasses), otherwise returns the upper-cased exception class name.
    """
    return getattr(exc, "code", type(exc).__name__.upper())
