"""Event_Dispatcher integration for plugin_loader.

When ``event_dispatcher`` is installed, :class:`PluginEventBridge` emits
``plugin.*`` lifecycle events so any part of the application can react to
plugin state changes without coupling to the loader directly.

Falls back to a no-op implementation when the package is absent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from plugin_loader.types import PluginOperationResult, PluginRecord

# ── Availability check ────────────────────────────────────────────

_EVENT_DISPATCHER_AVAILABLE: bool | None = None


def has_event_dispatcher() -> bool:
    """Return ``True`` if ``event_dispatcher`` is installed."""
    global _EVENT_DISPATCHER_AVAILABLE
    if _EVENT_DISPATCHER_AVAILABLE is None:
        try:
            import event_dispatcher  # noqa: F401
            _EVENT_DISPATCHER_AVAILABLE = True
        except ImportError:
            _EVENT_DISPATCHER_AVAILABLE = False
    return _EVENT_DISPATCHER_AVAILABLE


# ── Event bridge ──────────────────────────────────────────────────


class PluginEventBridge:
    """Emits structured ``plugin.*`` events for plugin lifecycle changes.

    When ``event_dispatcher`` is available, events are published through a
    ``LocalDispatcher`` (or a custom dispatcher passed to ``__init__``).
    When the package is absent every method is a no-op, so the bridge can
    always be instantiated and used unconditionally.

    Event kinds emitted
    -------------------
    ``plugin.registered``   — after a plugin class is registered
    ``plugin.initialized``  — after *successful* plugin initialisation
    ``plugin.started``      — after *successful* plugin start
    ``plugin.stopped``      — after a plugin is stopped
    ``plugin.error``        — whenever a lifecycle operation fails
    ``plugin.discovered``   — after a discovery run completes
    """

    def __init__(self, dispatcher: Any = None) -> None:
        """Create the bridge.

        Parameters
        ----------
        dispatcher:
            An existing ``AbstractEventDispatcher`` instance.  When *None*
            (the default) a fresh ``LocalDispatcher`` is created if
            ``event_dispatcher`` is installed.
        """
        self._dispatcher: Any = None

        if dispatcher is not None:
            self._dispatcher = dispatcher
        elif has_event_dispatcher():
            from event_dispatcher import create_dispatcher
            self._dispatcher = create_dispatcher("local")

    # ── Internal helper ───────────────────────────────────────────

    def _emit(self, event_kind: str, payload: dict[str, Any]) -> None:
        """Build and emit *event_kind* with *payload* (sync)."""
        if self._dispatcher is None:
            return
        from event_dispatcher import EventBuilder
        event = (
            EventBuilder(event_kind)
            .with_source("plugin_loader")
            .with_payload(payload)
            .build()
        )
        self._dispatcher.emit(event)

    async def _emit_async(self, event_kind: str, payload: dict[str, Any]) -> None:
        """Build and emit *event_kind* with *payload* (async)."""
        if self._dispatcher is None:
            return
        from event_dispatcher import EventBuilder
        event = (
            EventBuilder(event_kind)
            .with_source("plugin_loader")
            .with_payload(payload)
            .build()
        )
        await self._dispatcher.emit_async(event)

    # ── Lifecycle emitters (sync) ─────────────────────────────────

    def emit_registered(self, record: "PluginRecord") -> None:
        """Emit ``plugin.registered`` after a plugin class is registered."""
        self._emit("plugin.registered", {
            "plugin_name": record.plugin_name,
            "plugin_version": record.metadata.plugin_version,
            "plugin_tags": list(record.metadata.tags),
        })

    def emit_initialized(self, result: "PluginOperationResult") -> None:
        """Emit ``plugin.initialized`` after an initialisation attempt."""
        self._emit("plugin.initialized", {
            "plugin_name": result.plugin_name,
            "success": result.success,
            "elapsed_ms": result.elapsed_ms,
            "error": str(result.error) if result.error else None,
        })

    def emit_started(self, result: "PluginOperationResult") -> None:
        """Emit ``plugin.started`` after a start attempt."""
        self._emit("plugin.started", {
            "plugin_name": result.plugin_name,
            "success": result.success,
            "error": str(result.error) if result.error else None,
        })

    def emit_stopped(self, result: "PluginOperationResult") -> None:
        """Emit ``plugin.stopped`` after a plugin is stopped."""
        self._emit("plugin.stopped", {
            "plugin_name": result.plugin_name,
            "success": result.success,
        })

    def emit_error(
        self,
        plugin_name: str,
        operation: str,
        error: Exception,
    ) -> None:
        """Emit ``plugin.error`` when a lifecycle operation fails."""
        self._emit("plugin.error", {
            "plugin_name": plugin_name,
            "operation": operation,
            "error_type": type(error).__name__,
            "error_message": str(error),
        })

    def emit_discovered(self, plugin_names: list[str], source: str = "") -> None:
        """Emit ``plugin.discovered`` after a discovery run completes."""
        self._emit("plugin.discovered", {
            "plugin_names": plugin_names,
            "count": len(plugin_names),
            "source": source,
        })

    # ── Lifecycle emitters (async) ────────────────────────────────

    async def emit_registered_async(self, record: "PluginRecord") -> None:
        """Async variant of :meth:`emit_registered`."""
        await self._emit_async("plugin.registered", {
            "plugin_name": record.plugin_name,
            "plugin_version": record.metadata.plugin_version,
            "plugin_tags": list(record.metadata.tags),
        })

    async def emit_initialized_async(self, result: "PluginOperationResult") -> None:
        """Async variant of :meth:`emit_initialized`."""
        await self._emit_async("plugin.initialized", {
            "plugin_name": result.plugin_name,
            "success": result.success,
            "elapsed_ms": result.elapsed_ms,
            "error": str(result.error) if result.error else None,
        })

    async def emit_started_async(self, result: "PluginOperationResult") -> None:
        """Async variant of :meth:`emit_started`."""
        await self._emit_async("plugin.started", {
            "plugin_name": result.plugin_name,
            "success": result.success,
            "error": str(result.error) if result.error else None,
        })

    async def emit_stopped_async(self, result: "PluginOperationResult") -> None:
        """Async variant of :meth:`emit_stopped`."""
        await self._emit_async("plugin.stopped", {
            "plugin_name": result.plugin_name,
            "success": result.success,
        })

    async def emit_error_async(
        self,
        plugin_name: str,
        operation: str,
        error: Exception,
    ) -> None:
        """Async variant of :meth:`emit_error`."""
        await self._emit_async("plugin.error", {
            "plugin_name": plugin_name,
            "operation": operation,
            "error_type": type(error).__name__,
            "error_message": str(error),
        })

    async def emit_discovered_async(
        self,
        plugin_names: list[str],
        source: str = "",
    ) -> None:
        """Async variant of :meth:`emit_discovered`."""
        await self._emit_async("plugin.discovered", {
            "plugin_names": plugin_names,
            "count": len(plugin_names),
            "source": source,
        })
