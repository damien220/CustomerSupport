"""Sibling package integrations for plugin_loader.

Each sub-module follows the same pattern:

* A ``has_<pkg>()`` availability guard that is cheap to call repeatedly
  (result is cached after the first import attempt).
* Public helpers / classes that delegate to the sibling package when
  present, and fall back to a plain-Python implementation otherwise.

Availability checks
-------------------
.. code-block:: python

    from plugin_loader.integrations import (
        has_error_handler,
        has_logger_pkg,
        has_event_dispatcher,
        has_cache_manager,
        has_config_manager,
    )

Quick import
------------
.. code-block:: python

    from plugin_loader.integrations import (
        # Error integration
        plugin_error_to_structured,
        handle_plugin_exception,
        classify_plugin_error,
        # Logger integration
        get_plugin_logger,
        plugin_logging_context,
        log_plugin_loaded,
        log_plugin_initialized,
        log_plugin_started,
        log_plugin_stopped,
        log_plugin_error,
        # Event integration
        PluginEventBridge,
        # Cache integration
        CachedDiscovery,
        # Config integration
        load_plugin_manager_config,
    )
"""

from plugin_loader.integrations.error_integration import (
    classify_plugin_error,
    handle_plugin_exception,
    has_error_handler,
    plugin_error_to_structured,
)
from plugin_loader.integrations.logger_integration import (
    get_plugin_logger,
    has_logger_pkg,
    log_plugin_error,
    log_plugin_initialized,
    log_plugin_loaded,
    log_plugin_started,
    log_plugin_stopped,
    plugin_logging_context,
)
from plugin_loader.integrations.event_integration import (
    has_event_dispatcher,
    PluginEventBridge,
)
from plugin_loader.integrations.cache_integration import (
    has_cache_manager,
    CachedDiscovery,
)
from plugin_loader.integrations.config_integration import (
    has_config_manager,
    load_plugin_manager_config,
)

__all__ = [
    # Availability guards
    "has_error_handler",
    "has_logger_pkg",
    "has_event_dispatcher",
    "has_cache_manager",
    "has_config_manager",
    # Error integration
    "plugin_error_to_structured",
    "handle_plugin_exception",
    "classify_plugin_error",
    # Logger integration
    "get_plugin_logger",
    "plugin_logging_context",
    "log_plugin_loaded",
    "log_plugin_initialized",
    "log_plugin_started",
    "log_plugin_stopped",
    "log_plugin_error",
    # Event integration
    "PluginEventBridge",
    # Cache integration
    "CachedDiscovery",
    # Config integration
    "load_plugin_manager_config",
]
