"""Config_Manager integration for plugin_loader.

When ``config_manager`` is installed, :func:`load_plugin_manager_config`
reads a JSON or YAML configuration file through ``ConfigManager`` and
maps the resulting dict to a :class:`~plugin_loader.config.PluginManagerConfig`.

Falls back gracefully when the package is absent — callers receive a plain
default :class:`PluginManagerConfig` instance.
"""

from __future__ import annotations

from typing import Any

from plugin_loader.config import PluginManagerConfig

# ── Availability check ────────────────────────────────────────────

_CONFIG_MANAGER_AVAILABLE: bool | None = None


def has_config_manager() -> bool:
    """Return ``True`` if ``config_manager`` is installed."""
    global _CONFIG_MANAGER_AVAILABLE
    if _CONFIG_MANAGER_AVAILABLE is None:
        try:
            from config_manager.config_manager import ConfigManager  # noqa: F401
            _CONFIG_MANAGER_AVAILABLE = True
        except ImportError:
            _CONFIG_MANAGER_AVAILABLE = False
    return _CONFIG_MANAGER_AVAILABLE


# ── Key mapping ───────────────────────────────────────────────────

# Maps config-file keys → PluginManagerConfig field names.
# Only keys that differ from the dataclass field name need an entry here.
_KEY_ALIASES: dict[str, str] = {
    "dirs": "plugin_dirs",
    "plugins_dir": "plugin_dirs",
    "entry_point": "entry_point_group",
    "packages": "scan_packages",
    "base_class": "required_base_class",
    "required_methods": "required_methods",
    "strict": "strict_validation",
    "auto_init": "auto_initialize",
    "timeout": "initialization_timeout_seconds",
    "override": "allow_override",
    "max": "max_plugins",
    "cache": "cache_discovery",
    "cache_ttl": "cache_ttl_seconds",
    "log": "log_level",
    "log_lifecycle": "log_lifecycle",
}


def _normalize_keys(raw: dict[str, Any]) -> dict[str, Any]:
    """Apply ``_KEY_ALIASES`` and return a new dict with canonical keys."""
    out: dict[str, Any] = {}
    for k, v in raw.items():
        out[_KEY_ALIASES.get(k, k)] = v
    return out


# ── Public loader ─────────────────────────────────────────────────


def load_plugin_manager_config(config_file: str) -> PluginManagerConfig:
    """Load a :class:`PluginManagerConfig` from *config_file*.

    Reads the file via ``ConfigManager`` (supports JSON and YAML) and
    maps the resulting dict to :class:`PluginManagerConfig` keyword
    arguments.

    Unknown or unrecognised keys are silently ignored so that config files
    shared across multiple packages do not cause errors.

    When ``config_manager`` is not installed, a default
    :class:`PluginManagerConfig` is returned and *config_file* is not
    read.

    Parameters
    ----------
    config_file:
        Path to a ``.json`` or ``.yaml`` configuration file.

    Returns
    -------
    PluginManagerConfig
        Populated from the file, or a default instance on import failure.

    Raises
    ------
    FileNotFoundError
        Re-raised when *config_file* does not exist and
        ``config_manager`` is available.
    """
    if not has_config_manager():
        return PluginManagerConfig()

    from config_manager.config_manager import ConfigManager

    cm = ConfigManager(config_file)
    raw: dict[str, Any] = dict(cm)
    normalised = _normalize_keys(raw)

    # Only pass kwargs that PluginManagerConfig actually accepts.
    import dataclasses
    valid_fields = {f.name for f in dataclasses.fields(PluginManagerConfig)}
    filtered = {k: v for k, v in normalised.items() if k in valid_fields}

    return PluginManagerConfig(**filtered)
