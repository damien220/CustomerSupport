"""Cache_Manager integration for plugin_loader.

When ``cache_manager`` is installed, :class:`CachedDiscovery` wraps any
callable that returns a :class:`DiscoveryResult` and transparently caches
its output using ``PickleCache``.

Falls back to a pass-through (no caching) when the package is absent.
"""

from __future__ import annotations

import datetime
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from plugin_loader.types import DiscoveryResult

# ── Availability check ────────────────────────────────────────────

_CACHE_MANAGER_AVAILABLE: bool | None = None


def has_cache_manager() -> bool:
    """Return ``True`` if ``cache_manager`` is installed."""
    global _CACHE_MANAGER_AVAILABLE
    if _CACHE_MANAGER_AVAILABLE is None:
        try:
            from cache_manager.pickle import PickleCache  # noqa: F401
            _CACHE_MANAGER_AVAILABLE = True
        except ImportError:
            _CACHE_MANAGER_AVAILABLE = False
    return _CACHE_MANAGER_AVAILABLE


# ── Cached discovery wrapper ──────────────────────────────────────


class CachedDiscovery:
    """Cache-aware wrapper around a discovery callable.

    Wraps any zero-argument callable (or one whose arguments have been
    pre-bound via ``functools.partial``) that returns a
    :class:`~plugin_loader.types.DiscoveryResult`.

    When ``cache_manager`` is available the result is pickled to disk and
    reused on subsequent calls until *ttl_seconds* elapses.  When the
    package is absent every call is forwarded directly to *discover_fn*.

    Parameters
    ----------
    discover_fn:
        Callable that performs discovery and returns a ``DiscoveryResult``.
    cache_key:
        Unique string key under which results are stored.  Defaults to
        ``"plugin_loader.discovery"``.
    ttl_seconds:
        How long (in seconds) a cached result is considered fresh.
        Defaults to 300 (5 minutes).
    storage_path:
        Directory used by ``PickleCache``.  Defaults to ``".cache"``.
    """

    def __init__(
        self,
        discover_fn: Callable[[], "DiscoveryResult"],
        *,
        cache_key: str = "plugin_loader.discovery",
        ttl_seconds: int = 300,
        storage_path: str = ".cache",
    ) -> None:
        self._discover_fn = discover_fn
        self._cache_key = cache_key
        self._ttl = datetime.timedelta(seconds=ttl_seconds)
        self._storage_path = storage_path
        self._cache: Any = None  # PickleCache instance, lazily created

    # ── Internal helpers ──────────────────────────────────────────

    def _get_cache(self) -> Any:
        if self._cache is None and has_cache_manager():
            from cache_manager.pickle import PickleCache
            self._cache = PickleCache(self._storage_path)
        return self._cache

    # ── Public interface ──────────────────────────────────────────

    def discover(self) -> "DiscoveryResult":
        """Return a (possibly cached) :class:`DiscoveryResult`.

        On a cache hit the stored result is returned directly.
        On a cache miss the wrapped *discover_fn* is called, its result
        is persisted, and then returned.

        When ``cache_manager`` is not installed the wrapped function is
        called every time (no-op cache).
        """
        cache = self._get_cache()
        if cache is not None:
            cached = cache._get_data(self._cache_key)
            if cached is not None:
                return cached

        result = self._discover_fn()

        if cache is not None:
            cache._save_data(result, self._cache_key, self._ttl)

        return result

    def invalidate(self) -> None:
        """Remove the cached discovery result, forcing a fresh run next time.

        This is a best-effort operation — if the cache entry does not exist
        or ``cache_manager`` is not installed, the call is silently ignored.
        """
        cache = self._get_cache()
        if cache is None:
            return
        try:
            cache._save_data(None, self._cache_key, datetime.timedelta(seconds=0))
        except Exception:  # noqa: BLE001
            pass
