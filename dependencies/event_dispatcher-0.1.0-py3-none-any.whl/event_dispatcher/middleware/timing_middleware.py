"""DispatchTimingMiddleware — measure and report dispatch latency.

Logs a warning when total dispatch time exceeds a configurable threshold,
helping identify slow handler chains.
"""

from __future__ import annotations

import logging
import time
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome
from .base_middleware import BaseEventMiddleware

try:
    from logger_pkg import get_logger as _get_logger

    _HAS_LOGGER_PKG = True
except ImportError:  # pragma: no cover
    _HAS_LOGGER_PKG = False
    _get_logger = None  # type: ignore[assignment]


def _logger(name: str) -> logging.Logger:
    if _HAS_LOGGER_PKG:
        return _get_logger(name)  # type: ignore[misc]
    return logging.getLogger(name)


class DispatchTimingMiddleware(BaseEventMiddleware):
    """Tracks dispatch latency and warns on slow events.

    Parameters
    ----------
    slow_threshold_ms
        Emit a ``WARNING`` log if total dispatch exceeds this value.
        Set to ``0`` to disable the warning.
    logger_name
        Logger name for timing reports.
    """

    def __init__(
        self,
        *,
        slow_threshold_ms: float = 100.0,
        logger_name: str = "event_dispatcher.timing",
    ) -> None:
        self._threshold = slow_threshold_ms
        self._log = _logger(logger_name)
        self._start_times: dict[str, float] = {}

    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        self._start_times[event.event_id] = time.perf_counter()
        return event

    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        start = self._start_times.pop(event.event_id, None)
        if start is None:
            return

        elapsed_ms = (time.perf_counter() - start) * 1000

        if self._threshold > 0 and elapsed_ms > self._threshold:
            self._log.warning(
                "Slow event dispatch: %s took %.2fms (threshold: %.0fms, handlers: %d)",
                event.event_kind,
                elapsed_ms,
                self._threshold,
                outcome.handlers_invoked,
                extra={
                    "event_id": event.event_id,
                    "event_kind": event.event_kind,
                    "elapsed_ms": elapsed_ms,
                    "threshold_ms": self._threshold,
                    "handlers_invoked": outcome.handlers_invoked,
                },
            )
