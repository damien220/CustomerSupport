"""CorrelationMiddleware — auto-generate and propagate correlation IDs.

If a ``DispatchEvent`` lacks a ``correlation_id``, this middleware assigns
one (UUID-4).  This ensures that related events emitted within the same
workflow can be traced together.
"""

from __future__ import annotations

import uuid
from dataclasses import replace
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome
from .base_middleware import BaseEventMiddleware


class CorrelationMiddleware(BaseEventMiddleware):
    """Ensures every event has a ``correlation_id``.

    Parameters
    ----------
    id_factory
        Callable returning a new correlation ID string.  Defaults to
        ``uuid.uuid4()`` (hex form without dashes).
    """

    def __init__(
        self,
        *,
        id_factory: Optional[callable] = None,
    ) -> None:
        self._id_factory = id_factory or (lambda: uuid.uuid4().hex)

    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        if event.correlation_id is None:
            return replace(event, correlation_id=self._id_factory())
        return event

    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        pass  # no post-processing needed
