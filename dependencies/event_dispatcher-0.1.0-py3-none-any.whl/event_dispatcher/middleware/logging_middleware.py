"""EventLoggingMiddleware — structured logging for event dispatch.

Uses ``logger_pkg`` when available, falls back to stdlib ``logging``.
"""

from __future__ import annotations

import logging
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome
from .base_middleware import BaseEventMiddleware

try:
    from logger_pkg import get_logger as _get_logger

    _HAS_LOGGER_PKG = True
except ImportError:  # pragma: no cover
    _HAS_LOGGER_PKG = False
    _get_logger = None  # type: ignore[assignment]


def _logger(name: str) -> logging.Logger:
    if _HAS_LOGGER_PKG:
        return _get_logger(name)  # type: ignore[misc]
    return logging.getLogger(name)


class EventLoggingMiddleware(BaseEventMiddleware):
    """Logs each emitted event and its dispatch outcome.

    Parameters
    ----------
    logger_name
        Name passed to the underlying logger factory.
    log_payloads
        If ``False`` (default), event payloads are omitted from log messages
        to avoid leaking sensitive data.
    log_level
        Numeric log level for emission messages (default ``DEBUG``).
    error_level
        Numeric log level for handler-error messages (default ``WARNING``).
    """

    def __init__(
        self,
        *,
        logger_name: str = "event_dispatcher",
        log_payloads: bool = False,
        log_level: int = logging.DEBUG,
        error_level: int = logging.WARNING,
    ) -> None:
        self._log = _logger(logger_name)
        self._log_payloads = log_payloads
        self._log_level = log_level
        self._error_level = error_level

    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        extra: dict = {
            "event_id": event.event_id,
            "event_kind": event.event_kind,
            "source": event.source,
            "event_priority": event.event_priority.name,
        }
        if event.correlation_id:
            extra["correlation_id"] = event.correlation_id
        if self._log_payloads:
            extra["payload"] = event.payload

        self._log.log(
            self._log_level,
            "Emitting event %s [%s]",
            event.event_kind,
            event.event_id,
            extra=extra,
        )
        return event

    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        if outcome.handler_errors:
            for failure in outcome.handler_errors:
                self._log.log(
                    self._error_level,
                    "Handler %r failed for event %s: %s",
                    failure.handler_name,
                    event.event_kind,
                    failure.exception,
                    extra={
                        "event_id": event.event_id,
                        "event_kind": event.event_kind,
                        "handler_name": failure.handler_name,
                        "elapsed_ms": failure.elapsed_ms,
                    },
                )

        self._log.log(
            self._log_level,
            "Event %s dispatched to %d handler(s) in %.2fms",
            event.event_kind,
            outcome.handlers_invoked,
            outcome.elapsed_ms,
            extra={
                "event_id": event.event_id,
                "event_kind": event.event_kind,
                "handlers_invoked": outcome.handlers_invoked,
                "errors": len(outcome.handler_errors),
                "elapsed_ms": outcome.elapsed_ms,
            },
        )
