"""HandlerRetryMiddleware — retry failed handlers with exponential backoff.

This middleware wraps handler invocations with retry logic.  It operates in
the ``after_emit`` phase: when handler errors are detected, it records them
and injects retry metadata into the event so the dispatcher can re-invoke
failed handlers.

Because the middleware layer only sees the aggregate outcome (not individual
handler calls), this middleware works by **re-emitting** the event through
the dispatcher for handlers that failed, up to ``max_attempts`` times.

For Phase 2, the retry middleware tracks retry state and exposes it on the
outcome.  Full re-dispatch integration is deferred to when the dispatcher
supports per-handler retry (Phase 4 dead-letter).  In the meantime, it
provides retry metadata on ``EmitOutcome`` and logs retry-eligible failures.
"""

from __future__ import annotations

import logging
import random
import time
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome
from .base_middleware import BaseEventMiddleware

try:
    from logger_pkg import get_logger as _get_logger

    _HAS_LOGGER_PKG = True
except ImportError:  # pragma: no cover
    _HAS_LOGGER_PKG = False
    _get_logger = None  # type: ignore[assignment]


def _logger(name: str) -> logging.Logger:
    if _HAS_LOGGER_PKG:
        return _get_logger(name)  # type: ignore[misc]
    return logging.getLogger(name)


def _compute_delay(
    attempt: int,
    backoff_base: float,
    backoff_max: float,
    jitter: bool,
) -> float:
    """Exponential backoff with optional full jitter."""
    delay = min(backoff_base * (2 ** attempt), backoff_max)
    if jitter:
        delay = random.uniform(0, delay)
    return delay


class HandlerRetryMiddleware(BaseEventMiddleware):
    """Tracks handler failures eligible for retry and logs retry metadata.

    Parameters
    ----------
    max_attempts
        Maximum retry attempts per handler failure (not counting the
        original invocation).
    backoff_base
        Base delay in seconds for exponential backoff.
    backoff_max
        Maximum delay cap in seconds.
    jitter
        If ``True``, apply full jitter to the delay to spread retries.
    logger_name
        Logger name for retry reports.
    """

    def __init__(
        self,
        *,
        max_attempts: int = 3,
        backoff_base: float = 1.0,
        backoff_max: float = 30.0,
        jitter: bool = True,
        logger_name: str = "event_dispatcher.retry",
    ) -> None:
        self._max_attempts = max_attempts
        self._backoff_base = backoff_base
        self._backoff_max = backoff_max
        self._jitter = jitter
        self._log = _logger(logger_name)
        # Track per-event retry counts: event_id -> {handler_name -> attempt}
        self._retry_counts: dict[str, dict[str, int]] = {}

    @property
    def max_attempts(self) -> int:
        return self._max_attempts

    @property
    def retry_counts(self) -> dict[str, dict[str, int]]:
        """Expose retry state for testing and introspection."""
        return dict(self._retry_counts)

    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        return event

    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        if not outcome.handler_errors:
            # Clean up state for this event if no errors
            self._retry_counts.pop(event.event_id, None)
            return

        event_retries = self._retry_counts.setdefault(event.event_id, {})

        for failure in outcome.handler_errors:
            current_attempt = event_retries.get(failure.handler_name, 0)

            if current_attempt < self._max_attempts:
                event_retries[failure.handler_name] = current_attempt + 1
                delay = _compute_delay(
                    current_attempt,
                    self._backoff_base,
                    self._backoff_max,
                    self._jitter,
                )
                self._log.info(
                    "Handler %r eligible for retry (attempt %d/%d, delay %.2fs) "
                    "for event %s: %s",
                    failure.handler_name,
                    current_attempt + 1,
                    self._max_attempts,
                    delay,
                    event.event_kind,
                    failure.exception,
                    extra={
                        "event_id": event.event_id,
                        "event_kind": event.event_kind,
                        "handler_name": failure.handler_name,
                        "retry_attempt": current_attempt + 1,
                        "max_attempts": self._max_attempts,
                        "delay_seconds": delay,
                    },
                )
            else:
                self._log.warning(
                    "Handler %r exhausted retries (%d/%d) for event %s: %s",
                    failure.handler_name,
                    current_attempt,
                    self._max_attempts,
                    event.event_kind,
                    failure.exception,
                    extra={
                        "event_id": event.event_id,
                        "event_kind": event.event_kind,
                        "handler_name": failure.handler_name,
                        "max_attempts": self._max_attempts,
                    },
                )

    def clear_state(self) -> None:
        """Reset all tracked retry state."""
        self._retry_counts.clear()
