"""BaseEventMiddleware — abstract base for the middleware pipeline.

Middleware intercepts events **before** handler dispatch and **after** all
handlers have run, enabling cross-cutting concerns such as logging,
correlation, timing, retry, and filtering without modifying handlers.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome


class BaseEventMiddleware(ABC):
    """Intercepts events in the dispatch pipeline.

    Concrete subclasses override ``before_emit`` and/or ``after_emit``.
    """

    @abstractmethod
    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        """Called before handler dispatch.

        Parameters
        ----------
        event
            The event about to be dispatched.

        Returns
        -------
        DispatchEvent | None
            Return the (possibly modified) event to continue dispatch, or
            ``None`` to suppress the event entirely (skip all handlers).
        """

    @abstractmethod
    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        """Called after all handlers have run.

        Parameters
        ----------
        event
            The event that was dispatched (post-``before_emit`` version).
        outcome
            The outcome of handler dispatch.
        """
