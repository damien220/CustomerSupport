"""EventGateMiddleware — rate limiting and deduplication for events.

Suppresses events that exceed a rate limit or duplicate a recently seen
event (based on idempotency key or event_id).
"""

from __future__ import annotations

import threading
import time
from typing import Optional

from ..event import DispatchEvent
from ..types import EmitOutcome
from .base_middleware import BaseEventMiddleware


class EventGateMiddleware(BaseEventMiddleware):
    """Blocks duplicate or rate-limited events from reaching handlers.

    Parameters
    ----------
    dedup_enabled
        If ``True``, suppress events whose ``event_id`` has been seen
        within the ``dedup_ttl_seconds`` window.
    dedup_ttl_seconds
        Time-to-live for the dedup cache.  After this period, an event
        with the same id is considered new.
    rate_limit_enabled
        If ``True``, enforce a per-event-kind rate limit.
    rate_limit_per_second
        Maximum events **per event kind** per second.  Events exceeding
        this rate are suppressed.
    """

    def __init__(
        self,
        *,
        dedup_enabled: bool = True,
        dedup_ttl_seconds: float = 60.0,
        rate_limit_enabled: bool = False,
        rate_limit_per_second: float = 100.0,
    ) -> None:
        self._dedup_enabled = dedup_enabled
        self._dedup_ttl = dedup_ttl_seconds
        self._rate_limit_enabled = rate_limit_enabled
        self._rate_limit = rate_limit_per_second

        # Dedup state: event_id -> timestamp
        self._seen: dict[str, float] = {}
        # Rate-limit state: event_kind -> list of timestamps
        self._rate_windows: dict[str, list[float]] = {}
        self._lock = threading.Lock()

        self.suppressed_dedup: int = 0
        self.suppressed_rate: int = 0

    def before_emit(self, event: DispatchEvent) -> Optional[DispatchEvent]:
        now = time.monotonic()

        with self._lock:
            # Deduplication check
            if self._dedup_enabled:
                self._evict_stale(now)
                if event.event_id in self._seen:
                    self.suppressed_dedup += 1
                    return None
                self._seen[event.event_id] = now

            # Rate-limit check
            if self._rate_limit_enabled:
                kind = event.event_kind
                window = self._rate_windows.setdefault(kind, [])
                cutoff = now - 1.0  # 1-second sliding window
                # Remove timestamps older than the window
                self._rate_windows[kind] = [
                    ts for ts in window if ts > cutoff
                ]
                window = self._rate_windows[kind]

                if len(window) >= self._rate_limit:
                    self.suppressed_rate += 1
                    return None
                window.append(now)

        return event

    def after_emit(self, event: DispatchEvent, outcome: EmitOutcome) -> None:
        pass  # no post-processing needed

    def _evict_stale(self, now: float) -> None:
        """Remove entries older than the dedup TTL."""
        cutoff = now - self._dedup_ttl
        stale_keys = [k for k, ts in self._seen.items() if ts < cutoff]
        for k in stale_keys:
            del self._seen[k]

    def clear_state(self) -> None:
        """Reset all dedup and rate-limit state."""
        with self._lock:
            self._seen.clear()
            self._rate_windows.clear()
            self.suppressed_dedup = 0
            self.suppressed_rate = 0
