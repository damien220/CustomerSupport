"""DispatchEvent — immutable event model and ergonomic builder."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from .types import EventPriority


@dataclass(frozen=True)
class DispatchEvent:
    """Immutable event emitted by producers and consumed by handlers.

    Attributes
    ----------
    event_kind
        Dot-separated hierarchical name (e.g. ``"user.created"``).
        Supports wildcard matching on the subscriber side.
    source
        Identifier of the emitter (module name, service name, etc.).
    event_id
        Auto-generated UUID.
    timestamp
        UTC creation time.
    correlation_id
        Links related events across a workflow.
    payload
        Event-specific data.
    metadata
        Cross-cutting data (tracing context, auth info, etc.).
    event_priority
        Dispatch priority; higher = dispatched first in queued modes.
    """

    event_kind: str
    source: str = ""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc),
    )
    correlation_id: Optional[str] = None
    payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    event_priority: EventPriority = EventPriority.NORMAL


class EventBuilder:
    """Fluent builder for constructing :class:`DispatchEvent` instances.

    Usage::

        event = (
            EventBuilder("user.created")
            .with_source("auth_service")
            .with_payload({"username": "alice"})
            .with_priority(EventPriority.HIGH)
            .build()
        )
    """

    def __init__(self, event_kind: str) -> None:
        self._event_kind = event_kind
        self._source: str = ""
        self._event_id: Optional[str] = None
        self._timestamp: Optional[datetime] = None
        self._correlation_id: Optional[str] = None
        self._payload: dict[str, Any] = {}
        self._metadata: dict[str, Any] = {}
        self._event_priority: EventPriority = EventPriority.NORMAL

    def with_source(self, source: str) -> EventBuilder:
        self._source = source
        return self

    def with_event_id(self, event_id: str) -> EventBuilder:
        self._event_id = event_id
        return self

    def with_timestamp(self, timestamp: datetime) -> EventBuilder:
        self._timestamp = timestamp
        return self

    def with_correlation_id(self, correlation_id: str) -> EventBuilder:
        self._correlation_id = correlation_id
        return self

    def with_payload(self, payload: dict[str, Any]) -> EventBuilder:
        self._payload = payload
        return self

    def with_metadata(self, metadata: dict[str, Any]) -> EventBuilder:
        self._metadata = metadata
        return self

    def with_priority(self, event_priority: EventPriority) -> EventBuilder:
        self._event_priority = event_priority
        return self

    def build(self) -> DispatchEvent:
        """Construct and return the immutable event."""
        kwargs: dict[str, Any] = {
            "event_kind": self._event_kind,
            "source": self._source,
            "payload": self._payload,
            "metadata": self._metadata,
            "event_priority": self._event_priority,
        }
        if self._event_id is not None:
            kwargs["event_id"] = self._event_id
        if self._timestamp is not None:
            kwargs["timestamp"] = self._timestamp
        if self._correlation_id is not None:
            kwargs["correlation_id"] = self._correlation_id
        return DispatchEvent(**kwargs)
