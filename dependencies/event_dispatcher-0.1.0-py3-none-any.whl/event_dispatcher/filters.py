"""Event filter combinators for composable handler predicates.

Filters are plain callables ``(DispatchEvent) -> bool``.  The combinators
below let you compose them declaratively::

    from event_dispatcher import match_all, match_any, negate

    dispatcher.subscribe(
        "order.*",
        handle_urgent,
        event_filter=match_all(
            lambda e: e.event_priority >= EventPriority.HIGH,
            lambda e: e.payload.get("region") == "us-east",
        ),
    )
"""

from __future__ import annotations

from typing import Callable

from .event import DispatchEvent


def match_all(*predicates: Callable[[DispatchEvent], bool]) -> Callable[[DispatchEvent], bool]:
    """Return a filter that passes only when **every** predicate is ``True``."""

    def _combined(event: DispatchEvent) -> bool:
        return all(pred(event) for pred in predicates)

    return _combined


def match_any(*predicates: Callable[[DispatchEvent], bool]) -> Callable[[DispatchEvent], bool]:
    """Return a filter that passes when **at least one** predicate is ``True``."""

    def _combined(event: DispatchEvent) -> bool:
        return any(pred(event) for pred in predicates)

    return _combined


def negate(predicate: Callable[[DispatchEvent], bool]) -> Callable[[DispatchEvent], bool]:
    """Return a filter that inverts the given predicate."""

    def _inverted(event: DispatchEvent) -> bool:
        return not predicate(event)

    return _inverted
