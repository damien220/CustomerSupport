"""Event-dispatcher exception hierarchy.

Extends ``BaseAppException`` from the Error-Exception_Handler package when
available, otherwise falls back to plain ``Exception``.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:  # pragma: no cover

    class BaseAppException(Exception):  # type: ignore[no-redef]
        """Minimal stand-in when error_handler is not installed."""

        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.message = message
            self.code = code
            self.status_code = status_code
            self.details = details
            self.previous = previous
            if previous is not None:
                self.__cause__ = previous


class EventDispatcherError(BaseAppException):
    """Base for all event-dispatcher errors."""

    def __init__(
        self,
        message: str = "Event dispatcher error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="EVENT_DISPATCHER_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class EventEmitError(EventDispatcherError):
    """Emission failed (e.g. all handlers errored)."""

    def __init__(
        self,
        message: str = "Event emission failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "EVENT_EMIT_ERROR"


class HandlerRegistrationError(EventDispatcherError):
    """Invalid handler or event pattern during subscription."""

    def __init__(
        self,
        message: str = "Handler registration failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "HANDLER_REGISTRATION_ERROR"
        self.status_code = 400


class HandlerExecutionError(EventDispatcherError):
    """A specific handler raised an exception during dispatch."""

    def __init__(
        self,
        message: str = "Handler execution failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "HANDLER_EXECUTION_ERROR"


class EventStoreError(EventDispatcherError):
    """Event persistence failed."""

    def __init__(
        self,
        message: str = "Event store error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "EVENT_STORE_ERROR"


class EventBrokerError(EventDispatcherError):
    """Broker connection or transport failure."""

    def __init__(
        self,
        message: str = "Event broker error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "EVENT_BROKER_ERROR"
        self.status_code = 503


class EventSerializationError(EventDispatcherError):
    """Event cannot be serialized for broker transport."""

    def __init__(
        self,
        message: str = "Event serialization failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "EVENT_SERIALIZATION_ERROR"
