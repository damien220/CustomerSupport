"""BaseEventBroker — abstract interface for distributed event transport."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Optional

from ..event import DispatchEvent


class BaseEventBroker(ABC):
    """Abstract base class for event brokers.

    A broker transports events between processes or services.  Producers
    call :meth:`publish` and consumers register via :meth:`subscribe_broker`.
    """

    # ── Publish ───────────────────────────────────────────────────────

    @abstractmethod
    async def publish(self, channel: str, event: DispatchEvent) -> None:
        """Publish *event* on *channel*.

        Raises
        ------
        EventBrokerError
            If the publish fails.
        """

    # ── Subscribe ─────────────────────────────────────────────────────

    @abstractmethod
    async def subscribe_broker(
        self,
        channel: str,
        callback: Callable[[DispatchEvent], Any],
    ) -> None:
        """Register *callback* to receive events published on *channel*.

        Parameters
        ----------
        channel
            Channel name or pattern to listen on.
        callback
            Sync or async callable ``(DispatchEvent) -> None``.
        """

    @abstractmethod
    async def unsubscribe_broker(self, channel: str) -> None:
        """Stop listening on *channel*."""

    # ── Lifecycle ─────────────────────────────────────────────────────

    @abstractmethod
    async def connect(self) -> None:
        """Open the broker connection."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the broker connection and release resources."""

    @abstractmethod
    def is_connected(self) -> bool:
        """Return ``True`` if the broker is connected and ready."""

    # ── Context manager ───────────────────────────────────────────────

    async def __aenter__(self) -> BaseEventBroker:
        await self.connect()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.disconnect()
