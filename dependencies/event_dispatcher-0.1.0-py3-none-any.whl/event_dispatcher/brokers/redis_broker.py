"""RedisEventBroker — Redis Pub/Sub broker via DB_Package."""

from __future__ import annotations

import asyncio
import json
import threading
from typing import Any, Callable

from ..event import DispatchEvent
from ..event_serialization import event_from_json, event_to_json
from ..exceptions import EventBrokerError
from .base_broker import BaseEventBroker

try:
    from db_accessor import get_database as _get_database
except ImportError:  # pragma: no cover
    _get_database = None  # type: ignore[assignment]


class RedisEventBroker(BaseEventBroker):
    """Distributed event broker using Redis Pub/Sub.

    Requires the ``db_accessor`` package with Redis support installed.

    Parameters
    ----------
    host
        Redis server hostname.
    port
        Redis server port.
    db_number
        Redis database number.
    channel_prefix
        Prefix prepended to all channel names (namespace isolation).
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db_number: int = 0,
        channel_prefix: str = "evt:",
    ) -> None:
        if _get_database is None:
            raise EventBrokerError(
                "db_accessor package is not installed. "
                "Install with: pip install db-accessor"
            )

        self._host = host
        self._port = port
        self._db_number = db_number
        self._channel_prefix = channel_prefix
        self._db = _get_database("redis")
        self._connected = False
        self._subscriptions: dict[str, list[Callable[[DispatchEvent], Any]]] = {}
        self._pubsub: Any = None
        self._listener_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    # ── helpers ────────────────────────────────────────────────────────

    def _prefixed(self, channel: str) -> str:
        return f"{self._channel_prefix}{channel}"

    # ── Publish ───────────────────────────────────────────────────────

    async def publish(self, channel: str, event: DispatchEvent) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")
        try:
            message = event_to_json(event)
            self._db.execute_custom_query({
                "command": "publish",
                "args": [self._prefixed(channel), message],
            })
        except Exception as exc:
            raise EventBrokerError(
                f"Failed to publish to channel {channel!r}: {exc}",
                previous=exc,
            ) from exc

    # ── Subscribe ─────────────────────────────────────────────────────

    async def subscribe_broker(
        self,
        channel: str,
        callback: Callable[[DispatchEvent], Any],
    ) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")

        prefixed = self._prefixed(channel)
        if channel not in self._subscriptions:
            self._subscriptions[channel] = []
            # Subscribe on the Redis pubsub object
            if self._pubsub is not None:
                self._pubsub.subscribe(prefixed)

        self._subscriptions[channel].append(callback)

    async def unsubscribe_broker(self, channel: str) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")

        prefixed = self._prefixed(channel)
        if self._pubsub is not None:
            self._pubsub.unsubscribe(prefixed)
        self._subscriptions.pop(channel, None)

    # ── Listener ──────────────────────────────────────────────────────

    def _listener_loop(self) -> None:
        """Background thread that reads messages from Redis Pub/Sub."""
        if self._pubsub is None:
            return
        while not self._stop_event.is_set():
            try:
                message = self._pubsub.get_message(
                    ignore_subscribe_messages=True,
                    timeout=0.1,
                )
                if message is None:
                    continue
                if message["type"] != "message":
                    continue

                raw_channel = message["channel"]
                if isinstance(raw_channel, bytes):
                    raw_channel = raw_channel.decode("utf-8")

                # Strip prefix to find logical channel name
                if raw_channel.startswith(self._channel_prefix):
                    logical_channel = raw_channel[len(self._channel_prefix):]
                else:
                    logical_channel = raw_channel

                raw_data = message["data"]
                if isinstance(raw_data, bytes):
                    raw_data = raw_data.decode("utf-8")

                event = event_from_json(raw_data)

                # Deliver to subscribers
                callbacks = self._subscriptions.get(logical_channel, [])
                # Also deliver to wildcard "*" subscribers
                callbacks = callbacks + self._subscriptions.get("*", [])
                for cb in callbacks:
                    try:
                        result = cb(event)
                        if asyncio.iscoroutine(result):
                            # Schedule coroutine on the event loop if available
                            try:
                                loop = asyncio.get_event_loop()
                                if loop.is_running():
                                    asyncio.run_coroutine_threadsafe(result, loop)
                                else:
                                    asyncio.run(result)
                            except RuntimeError:
                                pass
                    except Exception:
                        pass  # Broker should not crash on callback failure
            except Exception:
                if self._stop_event.is_set():
                    break

    # ── Lifecycle ─────────────────────────────────────────────────────

    async def connect(self) -> None:
        if self._connected:
            return
        try:
            self._db.connect({
                "host": self._host,
                "port": self._port,
                "db": self._db_number,
            })
            # Create pubsub from the underlying Redis client
            self._pubsub = self._db.client.pubsub()
            self._connected = True

            # Subscribe to any channels registered before connect
            for channel in self._subscriptions:
                self._pubsub.subscribe(self._prefixed(channel))

            # Start listener thread
            self._stop_event.clear()
            self._listener_thread = threading.Thread(
                target=self._listener_loop,
                daemon=True,
                name="redis-event-broker-listener",
            )
            self._listener_thread.start()

        except Exception as exc:
            raise EventBrokerError(
                f"Failed to connect to Redis at {self._host}:{self._port}: {exc}",
                previous=exc,
            ) from exc

    async def disconnect(self) -> None:
        if not self._connected:
            return
        self._stop_event.set()
        if self._listener_thread is not None:
            self._listener_thread.join(timeout=2.0)
            self._listener_thread = None
        if self._pubsub is not None:
            try:
                self._pubsub.unsubscribe()
                self._pubsub.close()
            except Exception:
                pass
            self._pubsub = None
        try:
            self._db.disconnect()
        except Exception:
            pass
        self._connected = False
        self._subscriptions.clear()

    def is_connected(self) -> bool:
        return self._connected
