"""InProcessBroker — asyncio-based in-process event broker."""

from __future__ import annotations

import asyncio
from typing import Any, Callable

from ..event import DispatchEvent
from ..exceptions import EventBrokerError
from .base_broker import BaseEventBroker


class InProcessBroker(BaseEventBroker):
    """In-process event broker backed by :class:`asyncio.Queue`.

    Useful for testing, single-process fan-out, and as a reference
    implementation of the broker interface.

    Parameters
    ----------
    max_queue_size
        Maximum number of events buffered per channel.  ``0`` means
        unlimited.
    """

    def __init__(self, max_queue_size: int = 0) -> None:
        self._max_queue_size = max_queue_size
        self._channels: dict[str, list[Callable[[DispatchEvent], Any]]] = {}
        self._connected = False
        self._running_tasks: list[asyncio.Task[None]] = []

    # ── Publish ───────────────────────────────────────────────────────

    async def publish(self, channel: str, event: DispatchEvent) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")
        callbacks = self._channels.get(channel, [])
        # Also deliver to wildcard "*" subscribers
        callbacks = callbacks + self._channels.get("*", [])
        for cb in callbacks:
            try:
                result = cb(event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                # Broker should not crash on callback failure — log and continue
                pass

    # ── Subscribe ─────────────────────────────────────────────────────

    async def subscribe_broker(
        self,
        channel: str,
        callback: Callable[[DispatchEvent], Any],
    ) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")
        if channel not in self._channels:
            self._channels[channel] = []
        self._channels[channel].append(callback)

    async def unsubscribe_broker(self, channel: str) -> None:
        if not self._connected:
            raise EventBrokerError("Broker is not connected")
        self._channels.pop(channel, None)

    # ── Lifecycle ─────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False
        self._channels.clear()
        # Cancel running tasks
        for task in self._running_tasks:
            if not task.done():
                task.cancel()
        self._running_tasks.clear()

    def is_connected(self) -> bool:
        return self._connected

    # ── Introspection ─────────────────────────────────────────────────

    @property
    def channel_count(self) -> int:
        """Return the number of active channels."""
        return len(self._channels)

    def subscriber_count(self, channel: str) -> int:
        """Return the number of subscribers on *channel*."""
        return len(self._channels.get(channel, []))
