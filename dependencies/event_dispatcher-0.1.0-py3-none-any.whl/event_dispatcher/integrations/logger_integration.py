"""Logger integration — structured logging context for event dispatch.

Bridges the Event Dispatcher with the Logger_Package (``logger_pkg``)
to provide automatic context binding around event emission and handling.
Falls back to stdlib ``logging`` when ``logger_pkg`` is not installed.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Generator, Optional

from ..event import DispatchEvent

# ── Optional logger_pkg import ────────────────────────────────────────

try:
    from logger_pkg import get_logger as _get_logger
    from logger_pkg import bind_context as _bind_context
    from logger_pkg import clear_context as _clear_context

    _HAS_LOGGER_PKG = True
except ImportError:  # pragma: no cover
    _HAS_LOGGER_PKG = False
    _get_logger = None  # type: ignore[assignment]
    _bind_context = None  # type: ignore[assignment]
    _clear_context = None  # type: ignore[assignment]


def has_logger_pkg() -> bool:
    """Return ``True`` if the ``logger_pkg`` package is available."""
    return _HAS_LOGGER_PKG


def get_event_logger(name: str = "event_dispatcher") -> logging.Logger:
    """Return a logger instance, preferring ``logger_pkg`` when available.

    Parameters
    ----------
    name
        Logger name.  Defaults to ``"event_dispatcher"``.
    """
    if _HAS_LOGGER_PKG and _get_logger is not None:
        return _get_logger(name)
    return logging.getLogger(name)


@contextmanager
def event_logging_context(
    event: DispatchEvent,
    *,
    extra: Optional[dict[str, Any]] = None,
) -> Generator[logging.Logger, None, None]:
    """Context manager that binds event fields to the logging context.

    When ``logger_pkg`` is installed, this calls :func:`bind_context` so
    that all log statements inside the block carry event metadata
    (``event_id``, ``event_kind``, ``correlation_id``, ``source``).

    When ``logger_pkg`` is not installed, the extra fields are passed via
    the logger's ``extra`` dict instead.

    Usage::

        with event_logging_context(event) as log:
            log.info("Processing event")
            # log output includes event_id, event_kind, etc.
    """
    logger = get_event_logger()

    context: dict[str, Any] = {
        "event_id": event.event_id,
        "event_kind": event.event_kind,
        "correlation_id": event.correlation_id or "",
        "source": event.source,
    }
    if extra:
        context.update(extra)

    if _HAS_LOGGER_PKG and _bind_context is not None:
        _bind_context(**context)
        try:
            yield logger
        finally:
            # Clear the context keys we added
            if _clear_context is not None:
                _clear_context()
    else:
        # Stdlib fallback — return an adapter that injects extra
        yield logging.LoggerAdapter(logger, context)  # type: ignore[misc]


def log_event_emitted(
    event: DispatchEvent,
    *,
    logger: Optional[logging.Logger] = None,
    level: int = logging.DEBUG,
) -> None:
    """Log that an event was emitted."""
    log = logger or get_event_logger()
    log.log(
        level,
        "Event emitted: %s (id=%s, source=%s)",
        event.event_kind,
        event.event_id,
        event.source,
    )


def log_event_handled(
    event: DispatchEvent,
    handler_name: str,
    *,
    logger: Optional[logging.Logger] = None,
    level: int = logging.DEBUG,
) -> None:
    """Log that a handler processed an event."""
    log = logger or get_event_logger()
    log.log(
        level,
        "Event handled: %s by %s (id=%s)",
        event.event_kind,
        handler_name,
        event.event_id,
    )


def log_handler_error(
    event: DispatchEvent,
    handler_name: str,
    exception: Exception,
    *,
    logger: Optional[logging.Logger] = None,
    level: int = logging.ERROR,
) -> None:
    """Log a handler failure."""
    log = logger or get_event_logger()
    log.log(
        level,
        "Handler %s failed for event %s (id=%s): %s",
        handler_name,
        event.event_kind,
        event.event_id,
        exception,
        exc_info=True,
    )
