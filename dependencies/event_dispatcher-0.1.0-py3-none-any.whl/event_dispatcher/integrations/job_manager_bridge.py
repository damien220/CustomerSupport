"""Job Manager bridge — connect Job_Manager events to the event bus.

Provides two adapters:

* :class:`JobEventForwarder` — a :class:`JobListener` that re-publishes
  ``JobEvent`` instances as :class:`DispatchEvent` on a dispatcher.
* :func:`bind_event_trigger` — subscribes to an event pattern and fires
  a Job_Manager ``EventTrigger`` whenever a matching event arrives.

Falls back gracefully when ``job_manager`` is not installed.
"""

from __future__ import annotations

from typing import Any, Callable, Optional, Set

from ..event import DispatchEvent
from ..types import EventPriority

# ── Optional job_manager import ───────────────────────────────────────

try:
    from job_manager import JobEvent as _JobEvent
    from job_manager import JobListener as _JobListener
    from job_manager import EventTrigger as _EventTrigger
    from job_manager import EventType as _EventType

    _HAS_JOB_MANAGER = True
except ImportError:  # pragma: no cover
    _HAS_JOB_MANAGER = False
    _JobEvent = None  # type: ignore[assignment,misc]
    _JobListener = None  # type: ignore[assignment,misc]
    _EventTrigger = None  # type: ignore[assignment,misc]
    _EventType = None  # type: ignore[assignment,misc]


def has_job_manager() -> bool:
    """Return ``True`` if the ``job_manager`` package is available."""
    return _HAS_JOB_MANAGER


# ── JobEvent → DispatchEvent conversion ───────────────────────────────


def job_event_to_dispatch_event(
    job_event: Any,
    *,
    source: str = "job_manager",
) -> DispatchEvent:
    """Convert a Job_Manager ``JobEvent`` to a :class:`DispatchEvent`.

    The ``event_kind`` is derived as ``"job.<event_type_value>"``.

    Parameters
    ----------
    job_event
        A ``job_manager.JobEvent`` instance.
    source
        Source identifier for the resulting DispatchEvent.
    """
    event_type_value = str(job_event.event_type.value)

    payload: dict[str, Any] = {
        "job_id": job_event.job_id,
        "job_name": getattr(job_event, "job_name", ""),
        "attempt": getattr(job_event, "attempt", 0),
    }
    error_msg = getattr(job_event, "error_message", None)
    if error_msg:
        payload["error_message"] = error_msg

    metadata: dict[str, Any] = dict(getattr(job_event, "metadata", {}))

    return DispatchEvent(
        event_kind=f"job.{event_type_value}",
        source=source,
        payload=payload,
        metadata=metadata,
        event_priority=_job_event_priority(event_type_value),
    )


def _job_event_priority(event_type_value: str) -> EventPriority:
    """Map job event types to dispatch priorities."""
    high_priority = {"job_failed", "job_timeout", "job_cancelled"}
    if event_type_value in high_priority:
        return EventPriority.HIGH
    return EventPriority.NORMAL


# ── JobEventForwarder (JobListener → Dispatcher) ─────────────────────

if _HAS_JOB_MANAGER and _JobListener is not None:

    class JobEventForwarder(_JobListener):
        """A :class:`JobListener` that republishes job events on a dispatcher.

        Parameters
        ----------
        dispatcher
            The event dispatcher to publish converted events on.
        event_types
            Optional set of ``EventType`` values to forward.  ``None``
            forwards all events.
        source
            Source identifier for the resulting DispatchEvents.
        """

        def __init__(
            self,
            dispatcher: Any,
            event_types: Optional[Set[Any]] = None,
            source: str = "job_manager",
        ) -> None:
            self._dispatcher = dispatcher
            self._event_types = event_types
            self._source = source

        def on_event(self, event: Any) -> None:
            dispatch_event = job_event_to_dispatch_event(
                event, source=self._source,
            )
            self._dispatcher.emit(dispatch_event)

        def accepts(self, event_type: Any) -> bool:
            if self._event_types is None:
                return True
            return event_type in self._event_types

else:  # pragma: no cover

    class JobEventForwarder:  # type: ignore[no-redef]
        """Stub when ``job_manager`` is not installed."""

        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise RuntimeError(
                "job_manager package is not installed. "
                "Install with: pip install job-manager"
            )


# ── EventTrigger binding (Dispatcher → Job trigger) ──────────────────


def bind_event_trigger(
    dispatcher: Any,
    event_pattern: str,
    trigger: Any,
    *,
    payload_mapper: Optional[Callable[[DispatchEvent], dict[str, Any]]] = None,
) -> None:
    """Subscribe to *event_pattern* and fire *trigger* on each match.

    Parameters
    ----------
    dispatcher
        The event dispatcher to subscribe on.
    event_pattern
        Event pattern to listen for (supports wildcards).
    trigger
        A ``job_manager.EventTrigger`` instance.
    payload_mapper
        Optional function to extract a payload dict from the event.
        Defaults to forwarding the full event payload.
    """
    if not _HAS_JOB_MANAGER:
        raise RuntimeError(
            "job_manager package is not installed. "
            "Install with: pip install job-manager"
        )

    def _on_event(event: DispatchEvent) -> None:
        payload = event.payload
        if payload_mapper is not None:
            payload = payload_mapper(event)
        trigger.fire(payload=payload)

    dispatcher.subscribe(event_pattern, _on_event)
