"""Error integration — map handler exceptions to structured errors.

Bridges the Event Dispatcher with the Error-Exception_Handler package
(``error_handler``) to convert raw handler exceptions into structured
error responses with codes, status codes, and detail dicts.
Falls back to a minimal mapping when ``error_handler`` is not installed.
"""

from __future__ import annotations

from typing import Any, Optional

from ..event import DispatchEvent
from ..types import HandlerFailure

# ── Optional error_handler import ─────────────────────────────────────

try:
    from error_handler import BaseAppException as _BaseAppException
    from error_handler import ErrorHandler as _ErrorHandler

    _HAS_ERROR_HANDLER = True
except ImportError:  # pragma: no cover
    _HAS_ERROR_HANDLER = False
    _BaseAppException = None  # type: ignore[assignment,misc]
    _ErrorHandler = None  # type: ignore[assignment]


def has_error_handler() -> bool:
    """Return ``True`` if the ``error_handler`` package is available."""
    return _HAS_ERROR_HANDLER


def failure_to_structured_error(failure: HandlerFailure) -> dict[str, Any]:
    """Convert a :class:`HandlerFailure` to a structured error dict.

    When ``error_handler`` is installed **and** the exception is a
    :class:`BaseAppException` subclass, the structured fields (code,
    status_code, details) are extracted directly.

    Otherwise a generic mapping is produced.

    Returns
    -------
    dict
        ``{"success": False, "error": {"code": ..., "message": ...,
        "status_code": ..., "handler_name": ..., "details": ...}}``
    """
    exc = failure.exception

    # If error_handler is installed and the exception is a BaseAppException
    if _HAS_ERROR_HANDLER and _BaseAppException is not None and isinstance(exc, _BaseAppException):
        return {
            "success": False,
            "error": {
                "code": exc.code,
                "message": exc.message,
                "status_code": exc.status_code,
                "handler_name": failure.handler_name,
                "details": exc.details,
                "elapsed_ms": failure.elapsed_ms,
            },
        }

    # Generic mapping for plain exceptions
    return {
        "success": False,
        "error": {
            "code": _exception_code(exc),
            "message": str(exc),
            "status_code": 500,
            "handler_name": failure.handler_name,
            "details": None,
            "elapsed_ms": failure.elapsed_ms,
        },
    }


def handle_exception_structured(exception: Exception) -> dict[str, Any]:
    """Normalise any exception to a structured response dict.

    When ``error_handler`` is installed, delegates to
    :meth:`ErrorHandler.handle` for full normalisation.

    Otherwise produces a minimal structured dict.
    """
    if _HAS_ERROR_HANDLER and _ErrorHandler is not None:
        return _ErrorHandler.handle(exception)

    return {
        "status_code": 500,
        "body": {
            "success": False,
            "error": {
                "code": _exception_code(exception),
                "message": str(exception),
                "status_code": 500,
                "details": None,
            },
        },
    }


def classify_handler_errors(
    failures: list[HandlerFailure],
) -> dict[str, list[dict[str, Any]]]:
    """Group handler failures by error code.

    Returns
    -------
    dict
        ``{error_code: [structured_error, ...]}``
    """
    grouped: dict[str, list[dict[str, Any]]] = {}
    for failure in failures:
        structured = failure_to_structured_error(failure)
        code = structured["error"]["code"]
        grouped.setdefault(code, []).append(structured)
    return grouped


# ── Private helpers ───────────────────────────────────────────────────


def _exception_code(exc: Exception) -> str:
    """Derive a snake_case error code from an exception type name."""
    name = type(exc).__name__
    # Convert CamelCase to UPPER_SNAKE_CASE
    chars: list[str] = []
    for i, ch in enumerate(name):
        if ch.isupper() and i > 0:
            chars.append("_")
        chars.append(ch.upper())
    return "".join(chars)
