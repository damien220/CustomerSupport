"""Notification bridge — auto-send notifications on event patterns.

Subscribes to configurable event patterns on a dispatcher and
automatically sends notifications via the Notification_manager package
when matching events arrive.

Falls back gracefully when ``notification_manager`` is not installed.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ..event import DispatchEvent

# ── Optional notification_manager import ──────────────────────────────

try:
    from notification_manager import Notification as _Notification
    from notification_manager import Recipient as _Recipient
    from notification_manager import Priority as _Priority
    from notification_manager import NotificationManager as _NotificationManager

    _HAS_NOTIFICATION = True
except ImportError:  # pragma: no cover
    _HAS_NOTIFICATION = False
    _Notification = None  # type: ignore[assignment,misc]
    _Recipient = None  # type: ignore[assignment,misc]
    _Priority = None  # type: ignore[assignment,misc]
    _NotificationManager = None  # type: ignore[assignment,misc]


def has_notification_manager() -> bool:
    """Return ``True`` if the ``notification_manager`` package is available."""
    return _HAS_NOTIFICATION


# ── Notification rule ─────────────────────────────────────────────────


@dataclass
class NotificationRule:
    """Defines when and how to send a notification for matching events.

    Parameters
    ----------
    event_pattern
        Event pattern to listen for (supports wildcards).
    recipient_id
        Recipient identifier (user, team, channel).
    channels
        Notification channels to use (e.g. ``["slack", "email"]``).
    title_template
        Template for the notification title.  May include ``{event_kind}``,
        ``{source}``, ``{event_id}`` placeholders.
    body_template
        Template for the notification body.  Same placeholders plus
        ``{payload}`` for the serialised payload.
    channel_hint
        Preferred delivery channel (tried first).
    title_factory
        Optional callable ``(DispatchEvent) -> str`` that overrides
        *title_template* for dynamic title generation.
    body_factory
        Optional callable ``(DispatchEvent) -> str`` that overrides
        *body_template* for dynamic body generation.
    """

    event_pattern: str
    recipient_id: str
    channels: list[str] = field(default_factory=lambda: ["slack"])
    title_template: str = "Event: {event_kind}"
    body_template: str = "Event {event_kind} from {source} (id={event_id})"
    channel_hint: Optional[str] = None
    title_factory: Optional[Callable[[DispatchEvent], str]] = None
    body_factory: Optional[Callable[[DispatchEvent], str]] = None


# ── Bridge ────────────────────────────────────────────────────────────


class EventNotificationBridge:
    """Subscribes to a dispatcher and sends notifications on matching events.

    Parameters
    ----------
    dispatcher
        The event dispatcher to subscribe on.
    notification_manager
        A ``notification_manager.NotificationManager`` instance.
    rules
        List of :class:`NotificationRule` definitions.
    """

    def __init__(
        self,
        dispatcher: Any,
        notification_manager: Any,
        rules: Optional[list[NotificationRule]] = None,
    ) -> None:
        if not _HAS_NOTIFICATION:
            raise RuntimeError(
                "notification_manager package is not installed. "
                "Install with: pip install notification-manager"
            )

        self._dispatcher = dispatcher
        self._manager = notification_manager
        self._rules: list[NotificationRule] = []
        self._sent_count = 0

        if rules:
            for rule in rules:
                self.add_rule(rule)

    # ── Rule management ───────────────────────────────────────────────

    def add_rule(self, rule: NotificationRule) -> None:
        """Register a notification rule and subscribe to the dispatcher."""
        self._rules.append(rule)

        def _make_handler(r: NotificationRule) -> Callable[[DispatchEvent], None]:
            def _handler(event: DispatchEvent) -> None:
                self._send_notification(event, r)
            return _handler

        self._dispatcher.subscribe(rule.event_pattern, _make_handler(rule))

    @property
    def rules(self) -> list[NotificationRule]:
        """Return a copy of the registered rules."""
        return list(self._rules)

    @property
    def sent_count(self) -> int:
        """Number of notifications sent."""
        return self._sent_count

    # ── Internal ──────────────────────────────────────────────────────

    def _build_notification(
        self, event: DispatchEvent, rule: NotificationRule
    ) -> Any:
        """Build a Notification object from an event and rule."""
        fmt_kwargs = {
            "event_kind": event.event_kind,
            "source": event.source,
            "event_id": event.event_id,
            "payload": str(event.payload),
        }

        if rule.title_factory is not None:
            title = rule.title_factory(event)
        else:
            title = rule.title_template.format(**fmt_kwargs)

        if rule.body_factory is not None:
            body = rule.body_factory(event)
        else:
            body = rule.body_template.format(**fmt_kwargs)

        recipient = _Recipient(
            id=rule.recipient_id,
            channels=rule.channels,
        )

        kwargs: dict[str, Any] = {
            "title": title,
            "body": body,
            "recipient": recipient,
            "metadata": {
                "event_id": event.event_id,
                "event_kind": event.event_kind,
                "source": event.source,
            },
        }
        if rule.channel_hint is not None:
            kwargs["channel_hint"] = rule.channel_hint

        return _Notification(**kwargs)

    def _send_notification(
        self, event: DispatchEvent, rule: NotificationRule
    ) -> None:
        """Send a notification synchronously (best-effort)."""
        try:
            notification = self._build_notification(event, rule)
            # NotificationManager.send() is async, so we need to run it
            try:
                loop = asyncio.get_running_loop()
                asyncio.ensure_future(self._manager.send(notification))
            except RuntimeError:
                asyncio.run(self._manager.send(notification))
            self._sent_count += 1
        except Exception:
            pass  # Best-effort: don't crash the dispatch pipeline


# ── Convenience factory ───────────────────────────────────────────────


def create_notification_bridge(
    dispatcher: Any,
    notification_manager: Any,
    rules: list[NotificationRule],
) -> EventNotificationBridge:
    """One-liner factory for an :class:`EventNotificationBridge`.

    Parameters
    ----------
    dispatcher
        The event dispatcher to subscribe on.
    notification_manager
        A ``NotificationManager`` instance.
    rules
        List of notification rules.
    """
    return EventNotificationBridge(
        dispatcher=dispatcher,
        notification_manager=notification_manager,
        rules=rules,
    )
