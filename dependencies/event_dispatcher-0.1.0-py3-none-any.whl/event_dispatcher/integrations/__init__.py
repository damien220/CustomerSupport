"""Sibling package integrations — bridges and adapters."""

from .cache_integration import (
    create_cache_event_store,
    create_event_cache,
    has_cache_manager,
    is_cache_backend_available,
    list_cache_backends,
)
from .error_integration import (
    classify_handler_errors,
    failure_to_structured_error,
    handle_exception_structured,
    has_error_handler,
)
from .job_manager_bridge import (
    JobEventForwarder,
    bind_event_trigger,
    has_job_manager,
    job_event_to_dispatch_event,
)
from .logger_integration import (
    event_logging_context,
    get_event_logger,
    has_logger_pkg,
    log_event_emitted,
    log_event_handled,
    log_handler_error,
)
from .notification_bridge import (
    EventNotificationBridge,
    NotificationRule,
    create_notification_bridge,
    has_notification_manager,
)

__all__ = [
    # Logger
    "has_logger_pkg",
    "get_event_logger",
    "event_logging_context",
    "log_event_emitted",
    "log_event_handled",
    "log_handler_error",
    # Cache
    "has_cache_manager",
    "list_cache_backends",
    "is_cache_backend_available",
    "create_event_cache",
    "create_cache_event_store",
    # Error
    "has_error_handler",
    "failure_to_structured_error",
    "handle_exception_structured",
    "classify_handler_errors",
    # Job Manager
    "has_job_manager",
    "job_event_to_dispatch_event",
    "JobEventForwarder",
    "bind_event_trigger",
    # Notification
    "has_notification_manager",
    "NotificationRule",
    "EventNotificationBridge",
    "create_notification_bridge",
]
