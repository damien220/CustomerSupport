"""Cache integration — helpers for CacheBackedEventStore initialization.

Simplifies creating a :class:`CacheBackedEventStore` by wrapping the
``cache_manager`` factory with sensible defaults for event storage.
Falls back gracefully when ``cache_manager`` is not installed.
"""

from __future__ import annotations

from typing import Any, Optional

from ..exceptions import EventStoreError

try:
    from cache_manager import get_cache as _get_cache
    from cache_manager import list_available_backends as _list_backends
    from cache_manager import is_backend_available as _is_backend_available

    _HAS_CACHE = True
except ImportError:  # pragma: no cover
    _HAS_CACHE = False
    _get_cache = None  # type: ignore[assignment]
    _list_backends = None  # type: ignore[assignment]
    _is_backend_available = None  # type: ignore[assignment]


def has_cache_manager() -> bool:
    """Return ``True`` if the ``cache_manager`` package is available."""
    return _HAS_CACHE


def list_cache_backends() -> list[str]:
    """Return all registered cache backend names.

    Returns an empty list when ``cache_manager`` is not installed.
    """
    if _HAS_CACHE and _list_backends is not None:
        return _list_backends()
    return []


def is_cache_backend_available(backend: str) -> bool:
    """Check if a specific cache backend is usable."""
    if _HAS_CACHE and _is_backend_available is not None:
        return _is_backend_available(backend)
    return False


def create_event_cache(
    backend: str = "memory",
    ttl_seconds: Optional[int] = 3600,
    max_size: int = 10000,
    **kwargs: Any,
) -> Any:
    """Create a cache instance pre-configured for event storage.

    Parameters
    ----------
    backend
        Cache backend name (``"memory"``, ``"redis"``, ``"sqlite"``, etc.).
    ttl_seconds
        Default TTL for cached events in seconds.
    max_size
        Maximum number of entries.
    **kwargs
        Extra arguments forwarded to ``get_cache()``.

    Returns
    -------
    cache
        A cache instance from ``cache_manager``.

    Raises
    ------
    EventStoreError
        If ``cache_manager`` is not installed.
    """
    if not _HAS_CACHE or _get_cache is None:
        raise EventStoreError(
            "cache_manager package is not installed. "
            "Install with: pip install cache-manager"
        )

    return _get_cache(
        backend,
        default_ttl=ttl_seconds,
        max_size=max_size,
        **kwargs,
    )


def create_cache_event_store(
    backend: str = "memory",
    ttl_seconds: Optional[int] = 3600,
    **kwargs: Any,
) -> "CacheBackedEventStore":  # noqa: F821
    """One-liner factory for a ready-to-use CacheBackedEventStore.

    Parameters
    ----------
    backend
        Cache backend name (``"memory"``, ``"redis"``, etc.).
    ttl_seconds
        Per-entry TTL in seconds.  ``None`` for no expiry.
    **kwargs
        Extra arguments forwarded to ``get_cache()``.

    Returns
    -------
    CacheBackedEventStore
        A fully initialised event store.

    Raises
    ------
    EventStoreError
        If ``cache_manager`` is not installed.
    """
    from ..stores.cache_backed_store import CacheBackedEventStore

    return CacheBackedEventStore(
        backend=backend,
        ttl_seconds=ttl_seconds,
        **kwargs,
    )
