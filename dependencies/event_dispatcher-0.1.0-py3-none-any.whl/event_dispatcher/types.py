"""Core type definitions for the Event Dispatcher package.

Dataclasses, enums, and TypedDicts used across the package.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Awaitable, Callable, Optional, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class EventPriority(IntEnum):
    """Dispatch priority — higher value = dispatched first in queued modes."""

    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


class ErrorStrategy(str, Enum):
    """How the dispatcher handles a handler that raises an exception."""

    PROPAGATE = "propagate"      # Re-raise; abort remaining handlers
    SUPPRESS = "suppress"        # Log and continue to next handler
    DEAD_LETTER = "dead_letter"  # Route the event to the dead-letter store


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------

@runtime_checkable
class HandlerCallable(Protocol):
    """Any callable that accepts a DispatchEvent."""

    def __call__(self, event: Any) -> None | Awaitable[None]: ...


@runtime_checkable
class EventFilterFn(Protocol):
    """Predicate that decides whether a handler should receive an event."""

    def __call__(self, event: Any) -> bool: ...


# ---------------------------------------------------------------------------
# Handler failure record
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class HandlerFailure:
    """Records a single handler invocation that raised an exception."""

    handler_name: str
    exception: Exception
    elapsed_ms: float = 0.0


# ---------------------------------------------------------------------------
# Subscription descriptor
# ---------------------------------------------------------------------------

@dataclass
class HandlerSubscription:
    """Describes a single handler subscription on the dispatcher."""

    subscription_id: str
    handler_fn: Callable[..., Any]
    event_pattern: str
    handler_priority: int = 0
    single_shot: bool = False
    event_filter: Optional[Callable[..., bool]] = None
    on_error: ErrorStrategy = ErrorStrategy.SUPPRESS


# ---------------------------------------------------------------------------
# Emit outcome
# ---------------------------------------------------------------------------

@dataclass
class EmitOutcome:
    """Result returned by the dispatcher after emitting an event."""

    event_id: str
    event_kind: str
    handlers_invoked: int = 0
    handler_errors: list[HandlerFailure] = field(default_factory=list)
    elapsed_ms: float = 0.0
    dead_lettered: bool = False


# ---------------------------------------------------------------------------
# Dispatcher statistics
# ---------------------------------------------------------------------------

@dataclass
class DispatcherStats:
    """Aggregated statistics for a dispatcher instance."""

    total_emitted: int = 0
    total_handled: int = 0
    total_failed: int = 0
    total_dead_lettered: int = 0
    total_filtered: int = 0
    registered_handlers: int = 0
    avg_dispatch_ms: float = 0.0
    avg_handler_ms: float = 0.0
    slowest_handler_name: str = ""
    per_kind_counts: dict[str, int] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class DispatcherConfig:
    """Configuration for instantiating a dispatcher via the factory."""

    dispatcher_kind: str = "local"

    # Async dispatcher
    max_queue_size: int = 10000
    concurrency_limit: int = 4
    overflow_strategy: str = "block"

    # Broker
    broker_kind: Optional[str] = None
    broker_host: str = "localhost"
    broker_port: int = 6379
    broker_db: int = 0
    broker_password: Optional[str] = None

    # Event store
    store_enabled: bool = False
    store_kind: str = "memory"
    store_max_events: Optional[int] = None
    store_ttl_seconds: Optional[int] = None

    # Dead-letter
    dead_letter_enabled: bool = True
    dead_letter_max_size: int = 1000

    # Middleware
    enable_logging: bool = True
    enable_correlation: bool = True
    enable_timing: bool = False

    # Retry
    retry_enabled: bool = False
    retry_max_attempts: int = 3
    retry_backoff_base: float = 1.0
    retry_backoff_max: float = 30.0

    # Logging
    log_level: str = "DEBUG"
    log_events: bool = True
    log_handler_errors: bool = True
