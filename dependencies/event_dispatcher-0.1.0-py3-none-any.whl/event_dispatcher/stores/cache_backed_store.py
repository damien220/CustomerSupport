"""CacheBackedEventStore — event store backed by Cache_manager."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Optional

from ..event import DispatchEvent
from ..exceptions import EventStoreError
from ..types import EventPriority
from .base_store import BaseEventStore

try:
    from cache_manager import get_cache as _get_cache
except ImportError:  # pragma: no cover
    _get_cache = None  # type: ignore[assignment]

# Key prefixes for cache entries
_EVENT_PREFIX = "evt:"
_INDEX_KEY = "evt:__index__"


def _event_to_dict(event: DispatchEvent) -> dict[str, Any]:
    """Serialise a DispatchEvent to a JSON-safe dict."""
    return {
        "event_id": event.event_id,
        "event_kind": event.event_kind,
        "source": event.source,
        "timestamp": event.timestamp.isoformat(),
        "correlation_id": event.correlation_id,
        "payload": event.payload,
        "metadata": event.metadata,
        "event_priority": int(event.event_priority),
    }


def _dict_to_event(data: dict[str, Any]) -> DispatchEvent:
    """Deserialise a dict back into a DispatchEvent."""
    ts = data["timestamp"]
    if isinstance(ts, str):
        ts = datetime.fromisoformat(ts)
    return DispatchEvent(
        event_id=data["event_id"],
        event_kind=data["event_kind"],
        source=data.get("source", ""),
        timestamp=ts,
        correlation_id=data.get("correlation_id"),
        payload=data.get("payload", {}),
        metadata=data.get("metadata", {}),
        event_priority=EventPriority(int(data.get("event_priority", 1))),
    )


class CacheBackedEventStore(BaseEventStore):
    """Persist events via the ``cache_manager`` package.

    Events are stored individually keyed by ``evt:<event_id>`` and an
    in-cache index list tracks all known event IDs for query support.

    Parameters
    ----------
    backend
        Cache backend name (``"memory"``, ``"redis"``, etc.).
    ttl_seconds
        Per-entry TTL in seconds.  ``None`` means no expiry.
    **cache_kwargs
        Extra keyword arguments forwarded to ``get_cache()``.
    """

    def __init__(
        self,
        backend: str = "memory",
        ttl_seconds: Optional[int] = None,
        **cache_kwargs: Any,
    ) -> None:
        if _get_cache is None:
            raise EventStoreError(
                "cache_manager package is not installed. "
                "Install with: pip install cache-manager"
            )

        self._ttl = ttl_seconds
        self._cache = _get_cache(backend, **cache_kwargs)

    # ── helpers ────────────────────────────────────────────────────────

    def _event_key(self, event_id: str) -> str:
        return f"{_EVENT_PREFIX}{event_id}"

    def _get_index(self) -> list[str]:
        """Return the list of known event IDs from the cache index."""
        raw = self._cache.get(_INDEX_KEY)
        if raw is None:
            return []
        if isinstance(raw, str):
            return json.loads(raw)
        return list(raw)

    def _set_index(self, index: list[str]) -> None:
        # Index has no TTL — it's the manifest of all stored events
        self._cache.set(_INDEX_KEY, json.dumps(index))

    # ── BaseEventStore implementation ─────────────────────────────────

    def store(self, event: DispatchEvent) -> None:
        try:
            data = _event_to_dict(event)
            self._cache.set(
                self._event_key(event.event_id),
                json.dumps(data),
                ttl=self._ttl,
            )
            index = self._get_index()
            if event.event_id not in index:
                index.append(event.event_id)
                self._set_index(index)
        except Exception as exc:
            raise EventStoreError(
                f"Failed to store event {event.event_id}",
                previous=exc,
            ) from exc

    def retrieve(self, event_id: str) -> Optional[DispatchEvent]:
        try:
            raw = self._cache.get(self._event_key(event_id))
            if raw is None:
                return None
            data = json.loads(raw) if isinstance(raw, str) else raw
            return _dict_to_event(data)
        except Exception as exc:
            raise EventStoreError(
                f"Failed to retrieve event {event_id}",
                previous=exc,
            ) from exc

    def query(
        self,
        *,
        event_kind: Optional[str] = None,
        source: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DispatchEvent]:
        try:
            index = self._get_index()
            events: list[DispatchEvent] = []
            for eid in index:
                raw = self._cache.get(self._event_key(eid))
                if raw is None:
                    continue  # expired or removed
                data = json.loads(raw) if isinstance(raw, str) else raw
                event = _dict_to_event(data)

                if event_kind is not None and event.event_kind != event_kind:
                    continue
                if source is not None and event.source != source:
                    continue
                if correlation_id is not None and event.correlation_id != correlation_id:
                    continue
                if since is not None and event.timestamp < since:
                    continue
                if until is not None and event.timestamp > until:
                    continue
                events.append(event)

            events.sort(key=lambda e: e.timestamp)
            return events[offset : offset + limit]
        except EventStoreError:
            raise
        except Exception as exc:
            raise EventStoreError(
                "Failed to query events",
                previous=exc,
            ) from exc

    def remove(self, event_id: str) -> bool:
        try:
            existed = self._cache.delete(self._event_key(event_id))
            if existed:
                index = self._get_index()
                if event_id in index:
                    index.remove(event_id)
                    self._set_index(index)
            return existed
        except Exception as exc:
            raise EventStoreError(
                f"Failed to remove event {event_id}",
                previous=exc,
            ) from exc

    def clear(self) -> int:
        try:
            index = self._get_index()
            n = 0
            for eid in index:
                if self._cache.delete(self._event_key(eid)):
                    n += 1
            self._cache.delete(_INDEX_KEY)
            return n
        except Exception as exc:
            raise EventStoreError(
                "Failed to clear event store",
                previous=exc,
            ) from exc

    def count(self) -> int:
        try:
            index = self._get_index()
            # Only count entries that still exist (not TTL-expired)
            n = 0
            for eid in index:
                if self._cache.exists(self._event_key(eid)):
                    n += 1
            return n
        except Exception as exc:
            raise EventStoreError(
                "Failed to count events",
                previous=exc,
            ) from exc
