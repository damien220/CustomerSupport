"""BaseEventStore — abstract interface for event persistence."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from ..event import DispatchEvent


class BaseEventStore(ABC):
    """Abstract base class for event stores.

    Implementations persist :class:`DispatchEvent` instances and support
    retrieval, querying, and cleanup.
    """

    # ── Write ─────────────────────────────────────────────────────────

    @abstractmethod
    def store(self, event: DispatchEvent) -> None:
        """Persist *event*.

        Raises
        ------
        EventStoreError
            If the write fails.
        """

    # ── Read ──────────────────────────────────────────────────────────

    @abstractmethod
    def retrieve(self, event_id: str) -> Optional[DispatchEvent]:
        """Return the event with *event_id*, or ``None`` if not found."""

    @abstractmethod
    def query(
        self,
        *,
        event_kind: Optional[str] = None,
        source: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DispatchEvent]:
        """Return events matching the given filters.

        Parameters
        ----------
        event_kind
            Exact-match on ``DispatchEvent.event_kind``.
        source
            Exact-match on ``DispatchEvent.source``.
        correlation_id
            Exact-match on ``DispatchEvent.correlation_id``.
        since
            Events with ``timestamp >= since``.
        until
            Events with ``timestamp <= until``.
        limit
            Maximum number of events to return.
        offset
            Skip the first *offset* matching events.
        """

    # ── Delete ────────────────────────────────────────────────────────

    @abstractmethod
    def remove(self, event_id: str) -> bool:
        """Remove event by ID.  Return ``True`` if it existed."""

    @abstractmethod
    def clear(self) -> int:
        """Remove **all** stored events.  Return the count removed."""

    # ── Introspection ─────────────────────────────────────────────────

    @abstractmethod
    def count(self) -> int:
        """Return the total number of stored events."""
