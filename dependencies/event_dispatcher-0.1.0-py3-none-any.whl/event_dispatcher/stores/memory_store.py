"""InMemoryEventStore — in-process event store with max size and TTL."""

from __future__ import annotations

import threading
import time
from collections import OrderedDict
from datetime import datetime
from typing import Optional

from ..event import DispatchEvent
from ..exceptions import EventStoreError
from .base_store import BaseEventStore


class InMemoryEventStore(BaseEventStore):
    """Store events in an in-process ordered dictionary.

    Parameters
    ----------
    max_size
        Maximum number of events to retain.  When exceeded the oldest
        events are evicted automatically.  ``None`` means unlimited.
    ttl_seconds
        Time-to-live in seconds.  Expired events are lazily evicted on
        reads and writes.  ``None`` disables TTL.
    """

    def __init__(
        self,
        max_size: Optional[int] = None,
        ttl_seconds: Optional[int] = None,
    ) -> None:
        if max_size is not None and max_size < 1:
            raise EventStoreError("max_size must be >= 1")
        if ttl_seconds is not None and ttl_seconds < 0:
            raise EventStoreError("ttl_seconds must be >= 0")

        self._max_size = max_size
        self._ttl_seconds = ttl_seconds
        self._events: OrderedDict[str, tuple[DispatchEvent, float]] = OrderedDict()
        self._lock = threading.Lock()

    # ── helpers ────────────────────────────────────────────────────────

    def _now(self) -> float:
        return time.monotonic()

    def _is_expired(self, stored_at: float) -> bool:
        if self._ttl_seconds is None:
            return False
        return (self._now() - stored_at) > self._ttl_seconds

    def _evict_expired(self) -> None:
        """Remove all expired entries (caller must hold the lock)."""
        if self._ttl_seconds is None:
            return
        expired_ids = [
            eid
            for eid, (_, stored_at) in self._events.items()
            if self._is_expired(stored_at)
        ]
        for eid in expired_ids:
            del self._events[eid]

    def _enforce_max_size(self) -> None:
        """Pop oldest entries until we're under max_size (caller holds lock)."""
        if self._max_size is None:
            return
        while len(self._events) > self._max_size:
            self._events.popitem(last=False)

    # ── BaseEventStore implementation ─────────────────────────────────

    def store(self, event: DispatchEvent) -> None:
        with self._lock:
            self._evict_expired()
            self._events[event.event_id] = (event, self._now())
            # Move to end so OrderedDict stays oldest-first
            self._events.move_to_end(event.event_id)
            self._enforce_max_size()

    def retrieve(self, event_id: str) -> Optional[DispatchEvent]:
        with self._lock:
            entry = self._events.get(event_id)
            if entry is None:
                return None
            event, stored_at = entry
            if self._is_expired(stored_at):
                del self._events[event_id]
                return None
            return event

    def query(
        self,
        *,
        event_kind: Optional[str] = None,
        source: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DispatchEvent]:
        with self._lock:
            self._evict_expired()
            results: list[DispatchEvent] = []
            skipped = 0
            for event, _ in self._events.values():
                if event_kind is not None and event.event_kind != event_kind:
                    continue
                if source is not None and event.source != source:
                    continue
                if correlation_id is not None and event.correlation_id != correlation_id:
                    continue
                if since is not None and event.timestamp < since:
                    continue
                if until is not None and event.timestamp > until:
                    continue
                if skipped < offset:
                    skipped += 1
                    continue
                results.append(event)
                if len(results) >= limit:
                    break
            return results

    def remove(self, event_id: str) -> bool:
        with self._lock:
            if event_id in self._events:
                del self._events[event_id]
                return True
            return False

    def clear(self) -> int:
        with self._lock:
            n = len(self._events)
            self._events.clear()
            return n

    def count(self) -> int:
        with self._lock:
            self._evict_expired()
            return len(self._events)
