"""DatabaseEventStore — persistent event store using DB_Package."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

from ..event import DispatchEvent
from ..exceptions import EventStoreError
from ..types import EventPriority
from .base_store import BaseEventStore

try:
    from db_accessor import get_database as _get_database
except ImportError:  # pragma: no cover
    _get_database = None  # type: ignore[assignment]


def _event_to_row(event: DispatchEvent) -> dict[str, Any]:
    """Serialise a DispatchEvent to a flat dict suitable for DB storage."""
    return {
        "event_id": event.event_id,
        "event_kind": event.event_kind,
        "source": event.source,
        "timestamp": event.timestamp.isoformat(),
        "correlation_id": event.correlation_id or "",
        "payload": json.dumps(event.payload),
        "metadata": json.dumps(event.metadata),
        "event_priority": int(event.event_priority),
    }


def _row_to_event(row: dict[str, Any]) -> DispatchEvent:
    """Deserialise a DB row back into a DispatchEvent."""
    ts = row["timestamp"]
    if isinstance(ts, str):
        ts = datetime.fromisoformat(ts)
    corr = row.get("correlation_id") or None
    if corr == "":
        corr = None
    return DispatchEvent(
        event_id=row["event_id"],
        event_kind=row["event_kind"],
        source=row.get("source", ""),
        timestamp=ts,
        correlation_id=corr,
        payload=json.loads(row.get("payload", "{}")),
        metadata=json.loads(row.get("metadata", "{}")),
        event_priority=EventPriority(int(row.get("event_priority", 1))),
    )


class DatabaseEventStore(BaseEventStore):
    """Persist events via the ``db_accessor`` package.

    Parameters
    ----------
    db_type
        Database backend (``"sqlite"``, ``"postgres"``, etc.).
    connection_details
        Dict forwarded to ``db.connect()``.
    collection
        Table / collection name for event storage.
    """

    def __init__(
        self,
        db_type: str = "sqlite",
        connection_details: Optional[dict[str, Any]] = None,
        collection: str = "dispatch_events",
    ) -> None:
        if _get_database is None:
            raise EventStoreError(
                "db_accessor package is not installed. "
                "Install with: pip install db-accessor"
            )

        self._collection = collection
        self._db = _get_database(db_type)
        self._connection_details = connection_details or {}
        self._connected = False

    # ── connection management ─────────────────────────────────────────

    def connect(self) -> DatabaseEventStore:
        """Open the database connection.  Safe to call multiple times."""
        if not self._connected:
            self._db.connect(self._connection_details)
            self._connected = True
        return self

    def disconnect(self) -> None:
        """Close the database connection."""
        if self._connected:
            self._db.disconnect()
            self._connected = False

    def __enter__(self) -> DatabaseEventStore:
        self.connect()
        return self

    def __exit__(self, *exc: object) -> None:
        self.disconnect()

    def _ensure_connected(self) -> None:
        if not self._connected:
            raise EventStoreError(
                "DatabaseEventStore is not connected. Call connect() first."
            )

    # ── BaseEventStore implementation ─────────────────────────────────

    def store(self, event: DispatchEvent) -> None:
        self._ensure_connected()
        try:
            self._db.create(self._collection, _event_to_row(event))
        except Exception as exc:
            raise EventStoreError(
                f"Failed to store event {event.event_id}",
                previous=exc,
            ) from exc

    def retrieve(self, event_id: str) -> Optional[DispatchEvent]:
        self._ensure_connected()
        try:
            rows = self._db.read(self._collection, {"event_id": event_id})
        except Exception as exc:
            raise EventStoreError(
                f"Failed to retrieve event {event_id}",
                previous=exc,
            ) from exc
        if not rows:
            return None
        return _row_to_event(rows[0])

    def query(
        self,
        *,
        event_kind: Optional[str] = None,
        source: Optional[str] = None,
        correlation_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DispatchEvent]:
        self._ensure_connected()
        try:
            # Build a simple equality query — the DB abstraction only
            # supports dict-based equality filters.  Time-range filtering
            # is applied in Python after fetching.
            query_filter: dict[str, Any] = {}
            if event_kind is not None:
                query_filter["event_kind"] = event_kind
            if source is not None:
                query_filter["source"] = source
            if correlation_id is not None:
                query_filter["correlation_id"] = correlation_id

            rows = self._db.read(self._collection, query_filter)
        except Exception as exc:
            raise EventStoreError(
                "Failed to query events",
                previous=exc,
            ) from exc

        events = [_row_to_event(r) for r in rows]

        # Apply time-range filtering in Python
        if since is not None:
            events = [e for e in events if e.timestamp >= since]
        if until is not None:
            events = [e for e in events if e.timestamp <= until]

        # Sort by timestamp ascending
        events.sort(key=lambda e: e.timestamp)

        return events[offset : offset + limit]

    def remove(self, event_id: str) -> bool:
        self._ensure_connected()
        try:
            existing = self._db.read(self._collection, {"event_id": event_id})
            if not existing:
                return False
            self._db.delete(self._collection, {"event_id": event_id})
            return True
        except Exception as exc:
            raise EventStoreError(
                f"Failed to remove event {event_id}",
                previous=exc,
            ) from exc

    def clear(self) -> int:
        self._ensure_connected()
        try:
            rows = self._db.read(self._collection, {})
            n = len(rows)
            if n > 0:
                for row in rows:
                    self._db.delete(self._collection, {"event_id": row["event_id"]})
            return n
        except Exception as exc:
            raise EventStoreError(
                "Failed to clear event store",
                previous=exc,
            ) from exc

    def count(self) -> int:
        self._ensure_connected()
        try:
            rows = self._db.read(self._collection, {})
            return len(rows)
        except Exception as exc:
            raise EventStoreError(
                "Failed to count events",
                previous=exc,
            ) from exc
