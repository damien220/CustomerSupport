"""Dead-letter handling — capture events that failed all handler attempts."""

from __future__ import annotations

import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .event import DispatchEvent


@dataclass(frozen=True)
class DeadLetterRecord:
    """An event that was routed to the dead-letter store.

    Attributes
    ----------
    record_id
        Unique identifier for this dead-letter entry.
    event
        The original event that could not be processed.
    reason
        Human-readable description of why the event was dead-lettered.
    handler_name
        Name of the handler that failed (if applicable).
    exception_type
        Fully-qualified type name of the exception that triggered this.
    exception_message
        String representation of the exception.
    failed_at
        UTC timestamp when the failure occurred.
    attempt_count
        Number of delivery attempts before dead-lettering.
    """

    event: DispatchEvent
    reason: str = ""
    handler_name: str = ""
    exception_type: str = ""
    exception_message: str = ""
    attempt_count: int = 1
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    failed_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc),
    )


class DeadLetterStore:
    """In-memory store for dead-lettered events.

    Parameters
    ----------
    max_size
        Maximum number of dead-letter records to retain.  When exceeded
        the oldest records are evicted.
    """

    def __init__(self, max_size: int = 1000) -> None:
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        self._max_size = max_size
        self._records: OrderedDict[str, DeadLetterRecord] = OrderedDict()
        self._lock = threading.Lock()

    # ── Write ─────────────────────────────────────────────────────────

    def add(self, record: DeadLetterRecord) -> None:
        """Add a dead-letter record, evicting the oldest if at capacity."""
        with self._lock:
            self._records[record.record_id] = record
            self._records.move_to_end(record.record_id)
            while len(self._records) > self._max_size:
                self._records.popitem(last=False)

    def add_from_event(
        self,
        event: DispatchEvent,
        *,
        reason: str = "",
        handler_name: str = "",
        exception: Optional[Exception] = None,
        attempt_count: int = 1,
    ) -> DeadLetterRecord:
        """Create and store a DeadLetterRecord from an event and failure details."""
        record = DeadLetterRecord(
            event=event,
            reason=reason,
            handler_name=handler_name,
            exception_type=type(exception).__qualname__ if exception else "",
            exception_message=str(exception) if exception else "",
            attempt_count=attempt_count,
        )
        self.add(record)
        return record

    # ── Read ──────────────────────────────────────────────────────────

    def get(self, record_id: str) -> Optional[DeadLetterRecord]:
        """Return a record by ID, or ``None``."""
        with self._lock:
            return self._records.get(record_id)

    def get_by_event_id(self, event_id: str) -> list[DeadLetterRecord]:
        """Return all dead-letter records for a given event ID."""
        with self._lock:
            return [
                r for r in self._records.values()
                if r.event.event_id == event_id
            ]

    def list_records(
        self,
        *,
        event_kind: Optional[str] = None,
        handler_name: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DeadLetterRecord]:
        """Query dead-letter records with optional filters."""
        with self._lock:
            results: list[DeadLetterRecord] = []
            for record in self._records.values():
                if event_kind is not None and record.event.event_kind != event_kind:
                    continue
                if handler_name is not None and record.handler_name != handler_name:
                    continue
                if since is not None and record.failed_at < since:
                    continue
                results.append(record)
            results.sort(key=lambda r: r.failed_at)
            return results[offset : offset + limit]

    # ── Delete ────────────────────────────────────────────────────────

    def remove(self, record_id: str) -> bool:
        """Remove a record by ID.  Return ``True`` if it existed."""
        with self._lock:
            if record_id in self._records:
                del self._records[record_id]
                return True
            return False

    def clear(self) -> int:
        """Remove all records.  Return the count removed."""
        with self._lock:
            n = len(self._records)
            self._records.clear()
            return n

    # ── Introspection ─────────────────────────────────────────────────

    def count(self) -> int:
        """Return total number of stored records."""
        with self._lock:
            return len(self._records)

    @property
    def max_size(self) -> int:
        return self._max_size
