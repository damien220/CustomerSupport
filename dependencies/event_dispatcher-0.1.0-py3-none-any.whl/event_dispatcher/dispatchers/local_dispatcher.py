"""LocalDispatcher — synchronous, in-process event bus.

Supports sync and async handlers, wildcard pattern matching, handler
priority ordering, and decorator-style subscription.
"""

from __future__ import annotations

import asyncio
import fnmatch
import threading
import time
import uuid
from typing import Any, Callable, Optional

from ..event import DispatchEvent
from ..exceptions import HandlerExecutionError, HandlerRegistrationError
from ..types import (
    DispatcherStats,
    EmitOutcome,
    ErrorStrategy,
    HandlerFailure,
    HandlerSubscription,
)
from .base_dispatcher import AbstractEventDispatcher


class LocalDispatcher(AbstractEventDispatcher):
    """In-process event dispatcher with wildcard matching and priority ordering.

    Thread-safe for subscription management.  Handlers execute in the
    calling thread (``emit``) or the current event loop (``emit_async``).
    """

    def __init__(self) -> None:
        self._subscriptions: list[HandlerSubscription] = []
        self._lock = threading.Lock()
        self._stats = DispatcherStats()
        self._middleware_stack: list = []  # BaseEventMiddleware instances

    # ------------------------------------------------------------------
    # Subscription
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_pattern: str,
        handler_fn: Optional[Callable[..., Any]] = None,
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription | Callable[..., HandlerSubscription]:
        """Register a handler.  Can also be used as a decorator::

            @dispatcher.subscribe("user.created")
            def on_user_created(event):
                ...
        """
        if handler_fn is None:
            # Decorator mode — return a wrapper that registers the decorated fn
            def _decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
                self._register(
                    fn,
                    event_pattern,
                    handler_priority=handler_priority,
                    single_shot=False,
                    event_filter=event_filter,
                    on_error=on_error,
                )
                return fn

            return _decorator  # type: ignore[return-value]

        return self._register(
            handler_fn,
            event_pattern,
            handler_priority=handler_priority,
            single_shot=False,
            event_filter=event_filter,
            on_error=on_error,
        )

    def subscribe_once(
        self,
        event_pattern: str,
        handler_fn: Optional[Callable[..., Any]] = None,
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription | Callable[..., HandlerSubscription]:
        if handler_fn is None:

            def _decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
                self._register(
                    fn,
                    event_pattern,
                    handler_priority=handler_priority,
                    single_shot=True,
                    event_filter=event_filter,
                    on_error=on_error,
                )
                return fn

            return _decorator  # type: ignore[return-value]

        return self._register(
            handler_fn,
            event_pattern,
            handler_priority=handler_priority,
            single_shot=True,
            event_filter=event_filter,
            on_error=on_error,
        )

    def unsubscribe(self, subscription: HandlerSubscription) -> bool:
        with self._lock:
            for idx, sub in enumerate(self._subscriptions):
                if sub.subscription_id == subscription.subscription_id:
                    self._subscriptions.pop(idx)
                    self._stats.registered_handlers = len(self._subscriptions)
                    return True
            return False

    def unsubscribe_all(self, event_pattern: Optional[str] = None) -> int:
        with self._lock:
            if event_pattern is None:
                count = len(self._subscriptions)
                self._subscriptions.clear()
                self._stats.registered_handlers = 0
                return count

            before = len(self._subscriptions)
            self._subscriptions = [
                s for s in self._subscriptions if s.event_pattern != event_pattern
            ]
            removed = before - len(self._subscriptions)
            self._stats.registered_handlers = len(self._subscriptions)
            return removed

    # ------------------------------------------------------------------
    # Emission — synchronous
    # ------------------------------------------------------------------

    def emit(self, event: DispatchEvent) -> EmitOutcome:
        # --- Middleware: before_emit ---
        current_event = event
        for mw in self._middleware_stack:
            result = mw.before_emit(current_event)
            if result is None:
                # Event suppressed by middleware
                self._stats.total_filtered += 1
                outcome = EmitOutcome(
                    event_id=current_event.event_id,
                    event_kind=current_event.event_kind,
                )
                return outcome
            current_event = result
        event = current_event

        start = time.perf_counter()
        matching = self._resolve_handlers(event)
        outcome = EmitOutcome(event_id=event.event_id, event_kind=event.event_kind)
        to_remove: list[str] = []

        for sub in matching:
            handler_start = time.perf_counter()
            try:
                result = sub.handler_fn(event)
                # If the handler is a coroutine, run it in a new event loop
                if asyncio.iscoroutine(result):
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        loop = None

                    if loop is not None and loop.is_running():
                        # We're inside a running loop — schedule as a task
                        # This shouldn't normally happen in sync emit, but
                        # handle gracefully.
                        future = asyncio.ensure_future(result)
                        # Can't await here in sync context; best-effort
                    else:
                        asyncio.run(result)

                outcome.handlers_invoked += 1
                handler_elapsed = (time.perf_counter() - handler_start) * 1000
                self._track_handler_time(sub, handler_elapsed)

            except Exception as exc:
                handler_elapsed = (time.perf_counter() - handler_start) * 1000
                failure = HandlerFailure(
                    handler_name=_handler_name(sub.handler_fn),
                    exception=exc,
                    elapsed_ms=handler_elapsed,
                )
                outcome.handler_errors.append(failure)
                outcome.handlers_invoked += 1
                self._stats.total_failed += 1

                if sub.on_error is ErrorStrategy.PROPAGATE:
                    self._finalize_emit(event, outcome, start)
                    raise HandlerExecutionError(
                        f"Handler {failure.handler_name!r} raised: {exc}",
                        details={"handler": failure.handler_name, "event_kind": event.event_kind},
                        previous=exc,
                    )
                # SUPPRESS and DEAD_LETTER both continue; dead-letter routing
                # will be handled by the dead-letter middleware in Phase 4.

            if sub.single_shot:
                to_remove.append(sub.subscription_id)

        # Clean up single-shot subscriptions
        if to_remove:
            with self._lock:
                self._subscriptions = [
                    s for s in self._subscriptions if s.subscription_id not in to_remove
                ]
                self._stats.registered_handlers = len(self._subscriptions)

        self._finalize_emit(event, outcome, start)

        # --- Middleware: after_emit (reverse order) ---
        for mw in reversed(self._middleware_stack):
            mw.after_emit(event, outcome)

        return outcome

    # ------------------------------------------------------------------
    # Emission — asynchronous
    # ------------------------------------------------------------------

    async def emit_async(self, event: DispatchEvent) -> EmitOutcome:
        # --- Middleware: before_emit ---
        current_event = event
        for mw in self._middleware_stack:
            result = mw.before_emit(current_event)
            if result is None:
                self._stats.total_filtered += 1
                outcome = EmitOutcome(
                    event_id=current_event.event_id,
                    event_kind=current_event.event_kind,
                )
                return outcome
            current_event = result
        event = current_event

        start = time.perf_counter()
        matching = self._resolve_handlers(event)
        outcome = EmitOutcome(event_id=event.event_id, event_kind=event.event_kind)
        to_remove: list[str] = []

        for sub in matching:
            handler_start = time.perf_counter()
            try:
                result = sub.handler_fn(event)
                if asyncio.iscoroutine(result):
                    await result

                outcome.handlers_invoked += 1
                handler_elapsed = (time.perf_counter() - handler_start) * 1000
                self._track_handler_time(sub, handler_elapsed)

            except Exception as exc:
                handler_elapsed = (time.perf_counter() - handler_start) * 1000
                failure = HandlerFailure(
                    handler_name=_handler_name(sub.handler_fn),
                    exception=exc,
                    elapsed_ms=handler_elapsed,
                )
                outcome.handler_errors.append(failure)
                outcome.handlers_invoked += 1
                self._stats.total_failed += 1

                if sub.on_error is ErrorStrategy.PROPAGATE:
                    self._finalize_emit(event, outcome, start)
                    raise HandlerExecutionError(
                        f"Handler {failure.handler_name!r} raised: {exc}",
                        details={"handler": failure.handler_name, "event_kind": event.event_kind},
                        previous=exc,
                    )

            if sub.single_shot:
                to_remove.append(sub.subscription_id)

        if to_remove:
            with self._lock:
                self._subscriptions = [
                    s for s in self._subscriptions if s.subscription_id not in to_remove
                ]
                self._stats.registered_handlers = len(self._subscriptions)

        self._finalize_emit(event, outcome, start)

        # --- Middleware: after_emit (reverse order) ---
        for mw in reversed(self._middleware_stack):
            mw.after_emit(event, outcome)

        return outcome

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def has_handlers(self, event_pattern: str) -> bool:
        with self._lock:
            return any(
                _pattern_matches(sub.event_pattern, event_pattern)
                for sub in self._subscriptions
            )

    def handler_count(self, event_pattern: Optional[str] = None) -> int:
        with self._lock:
            if event_pattern is None:
                return len(self._subscriptions)
            return sum(
                1
                for sub in self._subscriptions
                if _pattern_matches(sub.event_pattern, event_pattern)
            )

    def get_stats(self) -> DispatcherStats:
        with self._lock:
            self._stats.registered_handlers = len(self._subscriptions)
        return self._stats

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _register(
        self,
        handler_fn: Callable[..., Any],
        event_pattern: str,
        *,
        handler_priority: int,
        single_shot: bool,
        event_filter: Optional[Callable[..., bool]],
        on_error: ErrorStrategy,
    ) -> HandlerSubscription:
        if not callable(handler_fn):
            raise HandlerRegistrationError(
                "handler_fn must be callable",
                details={"event_pattern": event_pattern},
            )
        if not event_pattern:
            raise HandlerRegistrationError(
                "event_pattern must not be empty",
                details={"handler": _handler_name(handler_fn)},
            )

        sub = HandlerSubscription(
            subscription_id=str(uuid.uuid4()),
            handler_fn=handler_fn,
            event_pattern=event_pattern,
            handler_priority=handler_priority,
            single_shot=single_shot,
            event_filter=event_filter,
            on_error=on_error,
        )
        with self._lock:
            self._subscriptions.append(sub)
            self._stats.registered_handlers = len(self._subscriptions)
        return sub

    def _resolve_handlers(self, event: DispatchEvent) -> list[HandlerSubscription]:
        """Return subscriptions matching *event*, sorted by priority (desc)."""
        with self._lock:
            snapshot = list(self._subscriptions)

        matched: list[HandlerSubscription] = []
        for sub in snapshot:
            if not _pattern_matches(sub.event_pattern, event.event_kind):
                continue
            if sub.event_filter is not None and not sub.event_filter(event):
                self._stats.total_filtered += 1
                continue
            matched.append(sub)

        matched.sort(key=lambda s: s.handler_priority, reverse=True)
        return matched

    def _finalize_emit(
        self, event: DispatchEvent, outcome: EmitOutcome, start: float
    ) -> None:
        elapsed = (time.perf_counter() - start) * 1000
        outcome.elapsed_ms = elapsed
        self._stats.total_emitted += 1
        self._stats.total_handled += outcome.handlers_invoked
        kind = event.event_kind
        self._stats.per_kind_counts[kind] = (
            self._stats.per_kind_counts.get(kind, 0) + 1
        )
        # Rolling average
        n = self._stats.total_emitted
        self._stats.avg_dispatch_ms = (
            self._stats.avg_dispatch_ms * (n - 1) + elapsed
        ) / n

    def _track_handler_time(self, sub: HandlerSubscription, elapsed_ms: float) -> None:
        n = self._stats.total_handled + 1  # about to increment
        self._stats.avg_handler_ms = (
            self._stats.avg_handler_ms * (n - 1) + elapsed_ms
        ) / n
        handler_name = _handler_name(sub.handler_fn)
        # Track slowest handler
        if elapsed_ms > self._stats.avg_handler_ms * 2 or not self._stats.slowest_handler_name:
            if not self._stats.slowest_handler_name:
                self._stats.slowest_handler_name = handler_name
            # Keep updating if this one is slower
            # (simplified — doesn't track absolute max, just a heuristic)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _pattern_matches(subscription_pattern: str, event_kind: str) -> bool:
    """Check whether a subscription pattern matches an event kind.

    Rules:
    * ``"*"`` matches everything.
    * ``"user.*"`` matches ``"user.created"``, ``"user.deleted"``, etc.
    * ``"user.created"`` matches exactly ``"user.created"``.
    * ``"user.**"`` matches ``"user.created"`` and ``"user.auth.login"``
      (recursive).
    """
    if subscription_pattern == "*":
        return True

    # Use fnmatch for glob-style matching
    # Convert our dot-hierarchy conventions:
    #   "user.*"  -> matches one level  (user.created, user.deleted)
    #   "user.**" -> matches any depth  (user.a, user.a.b.c)
    if subscription_pattern.endswith(".**"):
        prefix = subscription_pattern[:-3]
        return event_kind == prefix or event_kind.startswith(prefix + ".")

    if subscription_pattern.endswith(".*"):
        prefix = subscription_pattern[:-2]
        if not event_kind.startswith(prefix + "."):
            return False
        remainder = event_kind[len(prefix) + 1 :]
        # One level only: no more dots
        return "." not in remainder

    # Exact match
    return fnmatch.fnmatch(event_kind, subscription_pattern)


def _handler_name(handler_fn: Callable[..., Any]) -> str:
    """Best-effort human-readable name for a handler callable."""
    return getattr(handler_fn, "__qualname__", None) or getattr(
        handler_fn, "__name__", repr(handler_fn)
    )
