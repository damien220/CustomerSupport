"""BufferedAsyncDispatcher — async event bus with queue-based buffering.

Events are enqueued via :meth:`emit` (non-blocking) and dispatched by
background worker tasks.  This decouples event production from handler
execution, enabling high-throughput scenarios where the emitter must not
block on handler latency.

Key features:

* **Concurrency limit** — configurable number of worker tasks processing
  events in parallel.
* **Backpressure** — configurable queue max-size with overflow strategies:
  ``block`` (default), ``drop_oldest``, ``drop_newest``.
* **Middleware support** — inherits the middleware pipeline from
  :class:`AbstractEventDispatcher`.
* **Graceful shutdown** — :meth:`stop` / ``async with`` drains the queue
  and waits for workers to finish.
"""

from __future__ import annotations

import asyncio
import threading
import time
import uuid
from typing import Any, Callable, Optional

from ..event import DispatchEvent
from ..exceptions import HandlerExecutionError, HandlerRegistrationError
from ..types import (
    DispatcherStats,
    EmitOutcome,
    ErrorStrategy,
    HandlerFailure,
    HandlerSubscription,
)
from .base_dispatcher import AbstractEventDispatcher


_SENTINEL = object()  # poison pill for shutdown


class BufferedAsyncDispatcher(AbstractEventDispatcher):
    """Async dispatcher with an internal event queue and worker pool.

    Parameters
    ----------
    max_queue_size
        Maximum number of events buffered before backpressure kicks in.
    concurrency_limit
        Number of concurrent worker tasks consuming from the queue.
    overflow_strategy
        What to do when the queue is full:

        * ``"block"`` — ``emit`` awaits until space is available.
        * ``"drop_oldest"`` — discard the oldest queued event to make room.
        * ``"drop_newest"`` — silently drop the incoming event.
    """

    def __init__(
        self,
        *,
        max_queue_size: int = 10000,
        concurrency_limit: int = 4,
        overflow_strategy: str = "block",
    ) -> None:
        self._max_queue_size = max_queue_size
        self._concurrency_limit = concurrency_limit
        self._overflow_strategy = overflow_strategy

        self._subscriptions: list[HandlerSubscription] = []
        self._lock = threading.Lock()
        self._stats = DispatcherStats()
        self._middleware_stack: list = []

        # Async state — initialised in start()
        self._queue: Optional[asyncio.Queue] = None
        self._workers: list[asyncio.Task] = []
        self._started = False
        self._outcomes: dict[str, asyncio.Future] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Create the internal queue.  Workers are started lazily on first emit."""
        self._queue = asyncio.Queue(maxsize=self._max_queue_size)
        self._started = True

    def stop(self) -> None:
        """Signal shutdown (synchronous hint — use async context for full drain)."""
        self._started = False

    async def drain(self) -> None:
        """Wait for the queue to empty and shut down workers gracefully."""
        if self._queue is not None:
            # Wait for all items to be processed
            await self._queue.join()

        # Send poison pills to workers
        for _ in self._workers:
            if self._queue is not None:
                await self._queue.put(_SENTINEL)

        # Wait for workers to exit
        if self._workers:
            await asyncio.gather(*self._workers, return_exceptions=True)
            self._workers.clear()

        self._started = False

    async def __aenter__(self) -> BufferedAsyncDispatcher:
        self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.drain()

    # ------------------------------------------------------------------
    # Subscription
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_pattern: str,
        handler_fn: Optional[Callable[..., Any]] = None,
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription | Callable[..., HandlerSubscription]:
        if handler_fn is None:

            def _decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
                self._register(
                    fn, event_pattern,
                    handler_priority=handler_priority,
                    single_shot=False,
                    event_filter=event_filter,
                    on_error=on_error,
                )
                return fn

            return _decorator  # type: ignore[return-value]

        return self._register(
            handler_fn, event_pattern,
            handler_priority=handler_priority,
            single_shot=False,
            event_filter=event_filter,
            on_error=on_error,
        )

    def subscribe_once(
        self,
        event_pattern: str,
        handler_fn: Optional[Callable[..., Any]] = None,
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription | Callable[..., HandlerSubscription]:
        if handler_fn is None:

            def _decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
                self._register(
                    fn, event_pattern,
                    handler_priority=handler_priority,
                    single_shot=True,
                    event_filter=event_filter,
                    on_error=on_error,
                )
                return fn

            return _decorator  # type: ignore[return-value]

        return self._register(
            handler_fn, event_pattern,
            handler_priority=handler_priority,
            single_shot=True,
            event_filter=event_filter,
            on_error=on_error,
        )

    def unsubscribe(self, subscription: HandlerSubscription) -> bool:
        with self._lock:
            for idx, sub in enumerate(self._subscriptions):
                if sub.subscription_id == subscription.subscription_id:
                    self._subscriptions.pop(idx)
                    self._stats.registered_handlers = len(self._subscriptions)
                    return True
            return False

    def unsubscribe_all(self, event_pattern: Optional[str] = None) -> int:
        with self._lock:
            if event_pattern is None:
                count = len(self._subscriptions)
                self._subscriptions.clear()
                self._stats.registered_handlers = 0
                return count
            before = len(self._subscriptions)
            self._subscriptions = [
                s for s in self._subscriptions if s.event_pattern != event_pattern
            ]
            removed = before - len(self._subscriptions)
            self._stats.registered_handlers = len(self._subscriptions)
            return removed

    # ------------------------------------------------------------------
    # Emission — async (primary path)
    # ------------------------------------------------------------------

    async def emit_async(self, event: DispatchEvent) -> EmitOutcome:
        """Enqueue the event for async dispatch and return the outcome.

        If the queue is not started yet, starts it automatically.
        """
        self._ensure_started()
        self._ensure_workers()

        # --- Middleware: before_emit ---
        current_event = event
        for mw in self._middleware_stack:
            result = mw.before_emit(current_event)
            if result is None:
                self._stats.total_filtered += 1
                return EmitOutcome(
                    event_id=current_event.event_id,
                    event_kind=current_event.event_kind,
                )
            current_event = result
        event = current_event

        # Create a future to receive the outcome
        loop = asyncio.get_running_loop()
        future: asyncio.Future[EmitOutcome] = loop.create_future()
        self._outcomes[event.event_id] = future

        # Enqueue with backpressure handling
        await self._enqueue(event)

        # Wait for the worker to process and return the outcome
        outcome = await future
        return outcome

    def emit(self, event: DispatchEvent) -> EmitOutcome:
        """Synchronous emit — dispatches inline (not buffered).

        For fully buffered dispatch, use ``emit_async`` within an async
        context.  This method exists to satisfy the ABC and for
        convenience in mixed sync/async code.
        """
        self._ensure_started()

        # --- Middleware: before_emit ---
        current_event = event
        for mw in self._middleware_stack:
            result = mw.before_emit(current_event)
            if result is None:
                self._stats.total_filtered += 1
                return EmitOutcome(
                    event_id=current_event.event_id,
                    event_kind=current_event.event_kind,
                )
            current_event = result
        event = current_event

        # Dispatch inline (sync fallback)
        outcome = self._dispatch_event(event)

        # --- Middleware: after_emit ---
        for mw in reversed(self._middleware_stack):
            mw.after_emit(event, outcome)

        return outcome

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def has_handlers(self, event_pattern: str) -> bool:
        with self._lock:
            return any(
                _pattern_matches(sub.event_pattern, event_pattern)
                for sub in self._subscriptions
            )

    def handler_count(self, event_pattern: Optional[str] = None) -> int:
        with self._lock:
            if event_pattern is None:
                return len(self._subscriptions)
            return sum(
                1 for sub in self._subscriptions
                if _pattern_matches(sub.event_pattern, event_pattern)
            )

    def get_stats(self) -> DispatcherStats:
        with self._lock:
            self._stats.registered_handlers = len(self._subscriptions)
        return self._stats

    @property
    def queue_size(self) -> int:
        """Current number of events waiting in the queue."""
        if self._queue is None:
            return 0
        return self._queue.qsize()

    @property
    def is_running(self) -> bool:
        return self._started and len(self._workers) > 0

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_started(self) -> None:
        if self._queue is None:
            self.start()

    def _ensure_workers(self) -> None:
        """Lazily start worker tasks on the current event loop."""
        # Remove completed workers
        self._workers = [w for w in self._workers if not w.done()]

        while len(self._workers) < self._concurrency_limit:
            task = asyncio.ensure_future(self._worker_loop())
            self._workers.append(task)

    async def _enqueue(self, event: DispatchEvent) -> None:
        assert self._queue is not None

        if self._overflow_strategy == "block":
            await self._queue.put(event)

        elif self._overflow_strategy == "drop_newest":
            try:
                self._queue.put_nowait(event)
            except asyncio.QueueFull:
                self._stats.total_filtered += 1
                # Resolve the future immediately with an empty outcome
                future = self._outcomes.pop(event.event_id, None)
                if future and not future.done():
                    future.set_result(EmitOutcome(
                        event_id=event.event_id,
                        event_kind=event.event_kind,
                    ))

        elif self._overflow_strategy == "drop_oldest":
            try:
                self._queue.put_nowait(event)
            except asyncio.QueueFull:
                # Drop the oldest item
                try:
                    dropped = self._queue.get_nowait()
                    self._queue.task_done()
                    self._stats.total_filtered += 1
                    # Resolve the dropped event's future
                    if not isinstance(dropped, DispatchEvent):
                        pass  # sentinel, ignore
                    else:
                        dropped_future = self._outcomes.pop(dropped.event_id, None)
                        if dropped_future and not dropped_future.done():
                            dropped_future.set_result(EmitOutcome(
                                event_id=dropped.event_id,
                                event_kind=dropped.event_kind,
                            ))
                except asyncio.QueueEmpty:
                    pass
                # Now enqueue the new event
                try:
                    self._queue.put_nowait(event)
                except asyncio.QueueFull:
                    # Still full (race), resolve and drop
                    future = self._outcomes.pop(event.event_id, None)
                    if future and not future.done():
                        future.set_result(EmitOutcome(
                            event_id=event.event_id,
                            event_kind=event.event_kind,
                        ))
        else:
            await self._queue.put(event)

    async def _worker_loop(self) -> None:
        """Background task consuming events from the queue."""
        assert self._queue is not None

        while True:
            item = await self._queue.get()
            if item is _SENTINEL:
                self._queue.task_done()
                break

            event: DispatchEvent = item
            try:
                outcome = await self._dispatch_event_async(event)

                # --- Middleware: after_emit (reverse order) ---
                for mw in reversed(self._middleware_stack):
                    mw.after_emit(event, outcome)

                # Resolve the future
                future = self._outcomes.pop(event.event_id, None)
                if future is not None and not future.done():
                    future.set_result(outcome)
            except Exception as exc:
                future = self._outcomes.pop(event.event_id, None)
                if future is not None and not future.done():
                    future.set_exception(exc)
            finally:
                self._queue.task_done()

    def _dispatch_event(self, event: DispatchEvent) -> EmitOutcome:
        """Dispatch synchronously (inline fallback for sync emit)."""
        start = time.perf_counter()
        matching = self._resolve_handlers(event)
        outcome = EmitOutcome(event_id=event.event_id, event_kind=event.event_kind)
        to_remove: list[str] = []

        for sub in matching:
            handler_start = time.perf_counter()
            try:
                result = sub.handler_fn(event)
                if asyncio.iscoroutine(result):
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        loop = None
                    if loop is not None and loop.is_running():
                        asyncio.ensure_future(result)
                    else:
                        asyncio.run(result)
                outcome.handlers_invoked += 1
                self._track_handler_time(sub, (time.perf_counter() - handler_start) * 1000)
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - handler_start) * 1000
                outcome.handler_errors.append(HandlerFailure(
                    handler_name=_handler_name(sub.handler_fn),
                    exception=exc,
                    elapsed_ms=elapsed_ms,
                ))
                outcome.handlers_invoked += 1
                self._stats.total_failed += 1
                if sub.on_error is ErrorStrategy.PROPAGATE:
                    self._finalize_emit(event, outcome, start)
                    raise HandlerExecutionError(
                        f"Handler {_handler_name(sub.handler_fn)!r} raised: {exc}",
                        details={"handler": _handler_name(sub.handler_fn), "event_kind": event.event_kind},
                        previous=exc,
                    )
            if sub.single_shot:
                to_remove.append(sub.subscription_id)

        if to_remove:
            with self._lock:
                self._subscriptions = [
                    s for s in self._subscriptions if s.subscription_id not in to_remove
                ]
                self._stats.registered_handlers = len(self._subscriptions)

        self._finalize_emit(event, outcome, start)
        return outcome

    async def _dispatch_event_async(self, event: DispatchEvent) -> EmitOutcome:
        """Dispatch asynchronously — the primary worker path."""
        start = time.perf_counter()
        matching = self._resolve_handlers(event)
        outcome = EmitOutcome(event_id=event.event_id, event_kind=event.event_kind)
        to_remove: list[str] = []

        for sub in matching:
            handler_start = time.perf_counter()
            try:
                result = sub.handler_fn(event)
                if asyncio.iscoroutine(result):
                    await result
                outcome.handlers_invoked += 1
                self._track_handler_time(sub, (time.perf_counter() - handler_start) * 1000)
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - handler_start) * 1000
                outcome.handler_errors.append(HandlerFailure(
                    handler_name=_handler_name(sub.handler_fn),
                    exception=exc,
                    elapsed_ms=elapsed_ms,
                ))
                outcome.handlers_invoked += 1
                self._stats.total_failed += 1
                if sub.on_error is ErrorStrategy.PROPAGATE:
                    self._finalize_emit(event, outcome, start)
                    raise HandlerExecutionError(
                        f"Handler {_handler_name(sub.handler_fn)!r} raised: {exc}",
                        details={"handler": _handler_name(sub.handler_fn), "event_kind": event.event_kind},
                        previous=exc,
                    )
            if sub.single_shot:
                to_remove.append(sub.subscription_id)

        if to_remove:
            with self._lock:
                self._subscriptions = [
                    s for s in self._subscriptions if s.subscription_id not in to_remove
                ]
                self._stats.registered_handlers = len(self._subscriptions)

        self._finalize_emit(event, outcome, start)
        return outcome

    def _register(
        self,
        handler_fn: Callable[..., Any],
        event_pattern: str,
        *,
        handler_priority: int,
        single_shot: bool,
        event_filter: Optional[Callable[..., bool]],
        on_error: ErrorStrategy,
    ) -> HandlerSubscription:
        if not callable(handler_fn):
            raise HandlerRegistrationError(
                "handler_fn must be callable",
                details={"event_pattern": event_pattern},
            )
        if not event_pattern:
            raise HandlerRegistrationError(
                "event_pattern must not be empty",
                details={"handler": _handler_name(handler_fn)},
            )
        sub = HandlerSubscription(
            subscription_id=str(uuid.uuid4()),
            handler_fn=handler_fn,
            event_pattern=event_pattern,
            handler_priority=handler_priority,
            single_shot=single_shot,
            event_filter=event_filter,
            on_error=on_error,
        )
        with self._lock:
            self._subscriptions.append(sub)
            self._stats.registered_handlers = len(self._subscriptions)
        return sub

    def _resolve_handlers(self, event: DispatchEvent) -> list[HandlerSubscription]:
        with self._lock:
            snapshot = list(self._subscriptions)
        matched: list[HandlerSubscription] = []
        for sub in snapshot:
            if not _pattern_matches(sub.event_pattern, event.event_kind):
                continue
            if sub.event_filter is not None and not sub.event_filter(event):
                self._stats.total_filtered += 1
                continue
            matched.append(sub)
        matched.sort(key=lambda s: s.handler_priority, reverse=True)
        return matched

    def _finalize_emit(
        self, event: DispatchEvent, outcome: EmitOutcome, start: float
    ) -> None:
        elapsed = (time.perf_counter() - start) * 1000
        outcome.elapsed_ms = elapsed
        self._stats.total_emitted += 1
        self._stats.total_handled += outcome.handlers_invoked
        kind = event.event_kind
        self._stats.per_kind_counts[kind] = (
            self._stats.per_kind_counts.get(kind, 0) + 1
        )
        n = self._stats.total_emitted
        self._stats.avg_dispatch_ms = (
            self._stats.avg_dispatch_ms * (n - 1) + elapsed
        ) / n

    def _track_handler_time(self, sub: HandlerSubscription, elapsed_ms: float) -> None:
        n = self._stats.total_handled + 1
        self._stats.avg_handler_ms = (
            self._stats.avg_handler_ms * (n - 1) + elapsed_ms
        ) / n


# ---------------------------------------------------------------------------
# Module-level helpers (duplicated from local_dispatcher to avoid coupling)
# ---------------------------------------------------------------------------

import fnmatch as _fnmatch


def _pattern_matches(subscription_pattern: str, event_kind: str) -> bool:
    if subscription_pattern == "*":
        return True
    if subscription_pattern.endswith(".**"):
        prefix = subscription_pattern[:-3]
        return event_kind == prefix or event_kind.startswith(prefix + ".")
    if subscription_pattern.endswith(".*"):
        prefix = subscription_pattern[:-2]
        if not event_kind.startswith(prefix + "."):
            return False
        remainder = event_kind[len(prefix) + 1:]
        return "." not in remainder
    return _fnmatch.fnmatch(event_kind, subscription_pattern)


def _handler_name(handler_fn: Callable[..., Any]) -> str:
    return getattr(handler_fn, "__qualname__", None) or getattr(
        handler_fn, "__name__", repr(handler_fn)
    )
