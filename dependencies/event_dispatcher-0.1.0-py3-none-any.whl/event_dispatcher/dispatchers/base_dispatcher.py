"""AbstractEventDispatcher — the root interface all dispatchers implement."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Optional

from ..event import DispatchEvent
from ..types import (
    DispatcherStats,
    EmitOutcome,
    ErrorStrategy,
    EventFilterFn,
    HandlerSubscription,
)

if TYPE_CHECKING:
    from ..middleware.base_middleware import BaseEventMiddleware


class AbstractEventDispatcher(ABC):
    """Abstract base class defining the event dispatcher contract.

    Concrete implementations:

    * :class:`LocalDispatcher` — synchronous in-process bus.
    * ``BufferedAsyncDispatcher`` — async with queue-based buffering (Phase 3).
    * ``BrokeredDispatcher`` — distributed via pluggable broker (Phase 5).
    """

    # ------------------------------------------------------------------
    # Middleware management
    # ------------------------------------------------------------------

    def use_middleware(self, middleware: BaseEventMiddleware) -> None:
        """Append *middleware* to the dispatch pipeline.

        Middleware ``before_emit`` hooks run in registration order;
        ``after_emit`` hooks run in reverse order (LIFO), so the first
        middleware registered is the outermost wrapper.
        """
        if not hasattr(self, "_middleware_stack"):
            self._middleware_stack: list[BaseEventMiddleware] = []
        self._middleware_stack.append(middleware)

    @property
    def middleware(self) -> list[BaseEventMiddleware]:
        """Return the current middleware stack (read-only copy)."""
        if not hasattr(self, "_middleware_stack"):
            self._middleware_stack: list[BaseEventMiddleware] = []  # type: ignore[no-redef]
        return list(self._middleware_stack)

    # ------------------------------------------------------------------
    # Subscription management
    # ------------------------------------------------------------------

    @abstractmethod
    def subscribe(
        self,
        event_pattern: str,
        handler_fn: Callable[..., Any],
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription:
        """Register *handler_fn* for events matching *event_pattern*.

        Parameters
        ----------
        event_pattern
            Exact event kind or wildcard pattern (``"user.*"``, ``"*"``).
        handler_fn
            Sync or async callable ``(DispatchEvent) -> None``.
        handler_priority
            Execution order among handlers for the same event.  Higher
            values execute first.
        event_filter
            Optional predicate ``(DispatchEvent) -> bool`` for fine-grained
            filtering beyond the pattern match.
        on_error
            Strategy when *handler_fn* raises.
        """

    @abstractmethod
    def subscribe_once(
        self,
        event_pattern: str,
        handler_fn: Callable[..., Any],
        *,
        handler_priority: int = 0,
        event_filter: Optional[Callable[..., bool]] = None,
        on_error: ErrorStrategy = ErrorStrategy.SUPPRESS,
    ) -> HandlerSubscription:
        """Like :meth:`subscribe` but auto-removes after the first invocation."""

    @abstractmethod
    def unsubscribe(self, subscription: HandlerSubscription) -> bool:
        """Remove a single subscription.  Returns ``True`` if found."""

    @abstractmethod
    def unsubscribe_all(self, event_pattern: Optional[str] = None) -> int:
        """Remove all subscriptions, or those matching *event_pattern*.

        Returns the number of subscriptions removed.
        """

    # ------------------------------------------------------------------
    # Emission
    # ------------------------------------------------------------------

    @abstractmethod
    def emit(self, event: DispatchEvent) -> EmitOutcome:
        """Dispatch *event* to all matching handlers (synchronous)."""

    @abstractmethod
    async def emit_async(self, event: DispatchEvent) -> EmitOutcome:
        """Dispatch *event* to all matching handlers (asynchronous)."""

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @abstractmethod
    def has_handlers(self, event_pattern: str) -> bool:
        """Return ``True`` if at least one handler matches *event_pattern*."""

    @abstractmethod
    def handler_count(self, event_pattern: Optional[str] = None) -> int:
        """Return the number of matching handlers, or all if *event_pattern* is ``None``."""

    @abstractmethod
    def get_stats(self) -> DispatcherStats:
        """Return aggregated dispatch statistics."""

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Initialize the dispatcher (connect stores, brokers, etc.).

        Default implementation is a no-op.
        """

    def stop(self) -> None:
        """Graceful shutdown (flush pending events, disconnect).

        Default implementation is a no-op.
        """

    def __enter__(self) -> AbstractEventDispatcher:
        self.start()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.stop()

    async def __aenter__(self) -> AbstractEventDispatcher:
        self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.stop()
