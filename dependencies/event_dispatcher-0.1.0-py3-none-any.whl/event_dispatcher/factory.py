"""Dispatcher factory — instantiate dispatchers by name."""

from __future__ import annotations

from typing import Any

from .dispatchers.base_dispatcher import AbstractEventDispatcher
from .dispatchers.brokered_dispatcher import BrokeredDispatcher
from .dispatchers.buffered_async_dispatcher import BufferedAsyncDispatcher
from .dispatchers.local_dispatcher import LocalDispatcher
from .types import DispatcherConfig

# Registry of dispatcher_kind -> constructor callable
_DISPATCHER_REGISTRY: dict[str, type[AbstractEventDispatcher]] = {
    "local": LocalDispatcher,
    "buffered_async": BufferedAsyncDispatcher,
    "brokered": BrokeredDispatcher,
}


def create_dispatcher(
    dispatcher_kind: str = "local",
    **kwargs: Any,
) -> AbstractEventDispatcher:
    """Create a dispatcher instance by kind name.

    Parameters
    ----------
    dispatcher_kind
        Registered dispatcher name (``"local"``, ``"buffered_async"``,
        ``"brokered"``).  Only ``"local"`` is available in Phase 1.
    **kwargs
        Forwarded to the dispatcher constructor.

    Raises
    ------
    ValueError
        If *dispatcher_kind* is not registered.
    """
    cls = _DISPATCHER_REGISTRY.get(dispatcher_kind)
    if cls is None:
        available = ", ".join(sorted(_DISPATCHER_REGISTRY))
        raise ValueError(
            f"Unknown dispatcher kind {dispatcher_kind!r}. "
            f"Available: {available}"
        )
    return cls(**kwargs)


def register_dispatcher(
    dispatcher_kind: str, cls: type[AbstractEventDispatcher]
) -> None:
    """Register a custom dispatcher type in the factory."""
    _DISPATCHER_REGISTRY[dispatcher_kind] = cls


def list_dispatcher_types() -> list[str]:
    """Return all registered dispatcher kind names."""
    return sorted(_DISPATCHER_REGISTRY)


def is_dispatcher_available(dispatcher_kind: str) -> bool:
    """Return ``True`` if *dispatcher_kind* is registered."""
    return dispatcher_kind in _DISPATCHER_REGISTRY
