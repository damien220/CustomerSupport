"""Event serialization — encode/decode DispatchEvent for broker transport."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from .event import DispatchEvent
from .exceptions import EventSerializationError
from .types import EventPriority


def event_to_json(event: DispatchEvent) -> str:
    """Serialise a :class:`DispatchEvent` to a JSON string.

    Raises
    ------
    EventSerializationError
        If the event cannot be serialised (e.g. non-JSON-safe payload).
    """
    try:
        data = {
            "event_id": event.event_id,
            "event_kind": event.event_kind,
            "source": event.source,
            "timestamp": event.timestamp.isoformat(),
            "correlation_id": event.correlation_id,
            "payload": event.payload,
            "metadata": event.metadata,
            "event_priority": int(event.event_priority),
        }
        return json.dumps(data, default=str)
    except (TypeError, ValueError, OverflowError) as exc:
        raise EventSerializationError(
            f"Failed to serialise event {event.event_id}: {exc}",
            previous=exc,
        ) from exc


def event_from_json(raw: str) -> DispatchEvent:
    """Deserialise a JSON string back into a :class:`DispatchEvent`.

    Raises
    ------
    EventSerializationError
        If *raw* is not valid JSON or has missing/invalid fields.
    """
    try:
        data: dict[str, Any] = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        raise EventSerializationError(
            f"Invalid JSON: {exc}",
            previous=exc,
        ) from exc

    try:
        ts = data["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)

        return DispatchEvent(
            event_id=data["event_id"],
            event_kind=data["event_kind"],
            source=data.get("source", ""),
            timestamp=ts,
            correlation_id=data.get("correlation_id"),
            payload=data.get("payload", {}),
            metadata=data.get("metadata", {}),
            event_priority=EventPriority(int(data.get("event_priority", 1))),
        )
    except (KeyError, ValueError, TypeError) as exc:
        raise EventSerializationError(
            f"Malformed event data: {exc}",
            previous=exc,
        ) from exc


def event_to_dict(event: DispatchEvent) -> dict[str, Any]:
    """Convert a :class:`DispatchEvent` to a plain dict (JSON-safe values)."""
    return {
        "event_id": event.event_id,
        "event_kind": event.event_kind,
        "source": event.source,
        "timestamp": event.timestamp.isoformat(),
        "correlation_id": event.correlation_id,
        "payload": event.payload,
        "metadata": event.metadata,
        "event_priority": int(event.event_priority),
    }


def event_from_dict(data: dict[str, Any]) -> DispatchEvent:
    """Reconstruct a :class:`DispatchEvent` from a plain dict."""
    try:
        ts = data["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)

        return DispatchEvent(
            event_id=data["event_id"],
            event_kind=data["event_kind"],
            source=data.get("source", ""),
            timestamp=ts,
            correlation_id=data.get("correlation_id"),
            payload=data.get("payload", {}),
            metadata=data.get("metadata", {}),
            event_priority=EventPriority(int(data.get("event_priority", 1))),
        )
    except (KeyError, ValueError, TypeError) as exc:
        raise EventSerializationError(
            f"Malformed event dict: {exc}",
            previous=exc,
        ) from exc
