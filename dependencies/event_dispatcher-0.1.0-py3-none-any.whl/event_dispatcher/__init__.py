"""Event Dispatcher — reusable, abstract event bus for Python applications.

Public API
----------
Core model::

    DispatchEvent, EventBuilder, EventPriority

Subscription & dispatch::

    AbstractEventDispatcher, LocalDispatcher

Types & results::

    HandlerSubscription, EmitOutcome, HandlerFailure,
    DispatcherStats, DispatcherConfig, ErrorStrategy

Filters::

    match_all, match_any, negate

Factory::

    create_dispatcher, list_dispatcher_types, is_dispatcher_available,
    register_dispatcher

Middleware::

    BaseEventMiddleware, CorrelationMiddleware, DispatchTimingMiddleware,
    EventGateMiddleware, EventLoggingMiddleware, HandlerRetryMiddleware

Exceptions::

    EventDispatcherError, EventEmitError, HandlerRegistrationError,
    HandlerExecutionError, EventStoreError, EventBrokerError,
    EventSerializationError
"""

# Event model
from event_dispatcher.event import DispatchEvent, EventBuilder

# Types & enums
from event_dispatcher.types import (
    DispatcherConfig,
    DispatcherStats,
    EmitOutcome,
    ErrorStrategy,
    EventPriority,
    HandlerFailure,
    HandlerSubscription,
)

# Filters
from event_dispatcher.filters import match_all, match_any, negate

# Dispatchers
from event_dispatcher.dispatchers.base_dispatcher import AbstractEventDispatcher
from event_dispatcher.dispatchers.brokered_dispatcher import BrokeredDispatcher
from event_dispatcher.dispatchers.buffered_async_dispatcher import BufferedAsyncDispatcher
from event_dispatcher.dispatchers.local_dispatcher import LocalDispatcher

# Brokers
from event_dispatcher.brokers import BaseEventBroker, InProcessBroker, RedisEventBroker

# Serialization
from event_dispatcher.event_serialization import (
    event_from_dict,
    event_from_json,
    event_to_dict,
    event_to_json,
)

# Factory
from event_dispatcher.factory import (
    create_dispatcher,
    is_dispatcher_available,
    list_dispatcher_types,
    register_dispatcher,
)

# Middleware
from event_dispatcher.middleware import (
    BaseEventMiddleware,
    CorrelationMiddleware,
    DispatchTimingMiddleware,
    EventGateMiddleware,
    EventLoggingMiddleware,
    HandlerRetryMiddleware,
)

# Event stores
from event_dispatcher.stores import (
    BaseEventStore,
    CacheBackedEventStore,
    DatabaseEventStore,
    InMemoryEventStore,
)

# Dead letter
from event_dispatcher.dead_letter import DeadLetterRecord, DeadLetterStore

# Integrations
from event_dispatcher.integrations import (
    EventNotificationBridge,
    JobEventForwarder,
    NotificationRule,
    classify_handler_errors,
    create_cache_event_store,
    create_notification_bridge,
    event_logging_context,
    failure_to_structured_error,
    get_event_logger,
    handle_exception_structured,
    has_cache_manager,
    has_error_handler,
    has_job_manager,
    has_logger_pkg,
    has_notification_manager,
    job_event_to_dispatch_event,
    log_event_emitted,
    log_event_handled,
    log_handler_error,
)

# Exceptions
from event_dispatcher.exceptions import (
    EventBrokerError,
    EventDispatcherError,
    EventEmitError,
    EventSerializationError,
    EventStoreError,
    HandlerExecutionError,
    HandlerRegistrationError,
)

__all__ = [
    # Event model
    "DispatchEvent",
    "EventBuilder",
    "EventPriority",
    # Types
    "HandlerSubscription",
    "EmitOutcome",
    "HandlerFailure",
    "DispatcherStats",
    "DispatcherConfig",
    "ErrorStrategy",
    # Filters
    "match_all",
    "match_any",
    "negate",
    # Dispatchers
    "AbstractEventDispatcher",
    "BrokeredDispatcher",
    "BufferedAsyncDispatcher",
    "LocalDispatcher",
    # Brokers
    "BaseEventBroker",
    "InProcessBroker",
    "RedisEventBroker",
    # Serialization
    "event_to_json",
    "event_from_json",
    "event_to_dict",
    "event_from_dict",
    # Factory
    "create_dispatcher",
    "list_dispatcher_types",
    "is_dispatcher_available",
    "register_dispatcher",
    # Middleware
    "BaseEventMiddleware",
    "CorrelationMiddleware",
    "DispatchTimingMiddleware",
    "EventGateMiddleware",
    "EventLoggingMiddleware",
    "HandlerRetryMiddleware",
    # Event stores
    "BaseEventStore",
    "InMemoryEventStore",
    "DatabaseEventStore",
    "CacheBackedEventStore",
    # Dead letter
    "DeadLetterRecord",
    "DeadLetterStore",
    # Integrations — logger
    "has_logger_pkg",
    "get_event_logger",
    "event_logging_context",
    "log_event_emitted",
    "log_event_handled",
    "log_handler_error",
    # Integrations — cache
    "has_cache_manager",
    "create_cache_event_store",
    # Integrations — error
    "has_error_handler",
    "failure_to_structured_error",
    "handle_exception_structured",
    "classify_handler_errors",
    # Integrations — job manager
    "has_job_manager",
    "job_event_to_dispatch_event",
    "JobEventForwarder",
    # Integrations — notification
    "has_notification_manager",
    "NotificationRule",
    "EventNotificationBridge",
    "create_notification_bridge",
    # Exceptions
    "EventDispatcherError",
    "EventEmitError",
    "HandlerRegistrationError",
    "HandlerExecutionError",
    "EventStoreError",
    "EventBrokerError",
    "EventSerializationError",
]
