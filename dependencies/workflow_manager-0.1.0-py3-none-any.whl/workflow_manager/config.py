"""WorkflowEngineConfig — runtime configuration for WorkflowEngine.

No external dependencies required.  Config can be supplied as a plain
dict, via environment variables, or loaded from a YAML file.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any


@dataclass
class WorkflowEngineConfig:
    """Declarative configuration for a :class:`~workflow_manager.WorkflowEngine`.

    All fields have sensible defaults so the engine can be constructed
    with zero configuration.

    Parameters
    ----------
    executor:
        Dotted import path or class reference for the executor to use.
        Defaults to ``"workflow_manager.executors.SyncExecutor"``.
    state_store:
        Dotted import path or class reference for the state store.
        Defaults to ``"workflow_manager.state_stores.InMemoryStateStore"``.
    max_step_retries:
        Default number of retry attempts for every step (can be
        overridden by an explicit :class:`~workflow_manager.RetryMiddleware`).
    step_timeout:
        Default step timeout in seconds.  ``None`` disables timeouts.
    middleware:
        List of dotted import paths for middleware to apply globally.
    extras:
        Arbitrary extra key/value pairs forwarded to the engine and
        available via ``StepContext.extras``.
    """

    executor: str = "workflow_manager.executors.SyncExecutor"
    state_store: str = "workflow_manager.state_stores.InMemoryStateStore"
    max_step_retries: int = 0
    step_timeout: float | None = None
    middleware: list[str] = field(default_factory=list)
    extras: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Factory helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowEngineConfig":
        """Build a config from a plain dictionary.

        Unknown keys are collected into ``extras`` rather than raising.

        Example::

            cfg = WorkflowEngineConfig.from_dict({
                "executor": "workflow_manager.executors.AsyncExecutor",
                "max_step_retries": 3,
                "step_timeout": 60,
            })
        """
        known_fields = {
            "executor",
            "state_store",
            "max_step_retries",
            "step_timeout",
            "middleware",
            "extras",
        }
        kwargs: dict[str, Any] = {}
        extras: dict[str, Any] = {}
        for key, value in data.items():
            if key in known_fields:
                kwargs[key] = value
            else:
                extras[key] = value
        if extras:
            kwargs.setdefault("extras", {}).update(extras)
        return cls(**kwargs)

    @classmethod
    def from_env(cls, prefix: str = "WM_") -> "WorkflowEngineConfig":
        """Build a config from environment variables.

        Variable names follow the pattern ``{prefix}{FIELD}`` (upper-case).
        For example, with ``prefix="WM_"``:

        - ``WM_EXECUTOR`` → ``executor``
        - ``WM_STATE_STORE`` → ``state_store``
        - ``WM_MAX_STEP_RETRIES`` → ``max_step_retries`` (int)
        - ``WM_STEP_TIMEOUT`` → ``step_timeout`` (float; empty = None)
        - ``WM_MIDDLEWARE`` → ``middleware`` (comma-separated list)
        """
        def _env(suffix: str, default: Any = None) -> Any:
            return os.environ.get(f"{prefix}{suffix}", default)

        retries_raw = _env("MAX_STEP_RETRIES")
        timeout_raw = _env("STEP_TIMEOUT")
        middleware_raw = _env("MIDDLEWARE", "")

        return cls(
            executor=_env("EXECUTOR", cls.executor),
            state_store=_env("STATE_STORE", cls.state_store),
            max_step_retries=int(retries_raw) if retries_raw is not None else 0,
            step_timeout=float(timeout_raw) if timeout_raw else None,
            middleware=[m.strip() for m in middleware_raw.split(",") if m.strip()],
        )

    @classmethod
    def from_yaml(cls, path: str) -> "WorkflowEngineConfig":
        """Load config from a YAML file.

        Requires PyYAML (``pip install pyyaml``).

        Example YAML::

            executor: workflow_manager.executors.AsyncExecutor
            max_step_retries: 2
            step_timeout: 30
        """
        try:
            import yaml
        except ImportError as exc:
            raise ImportError(
                "PyYAML is required for WorkflowEngineConfig.from_yaml(). "
                "Install with: pip install pyyaml"
            ) from exc

        with open(path) as fh:
            data = yaml.safe_load(fh) or {}
        return cls.from_dict(data)

    # ------------------------------------------------------------------
    # Convenience: instantiate executor / state_store
    # ------------------------------------------------------------------

    def build_executor(self) -> Any:
        """Instantiate and return the configured executor."""
        return _import_dotted(self.executor)()

    def build_state_store(self) -> Any:
        """Instantiate and return the configured state store."""
        return _import_dotted(self.state_store)()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _import_dotted(dotted: str) -> Any:
    """Import a class from a dotted path like ``'package.module.ClassName'``."""
    parts = dotted.rsplit(".", 1)
    if len(parts) != 2:
        raise ImportError(f"Cannot import '{dotted}': expected 'module.ClassName' format.")
    module_path, class_name = parts
    import importlib
    module = importlib.import_module(module_path)
    obj = getattr(module, class_name, None)
    if obj is None:
        raise ImportError(f"'{class_name}' not found in module '{module_path}'.")
    return obj
