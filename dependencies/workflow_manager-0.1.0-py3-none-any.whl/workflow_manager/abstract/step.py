from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ..models import WorkflowRun

if TYPE_CHECKING:
    from .executor import AbstractExecutor


@dataclass
class StepContext:
    run: WorkflowRun
    inputs: dict[str, Any]
    extras: dict[str, Any] = field(default_factory=dict)
    # Injected by the engine so composite steps can dispatch sub-steps.
    executor: "AbstractExecutor | None" = field(default=None, repr=False)

    def step_result(self, name: str) -> Any:
        result = self.run.step_results.get(name)
        if result is None:
            raise KeyError(f"No result recorded for step {name!r}")
        return result.output


class AbstractStep(ABC):
    def __init__(self, name: str) -> None:
        if not name:
            raise ValueError("Step name must be non-empty")
        self.name = name

    @abstractmethod
    def execute(self, context: StepContext) -> Any: ...

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r})"
