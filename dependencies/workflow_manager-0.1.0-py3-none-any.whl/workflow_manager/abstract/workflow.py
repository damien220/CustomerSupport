from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable

from .step import AbstractStep


class AbstractWorkflow(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def steps(self) -> list[AbstractStep]: ...


class WorkflowDefinition(AbstractWorkflow):
    """Declarative, immutable-ish workflow graph built from a list of steps."""

    def __init__(
        self,
        name: str,
        steps: Iterable[AbstractStep] | None = None,
        version: str = "0.1.0",
    ) -> None:
        self._name = name
        self._steps: list[AbstractStep] = list(steps or [])
        self.version = version
        self._validate()

    def _validate(self) -> None:
        seen: set[str] = set()
        for step in self._steps:
            if step.name in seen:
                raise ValueError(f"Duplicate step name: {step.name!r}")
            seen.add(step.name)

    @property
    def name(self) -> str:
        return self._name

    def steps(self) -> list[AbstractStep]:
        return list(self._steps)

    def add(self, step: AbstractStep) -> "WorkflowDefinition":
        if step.name in {s.name for s in self._steps}:
            raise ValueError(f"Duplicate step name: {step.name!r}")
        self._steps.append(step)
        return self
