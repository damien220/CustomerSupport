from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .step import AbstractStep, StepContext


class AbstractExecutor(ABC):
    @abstractmethod
    def execute(self, step: AbstractStep, context: StepContext) -> Any: ...
