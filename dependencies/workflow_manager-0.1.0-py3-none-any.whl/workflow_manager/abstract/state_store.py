from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import WorkflowRun


class AbstractStateStore(ABC):
    @abstractmethod
    def save(self, run: WorkflowRun) -> None: ...

    @abstractmethod
    def load(self, run_id: str) -> WorkflowRun: ...

    @abstractmethod
    def delete(self, run_id: str) -> None: ...

    @abstractmethod
    def list_runs(self) -> list[str]: ...
