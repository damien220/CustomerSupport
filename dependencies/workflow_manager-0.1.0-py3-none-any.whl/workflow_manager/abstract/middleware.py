from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable

from .step import AbstractStep, StepContext

StepCallable = Callable[[AbstractStep, StepContext], Any]


class AbstractMiddleware(ABC):
    @abstractmethod
    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any: ...
