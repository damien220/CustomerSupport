from __future__ import annotations

import copy

from ..abstract.state_store import AbstractStateStore
from ..models import WorkflowRun


class InMemoryStateStore(AbstractStateStore):
    def __init__(self) -> None:
        self._runs: dict[str, WorkflowRun] = {}

    def save(self, run: WorkflowRun) -> None:
        self._runs[run.run_id] = copy.deepcopy(run)

    def load(self, run_id: str) -> WorkflowRun:
        if run_id not in self._runs:
            raise KeyError(f"Run {run_id!r} not found")
        return copy.deepcopy(self._runs[run_id])

    def delete(self, run_id: str) -> None:
        self._runs.pop(run_id, None)

    def list_runs(self) -> list[str]:
        return list(self._runs.keys())
