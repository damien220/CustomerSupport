"""DBStateStore — persists WorkflowRun objects via db_accessor.

Requires: pip install db_accessor (already a core dependency).
"""
from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any

from ..abstract.state_store import AbstractStateStore
from ..models import RunStatus, StepResult, StepStatus, WorkflowRun

_COLLECTION = "workflow_runs"


def _run_to_dict(run: WorkflowRun) -> dict[str, Any]:
    d = asdict(run)
    d["status"] = run.status.value
    d["step_results"] = {
        k: {**v, "status": v["status"]} for k, v in d["step_results"].items()
    }
    return {"run_id": run.run_id, "data": json.dumps(d)}


def _dict_to_run(row: dict[str, Any]) -> WorkflowRun:
    d: dict[str, Any] = json.loads(row["data"])
    d["status"] = RunStatus(d["status"])
    d["step_results"] = {
        k: StepResult(
            step_name=v["step_name"],
            status=StepStatus(v["status"]),
            output=v.get("output"),
            error=v.get("error"),
            started_at=v.get("started_at"),
            finished_at=v.get("finished_at"),
        )
        for k, v in d["step_results"].items()
    }
    return WorkflowRun(**d)


class DBStateStore(AbstractStateStore):
    """Durable state store backed by ``db_accessor``.

    Args:
        db_type: One of ``"sqlite"``, ``"postgres"``, ``"mysql"``, etc.
        connection_params: Dict passed to ``db.connect()``.
    """

    def __init__(self, db_type: str = "sqlite", connection_params: dict | None = None) -> None:
        try:
            from db_accessor import get_database
        except ImportError as exc:
            raise ImportError("db_accessor is required for DBStateStore") from exc

        from db_accessor import get_database  # type: ignore[import]
        self._db = get_database(db_type)
        self._db.connect(connection_params or {"file": ":memory:"})
        # Ensure the runs table exists (SQLite DDL).
        if hasattr(self._db, "execute_script"):
            self._db.execute_script(
                f"CREATE TABLE IF NOT EXISTS {_COLLECTION} "
                "(run_id TEXT PRIMARY KEY, data TEXT NOT NULL);"
            )
            if hasattr(self._db, "connection"):
                self._db.connection.commit()  # type: ignore[attr-defined]

    def save(self, run: WorkflowRun) -> None:
        row = _run_to_dict(run)
        existing = self._db.read(_COLLECTION, {"run_id": run.run_id})
        if existing:
            self._db.update(_COLLECTION, {"run_id": run.run_id}, row)
        else:
            self._db.create(_COLLECTION, row)

    def load(self, run_id: str) -> WorkflowRun:
        rows = self._db.read(_COLLECTION, {"run_id": run_id})
        if not rows:
            raise KeyError(f"Run {run_id!r} not found in DB")
        row = rows[0] if isinstance(rows, list) else rows
        return _dict_to_run(row)

    def delete(self, run_id: str) -> None:
        self._db.delete(_COLLECTION, {"run_id": run_id})

    def list_runs(self) -> list[str]:
        rows = self._db.read(_COLLECTION, {})
        if not rows:
            return []
        if isinstance(rows, list):
            return [r["run_id"] for r in rows]
        return [rows["run_id"]]
