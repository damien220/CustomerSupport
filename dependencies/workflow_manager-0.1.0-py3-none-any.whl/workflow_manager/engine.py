from __future__ import annotations

import time
from typing import Any

from .abstract.executor import AbstractExecutor
from .abstract.middleware import AbstractMiddleware, StepCallable
from .abstract.state_store import AbstractStateStore
from .abstract.step import AbstractStep, StepContext
from .abstract.workflow import AbstractWorkflow
from .executors import SyncExecutor
from .models import RunStatus, StepResult, StepStatus, WorkflowRun
from .state_stores import InMemoryStateStore
from .steps.human import WorkflowHalted


class WorkflowEngine:
    def __init__(
        self,
        executor: AbstractExecutor | None = None,
        state_store: AbstractStateStore | None = None,
        middleware: list[AbstractMiddleware] | None = None,
    ) -> None:
        self.executor = executor or SyncExecutor()
        self.state_store = state_store or InMemoryStateStore()
        self.middleware: list[AbstractMiddleware] = list(middleware or [])

    def run(
        self,
        workflow: AbstractWorkflow,
        inputs: dict[str, Any] | None = None,
    ) -> WorkflowRun:
        run = WorkflowRun(workflow_name=workflow.name, inputs=dict(inputs or {}))
        self.state_store.save(run)
        return self._drive(workflow, run)

    def resume(self, workflow: AbstractWorkflow, run_id: str) -> WorkflowRun:
        run = self.state_store.load(run_id)
        if run.status in (RunStatus.COMPLETED, RunStatus.CANCELLED):
            return run
        return self._drive(workflow, run)

    # ------------------------------------------------------------------
    # Middleware chain
    # ------------------------------------------------------------------

    def _dispatch(self, step: AbstractStep, ctx: StepContext) -> Any:
        """Execute a step through the middleware chain."""
        def base(s: AbstractStep, c: StepContext) -> Any:
            return self.executor.execute(s, c)

        chain: StepCallable = base
        for mw in reversed(self.middleware):
            def _wrap(
                s: AbstractStep,
                c: StepContext,
                _mw: AbstractMiddleware = mw,
                _prev: StepCallable = chain,
            ) -> Any:
                return _mw(s, c, _prev)

            chain = _wrap
        return chain(step, ctx)

    # ------------------------------------------------------------------
    # Drive loop
    # ------------------------------------------------------------------

    def _drive(self, workflow: AbstractWorkflow, run: WorkflowRun) -> WorkflowRun:
        run.status = RunStatus.RUNNING
        self.state_store.save(run)

        last_output: Any = None
        try:
            for step in workflow.steps():
                prior = run.step_results.get(step.name)
                if prior and prior.status == StepStatus.COMPLETED:
                    last_output = prior.output
                    continue

                started = time.time()
                run.record(
                    StepResult(
                        step_name=step.name,
                        status=StepStatus.RUNNING,
                        started_at=started,
                    )
                )
                self.state_store.save(run)

                ctx = StepContext(run=run, inputs=run.inputs, executor=self.executor)
                try:
                    output = self._dispatch(step, ctx)
                except WorkflowHalted:
                    # Suspend the run — can be resumed later.
                    run.record(
                        StepResult(
                            step_name=step.name,
                            status=StepStatus.PENDING,
                            started_at=started,
                            finished_at=time.time(),
                        )
                    )
                    run.status = RunStatus.WAITING
                    self.state_store.save(run)
                    return run
                except Exception as exc:
                    run.record(
                        StepResult(
                            step_name=step.name,
                            status=StepStatus.FAILED,
                            error=f"{type(exc).__name__}: {exc}",
                            started_at=started,
                            finished_at=time.time(),
                        )
                    )
                    run.status = RunStatus.FAILED
                    run.error = f"Step {step.name!r} failed: {exc}"
                    self.state_store.save(run)
                    return run

                run.record(
                    StepResult(
                        step_name=step.name,
                        status=StepStatus.COMPLETED,
                        output=output,
                        started_at=started,
                        finished_at=time.time(),
                    )
                )
                self.state_store.save(run)
                last_output = output

            run.status = RunStatus.COMPLETED
            run.output = last_output
            self.state_store.save(run)
            return run
        except Exception as exc:
            run.status = RunStatus.FAILED
            run.error = f"Engine error: {type(exc).__name__}: {exc}"
            self.state_store.save(run)
            raise
