"""YAML-based workflow loader.

YAML format::

    name: my_workflow
    version: "0.1.0"
    steps:
      - type: function
        name: step1
        callable: mypackage.module.my_function   # must be importable
      - type: decision
        name: route
        predicate: mypackage.module.my_predicate
        branches:
          yes:
            - type: function
              name: handle_yes
              callable: mypackage.module.handle_yes
          no:
            - type: function
              name: handle_no
              callable: mypackage.module.handle_no
      - type: parallel
        name: fan_out
        max_workers: 4
        steps:
          - type: function
            name: task_a
            callable: mypackage.module.task_a
          - type: function
            name: task_b
            callable: mypackage.module.task_b
      - type: loop
        name: poll
        max_iterations: 50
        condition: mypackage.module.keep_polling   # (ctx, i, last) -> bool
        step:
          type: function
          name: poll_once
          callable: mypackage.module.poll_once
      - type: human
        name: approval
"""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

from ..abstract.step import AbstractStep
from ..abstract.workflow import WorkflowDefinition
from ..steps.decision import DecisionStep
from ..steps.function import FunctionStep
from ..steps.human import HumanStep
from ..steps.loop import LoopStep
from ..steps.parallel import ParallelStep


def _import(dotted: str) -> Any:
    module_path, _, attr = dotted.rpartition(".")
    if not module_path:
        raise ImportError(f"Cannot import {dotted!r}: must be module.attribute")
    module = importlib.import_module(module_path)
    return getattr(module, attr)


def _parse_step(spec: dict[str, Any]) -> AbstractStep:
    kind = spec.get("type", "function")
    name = spec["name"]

    if kind == "function":
        fn = _import(spec["callable"])
        return FunctionStep(name, fn)

    if kind == "decision":
        predicate = _import(spec["predicate"])
        branches = {
            key: [_parse_step(s) for s in substeps]
            for key, substeps in spec["branches"].items()
        }
        return DecisionStep(name, predicate, branches)

    if kind == "parallel":
        child_steps = [_parse_step(s) for s in spec["steps"]]
        return ParallelStep(
            name,
            child_steps,
            max_workers=spec.get("max_workers"),
            fail_fast=spec.get("fail_fast", True),
        )

    if kind == "loop":
        condition = _import(spec["condition"])
        child = _parse_step(spec["step"])
        return LoopStep(
            name,
            child,
            condition,
            max_iterations=spec.get("max_iterations", 100),
        )

    if kind == "human":
        return HumanStep(name)

    raise ValueError(f"Unknown step type: {kind!r}")


def load_yaml(source: str | Path) -> WorkflowDefinition:
    """Load a WorkflowDefinition from a YAML file path or YAML string."""
    try:
        import yaml  # PyYAML — optional dep
    except ImportError as exc:
        raise ImportError(
            "PyYAML is required for YAML workflow loading. "
            'Install with: pip install "workflow-manager[yaml]"'
        ) from exc

    path = Path(source) if not isinstance(source, str) or "\n" not in source else None
    if path and path.exists():
        with open(path) as fh:
            data: dict[str, Any] = yaml.safe_load(fh)
    else:
        data = yaml.safe_load(str(source))

    steps = [_parse_step(s) for s in data.get("steps", [])]
    return WorkflowDefinition(
        name=data["name"],
        steps=steps,
        version=data.get("version", "0.1.0"),
    )
