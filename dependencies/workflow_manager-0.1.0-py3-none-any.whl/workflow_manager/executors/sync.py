from __future__ import annotations

from typing import Any

from ..abstract.executor import AbstractExecutor
from ..abstract.step import AbstractStep, StepContext


class SyncExecutor(AbstractExecutor):
    def execute(self, step: AbstractStep, context: StepContext) -> Any:
        return step.execute(context)
