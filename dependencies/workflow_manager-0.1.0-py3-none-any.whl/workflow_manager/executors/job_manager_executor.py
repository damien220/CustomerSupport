"""JobManagerExecutor — runs each step as a job_manager BaseJob.

Requires: pip install "workflow-manager[scheduling]"
"""
from __future__ import annotations

import threading
from typing import Any

from ..abstract.executor import AbstractExecutor
from ..abstract.step import AbstractStep, StepContext


class JobManagerExecutor(AbstractExecutor):
    """Executes workflow steps via job_manager's BackgroundScheduler.

    Each step is wrapped in a ``BaseJob`` and submitted with an
    ``ImmediateTrigger``.  The executor blocks until the job completes
    and returns the step's output, re-raising any exception on failure.

    This makes workflow steps first-class jobs: they inherit retry
    policies, timeout enforcement, and lifecycle events from the
    job_manager ecosystem.

    Parameters
    ----------
    max_workers:
        Thread-pool size for the scheduler's executor.
    timeout:
        Seconds to wait for a job to complete.  ``None`` waits forever.
    tick_interval:
        Scheduler polling interval in seconds (default 0.05 for fast pickup).
    """

    def __init__(
        self,
        max_workers: int = 4,
        timeout: float | None = 30.0,
        tick_interval: float = 0.05,
    ) -> None:
        try:
            import job_manager  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "job_manager is required for JobManagerExecutor. "
                'Install with: pip install "workflow-manager[scheduling]"'
            ) from exc
        self._max_workers = max_workers
        self._timeout = timeout
        self._tick_interval = tick_interval

    def execute(self, step: AbstractStep, context: StepContext) -> Any:
        from job_manager import (
            BackgroundScheduler,
            BaseJob,
            CallbackListener,
            ImmediateTrigger,
            MemoryJobStore,
        )
        from job_manager import ThreadPoolExecutor as JMThreadPool
        from job_manager.config import SchedulerConfig
        from job_manager.events.job_event import EventType
        from job_manager.models import JobContext as JMContext

        done_event = threading.Event()
        result_box: list[Any] = []
        error_box: list[BaseException] = []

        # Inner job — capture output/error into shared boxes via closure.
        class _StepJob(BaseJob):
            def execute(self_job, jm_ctx: JMContext) -> Any:  # noqa: N805
                try:
                    output = step.execute(context)
                    result_box.append(output)
                    return output
                except Exception as exc:
                    error_box.append(exc)
                    raise  # let job_manager record JOB_FAILED

        job = _StepJob(name=f"wm_step_{step.name}")
        store = MemoryJobStore()
        executor = JMThreadPool(max_workers=self._max_workers)
        config = SchedulerConfig(
            tick_interval=self._tick_interval,
            shutdown_timeout=2.0,
        )
        scheduler = BackgroundScheduler(store, executor, config)

        def _on_event(event) -> None:
            if event.job_id == job.job_id and event.event_type in (
                EventType.JOB_SUCCEEDED,
                EventType.JOB_FAILED,
                EventType.JOB_TIMEOUT,
            ):
                done_event.set()

        listener = CallbackListener(
            _on_event,
            event_types={
                EventType.JOB_SUCCEEDED,
                EventType.JOB_FAILED,
                EventType.JOB_TIMEOUT,
            },
        )
        scheduler.add_listener(listener)

        # Add the job before starting so the first tick picks it up.
        scheduler.add_job(job, ImmediateTrigger())
        scheduler.start()

        finished = done_event.wait(timeout=self._timeout)
        scheduler.shutdown(wait=False)

        if not finished:
            raise TimeoutError(
                f"Step '{step.name}' did not complete within {self._timeout}s "
                "when executed via JobManagerExecutor."
            )
        if error_box:
            raise error_box[0]
        return result_box[0] if result_box else None
