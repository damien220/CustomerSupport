from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor as _Pool
from typing import Any

from ..abstract.executor import AbstractExecutor
from ..abstract.step import AbstractStep, StepContext


class ThreadPoolExecutor(AbstractExecutor):
    """Submits each step to a thread pool — useful when steps release the GIL."""

    def __init__(self, max_workers: int = 4) -> None:
        self._pool = _Pool(max_workers=max_workers)

    def execute(self, step: AbstractStep, context: StepContext) -> Any:
        future = self._pool.submit(step.execute, context)
        return future.result()

    def shutdown(self, wait: bool = True) -> None:
        self._pool.shutdown(wait=wait)
