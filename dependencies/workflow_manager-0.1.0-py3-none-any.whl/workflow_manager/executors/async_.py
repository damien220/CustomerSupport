from __future__ import annotations

import asyncio
import inspect
from typing import Any, Coroutine, cast

from ..abstract.executor import AbstractExecutor
from ..abstract.step import AbstractStep, StepContext


class AsyncExecutor(AbstractExecutor):
    """Executor that transparently handles both sync and async step.execute()."""

    def execute(self, step: AbstractStep, context: StepContext) -> Any:
        result = step.execute(context)
        if inspect.isawaitable(result):
            coro: Coroutine[Any, Any, Any] = cast(Coroutine[Any, Any, Any], result)
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                return asyncio.run(coro)  # no running loop — safe to use run()
            # Already inside a running event loop (e.g. during tests).
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            return future.result()
        return result
