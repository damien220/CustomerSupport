"""WorkflowRegistry — register, look up, and optionally discover workflows.

Core registry requires no dependencies.
Plugin discovery requires: pip install "workflow-manager[plugins]"
"""
from __future__ import annotations

from typing import Any

from .abstract.workflow import WorkflowDefinition


class WorkflowRegistry:
    """Registry for :class:`WorkflowDefinition` objects.

    Workflows are keyed by ``(name, version)``.  ``get()`` without a
    version returns the latest registered version for that name.

    Optional plugin discovery (``load_plugins``) scans a directory for
    ``AbstractPlugin`` subclasses that expose a ``workflow`` attribute
    (a :class:`WorkflowDefinition`) and registers them automatically.

    Usage::

        registry = WorkflowRegistry()
        registry.register(my_wf)
        wf = registry.get("my_workflow")          # latest version
        wf = registry.get("my_workflow", "1.0")  # specific version
    """

    def __init__(self) -> None:
        # {name: {version: WorkflowDefinition}}
        self._store: dict[str, dict[str, WorkflowDefinition]] = {}
        # Insertion-order version tracking for "latest" lookup
        self._versions: dict[str, list[str]] = {}

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    def register(self, workflow: WorkflowDefinition) -> None:
        """Register a workflow definition.

        Raises
        ------
        ValueError
            If a workflow with the same name **and** version already exists.
        """
        name = workflow.name
        version = workflow.version or "0.0.0"

        if name in self._store and version in self._store[name]:
            raise ValueError(
                f"Workflow '{name}' version '{version}' is already registered. "
                "Use a different version or call unregister() first."
            )

        self._store.setdefault(name, {})[version] = workflow
        self._versions.setdefault(name, []).append(version)

    def unregister(self, name: str, version: str | None = None) -> None:
        """Remove a workflow.

        If *version* is omitted the entire name entry (all versions) is removed.
        """
        if name not in self._store:
            raise KeyError(f"No workflow named '{name}' is registered.")
        if version is None:
            del self._store[name]
            del self._versions[name]
        else:
            if version not in self._store[name]:
                raise KeyError(
                    f"Workflow '{name}' version '{version}' is not registered."
                )
            del self._store[name][version]
            self._versions[name].remove(version)
            if not self._store[name]:
                del self._store[name]
                del self._versions[name]

    def get(
        self, name: str, version: str | None = None
    ) -> WorkflowDefinition:
        """Retrieve a registered workflow.

        Parameters
        ----------
        name:
            Workflow name.
        version:
            Specific version string.  When omitted the most recently
            registered version is returned.

        Raises
        ------
        KeyError
            If the requested workflow / version is not found.
        """
        if name not in self._store:
            raise KeyError(f"No workflow named '{name}' is registered.")
        versions = self._store[name]
        if version is not None:
            if version not in versions:
                raise KeyError(
                    f"Workflow '{name}' version '{version}' is not registered. "
                    f"Available: {list(versions)}"
                )
            return versions[version]
        # Return the latest (most recently registered) version.
        latest = self._versions[name][-1]
        return versions[latest]

    def list_workflows(self) -> list[dict[str, Any]]:
        """Return a list of dicts describing registered workflows.

        Each dict has keys ``name``, ``version``, and ``steps`` (count).
        """
        result = []
        for name, version_map in self._store.items():
            for version, wf in version_map.items():
                result.append(
                    {
                        "name": name,
                        "version": version,
                        "steps": len(wf.steps()),
                    }
                )
        return result

    def __len__(self) -> int:
        return sum(len(v) for v in self._store.values())

    def __contains__(self, name: str) -> bool:
        return name in self._store

    # ------------------------------------------------------------------
    # Plugin-loader integration (optional)
    # ------------------------------------------------------------------

    def load_plugins(self, directory: str, *, strict: bool = False) -> int:
        """Discover and register workflows from a plugin directory.

        Scans *directory* for Python modules that contain concrete
        ``AbstractPlugin`` subclasses exposing a ``workflow`` attribute
        (a :class:`WorkflowDefinition`).  Each discovered workflow is
        registered automatically.

        Parameters
        ----------
        directory:
            Filesystem path to scan for plugins.
        strict:
            When ``True``, raise ``ImportError`` if ``plugin_loader``
            is unavailable instead of silently returning 0.

        Returns
        -------
        int
            Number of workflows registered from plugins.

        Raises
        ------
        ImportError
            If ``plugin_loader`` is not installed and ``strict=True``.
        """
        try:
            from plugin_loader import (
                DirectoryStrategy,
                PluginManager,
                PluginManagerConfig,
            )
        except ImportError as exc:
            if strict:
                raise ImportError(
                    "plugin_loader is required for WorkflowRegistry.load_plugins(). "
                    'Install with: pip install "workflow-manager[plugins]"'
                ) from exc
            return 0

        config = PluginManagerConfig(strict_validation=False, log_lifecycle=False)
        manager = PluginManager(config)
        manager.add_discovery_strategy(DirectoryStrategy(directory))
        result = manager.discover()

        registered = 0
        for plugin_class in result.discovered:
            wf = getattr(plugin_class, "workflow", None)
            if isinstance(wf, WorkflowDefinition):
                try:
                    self.register(wf)
                    registered += 1
                except ValueError:
                    pass  # already registered — skip duplicate
        return registered
