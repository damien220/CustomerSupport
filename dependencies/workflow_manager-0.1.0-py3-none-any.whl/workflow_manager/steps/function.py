from __future__ import annotations

from typing import Any, Callable

from ..abstract.step import AbstractStep, StepContext


class FunctionStep(AbstractStep):
    def __init__(self, name: str, func: Callable[[StepContext], Any]) -> None:
        super().__init__(name)
        self._func = func

    def execute(self, context: StepContext) -> Any:
        return self._func(context)
