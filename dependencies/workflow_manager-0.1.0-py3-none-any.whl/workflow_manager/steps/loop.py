from __future__ import annotations

from typing import Any, Callable

from ..abstract.step import AbstractStep, StepContext


class LoopStep(AbstractStep):
    """Repeats a single child step until a condition returns False.

    Args:
        name: Step name.
        step: The step to repeat.
        condition: ``(ctx, iteration, last_output) -> bool``
                   Return True to keep looping, False to stop.
        max_iterations: Safety cap (default 100).
    """

    def __init__(
        self,
        name: str,
        step: AbstractStep,
        condition: Callable[[StepContext, int, Any], bool],
        max_iterations: int = 100,
    ) -> None:
        super().__init__(name)
        self.step = step
        self.condition = condition
        self.max_iterations = max_iterations

    def execute(self, ctx: StepContext) -> Any:
        executor = ctx.executor
        last: Any = None
        for i in range(self.max_iterations):
            last = executor.execute(self.step, ctx) if executor else self.step.execute(ctx)
            if not self.condition(ctx, i, last):
                break
        else:
            raise RuntimeError(
                f"LoopStep {self.name!r}: reached max_iterations={self.max_iterations}"
            )
        return last
