"""AgentStep — executes an abstract_agent.AbstractAgent as a workflow step.

Requires: pip install "workflow-manager[agents]"
"""
from __future__ import annotations

import asyncio
import inspect
from typing import Any, Coroutine, cast

from ..abstract.step import AbstractStep, StepContext


class AgentStep(AbstractStep):
    """Delegates execution to an ``AbstractAgent`` instance.

    Args:
        name: Step name.
        agent: An instantiated ``AbstractAgent`` (from ``abstract_agent``).
        input_fn: Optional callable ``(ctx) -> str`` that extracts the agent
                  input from the step context. Defaults to ``ctx.inputs["input"]``.
    """

    def __init__(
        self,
        name: str,
        agent: Any,
        input_fn: Any | None = None,
    ) -> None:
        try:
            from abstract_agent import AbstractAgent  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "abstract_agent is required for AgentStep. "
                'Install with: pip install "workflow-manager[agents]"'
            ) from exc
        super().__init__(name)
        self._agent = agent
        self._input_fn = input_fn or (lambda ctx: ctx.inputs.get("input", ""))

    def execute(self, ctx: StepContext) -> Any:
        agent_input = self._input_fn(ctx)
        result = self._agent.run(agent_input)
        if inspect.isawaitable(result):
            coro: Coroutine[Any, Any, Any] = cast(Coroutine[Any, Any, Any], result)
            try:
                asyncio.get_running_loop()
                # Already inside a running loop — schedule on it from a thread.
                import concurrent.futures
                return concurrent.futures.ThreadPoolExecutor(max_workers=1).submit(
                    asyncio.run, coro
                ).result()
            except RuntimeError:
                return asyncio.run(coro)
        return result
