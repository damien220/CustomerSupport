from __future__ import annotations

from typing import Any, Callable

from ..abstract.step import AbstractStep, StepContext


class DecisionStep(AbstractStep):
    """Evaluates a predicate and executes the matching branch of sub-steps.

    Args:
        name: Step name.
        predicate: ``(ctx) -> str`` — returns the branch key to follow.
        branches: Mapping of branch-key → list of steps to execute.
    """

    def __init__(
        self,
        name: str,
        predicate: Callable[[StepContext], str],
        branches: dict[str, list[AbstractStep]],
    ) -> None:
        super().__init__(name)
        if not branches:
            raise ValueError("DecisionStep requires at least one branch")
        self.predicate = predicate
        self.branches = branches

    def execute(self, ctx: StepContext) -> dict[str, Any]:
        key = self.predicate(ctx)
        steps = self.branches.get(key)
        if steps is None:
            available = list(self.branches.keys())
            raise ValueError(
                f"DecisionStep {self.name!r}: predicate returned {key!r} "
                f"but available branches are {available}"
            )
        executor = ctx.executor
        results: dict[str, Any] = {}
        for step in steps:
            results[step.name] = executor.execute(step, ctx) if executor else step.execute(ctx)
        return results
