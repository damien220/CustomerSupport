"""ToolStep — executes a tool_interface_adapter tool as a workflow step.

Requires: pip install "workflow-manager[tools]"
"""
from __future__ import annotations

import asyncio
from typing import Any, Callable

from ..abstract.step import AbstractStep, StepContext


class ToolStep(AbstractStep):
    """Invokes a ``tool_interface_adapter.AbstractTool`` instance.

    Args:
        name: Step name.
        tool: An instantiated tool (implements ``async execute(params) -> ToolResult``).
        params_fn: Optional ``(ctx) -> dict`` to build tool params from context.
                   Defaults to passing ``ctx.inputs`` directly.
    """

    def __init__(
        self,
        name: str,
        tool: Any,
        params_fn: Callable[[StepContext], dict] | None = None,
    ) -> None:
        try:
            from tool_interface_adapter import AbstractTool  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "tool_interface_adapter is required for ToolStep. "
                'Install with: pip install "workflow-manager[tools]"'
            ) from exc
        super().__init__(name)
        self._tool = tool
        self._params_fn = params_fn or (lambda ctx: dict(ctx.inputs))

    def execute(self, ctx: StepContext) -> Any:
        params = self._params_fn(ctx)

        async def _call() -> Any:
            result = await self._tool.execute(params)
            if not result.success:
                raise RuntimeError(
                    f"Tool {self._tool.spec.name!r} failed: {result.error}"
                )
            return result.data

        try:
            asyncio.get_running_loop()
            # Already inside a running loop — run in an isolated thread.
            import concurrent.futures
            return concurrent.futures.ThreadPoolExecutor(max_workers=1).submit(
                asyncio.run, _call()
            ).result()
        except RuntimeError:
            return asyncio.run(_call())
