from __future__ import annotations

from ..abstract.step import AbstractStep, StepContext


class WorkflowHalted(Exception):
    """Raised by HumanStep to suspend the workflow until an external resume() call."""


class HumanStep(AbstractStep):
    """Suspends the workflow run (status → WAITING) until engine.resume() is called."""

    def execute(self, context: StepContext) -> None:
        raise WorkflowHalted(
            f"Workflow {context.run.workflow_name!r} paused at step {self.name!r}. "
            "Call engine.resume(workflow, run_id) to continue."
        )
