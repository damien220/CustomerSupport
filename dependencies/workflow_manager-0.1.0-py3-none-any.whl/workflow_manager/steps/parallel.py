from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor as _ThreadPool
from typing import Any

from ..abstract.step import AbstractStep, StepContext


class ParallelStep(AbstractStep):
    """Executes multiple child steps concurrently and collects all results.

    Args:
        name: Step name.
        steps: Child steps to run in parallel.
        max_workers: Thread pool size (default: one thread per step).
        fail_fast: If True, any step failure immediately raises.
    """

    def __init__(
        self,
        name: str,
        steps: list[AbstractStep],
        max_workers: int | None = None,
        fail_fast: bool = True,
    ) -> None:
        super().__init__(name)
        if not steps:
            raise ValueError("ParallelStep requires at least one child step")
        self._steps = list(steps)
        self.max_workers = max_workers or len(self._steps)
        self.fail_fast = fail_fast

    def execute(self, ctx: StepContext) -> dict[str, Any]:
        executor = ctx.executor

        def _run(step: AbstractStep) -> Any:
            return executor.execute(step, ctx) if executor else step.execute(ctx)

        with _ThreadPool(max_workers=self.max_workers) as pool:
            futures = {step.name: pool.submit(_run, step) for step in self._steps}

        results: dict[str, Any] = {}
        errors: dict[str, str] = {}
        for step_name, fut in futures.items():
            try:
                results[step_name] = fut.result()
            except Exception as exc:
                errors[step_name] = f"{type(exc).__name__}: {exc}"
                if self.fail_fast:
                    raise RuntimeError(
                        f"ParallelStep {self.name!r}: step {step_name!r} failed: {exc}"
                    ) from exc

        if errors:
            raise RuntimeError(
                f"ParallelStep {self.name!r}: {len(errors)} step(s) failed: {errors}"
            )
        return results
