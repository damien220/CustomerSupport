"""ErrorMiddleware — normalizes step exceptions via error_exception_handler.

Requires: pip install "workflow-manager[errors]"
"""
from __future__ import annotations

from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


class ErrorMiddleware(AbstractMiddleware):
    """Catches any exception, normalizes it through ErrorHandler, then re-raises.

    The original exception is enriched with structured error context, useful
    for consistent error bodies across the workflow execution boundary.
    """

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        try:
            return next_(step, context)
        except Exception as exc:
            try:
                from error_handler import ErrorHandler
                handled = ErrorHandler.handle(exc)
                raise RuntimeError(
                    f"Step {step.name!r} error [{handled.get('status_code', 500)}]: "
                    f"{handled.get('body', {})}"
                ) from exc
            except ImportError:
                raise  # re-raise original if error_handler not installed
