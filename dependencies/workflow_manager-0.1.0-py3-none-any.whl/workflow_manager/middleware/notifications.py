"""NotificationMiddleware — sends alerts on step failure or completion.

Requires: pip install "workflow-manager[notifications]"
"""
from __future__ import annotations

from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


class NotificationMiddleware(AbstractMiddleware):
    """Sends notifications via ``notification_manager.NotificationManager``.

    By default a notification is sent only on step failure.  Set
    ``notify_on_success=True`` to also send on successful completion.

    Parameters
    ----------
    manager:
        A configured ``notification_manager.NotificationManager`` instance.
    recipient_id:
        ID string passed to ``notification_manager.Recipient``.
    channel:
        Optional channel hint (e.g. ``"console"``, ``"email"``).
    notify_on_success:
        Also send a notification when the step completes successfully.
    """

    def __init__(
        self,
        manager: Any,
        recipient_id: str = "workflow-operator",
        channel: str | None = None,
        notify_on_success: bool = False,
    ) -> None:
        try:
            from notification_manager import NotificationManager  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "notification_manager is required for NotificationMiddleware. "
                'Install with: pip install "workflow-manager[notifications]"'
            ) from exc
        self._manager = manager
        self._recipient_id = recipient_id
        self._channel = channel
        self._notify_on_success = notify_on_success

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _send(self, title: str, body: str) -> None:
        """Fire-and-forget notification (swallows delivery errors)."""
        try:
            import asyncio

            from notification_manager.models import Notification, Recipient

            recipient = Recipient(id=self._recipient_id, channels=[self._channel or ""])
            notification = Notification(
                title=title,
                body=body,
                recipient=recipient,
                channel_hint=self._channel,
            )

            # NotificationManager.send() is async — run it safely.
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop is None:
                asyncio.run(self._manager.send(notification))
            else:
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    pool.submit(asyncio.run, self._manager.send(notification)).result(
                        timeout=5
                    )
        except Exception:
            pass  # Never let notifications break execution

    # ------------------------------------------------------------------
    # Middleware protocol
    # ------------------------------------------------------------------

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        run_id = context.run.run_id
        try:
            result = next_(step, context)
        except Exception as exc:
            self._send(
                title=f"[workflow-manager] Step FAILED: {step.name}",
                body=(
                    f"Run: {run_id}\n"
                    f"Workflow: {context.run.workflow_name}\n"
                    f"Error: {exc}"
                ),
            )
            raise

        if self._notify_on_success:
            self._send(
                title=f"[workflow-manager] Step completed: {step.name}",
                body=(
                    f"Run: {run_id}\n"
                    f"Workflow: {context.run.workflow_name}\n"
                    f"Output: {result!r}"
                ),
            )
        return result
