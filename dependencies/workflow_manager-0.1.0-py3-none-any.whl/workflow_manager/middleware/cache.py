"""CacheMiddleware — caches step outputs via cache_manager.

Requires: pip install "workflow-manager[cache]"
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext

_SENTINEL = object()


class CacheMiddleware(AbstractMiddleware):
    """Caches step outputs using a ``cache_manager.AbstractCache`` backend.

    On each step execution the middleware computes a cache key from the
    step name and the workflow run's current inputs.  If a cached value
    exists it is returned immediately without calling the step; otherwise
    the step executes normally and its output is stored.

    Parameters
    ----------
    cache:
        A ``cache_manager.AbstractCache`` instance.  When omitted an
        in-memory cache is created automatically.
    ttl:
        Time-to-live in seconds for cached entries.  ``None`` = no expiry.
    key_prefix:
        String prepended to every cache key (useful to namespace entries
        across multiple workflows sharing the same backend).
    """

    def __init__(
        self,
        cache: Any = None,
        ttl: int | None = None,
        key_prefix: str = "wm",
    ) -> None:
        try:
            from cache_manager import get_cache  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "cache_manager is required for CacheMiddleware. "
                'Install with: pip install "workflow-manager[cache]"'
            ) from exc

        if cache is None:
            from cache_manager import get_cache
            cache = get_cache("memory")
        self._cache = cache
        self._ttl = ttl
        self._key_prefix = key_prefix

    # ------------------------------------------------------------------
    # Key construction
    # ------------------------------------------------------------------

    def _make_key(self, step: AbstractStep, context: StepContext) -> str:
        """Build a stable, content-addressed cache key.

        Key is scoped to ``prefix:workflow_name:step_name:inputs_hash`` so
        the same workflow + step + inputs combination is a cache hit across
        multiple runs (the typical use-case for expensive steps).
        """
        try:
            inputs_hash = hashlib.md5(
                json.dumps(context.run.inputs, sort_keys=True, default=str).encode()
            ).hexdigest()[:8]
        except Exception:
            inputs_hash = "unhashable"
        wf_name = context.run.workflow_name or "wf"
        return f"{self._key_prefix}:{wf_name}:{step.name}:{inputs_hash}"

    # ------------------------------------------------------------------
    # Middleware protocol
    # ------------------------------------------------------------------

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        key = self._make_key(step, context)

        cached = self._cache.get(key, _SENTINEL)
        if cached is not _SENTINEL:
            return cached

        result = next_(step, context)

        try:
            if self._ttl is not None:
                self._cache.set(key, result, ttl=self._ttl)
            else:
                self._cache.set(key, result)
        except Exception:
            pass  # Never let caching break execution

        return result
