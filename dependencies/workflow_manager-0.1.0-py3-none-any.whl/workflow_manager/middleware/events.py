"""EventMiddleware — emits workflow step lifecycle events via event_dispatcher.

Requires: pip install "workflow-manager[events]"
"""
from __future__ import annotations

from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


class EventMiddleware(AbstractMiddleware):
    """Emits ``workflow.step.*`` events via an ``event_dispatcher.AbstractEventDispatcher``.

    Events emitted:
    - ``workflow.step.started``
    - ``workflow.step.completed``
    - ``workflow.step.failed``
    """

    def __init__(self, dispatcher: Any) -> None:
        try:
            from event_dispatcher import AbstractEventDispatcher  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "event_dispatcher is required for EventMiddleware. "
                'Install with: pip install "workflow-manager[events]"'
            ) from exc
        self._dispatcher = dispatcher

    def _emit(self, kind: str, step: AbstractStep, run_id: str, extra: dict | None = None) -> None:
        try:
            from event_dispatcher import EventBuilder
            event = (
                EventBuilder(kind)
                .with_source("workflow_manager")
                .with_payload({"step": step.name, "run_id": run_id, **(extra or {})})
                .build()
            )
            self._dispatcher.emit(event)
        except Exception:
            pass  # Never let observability break execution

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        run_id = context.run.run_id
        self._emit("workflow.step.started", step, run_id)
        try:
            result = next_(step, context)
            self._emit("workflow.step.completed", step, run_id)
            return result
        except Exception as exc:
            self._emit("workflow.step.failed", step, run_id, {"error": str(exc)})
            raise
