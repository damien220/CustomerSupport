from __future__ import annotations

import time
from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


class RetryMiddleware(AbstractMiddleware):
    """Retries a step up to *max_attempts* times on exception.

    Args:
        max_attempts: Total attempts including the first (default 3).
        delay: Seconds to wait between retries (default 0).
        exceptions: Tuple of exception types to catch (default ``Exception``).
    """

    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 0.0,
        exceptions: tuple[type[BaseException], ...] = (Exception,),
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        self.max_attempts = max_attempts
        self.delay = delay
        self.exceptions = exceptions

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        last_exc: BaseException | None = None
        for attempt in range(self.max_attempts):
            try:
                return next_(step, context)
            except self.exceptions as exc:
                last_exc = exc
                if attempt < self.max_attempts - 1 and self.delay > 0:
                    time.sleep(self.delay)
        raise last_exc  # type: ignore[misc]
