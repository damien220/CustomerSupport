from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor as _Pool
from concurrent.futures import TimeoutError as _FutureTimeout
from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


class TimeoutMiddleware(AbstractMiddleware):
    """Raises TimeoutError if a step does not complete within *seconds*.

    Uses a background thread, so it works with both sync and blocking steps.
    """

    def __init__(self, seconds: float) -> None:
        if seconds <= 0:
            raise ValueError("seconds must be > 0")
        self.seconds = seconds

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        with _Pool(max_workers=1) as pool:
            future = pool.submit(next_, step, context)
            try:
                return future.result(timeout=self.seconds)
            except _FutureTimeout as exc:
                raise TimeoutError(
                    f"Step {step.name!r} timed out after {self.seconds}s"
                ) from exc
