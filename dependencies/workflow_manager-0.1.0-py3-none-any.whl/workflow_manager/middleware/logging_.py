"""LoggingMiddleware — structured step logging via logger_pkg.

Requires: pip install "workflow-manager[logging]"
"""
from __future__ import annotations

import logging
from typing import Any

from ..abstract.middleware import AbstractMiddleware, StepCallable
from ..abstract.step import AbstractStep, StepContext


def _get_logger() -> logging.Logger:
    try:
        from logger_pkg import get_logger
        return get_logger("workflow_manager")
    except ImportError:
        return logging.getLogger("workflow_manager")


class LoggingMiddleware(AbstractMiddleware):
    """Logs step start / completion / failure with correlation IDs when logger_pkg is present."""

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._log = logger or _get_logger()

    def __call__(
        self, step: AbstractStep, context: StepContext, next_: StepCallable
    ) -> Any:
        run_id = context.run.run_id
        try:
            from logger_pkg import bind_context, reset_context
            token = bind_context(run_id=run_id, step=step.name)
        except ImportError:
            token = None

        self._log.info("Step starting", extra={"run_id": run_id, "step": step.name})
        try:
            result = next_(step, context)
            self._log.info("Step completed", extra={"run_id": run_id, "step": step.name})
            return result
        except Exception as exc:
            self._log.error(
                "Step failed: %s", exc,
                extra={"run_id": run_id, "step": step.name},
            )
            raise
        finally:
            if token is not None:
                try:
                    from logger_pkg import reset_context
                    reset_context(token)
                except ImportError:
                    pass
